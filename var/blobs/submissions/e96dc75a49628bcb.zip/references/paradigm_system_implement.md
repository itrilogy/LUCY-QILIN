## System Implementation Paradigm (系统实现类范式)

## Structure
1. 引言 (Introduction)
2. 系统需求分析 (Requirements)
3. 系统架构设计 (Architecture)
4. 关键技术实现 (Implementation)
5. 测试与应用验证 (Validation)
6. 结论 (Conclusion)

## Constraints
- **Architecture**: 必须包含逻辑架构图描述，明确模块间的数据流向。
- **Implementation**: 代码逻辑必须以伪代码或结构化文字描述，而非整段搬运源码。
- **Validation**: 必须包含客观的性能指标或功能覆盖率数据。

## Checklist
- [ ] 需求是否可回溯？
- [ ] 架构是否具备扩展性描述？
- [ ] 测试数据是否真实来源于 Fact_Pool？
