# MANIFEST — 论文施工蓝图

> **填写者**: `expert_blueprint_architect` (蓝图架构师)
> **消费者**: `expert_content_generator`, `expert_quality_controller`
> **用途**: 为每一章提供绝对准确的施工图纸，包含约束、引用锚点和 TRIZ 要求。

---

## 蓝图模板

```markdown
# MANIFEST.md — [论文标题] 施工蓝图

> **论文类型**: [project_type]  
> **范式来源**: [对应的 paradigm_*.md 文件]  
> **TRIZ 深度**: [强制 / △可选]

---

## 第 N 章: [章节名称]

### Constraint_Check
- [ ] 检查是否符合 GB 排版第 X 条规定
- [ ] 检查是否通过脱敏红线（rule_Tobacco_Norms.md）
- [ ] [其他本章特定约束]

### Reference_Standard
- 引用必须严格对照 `01_Raw_Data/REFERENCE_REGISTRY.md`，采用 GB/T 7714 顺序编码制。
- 引用角标通过 `00_CITATION_TRACKER.md` 动态分配。

### Data_Anchor (Critical)
| 数据锚点 | 来源文件 | 位置/行号 | 用途 |
|:---|:---|:---|:---|
| [核心数据描述] | Fact_Pool.md | 第 X-Y 行 | [在本章的用途] |
| [仿真数据描述] | Synthetic_Fact_Pool.md | 第 X-Y 行 | [在本章的用途] |

### TRIZ_Requirement
- **适用性**: [是/否 — 根据 §0.2 路由表判定]
- **预留骨架**: 
  - `[TRIZ 物理矛盾识别]` — [具体要分析的矛盾]
  - `[TRIZ 技术矛盾解决路径]` — [要应用的 TRIZ 原理]
- **要求撰写专家**: 使用 [具体 TRIZ 工具名称] 对问题进行深度降维。

### 排版豁免
- [本章的国标豁免项，如: 英文 Abstract 允许第一人称主动语态]

### Chart_Requirement
| 图表ID | 图表类型 | 渲染路线 (MCP优先/Mermaid/VChart-SVG) | 图表描述 | 数据源 | 对应 MANIFEST Data_Anchor |
|:---|:---|:---|:---|:---|:---|
| [如: arch-01] | `flowchart` | MCP 优先 / 降级 Mermaid | 系统总体架构图 | Fact_Pool: 模块清单 | 第 3 章 Data_Anchor |
| [如: kpi-01] | `bar/line` | MCP 优先 / 降级 VChart-SVG | 改善前后 KPI 对比 | Synthetic_Fact_Pool: 仿真结果 | 第 5 章 Data_Anchor |
```

---

> **蓝图纪律**:
> - 每一章必须包含全部 **6 个标签块**（Constraint_Check / Reference_Standard / Data_Anchor / TRIZ_Requirement / 排版豁免 / Chart_Requirement）。
> - Data_Anchor 表禁止为空 — 若本章确实无数据锚点，写明 `> 本章为纯论述章节，无数据锚点。`
> - TRIZ_Requirement 的「适用性」必须与 SKILL.md §0.2 路由表一致。
