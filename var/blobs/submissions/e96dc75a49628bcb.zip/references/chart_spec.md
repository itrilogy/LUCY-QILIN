# Paper-Arts 学术图表与渲染规范 (MCP 优先 + Mermaid / VChart-SVG)

> **用途**: 定义学术论文撰写中的三引擎图表渲染决策、学术排版样式、灰阶打印兼容性及代码块/矢量图嵌入规范。
> **消费者**: `expert_blueprint_architect`（规划图表需求）、`expert_content_generator`（查询 MCP 或降级绘图）、`expert_quality_controller`（图表存在性与规范核验）

---

## 1. 图表渲染路由（MCP 优先 + 双引擎降级）

在生成任意论文插图时，须遵循 `references/unified_file_handling_protocol.md §6`，按以下优先级执行：

### 1.1 Track A：运行期 MCP 四步探测与绘制（第一优先级）
1. **探测工具与路由资源**：通过 **`[MCP_DISCOVER]`** 查看当前环境挂载的绘图 MCP 服务清单及其路由/治理资源（如 `intents` / `governance`）；若 MCP 区分专业领域 CORE 工具与通用救济工具，优先匹配专业工具（如跨部门/业务程序流程优先查专业泳道 `flow` 工具，定量统计优先查专用统计图工具）。
2. **先读完整语法协议**：因工具列表通常只暴露精简简介，**必须先通过该 MCP 自带的协议查询工具或对应 Resource 读取完整 DSL 语法与红线**后再构造入参。
3. **合规传参并重试兜底**：严格按 MCP 规范传参（纯文本 `dsl` 入参时**禁止使用 Markdown 代码围栏**与解释性前后缀，按要求保留文本外壳而不直接传裸 JSON 对象），若返回校验报错可依提示修正重试 1 次。
4. **原样挂载返图**：接收 MCP 返回的 `![图标题](返回的图片地址)` 并原样嵌入正文，不可降级改写为普通超链接。若参数支持配色配置，优先选择灰度/高对比度配色，避免红绿对比失真。

### 1.2 Track B：无匹配 MCP 时的原生降级双引擎（兜底路径）
当运行环境未连接绘图 MCP、不支持所需图种或重试仍失败时，直接切入以下离线双引擎绘制（本节降级语法不可反向混用于 Track A）：

| 图种类别 | 推荐降级引擎 | 适用学术图型 | 交付形态 |
|:---|:---|:---|:---|
| **架构、流程、泳道与关系类** | **Mermaid** | 流程图 (`flowchart`)、跨部门泳道 (`flowchart` subgraphs)、时序图 (`sequenceDiagram`)、状态图 (`stateDiagram-v2`)、类图 (`classDiagram`)、甘特图 (`gantt`)、象限图 (`quadrantChart`)、思维导图 (`mindmap`) | 标准 ```` ```mermaid ```` 代码块 |
| **定量统计与对比分析类** | **VChart——SVG** | 柱状/折线/饼图、箱线图、散点/相关性矩阵、雷达图、热力图、瀑布图、分布直方图等需要精确刻度、误差线与图例的统计图 | `04_Final/charts/<id>.svg` 矢量图 + `![图标题](../04_Final/charts/<id>.svg)`（或 `03_Drafts/` 对应相对路径） |

---

## 2. Track B1：Mermaid 学术图表规范

### 2.1 可用图类型

| 图类型 | Mermaid 关键字 | 论文用途 | 推荐场景 |
|:---|:---:|:---|:---|
| **流程图** | `flowchart` | 系统架构、业务流程、逻辑框架 | 所有论文类型 |
| **时序图** | `sequenceDiagram` | 数据流、交互过程、实验步骤 | `system_implement`, `data_modeling` |
| **状态图** | `stateDiagram-v2` | 系统状态转换、流程阶段 | `system_implement` |
| **类图** | `classDiagram` | 数据结构、模块接口 | `system_implement`, `data_modeling` |
| **甘特图** | `gantt` | 项目计划、实施进度 | `lean_management`, `tech_methodology` |
| **象限图** | `quadrantChart` | 风险评估、对比分析 | `cross_boundary` |
| **饼图** | `pie` | 比例分布（轻量） | `data_modeling` (辅助) |
| **思维导图** | `mindmap` | 鱼骨图、因果分析、概念展开 | `lean_management` |

### 2.2 样式约束与防错细则

每条 Mermaid 代码块前使用配置块设置灰度打印友好样式：

```mermaid
%%{
  init: {
    'theme': 'base',
    'themeVariables': {
      'primaryColor': '#FFFFFF',
      'primaryTextColor': '#000000',
      'lineColor': '#000000',
      'fontSize': '14px'
    }
  }
}%%
```

- **灰度打印兼容**：`theme: 'base'`，配色优先黑白灰，避免仅靠红绿区分数据组。
- **防错规则**：英文节点 ID，禁止中文作节点 ID；标签含空格、逗号或括号时用 `A["文本"]` 双引号包裹；`flowchart` 明确指定方向（`TD`/`LR`/`RL`）。

---

## 3. Track B2：VChart——SVG 学术统计图规范

当环境无可用绘图 MCP 且图种属于定量统计、数值对比、箱线/散点/热力/多维评价时，按以下 VChart 语义与 SVG 规范输出：

1. **VChart 结构映射（若运行端支持 VChart-to-SVG 工具则先构造标准 VChart JSON Spec 导出 `.svg`；完全离线时直接生成自包含标准 `<svg>` 文件）**：
   - 明确声明主标题、坐标轴名称与国标物理量/单位（格式：`量 / 单位`，如 `Time / ms`、`准确率 / %`）。
   - 笛卡尔坐标系图表必须显式包含底部 X 轴与左侧 Y 轴刻度及网格线；分组/对比序列必须配备完整图例 (`legend`)。
   - **双盲学术灰度友好配色**：优先采用纯黑 `#111827`、深灰 `#4b5563`、中灰 `#9ca3af`、浅灰 `#e5e7eb` 配合实线/虚线/点划线或斜线填充纹理区分系列；若期刊/报告允许彩色印刷，可辅助使用低饱和度工业蓝 `#2563eb` 与警示红 `#dc2626`。
2. **SVG 独立文件自包含约束**：
   - 必须包含规范 `xmlns="http://www.w3.org/2000/svg"` 与显式 `viewBox`（如 `viewBox="0 0 800 480"`），字体族指定通用无衬线回退链（`sans-serif`），禁止外链图片或外部 CSS/JS 脚本，确保在任意阅读器中离线直开无乱码。
   - 数值标注、均值±标准差或显著性标记须与 `Fact_Pool.md` / `Synthetic_Fact_Pool.md` 1:1 严格对齐。

---

## 4. 图表嵌入与引用规范（三引擎统一）

### 4.1 正文嵌入形式

无论经由 MCP 返回图片、降级生成 `.svg` 文件还是降级输出 Mermaid 代码块，正文中均须携带统一锚点注释并紧跟 ≥150 字解读：

````markdown
<!-- CHART: sys-arch-01 — 系统总体架构图 -->
```mermaid
flowchart TD
  A["用户层"] --> B["业务服务层"]
  B --> C["数据存储层"]
```
````

或（MCP 返图 / VChart-SVG 矢量图形式）：

```markdown
<!-- CHART: kpi-cmp-01 — 实施前后关键性能对比 -->
![实施前后关键性能对比](../04_Final/charts/kpi-cmp-01.svg)
```

- 注释行 `<!-- CHART: id — 图标题 -->` 供质检专家与 `MANIFEST.md` 的 `Chart_Requirement` 一一交叉核对。
- 每幅图后必须紧跟 **≥150 字**的文字解读（说明结构特征、数值变化规律、与正文的因果印证）。

### 4.2 图表编号规则

正文引用图表遵循规范空格与无点格式：

| 示例 | 判定 | 说明 |
|:---|:---:|:---|
| `如图 1 所示` | ✅ | 中文“图”与阿拉伯数字间留半角空格，后无点 |
| `如图1所示` | ❌ | 缺少半角空格 |
| `图 1. 架构图` | ❌ | 序号后不应加点 |
| `Fig 1 Architecture` | ✅ | 英文 `Fig` 后无点且与数字留空格 |
| `Fig.1` | ❌ | `Fig` 后误加点或缺少空格 |

### 4.3 完整性校验清单

| 规则 | 说明 | 违反后果 |
|:---|:---|:---|
| 每幅图有 `<!-- CHART: id -->` 注释 | 供质检核对 `Chart_Requirement` | 🔴 质检拦截 |
| 每幅图有 ≥150 字文字解读 | 禁止“仅贴图不解读” | 🔴 质检拦截 |
| 本地 `.svg` 或 MCP 图片路径可达 | 若为本地 `.svg` 文件须实际落盘于 `charts/` | 🔴 质检拦截 |
| 标签语言与单位符号合规 | 中文节点+英文 ID，量与单位以 `/` 分隔 | 🟡 WARNING |
