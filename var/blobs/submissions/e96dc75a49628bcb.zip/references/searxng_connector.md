# 学术搜索引擎连接器 (Web Query & 可选 SearXNG 适配器)

> **用途**: 为 `expert_deductive_researcher` 提供外源文献检索协议。
> **默认通道**: 优先调用宿主原生 `[WEB_QUERY]`（`web_search` / `web_fetch`）。
> **可选私有引擎**: 当用户配置了 `SEARXNG_URL`（环境变量或 `00_Meta_Config/00_Project_State.json` 中的 `searxng_url` 字段）时，可启用 SearXNG JSON API。

---

## 1. API 调用格式（仅在已配置 `SEARXNG_URL` 时启用）

### 基础请求

```text
GET ${SEARXNG_URL}/search?format=json&q=<query>&language=zh-CN
```

### 引擎分类路由

通过 `engines` 参数指定搜索范围：

| 引擎组 | 引擎列表 | 用途 |
|:---|:---|:---|
| **学术组** | `semantic+scholar,arxiv,pubmed,google+scholar` | 检索学术论文、技术报告（注意: 部分学术引擎可能无响应，备用降级到通用搜索） |
| **中文组** | `baidu,zhihu,bilibili` | 检索中文行业资料/社区讨论 |
| **通用组** | `google,bing,duckduckgo` | 一般性补充检索 |

**示例** — 查学术论文：
```text
${SEARXNG_URL}/search?format=json&q=OEE+AND+精益&engines=semantic+scholar,arxiv,pubmed,google+scholar&language=zh-CN
```

**示例** — 查中文行业资料：
```text
${SEARXNG_URL}/search?format=json&q=设备管理+快速换型&engines=baidu,zhihu,bilibili&language=zh-CN
```

---

## 2. Query 构造规则

| 操作 | 语法 | 示例 |
|:---|:---|:---|
| AND 连接 | `+` 或 `AND`（大写） | `SMED+AND+OEE` |
| 精确短语 | `" "` 引号包围 | `"快速换牌"` |
| 排除词 | `-` 前缀 | `-proprietary` |
| 年份范围 | 自然语言包含 | `2020..2025` 或 `近3年` |
| 引擎内字段 | 加在 query 后即可 | searXNG 会自动路由字段查询 |

### 学术检索 Query 模板

```
"[核心关键词]" AND "[方法关键词]" AND "[应用场景]"
```

**构建步骤**:
1. 从 Fact_Pool 提取 2-3 个核心业务术语
2. 提取 1-2 个方法论术语（如 SMED、TPM、精益）
3. 组合为 `"业务词A" AND "业务词B" AND "方法论"` 
4. 第一轮用学术组，如果结果 < 3 条 → 放宽到通用组
5. 至多迭代 3 轮，每轮记录搜索词到 SEARCH_LOG.md

---

## 3. 响应解析

searXNG JSON 响应结构：

```json
{
  "query": "原始搜索词",
  "results": [
    {
      "title": "论文标题",
      "url": "https://...",
      "content": "摘要文本...",
      "engine": "google scholar"
    }
  ],
  "unresponsive_engines": ["engine_name"],
  "suggestions": ["推荐词1", "推荐词2"]
}
```

### 字段映射到 REFERENCE_REGISTRY

| JSON 字段 | REFERENCE_REGISTRY 输出 |
|:---|:---|
| `title` | 文献标题（需从 URL 中手动补全作者/期刊） |
| `url` | DOI 或可访问链接 |
| `content` | 核心摘要，格式化后作为"摘要" |
| `engine` | 来源标注 |

> **注意**: searXNG 返回的 `content` 可能仅有简短摘要。作者/期刊/年份等信息需通过 `web_fetch` 进一步获取全文页面元数据。

---

## 4. 集成调用方式

在 `expert_deductive_researcher` 中，按以下优先级路由：

```text
if 未配置 SEARXNG_URL:
    直接使用宿主原生 [WEB_QUERY] 工具（web_search + web_fetch）
elif 搜索目标是学术论文:
    用 [WEB_QUERY] Fetch 调用 ${SEARXNG_URL}/search?format=json&q=<query>&engines=semantic+scholar,arxiv,pubmed,google+scholar
elif 搜索目标是中文行业资料:
    用 [WEB_QUERY] Fetch 调用 ${SEARXNG_URL}/search?format=json&q=<query>&engines=baidu,zhihu,bilibili
else:
    使用宿主原生 [WEB_QUERY] 搜索工具
```

> **安全提示**: searXNG 查询通过 `web_fetch` 发出，响应 JSON 在可见文本限制内截断。建议每轮查询后检查 JSON 中 `results` 数组长度，若不足则迭代调整 query。
