## Technical Methodology Paradigm (技术开发方法论类范式)

## Structure
1. 引言 (Introduction)
2. 理论框架与推演 (Theoretical Framework)
3. 方法论实施路径 (Implementation Path)
4. 实证分析与案例验证 (Case Study)
5. 讨论与对比 (Discussion & Comparison)
6. 结论 (Conclusion)

## Constraints
- **Theoretical Framework**: 必须明确阐述该方法论的底层认知逻辑或维度划分（如轴向演进、认知审计维度），严禁仅停留在操作步骤层面。
- **Case Study**: 必须引用 `Fact_Pool` 中具体的企业应用案例（如某卷烟厂的信息化改造），以证明其可落地性。
- **Discussion**: 必须包含与传统开发范式（如瀑布流或常规敏捷）的对比，论证其效率提升或认知降维的价值。

## Checklist
- [ ] 理论推演是否具备逻辑闭环？
- [ ] 实施路径是否具备可操作性（SOP化）？
- [ ] 对比讨论是否客观公正，未夸大效果？
