# Experiment Storyline — 科研实验剧情

> **填写者**: `expert_deductive_researcher` (推导专家)
> **消费者**: `expert_blueprint_architect`, `expert_content_generator`
> **用途**: 为全篇论文提供统一的科研叙事线，杜绝章节间的逻辑断层和前言不搭后语。

---

## 剧情结构模板

```markdown
## 实验剧情总览

### 阶段 1: 问题锚定 (Problem Anchoring)
- **核心痛点**: [一句话描述]
- **现有方案局限性**: [为什么现有方法不足以解决]
- **物理/业务边界**: [来自 Fact_Pool 的空间、设备、人员等硬约束]

### 阶段 2: 冲突引入 (Conflict Introduction)
- **技术矛盾**: [改善 A 参数 → 恶化 B 参数]
- **物理矛盾**: [同一对象面临相反需求]
- **TRIZ 原理映射**: [应用的具体 TRIZ 原理名称]

### 阶段 3: 方案推进 (Solution Progression)
- **第一轮尝试**: [方案 + 结果 + 暴露的新问题]
- **调整与迭代**: [如何根据反馈修正方案]
- **干扰对抗**: [Confounding Variable 导致的挫折与克服过程]

### 阶段 4: 收敛验证 (Convergence & Validation)
- **最终方案**: [收敛后的完整方案描述]
- **关键性能指标**: [与 Synthetic_Fact_Pool 中锚定的核心数据对应]
- **鲁棒性证明**: [系统在干扰存在时仍能保持的性能水平]
```

---

> **剧情连贯性约束**:
> - 所有实验描述必须死死框在 Fact_Pool 提供的物理与业务边界内。
> - 严禁为了逻辑自洽而科幻式虚构物理条件。
> - 内容需与 Synthetic_Fact_Pool 中的干扰变量和波动描述严格对应。
