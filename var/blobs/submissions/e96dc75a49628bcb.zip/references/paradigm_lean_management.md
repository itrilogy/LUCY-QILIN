## Lean Management Paradigm (管理优化/精益管理类范式)

## Structure
1. 引言 (Introduction)
2. 现状诊断与问题剖析 (Current State Diagnosis)
3. 优化方案设计 (Optimization Strategy)
4. 方案实施与过程控制 (Implementation & Control)
5. 绩效评价与效益分析 (Performance Evaluation)
6. 结论 (Conclusion)

## Constraints
- **Diagnosis**: 必须包含客观的诊断工具应用描述（如：价值流图 VSM、鱼骨图分析、5Whys），问题必须通过定量数据表现（如：流转耗时、不良率）。
- **Strategy**: 提出的优化措施必须与前述诊断出的“真问题”一一对应，形成闭环。
- **Evaluation**: 必须包含改善前后的关键绩效指标 (KPI) 对比，且数据必须来源于 `Fact_Pool`。

## Checklist
- [ ] 问题诊断是否触及根本原因（Root Cause）？
- [ ] 优化措施是否遵循了精益原则（如消除浪费、拉动生产）？
- [ ] 改善前后的数据对比是否具有统计学意义？
