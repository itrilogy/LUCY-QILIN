## Data Analysis & Modeling Paradigm (数据分析及建模类范式)

## Structure
1. 引言 (Introduction)
2. 数据采集与预处理 (Data Preparation)
3. 模型构建与算法选择 (Model Construction)
4. 模型验证与仿真 (Validation & Simulation)
5. 业务洞察与应用策略 (Business Insights)
6. 结论 (Conclusion)

## Constraints
- **Data Preparation**: 必须详细说明数据来源、时间跨度、缺失值/异常值处理规则及特征工程方法。
- **Model Construction**: 若涉及复杂算法（如深度学习、运筹学），必须通过 LaTeX 语法呈现核心公式，并解释变量含义。
- **Validation**: 必须包含模型的精度评价指标（如 RMSE, MAPE, 召回率），并通过交叉验证证明模型的鲁棒性。

## Checklist
- [ ] 数据集描述是否足够详尽以支撑复现？
- [ ] 算法选择的依据是否充分？
- [ ] 业务洞察是否直接基于模型输出得出？
