---
name: paper-arts
version: 4.3.0
description: 面向多 Agent 协同的学术论文辅助撰写系统。统合全量素材摄入、基本演绎法实验推演、行业合规与国标排版蓝图缝合、章节级分段撰写、MCP 优先与 Mermaid/VChart-SVG 双引擎图表渲染及反幻觉双盲审计，支持可配置行业规范插槽与作者署名。
category: paper-writing-cluster
---

[TAG: PAPER_MASTER_ORCHESTRATOR]

# 论文撰写工坊
本集群是一套结构化的学术论文辅助生产流水线。面向高专业度、强规范约束（如国标排版、行业数据脱敏、TRIZ 矛盾建模）的长文本学术论文撰写与审计场景设计。

---

## 0. 快速判断与类型路由 (Quick Router & Type Routing)

### 0.1 场景→指令速查

| 你的场景 | 触发指令 | 预计产出 |
|:---|:---|:---|
| 新课题，有原始素材（PDF/Word/Excel/代码仓库） | `--init --project-type <类型>` → `--run-research` → `--run-write` | 完整论文定稿 |
| 已有 Fact_Pool 和素材，只需研究+撰写 | `--run-research` → `--run-write` | 完整论文定稿 |
| 已有蓝图 MANIFEST.md，只需撰写 | `--run-write` | 论文定稿 |
| 只需质检已有草稿 | 直接唤醒 `quality_controller` | 审计报告 |
| 撰写中途断点，需恢复 | 见 §5 断点续跑协议 | 从断点续写到定稿 |

### 0.2 论文类型路由表

| project_type | 范式文件 | 章节结构 | TRIZ 深度 | 适用场景 |
|:---|:---|:---|:---|:---|
| `lean_management` | `paradigm_lean_management.md` | 引言→现状诊断→优化方案→实施控制→绩效评价→结论 | **强制** 矛盾矩阵+分离原理 | 精益改善/管理优化类课题 |
| `system_implement` | `paradigm_system_implement.md` | 引言→需求分析→架构设计→关键技术→测试验证→结论 | △可选 资源分析 | 信息系统/平台开发类课题 |
| `data_modeling` | `paradigm_data_modeling.md` | 引言→数据预处理→模型构建→验证仿真→业务洞察→结论 | △可选 | 数据分析/算法建模类课题 |
| `tech_methodology` | `paradigm_tech_methodology.md` | 引言→理论框架→实施路径→案例分析→讨论对比→结论 | **强制** 40发明原理+IFR | 技术方法论/开发范式类课题 |
| `cross_boundary` | `paradigm_cross_boundary.md` | 引言→跨界背景→模式架构→支撑体系→风险评估→结论 | **强制** 九屏幕法+40原理 | 跨界融合/商业模式创新类课题 |

> **TRIZ 深度说明**: 「强制」= 蓝图架构师**必须**在 MANIFEST 中预留 TRIZ 骨架，质检专家**必须**校验骨架填充；「△可选」= 由蓝图架构师根据素材复杂度自主决定。

---

## 1. 核心参考文件与 Agent→阶段映射

本集群所有规则与专家灵魂已实行单点物理锁定，严禁运行时动态覆盖：

| 文件路径 | 职责/属性 | 活跃阶段 |
|:---|:---|:---|
| `references/rule_GB_Layout.md` | 【法典】全局排版与 GB/T 7714 参考文献约束 | ALL |
| `references/rule_Tobacco_Norms.md` | 【法典】行业敏感性脱敏红线与精益学术张力 | BLUEPRINT, AUDIT |
| `references/rule_TRIZ_Innovation.md` | 【法典】TRIZ 创新方法论 + 范式→TRIZ 映射表 | BLUEPRINT, AUDIT |
| `references/paradigm_cross_boundary.md` | 【范式】跨界业务生产模式创新类 | BLUEPRINT |
| `references/paradigm_data_modeling.md` | 【范式】数据分析及建模类 | BLUEPRINT |
| `references/paradigm_lean_management.md` | 【范式】管理优化/精益管理类 | BLUEPRINT |
| `references/paradigm_system_implement.md` | 【范式】系统实现类 | BLUEPRINT |
| `references/paradigm_tech_methodology.md` | 【范式】技术开发方法论类 | BLUEPRINT |
| `references/searxng_connector.md` | 【连接器】searXNG 引擎路由与 API 调用规范 | RESEARCH |
| `references/chart_spec.md` | 【图表】学术图表渲染规范（MCP 优先 + Mermaid / VChart-SVG 降级） | BLUEPRINT, WRITE, AUDIT |
| `references/template_Synthetic_Fact_Pool.md` | 【模板】仿真数据池字段 Schema | RESEARCH |
| `references/template_Experiment_Storyline.md` | 【模板】实验剧情结构 Schema | RESEARCH, BLUEPRINT |
| `references/template_MANIFEST.md` | 【模板】蓝图施工图纸 Schema | BLUEPRINT |
| `references/expert_infrastructure.md` | 【Agent】基建专家 — 全量素材摄入与微观细节索引 | INIT |
| `references/expert_deductive_researcher.md` | 【Agent】推导专家 — 外源检索与高保真数据倒推 | RESEARCH |
| `references/expert_blueprint_architect.md` | 【Agent】蓝图架构师 — 范式与双层约束缝合为施工清单 | BLUEPRINT |
| `references/expert_content_generator.md` | 【Agent】生成专家 — 深层回溯与原子化撰写 | WRITE, REWRITE |
| `references/expert_quality_controller.md` | 【Agent】质检专家 — 反幻觉审计与终末排版对齐 | AUDIT |
| `references/unified_file_handling_protocol.md` | 【协议】统一文件处理规范（异构降维提取、安全追加、版本保护） | ALL |
| `scripts/init_paper_scaffold.py` | 【脚本】脚手架初始化与素材相对路径保真搬运（支持 `--author-name` 与 `--industry-profile` 配置） | INIT |
| `scripts/extract_pdf.py` | 【脚本】统一异构文档格式降维提取引擎（支持 `.txt/.md/.csv/.docx/.xlsx/.pdf`，零第三方强依赖） | INIT, RESEARCH |
| `scripts/doc_append_helper.py` | 【脚本】统一长文本与增量账本安全追加器（防命令行转义截断） | WRITE, AUDIT |

> **阶段缩写**: INIT = 环境基建 | RESEARCH = 外源检索与数据倒推 | BLUEPRINT = 蓝图架构与合规缝合 | WRITE = 原子化章节撰写 | REWRITE = 质检打回靶向重写 | AUDIT = 双盲审计与终末排版 | ALL = 全阶段适用

---

## 2. 宏观运行时状态机 (Macro State Machine)

作为主控编排器，必须依靠以下指令序列严格控制论文生产的时序：

### `--init` (环境基建模式)

- **前置检查**: 若用户提供了 `--project-type`，校验其属于 5 种标准类型之一。若未提供，提示用户选择（见 §0.2 路由表）。
- **动作**: 执行 `python3 "${SKILL_ROOT}/scripts/init_paper_scaffold.py" --source-dir [源路径] --project-type [类型]`。
- **效用**: 部署从 `00_Meta_Config` 到 `04_Final` 的数据瀑布流目录，全量无损搬运用户素材至 `01_Raw_Data`。`00_Project_State.json` 将记录论文类型。

### `--run-research` (研究与蓝图模式)

- **前置检查**: 确认 `00_Project_State.json` 中 `project_type` 已分配（非"待分配"）。
- **路由**: 唤醒 `infrastructure` → `deductive_researcher` → `blueprint_architect`。
- **效用**: 生成深层细节索引、倒推生成 `Synthetic_Fact_Pool` 仿真实验数据（按 `template_Synthetic_Fact_Pool.md` Schema 填写）、演绎实验剧情（按 `template_Experiment_Storyline.md` Schema），蓝图架构师按 `project_type` 精确加载范式并缝合双层约束，最终落盘为强约束的 `MANIFEST.md` 蓝图图纸（按 `template_MANIFEST.md` Schema）。
- **TRIZ 骨架**: 蓝图架构师须根据 §0.2 路由表的 TRIZ 深度，在 MANIFEST 中预留或不预留 TRIZ 相关章节骨架。

### `--run-write` (撰写与质检模式)

- **前置检查**: 确认 `02_Blueprint/MANIFEST.md` 存在且非空。
- **路由**: 唤醒 `content_generator` → `quality_controller`。
- **效用**: 在后台执行原子化的逐章撰写与回溯（详见 §3.5 分段挂起法则），随后启动双盲与防幻觉终末审计，输出 `04_Final/COMPLIANCE_AUDIT_REPORT.md` 与定稿。
- **质检自动闭环 (Critical)**: 当质检专家输出审计报告后，主控编排器**必须**读取该报告。若报告中存在"标红拦截"或"格式不合规"等致命错误，绝不能判定流程结束，须重新委派 `expert_content_generator`，将审计报告的错误点作为指令输入，要求其对违规段落进行靶向重写（使用 `[FILE_EDIT]` 工具进行局部精确替换，而非整章重写），直到质检专家审核通过方可交付定稿。

---

## 3. 上下文隔离与子智能体委派机制 (Agent-Delegation Protocol)

学术论文的篇幅与规范约束较多，容易超出单次对话的上下文有效注意力窗口。作为主控编排器，应避免在单次主干上下文中直接拼接全量长文：

1. **子智能体委派 (Critical)**: 利用当前宿主运行平台支持的**子智能体委派/工作流调用功能（Sub-Agent / Delegation Tool）**将各阶段任务解耦执行。具体平台适配方案见 `platform/` 目录。
2. **委派指令范式**: 将具体任务及对应的专家规则路径（如 `${SKILL_ROOT}/references/expert_content_generator.md`）作为指令发给执行层子节点，同时传入当前项目的 `${PROJECT_ROOT}`（即 `--work-dir` 指向的目录）以便子节点定位数据文件。
3. **状态收敛法则**: 子节点完成文件 I/O 落盘后，主控编排器仅接收浓缩摘要与落盘确认。
4. **安全追加纪律 (Critical)**: 在向 `00_Meta_Config/00_PAPER_PROGRESS.md` 或 `00_CITATION_TRACKER.md` 追加记录时，**禁止**使用覆写操作（会抹除历史记录），统一遵循 `references/unified_file_handling_protocol.md` 执行“先写临时文件，再调用 `doc_append_helper.py --mode a` 追加”。
5. **章节级分段挂起与上下文清理法则 (Critical)**: **禁止在单轮对话内让子智能体一次性生成整篇长论文**。
   - 委派 `content_generator` 时，必须以**章节**（如"第二章：现状诊断与问题剖析"）为原子单位下发任务。
   - 每当子节点写完一章并落盘后，挂起状态机并向用户声明："**[流程挂起] 第 X 章已落盘，已记录入 00_PAPER_PROGRESS.md，请指示是否继续执行下一章。**"通过分轮交互隔离前序章节累积的上下文，确保每一章的生成质量与约束遵循度。

---

## 4. 集群三大核心信仰 (Core Philosophies)

- **基本演绎法拟撰**: 论文要有事实。若原生事实不足，允许进行高保真的数据倒推，但**必须通过显著性检验 (P<0.05 等倒算)**，严防低级逻辑漏洞。
- **微观细节回溯**: 拒绝空洞的套写。正文扩写必须基于 `DEEP_INDEX_SUMMARY.md` 的路由，使用 `[FILE_READ]` 跨区调取原始文件的核心段落进行还原。
- **双盲与反幻觉红线**: 在定稿（04_Final）前，必须通过质检专家的双重核实：1. 剥离所有未脱敏的涉密机构名；2. 所有结论主张必须能对应到 `Fact_Pool` 或 `Synthetic_Fact_Pool` 中，超越此二者边界的断言视为严重幻觉，必须标红拦截。

---

## 5. 断点续跑协议 (Checkpoint & Resume Protocol)

论文撰写是长链路多轮对话过程。当中断发生时，按以下步骤恢复：

### 5.1 断点定位

读取 `00_Meta_Config/00_PAPER_PROGRESS.md` 的「章节级撰写进度」表，确定最后完成的章节序号。

### 5.2 恢复策略

| 中断位置 | 恢复指令 | 操作 |
|:---|:---|:---|
| 基建未完成 | `--init` | 脚手架幂等重建（已存在文件不覆写） |
| 研究/蓝图未完成 | `--run-research` | 各 Agent 检查自身产出物是否存在，存在则跳过 |
| 第 N 章撰写中 | `--run-write` | 从第 N 章继续委派 content_generator |
| 质检未完成 | 直接唤醒 `quality_controller` | 质检专家读取 `03_Drafts/` 现有草稿执行审计 |

### 5.3 恢复时的必要检查

1. **读取 `00_Project_State.json`** 确认 `project_type` 和 `progress_phase`。
2. **读取 `00_PAPER_PROGRESS.md`** 确认最新进度行。
3. **不得重新初始化** — `--init` 仅在首次使用或显式要求时执行。
4. **向用户确认**: "检测到断点在[阶段名称]，最后完成的是[具体产出物]。是否从此处继续？"

---
**系统标识**: 论文撰写工坊 (Paper-Arts)
