import os
import shutil
import argparse
import json

# === 结构化资产模板 (Embedded Schemas) ===

SYNTHETIC_FACT_POOL_TEMPLATE = """# Synthetic Fact Pool — 高保真仿真数据池

> **填写者**: `expert_deductive_researcher` (推导专家)
> **消费者**: `expert_blueprint_architect`, `expert_content_generator`, `expert_quality_controller`
> **Schema 约束**: 每一条仿真数据记录必须包含以下全部字段，不可缺省。

---

## 记录模板

### [实验名称/场景标签]

| 字段 | 内容 |
|:---|:---|
| **实验组** | [组名/条件描述] |
| **对照组 (Baseline)** | [基准方法/空白对照] |
| **核心指标** | [指标名称，如: 分拣准确率 / 响应延迟 / 吞吐量] |
| **实验组结果** | [均值 ± 标准差] |
| **对照组结果** | [均值 ± 标准差] |
| **改善幅度** | [相对提升/降低百分比] |
| **P 值** | [显著性检验结果，必须 < 0.05] |
| **干扰变量 (Confounding Variable)** | [至少 1 个合理的客观干扰因素，如: 网络延迟突发 / 原材料批次不稳 / 人工误操作] |
| **干扰导致的波动描述** | [在实验数据中呈现的真实波动、局部异常或失败毛刺] |
| **鲁棒性说明** | [系统如何通过优化机制克服干扰] |
| **锚定来源** | [指向 Fact_Pool.md 中原始事实的具体行号或段落] |

---

> **红色底线**: 
> - 绝对禁止平铺直叙生成"完美达成目标"的平滑数据。
> - 每条仿真记录必须包含至少 1 个干扰变量及对应的波动描述。
> - P 值必须进行倒算验证，确保逻辑严密。
"""

EXPERIMENT_STORYLINE_TEMPLATE = """# Experiment Storyline — 科研实验剧情

> **填写者**: `expert_deductive_researcher` (推导专家)
> **消费者**: `expert_blueprint_architect`, `expert_content_generator`
> **用途**: 为全篇论文提供统一的科研叙事线，杜绝章节间的逻辑断层和前言不搭后语。

---

## 剧情结构模板

### 阶段 1: 问题锚定 (Problem Anchoring)
- **核心痛点**: [一句话描述]
- **现有方案局限性**: [为什么现有方法不足以解决]
- **物理/业务边界**: [来自 Fact_Pool 的空间、设备、人员等硬约束]

### 阶段 2: 冲突引入 (Conflict Introduction)
- **技术矛盾**: [改善 A 参数 → 恶化 B 参数]
- **物理矛盾**: [同一对象面临相反需求]
- **TRIZ 原理映射**: [应用的具体 TRIZ 原理名称]

### 阶段 3: 方案推进 (Solution Progression)
- **第一轮尝试**: [方案 + 结果 + 暴露的新问题]
- **调整与迭代**: [如何根据反馈修正方案]
- **干扰对抗**: [Confounding Variable 导致的挫折与克服过程]

### 阶段 4: 收敛验证 (Convergence & Validation)
- **最终方案**: [收敛后的完整方案描述]
- **关键性能指标**: [与 Synthetic_Fact_Pool 中锚定的核心数据对应]
- **鲁棒性证明**: [系统在干扰存在时仍能保持的性能水平]

---

> **剧情连贯性约束**:
> - 所有实验描述必须死死框在 Fact_Pool 提供的物理与业务边界内。
> - 严禁为了逻辑自洽而科幻式虚构物理条件。
> - 内容需与 Synthetic_Fact_Pool 中的干扰变量和波动描述严格对应。
"""

MANIFEST_TEMPLATE = """# MANIFEST — 论文施工蓝图

> **填写者**: `expert_blueprint_architect` (蓝图架构师)
> **消费者**: `expert_content_generator`, `expert_quality_controller`
> **用途**: 为每一章提供绝对准确的施工图纸，包含约束、引用锚点和 TRIZ 要求。

---

## 蓝图模板

## 第 N 章: [章节名称]

### Constraint_Check
- [ ] 检查是否符合 GB 排版第 X 条规定
- [ ] 检查是否通过脱敏红线（rule_Tobacco_Norms.md）
- [ ] [其他本章特定约束]

### Reference_Standard
- 引用必须严格对照 `01_Raw_Data/REFERENCE_REGISTRY.md`，采用 GB/T 7714 顺序编码制。
- 引用角标通过 `00_CITATION_TRACKER.md` 动态分配。

### Data_Anchor (Critical)
| 数据锚点 | 来源文件 | 位置/行号 | 用途 |
|:---|:---|:---|:---|
| [核心数据描述] | Fact_Pool.md | 第 X-Y 行 | [在本章的用途] |
| [仿真数据描述] | Synthetic_Fact_Pool.md | 第 X-Y 行 | [在本章的用途] |

### TRIZ_Requirement
- **适用性**: [是/否 — 根据 SKILL.md §0.2 路由表判定]
- **预留骨架**: 
  - `[TRIZ 物理矛盾识别]` — [具体要分析的矛盾]
  - `[TRIZ 技术矛盾解决路径]` — [要应用的 TRIZ 原理]
- **要求撰写专家**: 使用 [具体 TRIZ 工具名称] 对问题进行深度降维。

### 排版豁免
- [本章的国标豁免项，如: 英文 Abstract 允许第一人称主动语态]

### Chart_Requirement
| 图表ID | 图表类型 | 渲染路线 (MCP优先/Mermaid/VChart-SVG) | 图表描述 | 数据源 | 对应 MANIFEST Data_Anchor |
|:---|:---|:---|:---|:---|:---|
| [如: arch-01] | `flowchart` | MCP 优先 / 降级 Mermaid | 系统总体架构图 | Fact_Pool: 模块清单 | 第 3 章 Data_Anchor |
| [如: kpi-01] | `bar/line` | MCP 优先 / 降级 VChart-SVG | 改善前后 KPI 对比 | Synthetic_Fact_Pool: 仿真结果 | 第 5 章 Data_Anchor |

---

> **蓝图纪律**:
> - 每一章必须包含全部 **6 个标签块**（Constraint_Check / Reference_Standard / Data_Anchor / TRIZ_Requirement / 排版豁免 / Chart_Requirement）。
> - Data_Anchor 表禁止为空 — 若本章确实无数据锚点，写明 `> 本章为纯论述章节，无数据锚点。`
> - TRIZ_Requirement 的「适用性」必须与 SKILL.md §0.2 路由表一致。
"""

# === 论文类型→章节名称映射表 ===

CHAPTER_NAMES_BY_TYPE = {
    "lean_management": [
        "引言", "现状诊断与问题剖析", "优化方案设计",
        "方案实施与过程控制", "绩效评价与效益分析", "结论"
    ],
    "system_implement": [
        "引言", "系统需求分析", "系统架构设计",
        "关键技术实现", "测试与应用验证", "结论"
    ],
    "data_modeling": [
        "引言", "数据采集与预处理", "模型构建与算法选择",
        "模型验证与仿真", "业务洞察与应用策略", "结论"
    ],
    "tech_methodology": [
        "引言", "理论框架与推演", "方法论实施路径",
        "实证分析与案例验证", "讨论与对比", "结论"
    ],
    "cross_boundary": [
        "引言", "跨界融合背景与动因", "创新模式架构与核心逻辑",
        "支撑体系与落地路径", "风险评估与应对策略", "结论与展望"
    ],
}

def init_paper_scaffold(work_dir, source_dir=None, project_type=None, author_name=None, industry_profile="tobacco_lean"):
    """
    初始化学术论文自动化撰写的全生命周期物理脚手架
    """
    print("🚀 Paper-Arts - 学术论文脚手架初始化")
    
    base_path = os.path.abspath(work_dir)
    print(f"📁 项目基准路径: {base_path}\n")

    # 定义标准的五大生命周期目录
    directories = [
        "00_Meta_Config",
        "01_Raw_Data",
        "02_Blueprint",
        "03_Drafts",
        "04_Final",
        "04_Final/charts"
    ]

    for d in directories:
        os.makedirs(os.path.join(base_path, d), exist_ok=True)

    # 1. 00_Meta_Config: 生成物理状态机与终端反馈账本
    state_file = os.path.join(base_path, "00_Meta_Config", "00_Project_State.json")
    if not os.path.exists(state_file):
        VALID_TYPES = ["cross_boundary", "data_modeling", "lean_management", "system_implement", "tech_methodology"]
        initial_state = {
            "project_name": "待分配",
            "project_type": project_type if project_type in VALID_TYPES else "待分配",
            "author_name": author_name if author_name else "可配置署名",
            "industry_rule_slot": industry_profile,
            "progress_phase": "INIT",
            "last_updated": "待更新"
        }
        if project_type and project_type not in VALID_TYPES:
            print(f"⚠️ 警告: project_type '{project_type}' 不在标准类型列表中 {VALID_TYPES}，已回退为 '待分配'")
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(initial_state, f, ensure_ascii=False, indent=4)
            
    progress_file = os.path.join(base_path, "00_Meta_Config", "00_PAPER_PROGRESS.md")
    if not os.path.exists(progress_file):
        with open(progress_file, 'w', encoding='utf-8') as f:
            f.write("# 学术论文撰写进度总账\n\n")
            f.write("| 阶段 | 状态 | 核心产出物 | 检查时间 |\n")
            f.write("| :--- | :--- | :--- | :--- |\n")
            f.write("| 01. 素材摄入与基建 | 待启动 | `DEEP_INDEX_SUMMARY.md` | - |\n")
            f.write("| 02. 外源检索与倒推 | 待启动 | `Synthetic_Fact_Pool.md` | - |\n")
            f.write("| 03. 蓝图架构与合规 | 待启动 | `MANIFEST.md` | - |\n")
            f.write("| 04. 原子化正文生成 | 待启动 | `03_Drafts/*.md` | - |\n")
            f.write("| 05. 双盲审计与排版 | 待启动 | `FINAL_PAPER_SUBMISSION.md` | - |\n")
            f.write("\n## 章节级撰写进度\n\n")
            f.write("| 章序号 | 章节名称 | 状态 | 版本号 | 落盘时间 | 质检状态 |\n")
            f.write("| :--- | :--- | :--- | :--- | :--- | :--- |\n")
            # 根据 project_type 动态填充章节名
            valid_types = ["lean_management", "system_implement", "data_modeling",
                           "tech_methodology", "cross_boundary"]
            if project_type in valid_types:
                names = ["中英文摘要与关键词"] + CHAPTER_NAMES_BY_TYPE[project_type]
            else:
                names = ["中英文摘要与关键词", "引言", "第1章(待定)", "第2章(待定)",
                         "第3章(待定)", "第4章(待定)", "结论"]
            for idx, name in enumerate(names):
                f.write(f"| {idx:02d} | {name} | 待撰写 | — | — | — |\n")
            f.write("\n> **更新纪律**: 每章落盘后，由主控编排器调用 `doc_append_helper.py` 追加一行状态更新记录（不覆写原表，追加变更日志）。\n")

    citation_file = os.path.join(base_path, "00_Meta_Config", "00_CITATION_TRACKER.md")
    if not os.path.exists(citation_file):
        with open(citation_file, 'w', encoding='utf-8') as f:
            f.write("## 参考文献 (References)\n\n")
            f.write("> 本清单由生成专家动态维护，质检专家将在最后定稿时将其拼接入文末。\n\n")

    # 2. 01_Raw_Data: 初始化高保真核心资产（含结构化 Schema 模板）
    raw_assets = [
        "Fact_Pool.md",
        "SEARCH_LOG.md",
        "REFERENCE_REGISTRY.md",
        "DEEP_INDEX_SUMMARY.md"
    ]
    for asset in raw_assets:
        asset_path = os.path.join(base_path, "01_Raw_Data", asset)
        if not os.path.exists(asset_path):
            with open(asset_path, 'w', encoding='utf-8') as f:
                f.write(f"# {asset.replace('.md', '')}\n\n> 物理占位符，等待专家写入。\n")

    # Synthetic_Fact_Pool.md — 使用结构化 Schema 模板
    synth_path = os.path.join(base_path, "01_Raw_Data", "Synthetic_Fact_Pool.md")
    if not os.path.exists(synth_path):
        with open(synth_path, 'w', encoding='utf-8') as f:
            f.write(SYNTHETIC_FACT_POOL_TEMPLATE)

    # 3. 02_Blueprint: 初始化蓝图资产（含结构化 Schema 模板）
    os.makedirs(os.path.join(base_path, "02_Blueprint"), exist_ok=True)
    
    traceback_schema = (
        "# Traceback Log — 章节回溯源记录\n\n"
        "> **填写者**: `expert_content_generator` (生成专家)\n"
        "> **用途**: 记录每章撰写过程中执行「深层回溯」的具体位置，供质检专家核验数据真实性。\n\n"
        "| 章序号 | 章节名称 | 回溯原文路径 | 回溯行号 | 还原摘要 |\n"
        "|:---|:---|:---|:---|:---|\n"
        "| — | — | — | — | — |\n"
    )
    blueprint_assets = {
        "Experiment_Storyline.md": EXPERIMENT_STORYLINE_TEMPLATE,
        "MANIFEST.md": MANIFEST_TEMPLATE,
        "Traceback_Log.md": traceback_schema
    }
    for name, template in blueprint_assets.items():
        asset_path = os.path.join(base_path, "02_Blueprint", name)
        if not os.path.exists(asset_path):
            with open(asset_path, 'w', encoding='utf-8') as f:
                f.write(template)

    # 4. 执行全量无损素材搬运 (如果提供了 source_dir)
    # 采用保留源目录相对层级树 (Relative Path Tree) 的防御性复制法，防止同名文件扁平化覆盖
    if source_dir:
        if not os.path.exists(source_dir):
            print(f"⚠️ 警告: 素材源目录不存在: {source_dir}")
        else:
            print(f"📥 开始物理全量搬运学术素材: {source_dir} -> 01_Raw_Data/")
            count = 0
            for root, _, files in os.walk(source_dir):
                for file in files:
                    if file.startswith('.') or file == 'Thumbs.db':
                        continue
                    
                    src_file = os.path.join(root, file)
                    # 计算相对路径，保留深层目录结构
                    rel_path = os.path.relpath(src_file, source_dir)
                    target_full_path = os.path.join(base_path, "01_Raw_Data", rel_path)
                    
                    # 确保目标文件夹存在
                    os.makedirs(os.path.dirname(target_full_path), exist_ok=True)
                    shutil.copy2(src_file, target_full_path)
                    count += 1
            print(f"✅ 全量导入完成，共搬运 {count} 个物理文件，目录树层级已 100% 保真。")

    print("\n✅ Paper-Arts 脚手架部署完成。")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Paper-Arts 学术论文脚手架引擎")
    parser.add_argument("--work-dir", default=".", help="目标工作区路径")
    parser.add_argument("--source-dir", default=None, help="原始素材的物理来源目录")
    parser.add_argument("--project-type", default=None, 
                        choices=["cross_boundary", "data_modeling", "lean_management", "system_implement", "tech_methodology"],
                        help="论文类型: cross_boundary(跨界创新) | data_modeling(数据分析) | lean_management(精益管理) | system_implement(系统实现) | tech_methodology(技术方法论)")
    parser.add_argument("--author-name", default=None, help="论文作者或团队署名（可配置）")
    parser.add_argument("--industry-profile", default="tobacco_lean", help="行业规范插槽配置（默认: tobacco_lean 烟草与精益管理规范）")
    args = parser.parse_args()
    
    init_paper_scaffold(args.work_dir, args.source_dir, args.project_type, args.author_name, args.industry_profile)