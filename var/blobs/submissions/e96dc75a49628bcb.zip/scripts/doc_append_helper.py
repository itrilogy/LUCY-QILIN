#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一长文本与增量池安全追加器 (Unified Safe Document Appender - Stdlib Only)
解决大模型在命令行直接拼接超长文本或特殊字符（LaTeX/代码块/中文标点）时的转义截断与覆写风险。
"""

import argparse
import os


def safe_append(source_file: str, target_file: str, mode: str = "a") -> bool:
    if not os.path.exists(source_file):
        print(f"❌ 错误: 临时源文件不存在 {source_file}")
        return False

    try:
        with open(source_file, "r", encoding="utf-8", errors="replace") as sf:
            content = sf.read()

        os.makedirs(os.path.dirname(os.path.abspath(target_file)), exist_ok=True)

        with open(target_file, mode, encoding="utf-8", errors="replace") as tf:
            if mode == "a" and os.path.getsize(target_file) > 0:
                tf.write("\n\n")
            tf.write(content)

        action_str = "覆盖写入" if mode == "w" else "安全追加"
        print(f"✅ 已将 {len(content)} 字符{action_str}至 {target_file}")
        return True
    except Exception as e:
        print(f"❌ 写入发生异常: {e}")
        return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="统一长文档与增量池安全追加器")
    parser.add_argument("--source", required=True, help="已写入的临时源文件路径 (如 temp_chunk.md)")
    parser.add_argument("--target", required=True, help="目标文件路径")
    parser.add_argument("--mode", default="a", choices=["a", "w"], help="a=追加(默认), w=覆盖初始化")
    args = parser.parse_args()
    safe_append(args.source, args.target, args.mode)
