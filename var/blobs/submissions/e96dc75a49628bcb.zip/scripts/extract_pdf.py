#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
统一异构文档格式降维提取引擎 (Unified Document Extraction Engine - Stdlib Only)
支持将 .txt / .md / .csv / .docx / .xlsx / .pdf 统一提取为结构化 Markdown 纯文本。
遵循零第三方库强依赖原则：
- .txt / .md / .csv / .docx / .xlsx 均基于 Python 标准库 (zipfile, xml.etree.ElementTree, csv) 原生解析。
- .pdf 采用多级探测降级：依次尝试已安装的 pypdf / pdfminer / fitz，若均不可用则调用系统 pdftotext 命令，绝不因缺包崩溃。
"""

import argparse
import csv
import datetime
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

EXTENSION_MAP = {
    ".txt": "text",
    ".md": "text",
    ".json": "text",
    ".yaml": "text",
    ".yml": "text",
    ".py": "text",
    ".csv": "csv",
    ".docx": "docx",
    ".doc": "docx",
    ".xlsx": "xlsx",
    ".xls": "xlsx",
    ".pdf": "pdf",
}


def detect_file_type(filepath: str) -> str:
    """通过扩展名与文件头 Magic Bytes 识别文件类型"""
    ext = os.path.splitext(filepath)[1].lower()
    candidate = EXTENSION_MAP.get(ext, "unknown")

    if candidate == "pdf":
        with open(filepath, "rb") as f:
            header = f.read(5)
        return "pdf" if header == b"%PDF-" else "text"

    if candidate in ("docx", "xlsx"):
        with open(filepath, "rb") as f:
            header = f.read(4)
        if header == b"PK\x03\x04":
            return candidate
        return "text"

    return candidate


def extract_text(filepath: str) -> str:
    """读取纯文本文件"""
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def extract_csv(filepath: str, max_rows: int = 200) -> str:
    """将 CSV 转换为 Markdown 表格"""
    rows = []
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        for idx, row in enumerate(reader):
            if idx >= max_rows:
                break
            rows.append([cell.replace("|", "\\|").replace("\n", " ").strip() for cell in row])

    if not rows:
        return "*(空 CSV 文件)*"

    col_count = max(len(r) for r in rows)
    padded_rows = [r + [""] * (col_count - len(r)) for r in rows]

    lines = [
        "| " + " | ".join(padded_rows[0]) + " |",
        "| " + " | ".join(["---"] * col_count) + " |",
    ]
    for r in padded_rows[1:]:
        lines.append("| " + " | ".join(r) + " |")
    return "\n".join(lines)


def extract_docx(filepath: str) -> str:
    """
    基于 Python 标准库 (zipfile + xml.etree.ElementTree) 提取 .docx 段落与表格。
    不依赖 python-docx。
    """
    w_ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    try:
        with zipfile.ZipFile(filepath, "r") as z:
            if "word/document.xml" not in z.namelist():
                return f"⚠️ 无法解析 {os.path.basename(filepath)}：缺少 word/document.xml（可能为旧版二进制 .doc 格式，请另存为 .docx）"

            xml_content = z.read("word/document.xml")
            root = ET.fromstring(xml_content)
            body = root.find(f"{w_ns}body")
            if body is None:
                body = root

            blocks = []
            for child in body:
                if child.tag == f"{w_ns}p":
                    texts = [t.text for t in child.iter(f"{w_ns}t") if t.text]
                    para_text = "".join(texts).strip()
                    if para_text:
                        blocks.append(para_text)
                elif child.tag == f"{w_ns}tbl":
                    table_rows = []
                    for tr in child.findall(f"{w_ns}tr"):
                        row_cells = []
                        for tc in tr.findall(f"{w_ns}tc"):
                            cell_texts = [t.text for t in tc.iter(f"{w_ns}t") if t.text]
                            cell_str = "".join(cell_texts).replace("|", "\\|").replace("\n", " ").strip()
                            row_cells.append(cell_str)
                        if any(row_cells):
                            table_rows.append(row_cells)
                    if table_rows:
                        col_count = max(len(r) for r in table_rows)
                        padded = [r + [""] * (col_count - len(r)) for r in table_rows]
                        md_tbl = [
                            "| " + " | ".join(padded[0]) + " |",
                            "| " + " | ".join(["---"] * col_count) + " |",
                        ]
                        for r in padded[1:]:
                            md_tbl.append("| " + " | ".join(r) + " |")
                        blocks.append("\n".join(md_tbl))

            return "\n\n".join(blocks) if blocks else "*(.docx 文件无可见文本内容)*"
    except Exception as e:
        return f"⚠️ 解析 .docx 失败: {e}"


def _col_letters_to_index(col_str: str) -> int:
    """将 Excel 列字母 (A, B, ..., AA) 转为 0-based 索引"""
    idx = 0
    for ch in col_str:
        if "A" <= ch <= "Z":
            idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return max(idx - 1, 0)


def extract_xlsx(filepath: str, max_rows: int = 100) -> str:
    """
    基于 Python 标准库 (zipfile + xml.etree.ElementTree) 原生提取 .xlsx 工作簿。
    支持读取所有 Sheet 名称、共享字符串表 (sharedStrings.xml) 及单元格数据，无需 openpyxl。
    """
    main_ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    rel_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    try:
        with zipfile.ZipFile(filepath, "r") as z:
            names = set(z.namelist())
            if "xl/workbook.xml" not in names:
                return f"⚠️ 无法解析 {os.path.basename(filepath)}：不是有效的 .xlsx 容器"

            # 1. 读取 sharedStrings.xml
            shared_strings = []
            if "xl/sharedStrings.xml" in names:
                ss_root = ET.fromstring(z.read("xl/sharedStrings.xml"))
                for si in ss_root.findall(f"{main_ns}si"):
                    texts = [t.text for t in si.iter(f"{main_ns}t") if t.text]
                    shared_strings.append("".join(texts))

            # 2. 读取 workbook.xml.rels 建立 rId -> target 映射
            rid_to_target = {}
            rels_path = "xl/_rels/workbook.xml.rels"
            if rels_path in names:
                rels_root = ET.fromstring(z.read(rels_path))
                for rel in rels_root:
                    r_id = rel.attrib.get("Id")
                    target = rel.attrib.get("Target", "")
                    if r_id and target:
                        target = target.lstrip("/")
                        if not target.startswith("xl/"):
                            target = "xl/" + target
                        rid_to_target[r_id] = target

            # 3. 读取 workbook.xml 中的工作表列表
            wb_root = ET.fromstring(z.read("xl/workbook.xml"))
            sheets_info = []
            for idx, sheet_elem in enumerate(wb_root.iter(f"{main_ns}sheet"), start=1):
                s_name = sheet_elem.attrib.get("name", f"Sheet{idx}")
                r_id = sheet_elem.attrib.get(f"{rel_ns}id", "")
                target = rid_to_target.get(r_id, f"xl/worksheets/sheet{idx}.xml")
                sheets_info.append((s_name, target))

            output_sections = [
                f"**工作表清单 (Sheets)**: {', '.join(s[0] for s in sheets_info)}"
            ]

            for s_name, target in sheets_info:
                if target not in names:
                    continue
                ws_root = ET.fromstring(z.read(target))
                rows_data = []
                for row_idx, row_elem in enumerate(ws_root.iter(f"{main_ns}row")):
                    if row_idx >= max_rows:
                        break
                    row_dict = {}
                    max_col = -1
                    for c_elem in row_elem.findall(f"{main_ns}c"):
                        ref = c_elem.attrib.get("r", "")
                        col_letters = "".join(ch for ch in ref if ch.isalpha())
                        col_idx = _col_letters_to_index(col_letters) if col_letters else (max_col + 1)
                        max_col = max(max_col, col_idx)

                        c_type = c_elem.attrib.get("t", "")
                        v_elem = c_elem.find(f"{main_ns}v")
                        is_elem = c_elem.find(f"{main_ns}is")

                        val = ""
                        if c_type == "s" and v_elem is not None and v_elem.text is not None:
                            try:
                                s_idx = int(v_elem.text)
                                val = shared_strings[s_idx] if 0 <= s_idx < len(shared_strings) else v_elem.text
                            except ValueError:
                                val = v_elem.text
                        elif c_type == "inlineStr" and is_elem is not None:
                            val = "".join(t.text for t in is_elem.iter(f"{main_ns}t") if t.text)
                        elif v_elem is not None and v_elem.text is not None:
                            val = v_elem.text

                        row_dict[col_idx] = str(val).replace("|", "\\|").replace("\n", " ").strip()

                    if max_col >= 0:
                        row_list = [row_dict.get(i, "") for i in range(max_col + 1)]
                        if any(row_list):
                            rows_data.append(row_list)

                output_sections.append(f"### Sheet: {s_name}")
                if not rows_data:
                    output_sections.append("*(空工作表)*")
                    continue

                col_count = max(len(r) for r in rows_data)
                padded = [r + [""] * (col_count - len(r)) for r in rows_data]
                md_tbl = [
                    "| " + " | ".join(padded[0]) + " |",
                    "| " + " | ".join(["---"] * col_count) + " |",
                ]
                for r in padded[1:]:
                    md_tbl.append("| " + " | ".join(r) + " |")
                output_sections.append("\n".join(md_tbl))

            return "\n\n".join(output_sections)
    except Exception as e:
        return f"⚠️ 解析 .xlsx 失败: {e}"


def extract_pdf(filepath: str) -> str:
    """
    多级探测降级提取 PDF：
    1. 尝试 pypdf / PyPDF2
    2. 尝试 pdfminer.high_level
    3. 尝试 PyMuPDF (fitz)
    4. 尝试系统命令 pdftotext (poppler)
    5. 返回标准化降级指引
    """
    # 1. 尝试 pypdf
    for mod_name in ("pypdf", "PyPDF2"):
        try:
            mod = __import__(mod_name)
            reader = mod.PdfReader(filepath)
            pages = [page.extract_text() or "" for page in reader.pages]
            text = "\n\n".join(p.strip() for p in pages if p.strip())
            if text:
                return text
        except Exception:
            pass

    # 2. 尝试 pdfminer
    try:
        from pdfminer.high_level import extract_text as pm_extract_text
        text = pm_extract_text(filepath)
        if text and text.strip():
            return text.strip()
    except Exception:
        pass

    # 3. 尝试 fitz (PyMuPDF)
    try:
        import fitz
        doc = fitz.open(filepath)
        pages = [page.get_text("text") for page in doc]
        doc.close()
        text = "\n\n".join(p.strip() for p in pages if p.strip())
        if text:
            return text
    except Exception:
        pass

    # 4. 尝试系统命令 pdftotext
    try:
        res = subprocess.run(
            ["pdftotext", filepath, "-"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if res.returncode == 0 and res.stdout.strip():
            return res.stdout.strip()
    except Exception:
        pass

    return (
        f"⚠️ 检测到 PDF 文件: {os.path.basename(filepath)}\n\n"
        f"当前运行环境未安装 PDF 提取组件（pypdf / pdfminer / pdftotext）。\n"
        f"请安装系统工具 `pdftotext`（macOS: `brew install poppler`；Ubuntu/Debian: `sudo apt install poppler-utils`），"
        f"或将该文件导出为 `.docx` / `.txt` / `.md` 后放入素材目录。\n"
    )


def extract(filepath: str, output_path: str = None) -> str:
    """统一提取单文件入口"""
    if not os.path.exists(filepath):
        return f"❌ 错误: 文件不存在 {filepath}"

    file_type = detect_file_type(filepath)
    extractors = {
        "text": extract_text,
        "csv": extract_csv,
        "docx": extract_docx,
        "xlsx": extract_xlsx,
        "pdf": extract_pdf,
    }

    extractor = extractors.get(file_type)
    if extractor is None:
        return f"⚠️ 跳过不支持的格式: {os.path.basename(filepath)} (检测类型: {file_type})"

    content = extractor(filepath)
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    wrapped = (
        f"---\n"
        f"> 源文件: `{os.path.basename(filepath)}`\n"
        f"> 格式类型: `{file_type}`\n"
        f"> 提取时间: {now_str}\n"
        f"> 提取引擎: Unified Stdlib Document Extractor\n"
        f"---\n\n"
        f"{content}\n"
    )

    if output_path:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(wrapped)

    return wrapped


def main():
    parser = argparse.ArgumentParser(
        description="统一异构文档格式降维提取引擎 (.txt/.md/.csv/.docx/.xlsx/.pdf -> Markdown)"
    )
    parser.add_argument("input", nargs="?", help="源文件路径（位置参数）")
    parser.add_argument("--pdf-file", "-f", default=None, help="单个文件路径（兼容旧版参数）")
    parser.add_argument("--input-dir", "-d", default=None, help="批量提取目录路径")
    parser.add_argument("--output", "-o", default=None, help="单文件输出路径")
    parser.add_argument("--output-dir", default=None, help="批量提取输出目录")
    args = parser.parse_args()

    target_file = args.input or args.pdf_file
    if target_file:
        out_path = args.output
        if not out_path and args.output_dir:
            stem = os.path.splitext(os.path.basename(target_file))[0]
            out_path = os.path.join(args.output_dir, f"{stem}_extracted.md")
        result = extract(target_file, out_path)
        if not out_path:
            print(result)
        else:
            print(f"✅ 已提取至: {out_path}")
    elif args.input_dir:
        if not os.path.isdir(args.input_dir):
            print(f"❌ 目录不存在: {args.input_dir}", file=sys.stderr)
            sys.exit(1)
        out_dir = args.output_dir or os.path.join(args.input_dir, "_extracted")
        os.makedirs(out_dir, exist_ok=True)
        count = 0
        for root, _, files in os.walk(args.input_dir):
            if "_extracted" in root:
                continue
            for file in sorted(files):
                if file.startswith("."):
                    continue
                ext = os.path.splitext(file)[1].lower()
                if ext in EXTENSION_MAP:
                    src = os.path.join(root, file)
                    rel = os.path.relpath(src, args.input_dir)
                    safe_name = rel.replace(os.sep, "__") + ".md"
                    dst = os.path.join(out_dir, safe_name)
                    extract(src, dst)
                    count += 1
        print(f"✅ 批量提取完成，共转换 {count} 个文件至: {out_dir}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
