# 知林 · ZhiLin

> 百知成林，一图见著

知林把栖林知识包读进 DSH：左侧栏出现「知识库」，主区打开阅读器，能按关键字和标签查笔记，也能看两张图——包内链接图、元数据/标签图。

## 用它做什么

- **读**：打开知识包，从入口篇开始；`[[篇名]]` 点击跳转，`[[篇名#标题]]` 跳到目标标题；官方 markdown-it 渲染 Markdown，Mermaid 图直接渲染。
- **搜**：输入关键字回车；下拉可选「全部 / 摘要 / 标题 / 标签」。默认搜当前包，勾选「全库」搜所有包。
- **按标签筛**：左栏四个分面（主题/实体/方法/来源），点选是交集过滤。
- **看图**：链接图看引用关系，可滚轮缩放/拖拽平移；元数据图看笔记为什么聚在一起，图工具栏可调字号。右侧栏可切「信息 / 文件」，「文件」是按编号分段的包内文件列表。
- **入库**：点「入库」，填知识包目录；知林会校验入口、复制到知识根、更新索引。

## 知识包放在哪

按以下顺序找：

1. 插件配置的 `roots`；
2. 环境变量 `QILIN_KNOWLEDGE_ROOT`；
3. 默认 `~/.qilin/knowledge`。

知识根是用户级目录，不跟随会话工作目录；同一台机器上的所有 DSH 会话看到同一批包。首次安装不弹窗，默认 `~/.qilin/knowledge`；空态显示实际路径，可用环境变量或插件配置改。

## 入库约定

商店安装计划在 `kind=knowledge` 时会带 `post_install.op=knowledge_intake`。如果本机装了知林，agent 可以调用 `knowledge_intake`（或加载 `zhilin-intake` 技能）完成入库；没有插件时保持目录形态，知林下次扫描仍能读到。

入库只复制、不移动源目录；重复调用是幂等的；目标已存在且清单不同会拒绝覆盖。

## 给 agent 的检索

知林不只是给人看的页面；它给 agent 一套对象级检索工具：

- `knowledge_overview`：有多少包、多少笔记/链接/标签，形态/密级/业务线怎么分布；
- `knowledge_package`：一个包的画像 + 每篇的一句话摘要；
- `knowledge_search`：对象级检索，支持 `tag:`/`type:`/`status:`/`security:`/`package:`、引号短语、`-排除`，`field=summary` 只搜摘要；
- `knowledge_brief`：对 1–5 篇取结构化 brief；`knowledge_related` / `knowledge_path` 做多步扩散；
- `knowledge_tags` / `knowledge_metadata`：标签共现与元数据映射。

设计原则是“先确定对象，再取上下文”，不是把全文倒给模型。完整设计见 `docs/RETRIEVAL.md`。

## 边界

- 只读：v0.1 不修改笔记。
- 只面向知识包：题头、闭合链接、受控标签是前提；不是任意 Obsidian 库浏览器。
- `security_level` 是声明，不是访问控制；界面只做显示/过滤。
- 跨包链接被知识包协议禁止，所以没有全库链接大图；两张图都按包画。

## 验证状态

- Host 解析/索引/搜索/入库：Node 测试通过。
- Client 面板与双图：静态语法检查通过；尚未在 DSH 页面做视觉验收。
- 栖林侧 `knowledge-intake` 规范与 `post_install` 提示：Python 测试通过。

顶栏「关于」可看版本、本地渲染栈（Mermaid 11.17.2 / markdown-it 15.0.3）、许可与第三方声明。

完整设计见 `docs/DESIGN.md`，可行性见 `docs/FEASIBILITY.md`。
