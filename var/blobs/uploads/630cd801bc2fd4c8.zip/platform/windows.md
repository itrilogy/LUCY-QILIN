# Windows 适配说明

本技能在 Windows 上可用，但有三处与 macOS/Linux 不同。

## 1. 依赖安装

```powershell
# officecli（任选其一）
irm https://d.officecli.ai/install.ps1 | iex
# 或从 GitHub Releases 下载 zip，解压后把目录加入 PATH

# python3
winget install Python.Python.3.12
```

装完**重开终端**，确认：

```powershell
officecli --version
python3 --version
```

## 2. 字体

Windows 没有 PingFang SC。`md_compile.py` 默认按平台选字体（`--font auto`）：
Windows 用 **Microsoft YaHei（微软雅黑）**，macOS 用 PingFang SC。

交付前在 PowerPoint 里确认无缺字、无回退到宋体。

## 3. 脚本与路径

- 只用 `python3 scripts/*.py`；**不要**用 `morph-helpers.sh`（bash 版，Windows 需 Git Bash/WSL，不建议）。
- 路径含空格时用引号；`officecli` 的 `/slide[N]` 路径在 PowerShell 里用单引号：`'/slide[1]'`。
- `officecli open/close` 的驻留语义一致：改完必须 `close` 再渲染或交付。

## 4. 已知差异

| 项 | Windows | macOS/Linux |
|---|---|---|
| 字体 | Microsoft YaHei | PingFang SC |
| 安装脚本 | install.ps1 | install.sh |
| bash 助手 | 不建议（用 python 版） | 可用 |
| 渲染校验 | PowerPoint 本机 | LibreOffice / officecli |
