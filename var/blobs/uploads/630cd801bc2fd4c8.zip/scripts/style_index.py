#!/usr/bin/env python3
"""style_index.py —— 由磁盘上的风格目录生成/校验 INDEX.md。

- 目录是唯一事实来源：新增目录会出现，删掉的目录会从表里消失；
- 保留人工维护的 "Best For" 文案（按目录名匹配旧表）；
- 主色（bg/fg/accent）优先从 build.sh 的十六进制变量提取，其次 style.md 的色板表；
- `--check` 只校验不改写，供 CI / selfcheck 使用。

用法：
  python3 scripts/style_index.py --write     # 重建 INDEX.md
  python3 scripts/style_index.py --check     # 校验是否过期（0=一致）
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STYLES = ROOT / "references" / "styles"
INDEX = STYLES / "INDEX.md"

PREFIX_TITLES = {
    "dark": "Dark Palette (dark)",
    "light": "Light Palette (light)",
    "warm": "Warm Palette (warm)",
    "vivid": "Vivid Palette (vivid)",
    "bw": "Black & White (bw)",
    "mixed": "Mixed / Brand Systems (mixed)",
}
ORDER = ["dark", "light", "warm", "vivid", "bw", "mixed"]

HEX = re.compile(r"^[A-Z][A-Z0-9_]*\s*=\s*([0-9A-Fa-f]{6})\s*$", re.M)


def read_paragraph(text: str, label: str) -> str:
    match = re.search(rf"-\s*\*\*{label}\*\*:\s*(.+)", text)
    return match.group(1).strip() if match else ""


def name_of(directory: Path) -> str:
    style = directory / "style.md"
    if not style.is_file():
        return directory.name
    first = style.read_text(encoding="utf-8", errors="ignore").splitlines()[0]
    title = first.lstrip("# ").strip()
    return title.split("—")[0].strip() or directory.name


def hexes_of(directory: Path) -> str:
    build = directory / "build.sh"
    palette: list[str] = []
    if build.is_file():
        for value in HEX.findall(build.read_text(encoding="utf-8", errors="ignore")):
            up = value.upper()
            if up not in palette:
                palette.append(up)
    if len(palette) < 3:
        style = directory / "style.md"
        if style.is_file():
            for value in re.findall(r"\|\s*[^|\n]+\s*\|\s*([0-9A-Fa-f]{6})\s*\|", style.read_text(encoding="utf-8", errors="ignore")):
                up = value.upper()
                if up not in palette:
                    palette.append(up)
    return " / ".join(f"#{c}" for c in palette[:3]) if palette else "-"


def parse_existing(text: str) -> dict[str, dict[str, str]]:
    """从旧表保留人工文案（Best For / Mood），以便重建时不丢创作内容。"""
    rows: dict[str, dict[str, str]] = {}
    for line in text.splitlines():
        if not line.startswith("|") or line.startswith("|---") or "Directory" in line:
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) < 5 or not cells[0] or "--" not in cells[0]:
            continue
        if re.fullmatch(r"-+", cells[0]):
            continue
        rows[cells[0]] = {"name": cells[1], "hexes": cells[2].strip("`"), "best_for": cells[3], "mood": cells[4]}
    return rows


def collect() -> tuple[dict[str, list[tuple[str, str, str, str, str]]], list[str]]:
    existing = parse_existing(INDEX.read_text(encoding="utf-8")) if INDEX.is_file() else {}
    groups: dict[str, list[tuple[str, str, str, str, str]]] = {}
    dirs = sorted(d for d in STYLES.iterdir() if d.is_dir() and not d.name.startswith("."))
    for directory in dirs:
        prefix = directory.name.split("--")[0]
        if prefix not in PREFIX_TITLES:
            prefix = "mixed"
        style = directory / "style.md"
        text = style.read_text(encoding="utf-8", errors="ignore") if style.is_file() else ""
        old = existing.get(directory.name, {})
        best_for = old.get("best_for") or read_paragraph(text, "Scene") or "-"
        mood = old.get("mood") or read_paragraph(text, "Mood") or "-"
        hexes = hexes_of(directory)
        if hexes == "-" and old.get("hexes"):
            hexes = old["hexes"]
        groups.setdefault(prefix, []).append((directory.name, name_of(directory), hexes, best_for, mood))
    leftover = sorted(set(existing) - {d.name for d in dirs})
    return groups, leftover


def render(groups: dict[str, list[tuple[str, str, str, str, str]]], leftover: list[str]) -> str:
    total = sum(len(items) for items in groups.values())
    lines = [
        "# Style Index",
        "",
        "> **本文件由 `scripts/style_index.py` 从磁盘目录生成，不要手改。**",
        "> 改风格：增删 `references/styles/<dir>/`，再跑 `python3 scripts/style_index.py --write`。",
        "",
        f"共 **{total}** 套（磁盘目录数）。Agent 先按本节表格用主色/场景初筛，再读 `<目录>/style.md`；",
        "`build.sh` 只作实现技巧参考，**不要照抄坐标**（存在文字压叠等历史问题），版式底线见 `references/rules.md`。",
        "",
        "主色列从 `build.sh` 的十六进制变量提取，缺失时退回 `style.md` 色板；`-` 表示没有可提取的主色。",
        "",
    ]
    if leftover:
        lines += [
            "**旧索引残留（磁盘无目录，已剔除）**：" + "、".join(f"`{name}`" for name in leftover),
            "",
        ]
    for prefix in ORDER + sorted(set(groups) - set(ORDER)):
        items = groups.get(prefix)
        if not items:
            continue
        lines += [
            f"## {PREFIX_TITLES.get(prefix, prefix)}",
            "",
            "| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |",
            "| --- | --- | --- | --- | --- |",
        ]
        for name, title, hexes, best_for, mood in items:
            lines.append(f"| {name} | {title} | `{hexes}` | {best_for} | {mood} |")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    groups, leftover = collect()
    generated = render(groups, leftover)
    if args.check:
        current = INDEX.read_text(encoding="utf-8") if INDEX.is_file() else ""
        if current != generated:
            print("INDEX.md 与磁盘不一致，请运行 python3 scripts/style_index.py --write")
            return 1
        print("INDEX.md 与磁盘一致")
        return 0
    if args.write or not args.check:
        INDEX.write_text(generated, encoding="utf-8")
        print(f"已生成 INDEX.md：{sum(len(v) for v in groups.values())} 套，剔除残留 {len(leftover)} 条")
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
