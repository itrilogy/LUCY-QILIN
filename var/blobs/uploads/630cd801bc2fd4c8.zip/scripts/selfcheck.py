#!/usr/bin/env python3
"""slide-master 运行级自检（回归 smoke）。

按三条制作路线端到端验证 officecli 命令与共享脚本可用性：
  A. pptx-base  中文内容 + $ 单引号转义 + speaker notes + validate + issues=0
  B. pitch-deck 中文表 table data= + chart axismin=0
  C. morph-ppt  helpers clone → ghost(content) → verify → final-check
  D. morph-ppt-3d 前置探测（本地 .glb；缺失则 SKIP，非失败）

用法：python3 scripts/selfcheck.py
前置：officecli 在 PATH（实测基线 1.0.148）。
临时文件在 tempfile 目录自动清理。退出码：0 = 通过/SKIP，1 = 有失败。
"""
import subprocess, sys, os, tempfile, shutil, json

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
import morph_helpers as mh

FONT = "Microsoft YaHei" if os.name == "nt" else "PingFang SC"

WORK = tempfile.mkdtemp(prefix="slide-master-selfcheck-")
os.chdir(WORK)
results = []

def run(*a):
    r = subprocess.run(list(a), capture_output=True, text=True)
    if r.returncode != 0:
        raise AssertionError(f"cmd rc={r.returncode}: {r.stderr.strip()[-200:]}")
    return r.stdout

def step(name, fn):
    try:
        fn(); results.append(("PASS", name))
    except AssertionError as e:
        results.append(("FAIL", f"{name}: {e}"))
    except Exception as e:
        results.append(("FAIL", f"{name}: {type(e).__name__}: {e}"))

def route_a():
    run("officecli", "create", "a.pptx"); run("officecli", "open", "a.pptx")
    run("officecli", "add", "a.pptx", "/", "--type", "slide", "--prop", "layout=blank", "--prop", "background=1E2761")
    run("officecli", "add", "a.pptx", "/slide[1]", "--type", "shape", "--prop", "text=FY26 战略汇报（中文标题）",
        "--prop", "x=2cm", "--prop", "y=7cm", "--prop", "width=29.87cm", "--prop", "height=3cm",
        "--prop", "font=" + FONT, "--prop", "size=44", "--prop", "bold=true", "--prop", "color=FFFFFF", "--prop", "align=center")
    run("officecli", "add", "a.pptx", "/", "--type", "slide", "--prop", "layout=blank")
    run("officecli", "add", "a.pptx", "/slide[2]", "--type", "shape", "--prop", "text='营收增长 $15M，同比 +312%'",
        "--prop", "x=1.5cm", "--prop", "y=4cm", "--prop", "width=30cm", "--prop", "height=3cm",
        "--prop", "font=" + FONT, "--prop", "size=20")
    run("officecli", "add", "a.pptx", "/slide[2]", "--type", "notes", "--prop", "text=先讲结论：同比 +312%，其中 EMEA 贡献 12 个百分点。")
    run("officecli", "close", "a.pptx"); run("officecli", "validate", "a.pptx")
    issues = run("officecli", "view", "a.pptx", "issues")
    assert "Found 0 issue" in issues, f"issues 未清零: {issues[:120]}"
    html = run("officecli", "view", "a.pptx", "html").strip()
    assert "html" in html or os.path.exists(html.splitlines()[-1].strip())
    txt = run("officecli", "view", "a.pptx", "text")
    assert "$15M" in txt and "战略汇报" in txt, "内容未落盘回读"
    # 几何门（layout_scan，零依赖）
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run([sys.executable, os.path.join(here, "layout_scan.py"), "a.pptx", "--quiet"],
                       capture_output=True, text=True)
    assert r.returncode == 0, f"layout_scan 报告越界：{r.stdout.strip()[:150]}"

def route_b():
    run("officecli", "create", "b.pptx"); run("officecli", "open", "b.pptx")
    run("officecli", "add", "b.pptx", "/", "--type", "slide", "--prop", "layout=blank")
    run("officecli", "add", "b.pptx", "/slide[1]", "--type", "table", "--prop",
        "data=竞品,速度,价格;Datadog,12min,$15/host;Acme,90sec,$8/host",
        "--prop", "headerFill=1E2761", "--prop", "x=1.5cm", "--prop", "y=4cm",
        "--prop", "width=20cm", "--prop", "height=8cm")
    run("officecli", "add", "b.pptx", "/slide[1]", "--type", "chart", "--prop", "chartType=column",
        "--prop", "series1.values=0,1,3", "--prop", "series1.color=1E2761",
        "--prop", "categories=Q1,Q2,Q3", "--prop", "axismin=0",
        "--prop", "x=2cm", "--prop", "y=2cm", "--prop", "width=15cm", "--prop", "height=10cm",
        "--prop", "title='营收($M)'")
    run("officecli", "close", "b.pptx"); run("officecli", "validate", "b.pptx")
    txt = run("officecli", "view", "b.pptx", "text")
    assert "$15/host" in txt and "$8/host" in txt, "表格 $ 内容缺失"

def route_c():
    run("officecli", "create", "c.pptx"); run("officecli", "open", "c.pptx")
    run("officecli", "add", "c.pptx", "/", "--type", "slide", "--prop", "layout=blank", "--prop", "background=1E2761")
    run("officecli", "add", "c.pptx", "/slide[1]", "--type", "shape", "--prop", "name=!!scene-ring",
        "--prop", "preset=ellipse", "--prop", "fill=E94560", "--prop", "opacity=0.3",
        "--prop", "x=5cm", "--prop", "y=3cm", "--prop", "width=8cm", "--prop", "height=8cm")
    run("officecli", "add", "c.pptx", "/slide[1]", "--type", "shape", "--prop", "name=#s1-title",
        "--prop", "text=Morph 演示", "--prop", "x=4cm", "--prop", "y=12cm", "--prop", "width=20cm",
        "--prop", "height=2cm", "--prop", "font=" + FONT, "--prop", "size=36",
        "--prop", "bold=true", "--prop", "color=FFFFFF")
    mh.morph_clone_slide("c.pptx", 1, 2)
    mh.morph_ghost_content("c.pptx", 2, 2)  # shape[2] = !!#s1-title content ghost
    run("officecli", "add", "c.pptx", "/slide[2]", "--type", "shape", "--prop", "name=#s2-body",
        "--prop", "text=Morph 转场开始", "--prop", "x=4cm", "--prop", "y=12cm", "--prop", "width=20cm",
        "--prop", "height=2cm", "--prop", "font=" + FONT, "--prop", "size=20", "--prop", "color=FFFFFF")
    assert mh.morph_verify_slide("c.pptx", 2), "verify slide2 失败"
    assert mh.morph_final_check("c.pptx"), "final-check 失败"
    out = run("officecli", "get", "c.pptx", "/slide[2]", "--json")
    assert '"transition": "morph"' in out or '"transition":"morph"' in out
    run("officecli", "close", "c.pptx"); run("officecli", "validate", "c.pptx")

def route_d():
    glb = None
    for base in (os.path.expanduser("~/Downloads"), os.path.expanduser("~/Desktop")):
        if not os.path.isdir(base):
            continue
        for root, _dirs, files in os.walk(base):
            for f in files:
                if f.lower().endswith(".glb"):
                    glb = os.path.join(root, f); break
            if glb:
                break
        if glb:
            break
    if glb:
        results.append(("INFO", f"D. 3D：发现本地 .glb {glb}——可手动做 3D 端到端"))
    else:
        results.append(("SKIP", "D. morph-ppt-3d：本地无 .glb，3D 端到端需外部模型（CLI --type 3dmodel/roty 已实测支持）"))

def route_e():
    """md 编译回归：md_compile 生成构建脚本 → officecli 出片 → notes 按页落盘（无 pandoc）。"""
    if not shutil.which("officecli"):
        results.append(("SKIP", "E. md 编译：officecli 不在 PATH，跳过")); return
    md = "e_slides.md"
    with open(md, "w", encoding="utf-8") as f:
        f.write("---\ntitle: 回归\nsubtitle: 无 pandoc\n---\n\n## P1\n\n- a\n\n::: notes\n备注一。\n:::\n\n## P2\n\n- b\n\n::: notes\n备注二。\n:::\n")
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run([sys.executable, os.path.join(here, "md_compile.py"), md, "--out", "e_out", "--run"],
                       capture_output=True, text=True)
    assert r.returncode == 0, f"md_compile 失败：{r.stderr.strip()[-200:]}"
    deck = os.path.join("e_out", "e.pptx")
    src = json.loads(run("officecli", "query", deck, "notes", "--json"))["data"]["results"]
    assert len(src) == 2, f"notes 未按页落盘（{len(src)} 条）"
    pages = json.load(open(os.path.join("e_out", "pages.json"), encoding="utf-8"))
    assert len(pages) == 3, f"页数不符（{len(pages)}）"


def route_f():
    """规则单源：数值与 Gate 定义只在 rules.md。"""
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run([sys.executable, os.path.join(here, "rules_lint.py")], capture_output=True, text=True)
    assert r.returncode == 0, f"rules_lint 失败：{(r.stdout + r.stderr).strip()[-200:]}"

def route_g():
    """风格索引：INDEX.md 必须与磁盘目录一致。"""
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run([sys.executable, os.path.join(here, "style_index.py"), "--check"], capture_output=True, text=True)
    assert r.returncode == 0, f"style_index 不一致：{(r.stdout + r.stderr).strip()[-200:]}"


def route_h():
    """自由图形：S1/S2 检查能抓外链，且放过合格 SVG。"""
    here = os.path.dirname(os.path.abspath(__file__))
    good = "h_good.svg"
    bad = "h_bad.svg"
    open(good, "w", encoding="utf-8").write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 50"><rect width="100" height="50" fill="#FFFFFF"/><text x="5" y="30" font-size="16" fill="#1A2428">ok</text></svg>')
    open(bad, "w", encoding="utf-8").write('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 50"><script>1</script></svg>')
    run(sys.executable, os.path.join(here, "svg_lint.py"), good)
    r = subprocess.run([sys.executable, os.path.join(here, "svg_lint.py"), bad], capture_output=True, text=True)
    assert r.returncode != 0, "外链/脚本 SVG 未被拦下"

step("A. pptx-base：中文+$转义+notes+validate+issues=0+html", route_a)
step("B. pitch-deck：table data 中文$ + chart axismin=0", route_b)
step("C. morph-ppt：helpers clone→ghost→verify→final-check", route_c)
step("D. 3D 前置探测", route_d)
step("E. md 编译：md_compile → officecli 出片 → notes 落盘", route_e)
step("F. 规则单源：数值/Gate 只在 rules.md", route_f)
step("G. 风格索引：INDEX.md 与磁盘一致", route_g)
step("H. 自由图形：S1/S2 检查", route_h)

print("=" * 64)
print("slide-master selfcheck")
print("=" * 64)
for s, n in results:
    print(f"[{s}] {n}")
fails = [n for s, n in results if s == "FAIL"]
print("-" * 64)
print(f"PASS {sum(1 for s,_ in results if s=='PASS')} / FAIL {len(fails)} / SKIP·INFO {sum(1 for s,_ in results if s not in ('PASS','FAIL'))}")
shutil.rmtree(WORK, ignore_errors=True)
sys.exit(1 if fails else 0)