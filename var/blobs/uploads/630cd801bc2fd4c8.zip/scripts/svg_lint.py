#!/usr/bin/env python3
"""svg_lint.py —— 自由图形的 S1/S2 检查（自包含 + 可读）。

S1：xmlns、viewBox、无 <script>、无外链（http/https）、无 <image>/<foreignObject>；
S2：文本字号 ≥12、文本填充与白底对比度 ≥4.5:1（无透明度时）。

用法：python3 scripts/svg_lint.py <file.svg> [--json]
退出码：0 通过；1 有问题。
"""
from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

NS = "{http://www.w3.org/2000/svg}"
EXTERNAL = re.compile(r"^(https?:)?//", re.I)


def luminance(hex_color: str) -> float:
    value = hex_color.lstrip("#")
    if len(value) == 3:
        value = "".join(c * 2 for c in value)
    if len(value) != 6 or not re.fullmatch(r"[0-9A-Fa-f]{6}", value):
        return 1.0
    channels = []
    for i in (0, 2, 4):
        c = int(value[i:i+2], 16) / 255
        channels.append(c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4)
    r, g, b = channels
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a: str, b: str = "FFFFFF") -> float:
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def check(path: Path) -> list[str]:
    problems: list[str] = []
    text = path.read_text(encoding="utf-8", errors="replace")
    if "<script" in text.lower():
        problems.append("S1 含 <script>")
    for match in re.finditer(r'(?:xlink:)?href\s*=\s*"([^"]+)"', text):
        if EXTERNAL.match(match.group(1)) or match.group(1).startswith("data:"):
            problems.append(f"S1 外链引用：{match.group(1)[:60]}")
    try:
        root = ET.fromstring(text)
    except ET.ParseError as exc:
        return [f"S1 XML 解析失败：{exc}"]
    if not root.tag.endswith("svg"):
        problems.append("S1 根元素不是 <svg>")
    if not root.tag.startswith(NS):
        problems.append("S1 缺少 xmlns")
    if not root.get("viewBox"):
        problems.append("S1 缺少 viewBox")
    if root.get("width") is None and root.get("height") is None and not root.get("viewBox"):
        problems.append("S1 未声明尺寸")
    for tag in ("image", "foreignObject"):
        if root.iter(f"{NS}{tag}") and any(True for _ in root.iter(f"{NS}{tag}")):
            problems.append(f"S1 使用了 <{tag}>")
    # 收集矩形，用于判断文字底色（不做 transform 展开，覆盖常见插图）
    def rects_of(parent):
        out = []
        for rect in parent.iter(f"{NS}rect"):
            try:
                x = float(rect.get("x", 0)); y = float(rect.get("y", 0))
                w = float(rect.get("width", 0)); h = float(rect.get("height", 0))
            except ValueError:
                continue
            fill = rect.get("fill")
            if fill and fill.startswith("#") and w > 0 and h > 0:
                try:
                    alpha = float(rect.get("opacity", rect.get("fill-opacity", 1)) or 1)
                except ValueError:
                    alpha = 1.0
                if alpha < 1.0:
                    base = fill.lstrip("#")
                    if len(base) == 3:
                        base = "".join(c * 2 for c in base)
                    if len(base) == 6:
                        r, g, b = (int(base[i:i+2], 16) for i in (0, 2, 4))
                        mix = lambda v: int(round(v * alpha + 255 * (1 - alpha)))
                        fill = "#%02X%02X%02X" % (mix(r), mix(g), mix(b))
                out.append((x, y, x + w, y + h, fill))
        return out
    rects = rects_of(root)

    for node in root.iter(f"{NS}text"):
        style = node.get("style") or ""
        size = node.get("font-size") or (re.search(r"font-size:\s*([\d.]+)", style).group(1) if re.search(r"font-size:\s*([\d.]+)", style) else None)
        if size is not None:
            try:
                if float(str(size).replace("px", "").replace("pt", "")) < 12:
                    problems.append(f"S2 字号过小：{size}（{''.join(node.itertext())[:20]}）")
            except ValueError:
                pass
        fill = node.get("fill") or (re.search(r"fill:\s*(#[0-9A-Fa-f]{3,6})", style).group(1) if re.search(r"fill:\s*(#[0-9A-Fa-f]{3,6})", style) else None)
        if fill and fill.startswith("#"):
            try:
                tx = float(node.get("x", 0)); ty = float(node.get("y", 0))
            except ValueError:
                tx = ty = 0.0
            bg = "FFFFFF"
            for x1, y1, x2, y2, rect_fill in rects:
                if x1 <= tx <= x2 and y1 <= ty <= y2:
                    bg = rect_fill
            if contrast(fill, bg) < 4.5:
                problems.append(f"S2 对比度不足：{fill} on {bg}（{''.join(node.itertext())[:20]}）")
    return problems


def main() -> int:
    if len(sys.argv) < 2:
        print("用法：svg_lint.py <file.svg>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"找不到 {path}", file=sys.stderr)
        return 2
    problems = check(path)
    if "--json" in sys.argv:
        print(json.dumps({"file": str(path), "ok": not problems, "problems": problems}, ensure_ascii=False))
    elif problems:
        print("S1/S2 未通过：")
        for item in problems:
            print("  -", item)
    else:
        print("S1/S2 通过")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
