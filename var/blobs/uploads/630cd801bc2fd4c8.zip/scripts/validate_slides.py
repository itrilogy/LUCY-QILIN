#!/usr/bin/env python3
"""Pandoc Slide Shows 语法验证器"""
from __future__ import annotations
import argparse
import json
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Issue:
    severity: str
    line: int
    code: str
    message: str
    def __str__(self) -> str:
        return f"  L{self.line:>4}  [{self.severity.upper():>7}] {self.code}: {self.message}"

@dataclass
class Report:
    file: str
    issues: list[Issue] = field(default_factory=list)
    fixed: list[str] = field(default_factory=list)
    slide_count: int = 0
    section_count: int = 0
    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "error"]
    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == "warning"]
    @property
    def ok(self) -> bool:
        return len(self.errors) == 0
    def to_dict(self) -> dict[str, Any]:
        return {"file": self.file, "ok": self.ok, "errors": len(self.errors),
                "warnings": len(self.warnings), "slides": self.slide_count,
                "sections": self.section_count, "fixed": self.fixed,
                "issues": [{"severity": i.severity, "line": i.line,
                            "code": i.code, "message": i.message} for i in self.issues]}


class SlideValidator:
    _RE_YAML_START = re.compile(r"^---\s*$")
    _RE_YAML_END = re.compile(r"^---\s*$")
    _RE_H1 = re.compile(r"^#\s+(.+)")
    _RE_H2 = re.compile(r"^##\s+(.+)")
    _RE_H3 = re.compile(r"^###\s+(.+)")
    _RE_H4 = re.compile(r"^####\s+(.+)")
    _RE_H2_ATTR = re.compile(r"^##\s+\{(.+)\}\s*$")
    _RE_NOTES_OPEN = re.compile(r"^:::\s*notes\s*$")
    _RE_NOTES_CLOSE = re.compile(r"^:::\s*$")
    _RE_COLUMNS_OPEN = re.compile(r"^:{4,}\s*columns\s*$")
    _RE_COLUMNS_CLOSE = re.compile(r"^:{4,}\s*$")
    _RE_COLUMN_OPEN = re.compile(r"^:{3}\s*column.*$")
    _RE_COLUMN_CLOSE = re.compile(r"^:{3}\s*$")
    _RE_INCR_OPEN = re.compile(r"^:::\s*incremental\s*$")
    _RE_INCR_CLOSE = re.compile(r"^:::\s*$")
    _RE_TABLE_SEP = re.compile(r"^\|[\s\-:|]+\|\s*$")
    _RE_TABLE_ROW = re.compile(r"^\|.+\|")
    _RE_CONTENT = re.compile(r"^(\s*[-*]\s|^\s*\d+\.\s|^\|)")
    _RE_IMAGE = re.compile(r"^!\[.*\]\(.+\)")
    _RE_CODE_FENCE = re.compile(r"^```")
    _RE_BLANK = re.compile(r"^\s*$")
    _RE_HORIZ_RULE = re.compile(r"^---\s*$")
    _RE_BG_IMAGE = re.compile(r'\{background-image\s*=\s*"[^"]*"\}')

    def __init__(self, fix: bool = False, strict: bool = False):
        self.fix = fix
        self.strict = strict
        self._lines: list[str] = []
        self._report: Report | None = None
        self._in_yaml = False
        self._yaml_start_line = -1
        self._yaml_end_line = -1
        self._in_code_fence = False
        self._in_notes = False
        self._in_columns = 0
        self._in_column = 0
        self._in_incremental = False

    def validate(self, file_path: str | Path) -> Report:
        path = Path(file_path)
        self._report = Report(file=str(path))
        self._lines = path.read_text(encoding="utf-8").splitlines(keepends=False)
        self._reset_state()
        if not self._lines:
            self._add_issue("error", 0, "E001", "文件为空")
            return self._report
        self._check_yaml_front_matter()
        self._check_body()
        self._check_unclosed_blocks()
        return self._report

    def validate_and_fix(self, file_path: str | Path) -> Report:
        report = self.validate(file_path)
        if self.fix and self._lines is not None and report.fixed:
            Path(file_path).write_text("\n".join(self._lines) + "\n", encoding="utf-8")
        return report

    def _reset_state(self) -> None:
        self._in_yaml = False
        self._yaml_start_line = -1
        self._yaml_end_line = -1
        self._in_code_fence = False
        self._in_notes = False
        self._in_columns = 0
        self._in_column = 0
        self._in_incremental = False

    def _add_issue(self, severity: str, line: int, code: str, message: str) -> None:
        self._report.issues.append(Issue(severity, line, code, message))

    def _log_fix(self, line: int, description: str) -> None:
        self._report.fixed.append(f"L{line}: {description}")

    def _check_yaml_front_matter(self) -> None:
        if not self._RE_YAML_START.match(self._lines[0].rstrip()):
            self._add_issue("error", 1, "E100", "文件必须以 YAML Front Matter `---` 开头")
            return
        self._in_yaml = True
        self._yaml_start_line = 0
        yaml_content: list[str] = []
        for i in range(1, len(self._lines)):
            stripped = self._lines[i].rstrip()
            if self._RE_YAML_END.match(stripped) and self._in_yaml:
                self._yaml_end_line = i
                self._in_yaml = False
                if i + 1 < len(self._lines) and not self._RE_BLANK.match(self._lines[i + 1]):
                    self._add_issue("error", i + 2, "E101", "YAML 闭合 `---` 后必须紧跟一个空行")
                    if self.fix:
                        self._lines.insert(i + 1, "")
                        self._log_fix(i + 1, "在 YAML 闭合后插入空行")
                break
            yaml_content.append(stripped)
        if self._in_yaml:
            self._add_issue("error", self._yaml_start_line + 1, "E102",
                            "YAML Front Matter 未正确闭合（缺少结尾的 `---`）")
            return
        if "title:" not in "\n".join(yaml_content):
            self._add_issue("warning", self._yaml_start_line + 1, "W103",
                            "YAML 缺少 `title` 字段，Title Slide 将为空标题")

    def _check_body(self) -> None:
        body_start = self._yaml_end_line + 2 if self._yaml_end_line >= 0 else 0
        if body_start >= len(self._lines):
            self._add_issue("error", len(self._lines), "E200", "正文为空")
            return
        if self._yaml_end_line >= 0:
            body_start = self._yaml_end_line + 1
            while body_start < len(self._lines) and self._RE_BLANK.match(self._lines[body_start]):
                body_start += 1
        self._reset_state()
        slides: list[tuple[int, int, str]] = []
        sections: list[int] = []
        current_slide_start = -1
        current_slide_has_notes = False
        i = body_start
        while i < len(self._lines):
            line = self._lines[i].rstrip()
            line_no = i + 1

            if self._in_code_fence:
                if self._RE_CODE_FENCE.match(line):
                    self._in_code_fence = False
                i += 1; continue
            if self._RE_CODE_FENCE.match(line):
                self._in_code_fence = True
                i += 1; continue
            if self._in_notes:
                if self._RE_NOTES_CLOSE.match(line):
                    self._in_notes = False
                    if i + 1 < len(self._lines) and not self._RE_BLANK.match(self._lines[i + 1]) \
                       and not self._RE_H2.match(self._lines[i + 1]) \
                       and not self._RE_H1.match(self._lines[i + 1]) \
                       and not self._RE_HORIZ_RULE.match(self._lines[i + 1]):
                        self._add_issue("warning", i + 2, "W205", "`:::` (notes闭合) 后建议留空行")
                i += 1; continue
            if self._in_incremental:
                if self._RE_INCR_CLOSE.match(line):
                    self._in_incremental = False
                i += 1; continue
            if self._in_columns > 0:
                if self._RE_COLUMN_OPEN.match(line):
                    self._in_column += 1
                elif self._RE_COLUMN_CLOSE.match(line):
                    self._in_column -= 1
                    if self._in_column < 0:
                        self._add_issue("error", line_no, "E301", "多余的 `::: column` 闭合标记")
                        self._in_column = 0
                elif self._RE_COLUMNS_CLOSE.match(line):
                    if self._in_column > 0:
                        self._add_issue("error", line_no, "E302",
                                        f"columns 闭合前还有 {self._in_column} 个未闭合的 column")
                    self._in_columns = 0; self._in_column = 0
                i += 1; continue

            h1_match = self._RE_H1.match(line)
            if h1_match:
                sections.append(line_no)
                self._report.section_count += 1
                if i > body_start and not self._RE_BLANK.match(self._lines[i - 1]):
                    self._add_issue("warning", line_no, "W201", "`#` Section 前应留空行")
                    if self.fix and not self._lines[i - 1].rstrip() == "":
                        self._lines.insert(i, ""); self._log_fix(line_no, "在 Section 前插入空行")
                if i + 1 < len(self._lines) and not self._RE_BLANK.match(self._lines[i + 1]):
                    self._add_issue("error", line_no + 1, "E202", "`#` Section 标题后必须空行")
                    if self.fix:
                        self._lines.insert(i + 1, ""); self._log_fix(line_no, "在 Section 后插入空行")
                i += 1; continue

            h2_attr = self._RE_H2_ATTR.match(line)
            h2_match = self._RE_H2.match(line)
            if h2_attr or h2_match:
                title = h2_match.group(1) if h2_match else (h2_attr.group(1) if h2_attr else "")
                if current_slide_start >= 0 and not current_slide_has_notes:
                    last_title = slides[-1][2] if slides else ""
                    self._add_issue("error", current_slide_start, "E203",
                                    f"幻灯片 '{last_title}' 缺少 `::: notes`")
                    if self.fix:
                        self._lines.insert(i, ""); self._lines.insert(i + 1, "::: notes")
                        self._lines.insert(i + 2, "（待补充备注）"); self._lines.insert(i + 3, ":::")
                        self._lines.insert(i + 4, "")
                        self._log_fix(line_no, f"为幻灯片 '{title}' 插入占位备注"); i += 5
                current_slide_start = line_no; current_slide_has_notes = False
                slides.append((i, -1, title)); self._report.slide_count += 1
                if not h2_attr and i + 1 < len(self._lines) \
                   and not self._RE_BLANK.match(self._lines[i + 1]) \
                   and not self._RE_CODE_FENCE.match(self._lines[i + 1]):
                    self._add_issue("warning", line_no + 1, "W204", "`##` 标题后建议留空行")
                i += 1; continue

            if self._RE_HORIZ_RULE.match(line):
                if current_slide_start >= 0 and not current_slide_has_notes:
                    self._add_issue("error", current_slide_start, "E203", "幻灯片缺少 `::: notes`")
                if i > body_start and not self._RE_BLANK.match(self._lines[i - 1]):
                    self._add_issue("warning", line_no, "W206", "幻灯片分隔 `---` 前应留空行")
                if i + 1 < len(self._lines) and not self._RE_BLANK.match(self._lines[i + 1]):
                    self._add_issue("error", line_no + 1, "E207", "幻灯片分隔 `---` 后必须空行")
                    if self.fix:
                        self._lines.insert(i + 1, ""); self._log_fix(line_no, "在 --- 后插入空行")
                current_slide_start = -1; current_slide_has_notes = False
                i += 1; continue

            if sections and current_slide_start < 0:
                is_content = (self._RE_CONTENT.match(line) or self._RE_IMAGE.match(line)
                              or self._RE_TABLE_ROW.match(line)
                              or (line.strip() and not self._RE_BLANK.match(line)
                                  and not self._RE_H2.match(line) and not self._RE_H3.match(line)
                                  and not self._RE_NOTES_OPEN.match(line)
                                  and not self._RE_COLUMNS_OPEN.match(line)
                                  and not self._RE_INCR_OPEN.match(line)
                                  and not self._RE_CODE_FENCE.match(line)
                                  and not self._RE_HORIZ_RULE.match(line)))
                if is_content:
                    self._add_issue("error", line_no, "E208",
                                    "`#` Section 页内禁止出现正文内容，请移至 `##` 幻灯片中")
                    if self.fix:
                        self._lines.insert(i, ""); self._lines.insert(i + 1, "## （自动提取的幻灯片）")
                        self._lines.insert(i + 2, "")
                        self._log_fix(line_no, "为 Section 内的游离内容自动创建幻灯片")

            if self._RE_NOTES_OPEN.match(line):
                current_slide_has_notes = True; self._in_notes = True
                if i > body_start and not self._RE_BLANK.match(self._lines[i - 1]):
                    self._add_issue("error", line_no, "E209", "`::: notes` 前必须空行")
                    if self.fix:
                        self._lines.insert(i, ""); self._log_fix(line_no, "在 ::: notes 前插入空行")
                i += 1; continue

            if self._RE_COLUMNS_OPEN.match(line):
                self._in_columns += 1
                colons = len(line) - len(line.lstrip(":"))
                if colons < 4:
                    self._add_issue("error", line_no, "E303",
                                    f"columns 外层必须至少 4 个冒号，当前 {colons} 个")
                i += 1; continue

            if self._RE_INCR_OPEN.match(line):
                self._in_incremental = True; i += 1; continue

            bg_match = self._RE_BG_IMAGE.search(line)
            if bg_match and not h2_attr:
                self._add_issue("warning", line_no, "W400",
                                "`{background-image=...}` 应作为 `##` 标题的属性使用")

            if self._RE_TABLE_SEP.match(line):
                if i > 0 and not self._RE_TABLE_ROW.match(self._lines[i - 1]):
                    self._add_issue("error", line_no, "E500", "表格分隔线前必须有一行表头")
                if i + 1 < len(self._lines) and self._RE_BLANK.match(self._lines[i + 1]):
                    self._add_issue("error", line_no, "E501", "表格分隔线后不应立即空行（缺少数据行）")

            h4_match = self._RE_H4.match(line)
            if h4_match and current_slide_start < 0:
                self._add_issue("error", line_no, "E600",
                                "`####` 不能直接出现在 Section 页下，必须位于内容幻灯片内")
            if h4_match and current_slide_start > 0:
                found_h3 = False
                for j in range(i - 1, current_slide_start - 1, -1):
                    if self._RE_H3.match(self._lines[j]): found_h3 = True; break
                    if self._RE_H2.match(self._lines[j]): break
                if not found_h3:
                    self._add_issue("warning", line_no, "W601",
                                    "`####` 建议先经过 `###` 层级，可能影响 layout 匹配")
            i += 1

        if current_slide_start >= 0 and not current_slide_has_notes:
            last_title = slides[-1][2] if slides else ""
            self._add_issue("error", current_slide_start, "E203",
                            f"最后一张幻灯片 '{last_title}' 缺少 `::: notes`")
            if self.fix:
                self._lines.append(""); self._lines.append("::: notes")
                self._lines.append("（待补充备注）"); self._lines.append(":::")
                self._log_fix(current_slide_start, "为最后一张幻灯片插入占位备注")

        if self._report.slide_count == 0:
            self._add_issue("error", len(self._lines), "E210",
                            "未检测到任何幻灯片（需要 `## 标题` 或 `## {background-image=...}`）")
        if self._report.section_count > 0 and self._report.slide_count == 0:
            self._add_issue("error", 1, "E211",
                            "检测到 Section 页但没有内容幻灯片，编译后会得到空白章节页")

    def _check_unclosed_blocks(self) -> None:
        last = len(self._lines)
        if self._in_code_fence: self._add_issue("error", last, "E700", "代码块未闭合")
        if self._in_notes: self._add_issue("error", last, "E701", "::: notes 未闭合")
        if self._in_columns > 0: self._add_issue("error", last, "E702", "columns 未闭合")
        if self._in_incremental: self._add_issue("error", last, "E703", "::: incremental 未闭合")


ERROR_STYLE = "\033[91m"
WARN_STYLE = "\033[93m"
OK_STYLE = "\033[92m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_report(report: Report) -> None:
    print(f"\n{BOLD}═══ Pandoc Slide 语法验证报告 ═══{RESET}")
    print(f"  文件: {report.file}  Section: {report.section_count}  幻灯片: {report.slide_count}\n")
    for issue in report.issues:
        color = ERROR_STYLE if issue.severity == "error" else WARN_STYLE
        print(f"{color}{issue}{RESET}")
    if report.fixed:
        print(f"\n{OK_STYLE}  自动修复 {len(report.fixed)} 处:{RESET}")
        for f in report.fixed: print(f"    ✓ {f}")
    ec, wc = len(report.errors), len(report.warnings)
    if ec == 0 and wc == 0: print(f"\n{OK_STYLE}{BOLD}  ✅ 全部通过，可以编译{RESET}")
    elif ec == 0: print(f"\n{WARN_STYLE}{BOLD}  ⚠️  通过（{wc} 个警告）{RESET}")
    else: print(f"\n{ERROR_STYLE}{BOLD}  ❌ {ec} 个错误, {wc} 个警告 — 不可编译{RESET}")
    print()

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Pandoc Slide Shows 语法验证器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="示例:\n  python validate_slides.py slides.md             仅检查\n"
               "  python validate_slides.py slides.md --fix       自动修复\n"
               "  python validate_slides.py slides.md --json      JSON输出\n"
               "  python validate_slides.py slides.md            （编译交给 md_compile.py）")
    parser.add_argument("file", help="Markdown 幻灯片文件路径")
    parser.add_argument("--fix", action="store_true", help="自动修复可修复的问题")
    parser.add_argument("--json", action="store_true", help="以 JSON 格式输出结果")
    parser.add_argument("--strict", action="store_true", help="严格模式：警告也视为错误")
    args = parser.parse_args()
    validator = SlideValidator(fix=args.fix, strict=args.strict)
    report = validator.validate_and_fix(args.file)
    if args.json:
        data = report.to_dict()
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else: print_report(report)
    sys.exit(0 if report.ok else 1)

if __name__ == "__main__":
    main()
