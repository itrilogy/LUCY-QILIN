#!/usr/bin/env python3
"""layout_scan — 零依赖几何越界/重叠扫描（复盘 P1 落地）。

原理：`officecli view <deck> html` 的输出含每个 shape 的绝对坐标
（`.slide-container[data-slide=N]` 内 `.shape` 的 inline style left/top/width/height，单位 pt），
本脚本用标准库解析 HTML 直接判定几何——不需要浏览器/puppeteer，与截图判读互补。

用法：
  python3 layout_scan.py <deck.pptx|view.html> [--allow REGEX] [--overlap] [--quiet]
  --allow   放行 data-path 匹配该正则的 shape（装饰元素白名单，可重复）
  --overlap 额外报告同页两两重叠（AABB 相交；默认只报越界）
退出码：0 无违规；1 有违规（可作 Gate 3 前置 MUST）。
"""
import subprocess, sys, os, re, argparse, tempfile

CANVAS_W, CANVAS_H = 960.0, 540.0     # 16:9 标准画布（pt），可由 HTML :root 变量覆盖
SHAPE_RE = re.compile(r'<div class="shape[^"]*"[^>]*data-path="([^"]+)"[^>]*style="([^"]*)"')
SLIDE_RE = re.compile(r'class="slide-container"[^>]*data-slide="(\d+)"')
RECT_RE = re.compile(r"left:\s*(-?[\d.]+)pt;\s*top:\s*(-?[\d.]+)pt;\s*width:\s*([\d.]+)pt;\s*height:\s*([\d.]+)pt")


def load_html(target):
    if target.endswith((".html", ".htm")):
        return open(target, encoding="utf-8", errors="ignore").read()
    out = tempfile.NamedTemporaryFile(suffix=".html", delete=False)
    out.close()
    r = subprocess.run(["officecli", "view", target, "html"], capture_output=True, text=True)
    if r.returncode != 0:
        print("ERROR: 无法导出 HTML：", r.stderr.strip()[-200:], file=sys.stderr); sys.exit(2)
    open(out.name, "w", encoding="utf-8").write(r.stdout)
    return open(out.name, encoding="utf-8", errors="ignore").read()


def main():
    ap = argparse.ArgumentParser(description="零依赖几何越界/重叠扫描")
    ap.add_argument("target", help="deck.pptx 或已导出的 view.html")
    ap.add_argument("--allow", action="append", default=[], help="放行 data-path 正则（可重复）")
    ap.add_argument("--overlap", action="store_true", help="额外报告重叠")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    html = load_html(a.target)
    global CANVAS_W, CANVAS_H
    m = re.search(r"--slide-design-w:\s*([\d.]+)pt", html)
    if m:
        CANVAS_W = float(m.group(1))
    m = re.search(r"--slide-design-h:\s*([\d.]+)pt", html)
    if m:
        CANVAS_H = float(m.group(1))

    # 按 slide 分段
    marks = [(mm.start(), int(mm.group(1))) for mm in SLIDE_RE.finditer(html)]
    marks.append((len(html), None))
    allow = [re.compile(p) for p in a.allow]
    violations = 0
    report = []
    for i in range(len(marks) - 1):
        start, num = marks[i]
        seg = html[start:marks[i + 1][0]]
        rects = []
        for mm in SHAPE_RE.finditer(seg):
            path, style = mm.group(1), mm.group(2)
            rm = RECT_RE.search(style)
            if not rm:
                continue
            x, y, w, h = (float(v) for v in rm.groups())
            if any(p.search(path) for p in allow):
                continue
            rects.append((path, x, y, w, h))
        for path, x, y, w, h in rects:
            msgs = []
            if x < -0.6:
                msgs.append(f"左侧越界 {x:.1f}pt")
            if y < -0.6:
                msgs.append(f"顶部越界 {y:.1f}pt")
            if x + w > CANVAS_W + 0.6:
                msgs.append(f"右侧越界 {x + w - CANVAS_W:.1f}pt")
            if y + h > CANVAS_H + 0.6:
                msgs.append(f"底部越界 {y + h - CANVAS_H:.1f}pt")
            if msgs:
                violations += 1
                report.append(f"  slide[{num}] {path}: " + " / ".join(msgs))
        if a.overlap:
            for j in range(len(rects)):
                for k in range(j + 1, len(rects)):
                    _, x1, y1, w1, h1 = rects[j]
                    _, x2, y2, w2, h2 = rects[k]
                    if x1 < x2 + w2 and x2 < x1 + w1 and y1 < y2 + h2 and y2 < y1 + h1:
                        violations += 1
                        report.append(f"  slide[{num}] 重叠: {rects[j][0]} ↔ {rects[k][0]}")

    print(f"layout_scan：{os.path.basename(a.target)} · 画布 {CANVAS_W:.0f}×{CANVAS_H:.0f}pt · 越界/违规 {violations}")
    if report and not a.quiet:
        print("\n".join(report[:60]))
    sys.exit(1 if violations else 0)


if __name__ == "__main__":
    main()
