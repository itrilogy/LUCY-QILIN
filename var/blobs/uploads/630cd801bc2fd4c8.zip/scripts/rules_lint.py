#!/usr/bin/env python3
"""rules_lint.py —— 检查"规则单源"是否被破坏。

规则：
1. 除 rules.md 外，文档里不得出现规范句 `≥36pt` / `≥18pt` / `33.87×19.05`（代码块内不算）；
2. 提到 Gate 的文档必须链接 rules.md；
3. rules.md 自身必须包含 R1–R6 与 G1–G6。

退出码：0 通过；1 有违规。
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOCS = [ROOT / "SKILL.md"] + sorted((ROOT / "references").glob("*.md")) + sorted((ROOT / "platform").glob("*.md"))
SKIP = {"rules.md", "CHANGELOG.md"}
NORMATIVE = [re.compile(r"≥\s*36\s*pt", re.I), re.compile(r"≥\s*18\s*pt", re.I),
             re.compile(r"33\.87\s*[×x]\s*19\.05")]
GATE = re.compile(r"Gate\s*[1-6]")


def strip_code(text: str) -> str:
    return re.sub(r"```[\s\S]*?```", "", text)


def main() -> int:
    problems: list[str] = []
    rules = (ROOT / "references" / "rules.md").read_text(encoding="utf-8")
    for metric in ("R1", "R2", "R3", "R4", "R5", "R6", "G1", "G2", "G5a", "G5b", "G6"):
        if f"| {metric} |" not in rules and f"## {metric}" not in rules:
            problems.append(f"rules.md 缺少 {metric}")
    for doc in DOCS:
        if doc.name in SKIP:
            continue
        text = strip_code(doc.read_text(encoding="utf-8"))
        relative = doc.relative_to(ROOT).as_posix()
        for pattern in NORMATIVE:
            for match in pattern.finditer(text):
                line = text[: match.start()].count("\n") + 1
                problems.append(f"{relative}:{line} 重复定义底线 `{match.group(0)}`（改为引用 rules.md）")
        if GATE.search(text) and "rules.md" not in text:
            problems.append(f"{relative} 提到 Gate 但没有链接 rules.md")
    if problems:
        print("规则单源检查未通过：")
        for item in problems:
            print("  -", item)
        return 1
    print("规则单源检查通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
