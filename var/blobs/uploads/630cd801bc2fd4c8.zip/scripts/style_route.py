#!/usr/bin/env python3
"""style_route — 风格包的确定性路由（无随机、无打分、无模型判断）。

对输入 (scene, env, lang) 按固定规则表输出唯一变体与全部 token：
  variant = luxi-dark  if env == projection
          = luxi-ink   if scene == immersive
          = luxi-light otherwise
  density = compact    if scene in {dashboard, workbench} else regular

用法：
  python3 style_route.py --scene dashboard --env projection
  python3 style_route.py --keywords "看板,KPI,数据大屏"
  python3 style_route.py --from-md 复盘简报_slides.md
  python3 style_route.py --list            # 列出包/变体/规则
  python3 style_route.py --scene marketing --json   # 机器可读
退出码：0 成功；2 参数/文件错误。
"""
import argparse, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOKENS = os.path.join(HERE, "..", "references", "styles", "mixed--luxi-scenario", "tokens.json")


def load():
    with open(TOKENS, encoding="utf-8") as f:
        return json.load(f)


def scene_from_keywords(tok, text):
    """确定性关键词映射：命中即入；**最长命中词优先**（length desc），同长再按 routing.priority。"""
    low = text.lower()
    best = {}            # scene -> 命中词最长长度
    for sc, words in tok["routing"]["keywords"].items():
        hit = max((len(w) for w in words if w.lower() in low), default=0)
        if hit:
            best[sc] = hit
    if not best:
        return None
    top = max(best.values())
    cands = [sc for sc, ln in best.items() if ln == top]
    for sc in tok["routing"]["priority"]:
        if sc in cands:
            return sc
    return cands[0]


def route(tok, scene=None, env=None):
    scene = scene or "marketing"          # 缺省场景（保守：不假设 dashboard/workbench 密度）
    env = env or "light"
    if env == "projection":
        variant = "luxi-dark"
    elif scene == "immersive":
        variant = "luxi-ink"
    else:
        variant = "luxi-light"
    density = "compact" if scene in tok["routing"]["density"]["compact"] else "regular"
    return scene, env, variant, density


def main():
    ap = argparse.ArgumentParser(description="鹿溪风格包确定性路由")
    ap.add_argument("--scene", choices=["dashboard", "workbench", "marketing", "immersive", "collateral"])
    ap.add_argument("--env", choices=["light", "projection"], default="light")
    ap.add_argument("--keywords", help="逗号分隔关键词（自动映射 scene）")
    ap.add_argument("--from-md", help="从 markdown 素材提取关键词映射 scene")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--list", action="store_true", help="列出包与规则")
    a = ap.parse_args()

    tok = load()
    if a.list:
        print(f"风格包：{tok['pack']}（{tok['dir']}）")
        print("变体：", ", ".join(tok["variants"].keys()))
        print("路由规则：", json.dumps(tok["routing"]["rules"], ensure_ascii=False))
        print("场景关键词：", json.dumps(tok["routing"]["keywords"], ensure_ascii=False))
        return

    scene = a.scene
    if not scene and (a.keywords or a.from_md):
        text = a.keywords or ""
        if a.from_md:
            try:
                text += open(a.from_md, encoding="utf-8").read()
            except OSError as e:
                print(f"ERROR: 无法读取 {a.from_md}: {e}", file=sys.stderr); sys.exit(2)
        scene = scene_from_keywords(tok, text)
        if scene is None:
            print("提示：未命中任何场景关键词 → 使用缺省场景 marketing（规则：无命中即缺省，非随机）",
                  file=sys.stderr)
    scene, env, variant, density = route(tok, scene, a.env)
    out = {
        "scene": scene, "env": env, "variant": variant, "density": density,
        "font_body": tok["variants"][variant]["font_body"],
        "tokens": tok["variants"][variant],
        "type_scale_ppt_pt": tok["type_scale_ppt_pt"],
        "radius_ppt_adj": tok["radius_ppt_adj"],
        "rule_trace": f"env={env}" + (" → luxi-dark" if env == "projection" else
                                      f"; scene={scene}" + (" → luxi-ink" if scene == "immersive" else " → luxi-light")),
    }
    if a.json:
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print(f"变体：{variant} · 密度：{density} · 场景：{scene} · 环境：{env}")
        print(f"规则轨迹：{out['rule_trace']}")
        t = out["tokens"]
        print(f"背景 {t['bg']} · 卡片 {t['card']} · 主色 {t['primary']} · 强调 {t['accent']} · 金 {t['gold']}")
        print(f"正文色 {t['text']} · 弱文本 {t['muted']} · 字体 {t['font_body']}")


if __name__ == "__main__":
    main()
