#!/usr/bin/env python3
"""pilot_verify — 试点对照验证（复盘 §5.3）：P0 文本度量协议效果 + 两段式流水线效率。

同一份中文高密度内容（10 页）三种构建对照：
  A 旧协议：框高 = size × 0.05cm（复盘基线 rule of thumb，不感知行数）
  B 新协议：框高 = ceil(行数) × size × 1.2 + 7.2pt（P0 §Text metrics）
  A' 采纳 A 的 view issues suggest.height → 修复闭环（应归零）
  E 两段式：同素材 → md(::: notes) → pandoc --slide-level=2（一次编译）
指标：首轮 issues（基线 83 → 目标 ≤10）、结构性返工页数、notes 100%、命令数。
用法：python3 scripts/pilot_verify.py   （依赖 officecli；E 段需 pandoc，缺失则跳过）
"""
import subprocess, sys, os, math, tempfile, shutil, re, json

WORK = tempfile.mkdtemp(prefix="sm-pilot-")
os.chdir(WORK)
PT2CM = 28.3465  # cm → pt（1cm = 28.3465pt）

PAGES = [
    {"title": "深圳南特金融科技学院完整调研综合评估简报（2026 年度）", "size": 36, "w": 29.87, "y": 6.5,
     "blocks": [("副标题：院系概况 · 师资结构 · 专业体系 · 科研产出 · 升学就业 · 国际化与奖学金", 20, 29.87, 10.5)]},
    {"title": "学院概览：办学定位与治理结构", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("学院依托深圳大学与法国南特高等商学院合作办学，聚焦金融科技交叉领域，构建本硕贯通培养体系，面向粤港澳大湾区金融科技产业需求输送复合型人才。", 18, 14, 3.6),
                ("治理结构由联合管理委员会统筹，下设学术委员会、教学指导委员会与产教融合办公室，分别负责学科建设、课程质量监控与实习基地对接。", 18, 14, 7.6),
                ("学院现有专任教师四十余人，其中海外博士占比过半，同时聘请业界导师参与项目制课程与毕业设计指导。", 18, 14, 11.6)]},
    {"title": "治理架构：三层决策与执行体系", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("联合管理委员会：统筹办学方向、预算审批与重大事项决策，中法双方各派代表组成。", 16, 9.5, 3.6),
                ("学术委员会：负责学科规划、师资聘任标准与学术规范审定。", 16, 9.5, 6.2),
                ("教学指导委员会：审定培养方案、课程大纲与实践学分认定规则。", 16, 9.5, 8.8),
                ("产教融合办公室：对接金融机构、科技企业与实习基地，组织项目制教学。", 16, 9.5, 11.4),
                ("学生发展中心：统筹学业辅导、职业规划与国际化交流项目。", 16, 9.5, 14.0)]},
    {"title": "师资队伍：名单与研究方向（节选）", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("王教授 金融工程 量化投资与风险管理方向", 15, 14, 3.6),
                ("李教授 计算机科学 分布式系统与区块链方向", 15, 14, 5.4),
                ("张副教授 统计学 高维数据建模与因果推断", 15, 14, 7.2),
                ("陈副教授 金融学 资产定价与市场微观结构", 15, 14, 9.0),
                ("刘博士 人工智能 大模型与智能投顾", 15, 14, 10.8),
                ("赵博士 密码学 隐私计算与安全多方计算", 15, 14, 12.6),
                ("孙博士 产业经济 金融科技监管与政策评估", 15, 14, 14.4)]},
    {"title": "本科专业体系：三个方向与培养要点", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("金融科技方向：以金融学原理为根基，叠加程序设计、数据结构与数据库课程，培养兼具金融理解与技术实现能力的复合人才，核心课程包括金融科技导论、程序设计基础与金融数据分析。", 17, 9.5, 3.8),
                ("智能金融方向：侧重人工智能与机器学习在金融场景的应用，覆盖智能投顾、风控建模与自然语言处理，要求完成至少一个企业真实数据项目。", 17, 9.5, 8.0),
                ("区块链与数字资产方向：聚焦分布式账本、智能合约与数字资产合规，配套密码学基础与监管科技课程，鼓励参与开源社区实践。", 17, 9.5, 12.2)]},
    {"title": "关键统计：招生与就业核心指标", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("420", 54, 6, 4.0), ("人/年 招生规模，较上年增长 12%", 18, 10, 8.0)]},
    {"title": "对比分析：本院与同类项目差异", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("本院优势：中法双学位通道、项目制课程占比高、业界导师密度大、实习基地覆盖头部机构，毕业生在金融科技岗位的起薪与晋升速度处于区域领先水平。", 16, 14, 3.6),
                ("待补短板：科研平台建设起步较晚，高水平论文产出规模有限，国际学术网络仍在拓展期；部分课程依赖外聘师资，教学连续性存在波动风险。", 16, 14, 8.4),
                ("改进方向：加大专职科研岗引进力度，建立与产业联合实验室，完善课程负责人制度以稳定教学质量。", 16, 14, 13.2)]},
    {"title": "综合评估：五维打分与结论", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("培养体系：课程结构完整、方向划分清晰，项目制与实践学分设计具备竞争力。", 16, 29.87, 3.6),
                ("师资结构：海外背景比例高，但专职科研力量与学科带头人数量仍需补充。", 16, 29.87, 5.8),
                ("科研产出：总量偏小，增长趋势明确，联合实验室建成后有望提速。", 16, 29.87, 8.0),
                ("就业表现：金融科技岗位对口率高，头部机构录用比例逐年提升。", 16, 29.87, 10.2),
                ("国际化：双学位与国际交流项目成熟，但海外交换名额覆盖仍不均衡。", 16, 29.87, 12.4)]},
    {"title": "结论与建议", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("结论一：学院在培养体系与产业对接方面形成明显优势，适合作为金融科技本科的首选方向之一。", 18, 29.87, 3.8),
                ("结论二：科研与师资结构是下一阶段的核心瓶颈，建议以联合实验室与专职科研岗为突破口。", 18, 29.87, 6.6),
                ("结论三：国际化资源应向中西部生源倾斜，提升交换项目的覆盖面与公平性。", 18, 29.87, 9.4)]},
    {"title": "致谢与资料来源", "size": 36, "w": 30, "y": 1.2,
     "blocks": [("资料来源：学院官网公开信息、招生简章、就业质量报告与第三方调研数据；本简报由 slide-master 两段式流水线生成，备注内容按演讲者备注规范撰写。", 16, 29.87, 3.8)]},
]
NOTES = [
    "开场一句结论：这份简报用十个维度评估学院竞争力，最后给出三条可执行建议。",
    "先讲定位：中法合作、金融科技交叉、本硕贯通；治理三层结构一句话带过，重点落在产教融合。",
    "这页快讲：三层决策加两个支撑机构，强调委员会与办公室的分工，不要逐条念。",
    "师资名单只念三到四位代表，重点说海外博士占比过半与业界导师参与项目制教学。",
    "三个方向各一句话：金融科技打基础、智能金融重应用、区块链讲合规，提问环节再展开。",
    "大数字页：直接说招生规模与增幅，其余指标一句话带过，留时间给下一页。",
    "对比页要诚实：优势三条讲证据，短板两条讲风险，改进方向落到具体动作。",
    "评估页按五维念结论句即可，每维不超过一句，重点在最后的总体判断。",
    "结论三条需要放慢语速，每条后停顿一拍，方便听众记录。",
    "收尾感谢并提示资料来源，主动说明数据口径与更新时点。",
]


def run(*a, check=True):
    r = subprocess.run(list(a), capture_output=True, text=True)
    if check and r.returncode != 0:
        print("CMD FAIL:", " ".join(a)[:120], r.stderr.strip()[-160:]); sys.exit(1)
    return r.stdout


def issue_count(deck):
    out = run("officecli", "view", deck, "issues")
    m = re.search(r"Found (\d+) issue", out)
    return (int(m.group(1)) if m else 0), out


def issue_slides(out):
    return len(set(re.findall(r"/slide\[(\d+)\]", out)))


def est_lines(text, size, width_cm):
    cw = size * 1.2
    eff = width_cm * PT2CM - 14.4  # pt
    per = max(1, int(eff // cw))
    return math.ceil(len(text) / per)


def height_cm(text, size, width_cm, old):
    if old:
        return round(size * 0.05, 2)
    return round((est_lines(text, size, width_cm) * size * 1.2 + 7.2) / PT2CM, 2)


def build(tag, old):
    deck = f"{tag}.pptx"
    run("officecli", "create", deck); run("officecli", "open", deck)
    cmds = 0
    for i, pg in enumerate(PAGES, 1):
        run("officecli", "add", deck, "/", "--type", "slide", "--prop", "layout=blank"); cmds += 1
        run("officecli", "add", deck, f"/slide[{i}]", "--type", "shape", "--prop", f"text={pg['title']}",
            "--prop", "x=1.5cm", "--prop", f"y={pg['y']}cm", "--prop", f"width={pg['w']}cm",
            "--prop", f"height={height_cm(pg['title'], pg['size'], pg['w'], old)}cm",
            "--prop", f"size={pg['size']}", "--prop", "bold=true"); cmds += 1
        for text, size, w, y in pg["blocks"]:
            run("officecli", "add", deck, f"/slide[{i}]", "--type", "shape", "--prop", f"text={text}",
                "--prop", "x=1.5cm", "--prop", f"y={y}cm", "--prop", f"width={w}cm",
                "--prop", f"height={height_cm(text, size, w, old)}cm", "--prop", f"size={size}"); cmds += 1
        run("officecli", "add", deck, f"/slide[{i}]", "--type", "notes", "--prop", f"text={NOTES[i-1]}"); cmds += 1
    run("officecli", "close", deck); run("officecli", "validate", deck)
    return deck, cmds


print("=" * 66)
print("slide-master pilot_verify — P0 对照 + 两段式")
print("=" * 66)

deckA, cmdsA = build("A_old", old=True)
nA, outA = issue_count(deckA)
print(f"[A 旧协议 0.05cm/pt]      首轮 issues = {nA}（涉及 {issue_slides(outA)} 页，命令 {cmdsA}）")

deckB, cmdsB = build("B_new", old=False)
nB, outB = issue_count(deckB)
print(f"[B 新协议 P0 公式]        首轮 issues = {nB}（涉及 {issue_slides(outB)} 页，命令 {cmdsB}）")

fixed = 0
for m in re.finditer(r"(/slide\[\d+\]/shape\[@id=\d+\])[^\n]*?suggest\.height=([\d.]+)cm", outA):
    run("officecli", "set", deckA, m.group(1), "--prop", f"height={m.group(2)}cm", check=False)
    fixed += 1
run("officecli", "close", deckA, check=False)
nA2, _ = issue_count(deckA)
print(f"[A' 采纳 suggest.height]  修复 {fixed} 框后 issues = {nA2}")

nE = notesE = -1
if shutil.which("pandoc"):
    md = "E_slides.md"
    with open(md, "w", encoding="utf-8") as f:
        f.write("---\ntitle: 深圳南特金融科技学院调研简报\nauthor: slide-master\n---\n\n")
        for i, pg in enumerate(PAGES):
            f.write(f"## {pg['title']}\n\n")
            for text, size, w, y in pg["blocks"]:
                f.write(f"- {text}\n")
            f.write(f"\n::: notes\n{NOTES[i]}\n:::\n\n---\n\n")
    run("pandoc", md, "-t", "pptx", "-o", "E.pptx", "--slide-level=2")
    nE, outE = issue_count("E.pptx")
    notesE = len(json.loads(run("officecli", "query", "E.pptx", "notes", "--json"))["data"]["results"])
    line1 = run("officecli", "view", "E.pptx", "outline").split("\n")[0].strip()
    print(f"[E 两段式 pandoc]         issues = {nE}；{line1}；notes = {notesE}；构建命令 = 1（vs officecli {cmdsB}）")
else:
    print("[E 两段式] SKIP（pandoc 不在 PATH）")

notesA = len(json.loads(run("officecli", "query", "A_old.pptx", "notes", "--json"))["data"]["results"])
notesB = len(json.loads(run("officecli", "query", "B_new.pptx", "notes", "--json"))["data"]["results"])

print("-" * 66)
print(f"指标1 首轮 issues：基线 83 → 旧协议 {nA} / 新协议 {nB}（目标 ≤10：{'达标' if 0 <= nB <= 10 else '未达标'}）")
print(f"指标2 结构性返工页：旧 {issue_slides(outA)} / 新 {issue_slides(outB)}（目标 ≤1）")
print(f"指标3 修复闭环：采纳 suggest.height 后 {nA2}（目标 0）")
print(f"指标4 notes：A {notesA}/10  B {notesB}/10  E {notesE}/{len(PAGES)}")
shutil.rmtree(WORK, ignore_errors=True)
