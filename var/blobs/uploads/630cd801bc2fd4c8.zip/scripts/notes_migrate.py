#!/usr/bin/env python3
"""notes_migrate — 把 notes 从旧 deck 按页序迁移到新 deck（两段式 2c 版式重做时零重写备注）。

实测依据：pandoc 产出的 pptx 的 notes 可被 officecli 完整读出（query notes --json），
本脚本按 /slide[N]/notes 的 N 对齐写入新 deck。

用法：
  python3 notes_migrate.py <旧deck.pptx> <新deck.pptx> [--dry-run] [--overwrite]
退出码：0 成功；1 失败（含页数不匹配但已尽力迁移的情形，会列出缺页）。
"""
import subprocess, sys, json, argparse


def query_notes(deck):
    r = subprocess.run(["officecli", "query", deck, "notes", "--json"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print("ERROR: query notes 失败:", r.stderr.strip()[-200:], file=sys.stderr)
        sys.exit(1)
    out = {}
    for item in json.loads(r.stdout).get("data", {}).get("results", []):
        p = item.get("path", "")
        if "/slide[" in p:
            n = int(p.split("/slide[")[1].split("]")[0])
            out[n] = item.get("format", {}).get("text", "")
    return out


def slide_count(deck):
    r = subprocess.run(["officecli", "view", deck, "outline"], capture_output=True, text=True)
    first = (r.stdout or "").splitlines()[0] if r.stdout else ""
    for tok in first.replace("|", " ").split():
        if tok.isdigit():
            return int(tok)
    return 0


def main():
    ap = argparse.ArgumentParser(description="按页序迁移 speaker notes")
    ap.add_argument("old_deck")
    ap.add_argument("new_deck")
    ap.add_argument("--dry-run", action="store_true", help="只报告将要迁移的内容，不写入")
    ap.add_argument("--overwrite", action="store_true", help="新 deck 已有 notes 时也覆盖（默认跳过并提示）")
    args = ap.parse_args()

    src = query_notes(args.old_deck)
    if not src:
        print(f"WARN: {args.old_deck} 中未找到任何 notes"); sys.exit(1)
    total = slide_count(args.new_deck)
    print(f"源 notes {len(src)} 条（pages {sorted(src)}）；目标 deck {total} 页")

    missing = [n for n in src if n > total]
    if missing:
        print(f"ERROR: 目标 deck 页数不足，以下页的 notes 无处安放：{missing}", file=sys.stderr)
        print("  请先补齐目标页数再迁移（新版式页顺序须与源一致）。", file=sys.stderr)

    dst_existing = query_notes(args.new_deck)
    migrated = skipped = 0
    for n in sorted(src):
        if n > total:
            continue
        if n in dst_existing and not args.overwrite:
            print(f"  slide[{n}]：目标已有 notes，跳过（用 --overwrite 覆盖）")
            skipped += 1
            continue
        text = src[n]
        if args.dry_run:
            print(f"  [dry-run] slide[{n}] ← {len(text)} 字：{text[:40]}…")
            migrated += 1
            continue
        r = subprocess.run(["officecli", "add", args.new_deck, f"/slide[{n}]",
                            "--type", "notes", "--prop", f"text={text}"],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print(f"  slide[{n}] 写入失败：{r.stderr.strip()[-120:]}", file=sys.stderr)
            continue
        migrated += 1
        print(f"  slide[{n}] ✔（{len(text)} 字）")

    print(f"迁移 {migrated} 条，跳过 {skipped} 条")
    if missing:
        sys.exit(1)
    print("MIGRATE OK")


if __name__ == "__main__":
    main()
