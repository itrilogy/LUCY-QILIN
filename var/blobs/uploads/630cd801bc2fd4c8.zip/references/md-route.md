# 自带 md 编译路线（无 pandoc）

> 数值与 Gate 定义以 `references/rules.md` 为准（本文件不重复定义）。

`md_compile.py` 把 markdown 直接编译成 officecli 构建脚本，**不依赖 pandoc**。
适用：已有结构化的 `*_slides.md`，想先出结构稿再精修；或只需要一份可交付的骨架。

## 1. 输入语法

```markdown
---
title: 季度复盘
subtitle: 运营中心 · 2026 Q2
---

# 章节（可选，无正文）

## 内容页标题

- 一条结论
- 一条证据

::: notes
这一页要讲什么；三拍：记住什么 / 凭什么 / 接下来。
:::
```

- `#`：没有 frontmatter title 时作为封面；否则作为章节页；
- `##`：内容页；
- `- `：项目符号；
- 普通段落：正文（正文与项目符号同页时，正文在上）；
- `::: notes … :::`：该页 speaker notes，必须有。

## 2. 编译

```bash
python3 scripts/validate_slides.py deck.md          # 预检语法/页结构
python3 scripts/md_compile.py deck.md --out build/ --theme light            # 只生成
python3 scripts/md_compile.py deck.md --out build/ --theme light --run      # 生成并出片
python3 scripts/md_compile.py deck.md --out build/ --theme dark --font "Microsoft YaHei" --run   # 指定主题与字体
```

`--theme`：`light | dark | ink`（取随包 `tokens.json` 的色板）；`--font`：`auto`（默认，macOS 用 PingFang SC、Windows 用 Microsoft YaHei）或显式字体族。

产物：`build/pages.json`（页模型）、`build/build_deck.py`（纯 officecli 调用）、`build/<name>.pptx`。

## 3. 2a / 2b / 2c 分流

| 分流 | 做法 | 何时用 |
|---|---|---|
| 2a 朴素交付 | `--run` 直接出片，Gate 1–5a 后交付 | 结构清晰、不要求设计感 |
| 2b 主题精修 | 读 `style-lookup.md` 选风格；把该风格的 bg/fg/accent 与字体写进 `build_deck.py` 的 `CALLS` 色值（或用 `--theme` 快速换档）后重跑；只改色/字，不动版式 | 有品牌或场景风格要求 |
| 2c 自由版式 | 以 `build_deck.py` 为骨架，按 `pptx-base.md` 的 recipes 改写形状；notes 用 `notes_migrate.py` 按页序迁移 | 需要非模板化版式 |

## 4. 能力边界（写清楚，别承诺过头）

- 支持：标题、副标题、章节页、项目符号、正文段落、逐页 notes；
- **不支持**：表格、图表、图片、自由分栏、Morph/3D——这些走 `pptx-base.md` / `morph-ppt.md` 的 recipes；
- 字体：默认 `PingFang SC`；非 macOS 交付前在目标 viewer 确认无缺字；
- 页面尺寸按 16:9（16:9（R4））由 officecli 默认版式决定。

## 5. 与质量门的关系

`md_compile` 只负责"结构正确"；`officecli validate` 与 Gate 1–5a 仍要逐条跑。
交付前必须确认：每页 notes 存在、字号达标、无越界、渲染已人眼看过。