## v2.0.1（当前）— 发布后清理

- 移除包内过程笔记（`doc/`），过程文档归集到项目 `docs/archive`。
- 清理与本机绑定的路径：资产抽取器改为 `--src`/`LUXI_SOURCE_HTML`，不再内置绝对路径。
- 字体按平台回退（Windows 用 Microsoft YaHei），`md_compile --font` 真正生效。
- 补齐 `LICENSE`；`.storeignore` 排除 `__pycache__`/`*.pyc`。
- 功能不变。

# slide-master 变更记录（CHANGELOG）

版本号见 frontmatter `version`。本文件记录架构级变更与修复决策，供维护与交接回溯。

## v2.0.0— 排云PRO：去 pandoc、图表资产、随包交付

- **更名**：产品名 **排云PRO**（`luxi.paiyun-pro` / `paiyun-pro`），与轻量版排云成序列。
- **图表资产**（`references/chart-assets.md`）：标准数据图与管理工具图 **MCP 优先**；插图与自由图形走自包含 SVG；降级链 MCP → 原生 chart → SVG/表格。
- **A+B 可编辑性**：默认位图交付；spec 写 `editable: true` 时额外产出 `<id>.editable.pptx`（原生 chart，可改数），单独交付。
- **不设 Seed 模板**：MCP 语法可能变更，DSL 一律以当次 `read_protocol` 为准。
- **门**：C1 数据保真、C6 非空白、C7 资产溯源、S1/S2 SVG、E1 可编辑版。
- **svg_lint.py**：自由图形 S1/S2 检查（自包含、字号、对比度，识别文字底色与透明度），接入自检 H 路线。
- **端到端实测**：ChartSpec → MCP（2880×1620）→ 资产索引 → 页内引用；B 模式原生 chart 逐系列调色；SVG 插图整页渲染通过。

- **移除 pandoc 依赖**：删除 `references/pandoc-route.md`、`references/pipeline.md`；新增 `references/md-route.md`。
- **自带编译器** `scripts/md_compile.py`：解析 `*_slides.md`（H1 封面/章节、H2 页、`- ` 项目符号、`::: notes`），生成纯 officecli 的 `build_deck.py` + `pages.json`，可选 `--run` 直接出片并 `validate`。
- **依赖收敛**：仅 officecli（≥1.0.148）与 python3（≥3.9）；缺 officecli 直接拒单，不再有 pandoc 兜底。
- **随包交付**：27 个风格模板与 references/scripts 随包；过程笔记移出包外（docs/archive），安装即完整。
- **自检更新**：`selfcheck.py` 的 E 路线由 pandoc 改为 md_compile 端到端（出片 + notes 落盘）。
- **定位独立**：不再与其它技能做仲裁；用户自行定向调用。
- **Windows 支持**：platforms 增加 `windows-arm64/amd64`；新增 `platform/windows.md`（install.ps1、Microsoft YaHei、路径与 bash 差异）；`md_compile --font auto` 按平台选字体。
- **规则单源**：新增 `references/rules.md`（R1–R6 视觉底线 + Gate 1–6 定义）；`rules_lint.py` 禁止在其它文档复述数值。
- **索引生成**：新增 `style_index.py`，`INDEX.md` 由磁盘 52 个目录生成（剔除 3 条残留），`--check` 进自检。
- **自检扩展**：A–G 七条路线（F=规则单源，G=索引一致）。
- 实测：md → 3 页 deck（封面 + 2 内容），notes 2/2 落盘，`officecli validate` 通过。

## v1.3.1— 鹿溪 SVG 资产化

- **资产抽取**：`styles/mixed--luxi-scenario/assets/` 新增 **30 个独立 SVG**（`xmllint` 全部通过）：
  **主 LOGO** `logo-lab-mark.svg`（2048，绿+青，官方路径原样）· **符号标** `logo-symbol-mark.svg`（48，currentColor 可着色）· **双标等大 lockup** `logo-lockup.svg`（140×64）· **23 枚语义图标**（`icons/`，24×24 stroke 1.7，按 `data-od-id` 命名 + `INDEX.md` 清单，如 跃鹿 YueLu/观澜/衡流）· **4 幅商品插画**（`illustrations/`，符号标已内联化保证独立可用）。
- **可重跑抽取器** `assets/extract_assets.py`：sprite symbol 原样导出；图标语义命名 + 生成清单；插画**平衡匹配**（正确处理嵌套 `<svg>`，修复了非贪婪截断导致的 2 处解析错误）。
- **可用性实测**：officecli `--type picture --prop src=x.svg` **直接支持 SVG** → 资产可即时用于 .pptx；规范要求插入必带 `alt`。
- **登记**：`assets/README.md`（清单/用法/品牌约束/再抽取）；style.md §8 资产节；tokens.json `assets` 段（含品牌规则 5 条）。
- 品牌约束落文：主标禁重绘 · 双标并排仅用 lockup · 符号标不占封面主位 · 每页点缀 ≤3 处 · 插图必带 alt。

## v1.3.0 — 鹿溪场景范式固定风格包 + 确定性路由

- **新风格包** `styles/mixed--luxi-scenario/`：吸收 LUCY-DESIGN 鹿溪场景套件（三主题 light/dark/ink × 完备 token × 四色基石 绿#0D5E42/青#00D2FF/金#F1C40F/源白#F5F7FA × L-U-X-I 法则）。含 `style.md`（排印 px→pt **投影映射**、组件 PPT 化、品牌规范）+ `tokens.json`（机器可读全量 token）。
- **确定性路由** `scripts/style_route.py`：按固定规则表输出唯一变体——`env==projection→luxi-dark`；`scene==immersive→luxi-ink`；否则 `luxi-light`；密度 `compact` 于 dashboard/workbench；scene 由**最长命中关键词**词典映射（同长按固定 priority）。**无随机、无打分、无模型判断**，同输入恒同输出。
- **接线**：style-lookup.md 增"确定性风格包"节（命中规则即采用，无需 ask）；INDEX.md 登记（主表 + Brand System/Scenario Kit 分组）；SKILL.md 脚本树与版本更新。
- 关键设计约束：网页 px **不可 1:1 转 pt**（0.75× 会破 PPT 投影底线）——采用固定投影档位映射（fs-body 14px→18pt、fs-h1 28px→36pt…）；PPT 无 box-shadow → 底色分层 + 描边替代。
- 实测：路由 4 用例全通过（投影→dark、看板→light/compact、品牌故事→ink、素材 md 自动判场景）。
- 风格库 **51 → 52**（新增本包）；全库计数同步（SKILL.md / style-lookup / morph-ppt / morph-ppt-3d / pptx-design / decision-rules mood 分布 mixed 4→5），磁盘为唯一事实源。

## v1.2.2 — layout_scan 落地 + 页脚几何约束 + notes 直写策略

- **T2/T3 落地**：`scripts/layout_scan.py`（零依赖几何扫描，纯标准库解析 `view html` 的 pt 级绝对坐标）→ Gate 3 升级为**双轨**（几何扫描 MUST + 截图判读可选）。实测价值：`view issues` 漏报页脚越界 7.9pt（issues=0 但实际出界），几何扫描精确捕获 38 条。
- **P0 §Gate 3 补充**：轻微越界不在 `view issues` 覆盖范围 → 交付前必须跑 layout_scan。
- **页脚几何教训**：页脚文字 y + 行高（`size×1.2pt + 7.2pt`）必须 ≤ 19.05cm；本次页脚 y=18.65 + 10pt 行高 0.68cm = 19.33cm → 越界 0.28cm（7.9pt）。修正为 y=18.22 + 9pt（18.86cm，底部留 0.19cm）。
- **notes 保障策略**：**从 md 直写 + 落盘复检**（md 为唯一事实源；写入后 close → 独立进程读回断言条数），不再依赖中间 deck 迁移。实测：13 条写入、落盘复检 13 条、zip 级验证 13 个 notesSlide（内容正确）。
- 已证实（最小实验）：officecli 的 open/set/close/add 操作**不会**破坏 pandoc 写入的 notes（A–D 四类操作后 notes 完好）——notes 丢失只可能来自脚本流程缺陷（如依赖他 deck 迁移且静默跳过），故改为直写并断言。
- 实战：《复盘简报》2c-v2 = 19 页 / 454 shapes / issues 0 / 几何越界 0 / notes 13。

## v1.2.1 — P0 补充条款（多段行数）+ 2c 设计版实战验证

- **P0 §Text metrics 补充**：显式换行（`\n`/多段）的行数 = **Σ 各段行数**——按整串字符数一次计算会漏算，多段文本必溢出（实战暴露并修正）。
- **溢出闭环强化**：修复步骤改为"close → 读 issues → 采纳 suggest.height → close"循环（`view issues` 输出可能滞后于写盘，须落盘后复检）。
- **实战数据（《复盘简报》2c 设计版）**：19 页自由版式（蓝图网格体系：网格底纹/金线/卡片/KPI/阶梯时间线/页脚）；修正多段行数后 **首轮 issues = 0**、validate PASS、notes 13 条迁移（`notes_migrate.py`）。对照复盘基线（首轮 83）与 2b 版（首轮 1）。

## v1.2.0 — 两段式流水线 + pandoc 路线合并 + P0 文本度量

- **两段式流水线**（`references/pipeline.md` 新）：文本期（markdown，便宜）与几何期（officecli 版式，贵）分离；分流 **2a 朴素交付 / 2b 主题精修(--reference-doc) / 2c 自由版式重做**；附实测成本模型（SAFTI 基线：朴素场景省 ≈90%，精修省 ≈20-30%）。
- **吸收 pandoc-slide-compiler 精髓**（`references/pandoc-route.md` 新）：编译命令与 `--slide-level=2` 铁律、YAML/层级铁律、语法全量（incremental/暂停/双栏/表格/图片/背景图）、`::: notes` 强制块、**5 风格备注字数档**、内容约束、不支持项清单、自检清单；`scripts/validate_slides.py`（400 行校验器）与 `scripts/notes_migrate.py`（notes 按页序迁移、零重写）入共享脚本层。原独立技能保留为直接入口，规范以本技能为准。
- **P0 文本度量协议**（pptx-base §Text metrics 新，实测校准）：
  - 内边距 **上下 3.6pt / 左右 7.2pt**；行高 **1.2×size**；`need=行数×size×1.2pt`、`usable=框高pt−7.2pt`；
  - **中文全角字宽 = 1.2×size pt（0.0423cm/pt）**（修正复盘自研 0.0353 → 偏小 20%，是其 C2 溢出的技术根因）；
  - 最小高速查表（9.5–44pt）+ 标题单行宽度速查（36pt ≤16 全角，修正复盘"≤20"偏乐观）；
  - **修复第一手段 = 直接采纳 `view issues` 的 `suggest.height`**；footer 保留区（内容底 ≤17.9cm）；
  - 修正旧 rule of thumb（0.05cm/pt 偏小）；中文节修正为"**单写 `font=` 即双槽生效**，无需双写"（实测）。
- **speaker-notes 合流**：5 风格字数档 + 按页数/时长反推（12 页≈15min→≤210 字/页）。
- **description/决策树/边界接线**：L1 分支改为两段式；DO NOT 移除 pandoc 条（已并入）；触发词补"md 转 PPT"。
- 实测依据：pandoc 3.10.1 编译 → officecli 读取 notes 逐页落盘 → notes_migrate 迁移 PASS。
- **试点验证（`scripts/pilot_verify.py`，复盘 §5.3 对照实验）**：同素材 10 页中文高密度 deck——
  **首轮 issues：旧协议(0.05cm/pt) 33 条/10 页返工 → 新协议(P0) 0 条/0 页返工**（目标 ≤10，达标）；
  采纳 `suggest.height` 修复闭环 33→0（一轮归零）；两段式 pandoc **1 条命令 vs officecli 63 条**、issues 0、notes 10/10 落盘。
  （验证中曾暴露 pilot 脚本自身 cm→pt 系数笔误，已修正——系数正确性由 `view issues` 独立复核。）

## v1.1.0 — 工程化补齐 + 生产过程规范

- **新增 references/scaffold.md**：任务工作区、单次构建纪律（officecli resident/close 落盘）、过程产物生命周期表、交付核对清单、失败恢复（修脚本整建重跑）。**v1.1.0 修订：默认产出即当前工作目录（workdir），不另建任务文件夹**——子目录仅 `inputs/`（素材多时）与 `.previews/`（过程预览，交付前删除）；大型共享目录等例外按用户指示或 ask。
- **新增 references/speaker-notes.md**：每页演讲者备注内容规范（三拍口述结构 / 45–90s / 口语化与数字出处 / 分场景侧重 / 质量 REJECT 规则）——与各子技能"notes 必须有"硬规则配套。
- **接线**：SKILL.md 调度纪律前置"工作区与备注"；pptx-base/pitch-deck/morph-ppt/morph-ppt-3d 的 speaker-notes 规则行指向 speaker-notes.md。
- **元数据**：frontmatter 增 version/tags/category；SKILL.md 尾增"维护与溯源"；清理技能目录 .DS_Store。
- **回归固化**：scripts/selfcheck.py（pptx-base/pitch-deck/morph-ppt 三路线端到端断言）。
- 来源版本基线：早期 officecli 技能集（不再追踪上游仓库）。

## v1.0.x — 架构整合与审核修复（迁移记录，源自本技能成型期）

### 架构整合
- 整合 officecli-pptx/pitch-deck/morph-ppt/morph-ppt-3d 四个子技能；子技能定义平铺为 references/*.md（受管形态 MODULE，非独立 SKILL.md）。
- 资源上提共享层：styles/（51 风格库）、scripts/（morph_helpers.py / morph-helpers.sh）、decision-rules.md、pptx-design.md、style-lookup.md（通用流程抽象）。
- 风格查找抽象为跨路线 style-lookup.md；总控 SKILL.md 决策树（L0-L4 + ask 逐层 + Reverse handoff）。

### 四维审核修复（G1–G5 / H1–H6）
- G1 风格库数量统一为磁盘事实 51（原多处 52/55/50+ 漂移）；INDEX 标注 3 个上游缺失条目（dark--tech-cosmos / warm--creative-marketing / warm--minimal-brand）。
- G2 morph-ppt 交付提醒去除宿主残留文案。
- G3 style-lookup 增"风格缺失回退"。
- G4 decision-rules 头部放宽为所有路线通用（不再绑定 morph）。
- G5 SKILL.md 相对路径基准注记（references/ 基准，../scripts 勿二次解析）。
- H1 **clean-accumulation 逻辑矛盾修复**：原实现按全局 `/shape[@id=]` 删除（CLI 实测拒绝："Cannot resolve @id= outside of a slide context"）+ 会删 `!!` ghost（违反 "never delete !! shape" 配对纪律）。重写为：按 query 返回完整 slide 路径删除、只删 `#sN-*` content ghost、`!!` ghost 永不删、阈值与 final-check 对齐 max(50, slides×4)；端到端冒烟 PASS。
- H2 morph-ppt-3d 删除整表重复的 10 色板/8 字体，改引用 pptx-base 单一事实源；H4 的 16pt floor 对齐 base ≥18pt。
- H3 morph-ppt-3d 增模型下载网络失败兜底（大陆网络不可达时重试/请用户提供/降级无模型）。
- H4 中文字体规则上提 pptx-base §Font pairings「中文排版」（思源黑体/PingFang/雅黑、禁拉丁衬线排中文）。
- H5 helpers clone/transition 增加 rc 检查与 sys.exit(1)。
- H6 final-check 阈值文档统一为 max(50, slides×4)。
- 附带：morph-helpers.py 改名 morph_helpers.py（可 import）；scripts/ 统一层。

### 运行级验证
- officecli 1.0.148 实测：`--type 3dmodel`/roty、geometry=preset 别名、chart colors/axismin、table data=、add --from 克隆、query shape[x>=34cm]、view outline 均与文档一致。
- 三路线端到端 PASS（中文内容/$ 转义/notes/validate/Gate 检查）。

### description 收敛（本技能形态期收尾）
- 原 description 过宽（decision-rules 叙事规划器/实现细节进触发面/裸词歧义）→ 收敛为"当且仅当产出或加工 .pptx"的交付契约 + 限定触发词 + 完整 DO NOT（word-form/financial-model/纯文本写作/叙述规划类）。
