# Style Library Lookup — 共享视觉风格查找流程

> 适用范围：**所有 .pptx 制作路线通用**（pptx-base 普通 deck、pitch-deck 融资路演、morph-ppt 动效 deck、morph-ppt-3d）。
> 风格库与 Morph 动画解耦——它是纯视觉语言资源（配色/字体/版式理念），任何路线都可在定稿前套用。
> 存放位置：`styles/`（本文件同目录），含 52 个视觉风格目录 + `styles/INDEX.md` 索引。

`styles/` 持有 52 个视觉风格目录（dark / light / warm / vivid / bw / mixed moods；含确定性风格包 luxi-scenario）——**设计灵感库，不是模板**。
按需查阅，不要整段搬运。

**Why lookup, not copy.** 每个 `build.sh` 都是完整风格演示，但其坐标针对该演示的内容长度手工调校。逐字复制到不同内容的 deck 会产生重叠与错位（见 `INDEX.md` L5-11）。风格库的价值是**设计逻辑**：按 mood 选配色、标志性形状、编排模式。把逻辑套用到你自己的网格计算上。

**四步查找：**

1. **浏览 INDEX。** `styles/INDEX.md` 按配色类别与 mood 分组全部 52 风格（如 `dark--premium-navy` = 权威/精致；`warm--earth-organic` = 有机/接地气）。Quick Lookup 表还给出每风格的**主色三元组**（bg / fg / accent）——若用户指定了品牌色，先扫 hex 列找最近匹配，不必逐个打开 `style.md`。选定 1 个匹配主题 mood 或贴近用户 hex 的风格。
2. **读理念。** 打开 `styles/<style-id>/style.md` 了解设计意图——字体搭配、配色逻辑、标志性元素。
3. **看技法。** 仅在需要实现参考时打开 `styles/<style-id>/build.sh`（标志性形状、色板 hex、编排思路）——**坐标已知有 bug（见 `INDEX.md` L5-11），不要照抄**。
4. **在自己的画布上应用。** 用 pptx 网格计算 + 视觉底线（见 `pptx-base.md` §Requirements / §Visual delivery floor）搭 deck，只借用配色与标志性手法。

**Pointer：** `→ 参见 styles/<style-id>/` —— 绝不内联复制风格 build.sh 的坐标。

**风格缺失回退（索引含 3 个上游残留条目）**：INDEX.md 头部已标注 `dark--tech-cosmos` / `warm--creative-marketing` / `warm--minimal-brand` 三个风格**磁盘无目录**（上游索引残留）。若第 1 步选中的风格落入三者，或打开 `styles/<id>/style.md` 报不存在：不卡住、不臆造——① 回 INDEX 按 mood / 用户品牌 hex 就近重选一个**存在**的风格；② 仍不匹配则直接问用户偏好；③ 绝不要编造 style.md 内容或照 build.sh 名字空跑。

## 确定性风格包：luxi-scenario（规则路由，非随机、非判断）

`styles/mixed--luxi-scenario/`（鹿溪场景范式，3 变体）**不走 mood/hex 主观匹配**——由 `scripts/style_route.py` 按固定规则表输出唯一结果，任何 agent 对同一输入得到同一变体：

```
variant = luxi-dark   if env == projection      # 投影/大屏/暗环境
        = luxi-ink    if scene == immersive     # 沉浸/文化/故事/深度阅读
        = luxi-light  otherwise
density = compact     if scene ∈ {dashboard, workbench} else regular
scene   = 关键词词典最长命中（length desc，同长按 priority）；无命中 → 缺省 marketing
```

```bash
python3 ../scripts/style_route.py --keywords "看板,KPI,数据大屏"     # → dashboard / luxi-light / compact
python3 ../scripts/style_route.py --scene immersive                 # → luxi-ink（serif-zh 墨底）
python3 ../scripts/style_route.py --scene dashboard --env projection # → luxi-dark / compact
python3 ../scripts/style_route.py --from-md <素材.md> --json         # 从素材自动判场景，机器可读 token
```

**命中规则即直接采用，无需 ask 用户**（满足"非随机或判断"）；输出含完整 tokens（背景/卡片/主色/强调/金/正文/字体）与 `type_scale_ppt_pt`、`radius_ppt_adj`，可直接驱动 officecli 命令。仅当规则输出与用户明示偏好冲突时才改由用户指定变体。规范细节见 `styles/mixed--luxi-scenario/style.md`（排印 px→pt 投影映射、组件 PPT 化、品牌四色基石规则）。

**编排时机（总控 slide-master 使用）：**
- 在 L2 场景确定后、内容铺排前询问用户是否套用风格（或按主题自动建议 1-2 个候选）。
- 若用户已给品牌色/风格词（如"瑞士国际主义""深色科技感"），直接走第 1 步 hex/mood 匹配，不必再问。
- Morph 路线的额外注意：风格选择还需匹配 morph choreography（见 `morph-ppt.md` §What is Morph? / §Morph Pair Planning）。
