# PPT 制作脚手架与过程产物规范（scaffold）

> 数值与 Gate 定义以 `references/rules.md` 为准（本文件不重复定义）。

> **Route-agnostic**：适用于 pptx-base / pitch-deck / morph-ppt / morph-ppt-3d 全部路线。
> 由 slide-master 在确认"从零制作或重做 .pptx"后、写任何 `officecli` 命令前建立工作区。
> 目的：让过程可重跑、产物可交付、中间件不散落、任何一步失败都能从脚本整建而不是手工续补。

## 1. 工作区布局（单任务 = 单目录）

```
<workdir>/                      ← 默认 = 当前工作目录（agent 的 workdir / 会话所在文件夹），产出物直接落此处顶层，不另建任务文件夹
├── inputs/                     ← 用户素材（图片/数据/原稿/logo）：仅在素材较多或需复制副本时建立；只读引用原件，不直接改
├── brief.md                    ← 规划产物（decision-rules / pitch-deck §Stage 诊断 / morph Pair Planning 输出）
├── <topic>.pptx                ← 目标 deck（主题短名：如 FY26-strategy-review）
├── build.sh 或 build.py        ← 可重跑构建脚本
└── .previews/                  ← 过程预览（view html、Gate 截图 png）——交付前删除，不留在工作目录
```

**默认即 workdir**：产出物（brief.md / deck / build 脚本）一律落当前工作目录顶层，**不默认创建子目录**。仅当用户素材大量、需要隔离时建 `inputs/`；过程预览放 `.previews/`（交付门通过后整目录删除）。若用户明确要求"放某处/新建文件夹"或当前 workdir 是大型共享目录（如笔记库根），才按用户指示落位或 ask 一次。

**命名**：deck / build 脚本 / brief 三者用同一主题短名（`FY26-review.pptx` + `build-FY26-review.py`），一眼可对应。

## 2. 构建纪律（officecli 实操基线）

1. **单次构建策略**：`officecli create` → `open` 一次 → **在同一进程内连续完成**全部 slide 的 add/batch → 内容齐后 `close` 落盘 → `validate`。不要在多个 shell 调用间分段操作同一文件（resident 驻留与落盘时序是头号坑）。
2. **不要依赖 auto-flush**：改动先驻留内存，闲置数秒才自动落盘。任何非 officecli 读取（预览器/上传/其它程序）前必须先 `close`（或 `save` 后仍保持 resident 的自觉）。`validate` 前也必须 `close`。
3. **逐页顺序**：`bg(含 decoration) → title → body/chart/connector → speaker notes`（notes 最后写，内容按 `speaker-notes.md` 规范）。每页一个结构操作后 `get --depth 1` 复核一次 shape id。
4. **批量用 batch heredoc**：多 shape 页用 `cat <<'EOF' | officecli batch "$FILE"`（单引号定界符关闭 shell 展开），单条命令见 pptx-base §Shell & Execution Discipline。
5. **位置即代码**：所有 x/y/width/height 写进 build 脚本，不手工点选；改动坐标改脚本再重跑，而非追加 set 修补。

## 3. 过程产物生命周期

| 产物 | 归属阶段 | 交付时 |
|---|---|---|
| `brief.md` | 规划（最先产出） | **保留**（设计记录，评审可回溯） |
| `build.sh/py` | 构建（与 deck 同步演进） | **保留**（可重跑 = 可复审） |
| `<topic>.pptx` | 构建 | **保留**（唯一对外交付文件） |
| `.glb`（3D 路线） | 素材 | **保留**（4 件套之一） |
| `.previews/*`、中间日志 | Gate 目检 | **可清理**（Gate 通过后整目录删除） |
| 其它临时文件 | — | **禁止产生**（outline.md / quality-report.md / 试错 deck 等一律不建，规划进 brief、校验输出进 stdout） |

**失败恢复**：构建中途失败 → 保留错误输出 → **修 build 脚本 → `rm` deck → 从 `create` 整建重跑**，禁止在残稿上手工续加形状（残稿状态不可复现，后续 Gate 无法审计）。

## 4. 交付核对清单（任何路线交付前过一遍）

- [ ] `officecli close` 已完成且 `validate` 无错误（Gate 1）
- [ ] `view issues` 无遗留（Gate 2）、文本无占位符（Gate 2b / 6.x）
- [ ] 每页 content slide 有 speaker notes，且**内容质量符合 `speaker-notes.md`**（不是"必须有"的摆设）
- [ ] 本路线 Gate 目检通过（pptx-base Gate 3 / pitch Gate 5b+6 / morph Gate 5b-morph-1..4）
- [ ] 三件套齐：`<topic>.pptx` + `build.*`（可从 fresh create 整建）+ `brief.md`（3D 路线另 + `.glb`）
- [ ] `.previews/` 已删除；工作目录外无散落产物
- [ ] 已按目标 viewer 提示用户目检渲染类特性（morph 动画 / 图表颜色 / 字体无缺字）

## 5. 异常处理

| 场景 | 处置 |
|---|---|
| `officecli` 报文件锁 / resident 冲突 | `close` 该文件后重试；检查是否有其它程序（预览器/Word）打开同文件 |
| 用户中途改了素材 | 素材只读引用 → 替换 `inputs/` 副本 → 改 build 脚本（路径/数值）→ 整建重跑 |
| 目标 viewer 不可用 | morph/动画/图表类特性如实告知用户需 PowerPoint/WPS/Keynote 目检，不声称已渲染验证 |
| 任务被中断 | 一切状态都在 build 脚本 + brief.md 中（脚本即状态），下次从 `create` 重跑即恢复 |