# Style Index

> **本文件由 `scripts/style_index.py` 从磁盘目录生成，不要手改。**
> 改风格：增删 `references/styles/<dir>/`，再跑 `python3 scripts/style_index.py --write`。

共 **52** 套（磁盘目录数）。Agent 先按本节表格用主色/场景初筛，再读 `<目录>/style.md`；
`build.sh` 只作实现技巧参考，**不要照抄坐标**（存在文字压叠等历史问题），版式底线见 `references/rules.md`。

主色列从 `build.sh` 的十六进制变量提取，缺失时退回 `style.md` 色板；`-` 表示没有可提取的主色。

## Dark Palette (dark)

| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |
| --- | --- | --- | --- | --- |
| dark--architectural-plan | architectural-plan | `#1C2B3A / #B8D4E0 / #F4C430` | Architectural design, business plans, real estate development | Professional, structured, architectural |
| dark--aurora-softedge | Aurora Softedge | `-` | Design portfolios, creative showcases, art galleries | Aurora-like, dreamy, artistic |
| dark--blueprint-grid | S15-blueprint-grid | `#1B3A5C / #4A90D9 / #FFFFFF` | Technical planning, engineering blueprints, system architecture | Precise, professional, engineered |
| dark--circle-digital | circle-digital | `#0D0E11 / #171A20 / #22252E` | Digital marketing, creative agencies, tech companies | Modern, dark-cool, digital |
| dark--cosmic-neon | Cosmic Neon | `#050510 / #8A2BE2 / #00FFFF` | Science talks, futuristic topics, physics, cosmic themes | Sci-fi, mysterious, futuristic, neon |
| dark--cyber-future | Cyber Future | `#0B0C10 / #66FCF1 / #1F2833` | Futuristic topics, tech vision, cyberpunk, AI/robotics | Futuristic, cyberpunk, immersive |
| dark--diagonal-cut | 09 Diagonal Cut | `#1A1A1A / #FF6600 / #FFCC00` | Industrial, engineering, construction, manufacturing | Rugged, powerful, bold |
| dark--editorial-story | 06-editorial-story | `#FFFFFF / #2C3E50 / #E74C3C` | Brand storytelling, editorial magazines, content releases | Narrative, artistic, premium |
| dark--investor-pitch | 08-investor-pitch | `#1A1A2E / #0F3460 / #16213E` | Investor pitches, fundraising decks, business plans | Professional, trustworthy, composed |
| dark--liquid-flow | Liquid Flow | `#0F0F2D / #6C63FF / #48E5C2` | Brand upgrades, creative launches, fashion showcases | Fluid, dreamy, avant-garde |
| dark--luxury-minimal | Luxury Minimal | `#111111 / #D4AF37 / #FFFFFF` | Luxury brands, premium products, high-end corporate | Luxurious, minimalist, sophisticated |
| dark--midnight-blueprint | Midnight Blueprint | `#080B2A / #181B55 / #131650` | Architecture firms, professional services, luxury real estate | Sophisticated, architectural, premium |
| dark--neon-productivity | Neon Productivity | `#0B0F1A / #2BE4A8 / #FFB020` | Productivity talks, tech workshops, motivation, startups | Energetic, modern, vibrant |
| dark--obsidian-amber | Obsidian Amber | `-` | Finance, investment, luxury services, premium consulting | Premium, sophisticated, powerful |
| dark--premium-navy | 05-premium-navy | `#0C1B33 / #C9A84C / #1E3A5F` | High-end corporate, annual strategy, board presentations | Authoritative, refined, premium |
| dark--sage-grain | Sage Grain | `#1E2720 / #FFFFFF / #D9B88F` | Creative agencies, boutique consultancies, organic brands | Organic, sophisticated, artisanal |
| dark--space-odyssey | Space Odyssey | `#0A0E27 / #1E3A5F / #4A5FFF` | Space/astronomy, science education, exploration narratives | Cosmic, inspiring, epic, exploratory |
| dark--spotlight-stage | S18-spotlight-stage | `#0A0A0A` | Keynotes, launch events, TED-style talks, galas | Dramatic, focused, theatrical |
| dark--velvet-rose | Velvet Rose | `-` | Luxury brands, premium fashion, high-end retail | Luxurious, elegant, refined |

## Light Palette (light)

| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |
| --- | --- | --- | --- | --- |
| light--bold-type | 08-bold-type | `#1A1A1A / #FF3C38` | Editorial layouts, magazine-style, brand manuals | Bold, modern, editorial |
| light--firmwise-saas | Firmwise SaaS | `#EFF2F7 / #7B3FF2 / #FFFFFF` | SaaS platforms, productivity tools, B2B software | Clean, efficient, trustworthy |
| light--fluid-gradient | Fluid Gradient | `-` | AI/tech products, SaaS platforms, modern software | Fluid, tech-forward, dynamic |
| light--glassmorphism-vc | Glassmorphism VC | `-` | VC funds, investment decks, fintech, startup pitches | Modern, premium, sophisticated |
| light--isometric-clean | S23-isometric-clean | `#F0F4F8 / #4A90D9 / #E8ECF1` | Tech products, SaaS platforms, data presentations | Fresh, modern, techy |
| light--minimal-corporate | 02-minimal-corporate | `#FFFFFF / #E8EEF4 / #1E3A5F` | Annual reports, work summaries, business proposals | Professional, clean, composed |
| light--minimal-product | 05-minimal-product | `#FAFAFA / #00B894 / #2D3436` | Product launches, tech showcases, brand introductions | Modern, minimalist, premium |
| light--project-proposal | 12-project-proposal | `#E8EEF4 / #1E3A5F / #D4A84B` | Project kickoffs, business proposals, bid presentations | Professional, trustworthy, rigorous |
| light--spring-launch | 07-spring-launch | `#E8F5E9 / #4CAF50 / #8BC34A` | Spring launches, new product releases, seasonal marketing | Fresh, natural, vibrant |
| light--training-interactive | 10-training-interactive | `#FFF9E6 / #FF6B6B / #4ECDC4` | Corporate training, online courses, knowledge sharing | Educational, interactive, friendly |
| light--watercolor-wash | S16-watercolor-wash | `#FFFDF7 / #7AADCF / #E8A87C` | Art, cultural creative, tea ceremony, weddings | Soft, poetic, artistic |

## Warm Palette (warm)

| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |
| --- | --- | --- | --- | --- |
| warm--bloom-academy | Bloom Academy | `-` | Education, e-learning, children's content, playful branding | Playful, educational, friendly |
| warm--brand-refresh | Brand Refresh | `#F5F0E8 / #162040 / #1A6BFF` | Brand launches, corporate image updates, creative proposals | Fashionable, colorful, modern |
| warm--coral-culture | Coral Culture | `-` | Company culture decks, HR presentations, team showcases | Warm, cultural, human-centered |
| warm--earth-organic | 04-earth-organic | `#F5F0E8 / #8B6F47 / #A8C686` | Eco-friendly, sustainability, organic brands | Warm, sincere, natural |
| warm--monument-editorial | Monument Editorial | `-` | Architecture, luxury brands, editorial magazines, studio branding | Monumental, refined, typographic |
| warm--playful-organic | Playful Organic | `#FFF8E7 / #3D3B3C / #FFFFFF` | Lifestyle, pet/animal topics, children's education, storytelling | Warm, playful, friendly |
| warm--sunset-mosaic | Sunset Mosaic | `-` | Engineering, infrastructure, B2B corporate, construction | Professional, warm, grounded |
| warm--vital-bloom | Vital Bloom | `-` | Wellness apps, yoga studios, mindful living, organic brands | Organic, vibrant, healthy |

## Vivid Palette (vivid)

| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |
| --- | --- | --- | --- | --- |
| vivid--bauhaus-electric | Bauhaus Electric | `-` | Creative agencies, design studios, bold branding | Bold, energetic, electric |
| vivid--candy-stripe | 10 Candy Stripe | `#FFFFFF / #FF5252 / #FF7B39` | Event celebrations, holidays, children's education | Joyful, lively, rainbow |
| vivid--energy-neon | Energy Neon | `#E8E8E8 / #00FF41 / #111111` | Conferences, energy summits, tech events, editorial | Energetic, impactful, modern |
| vivid--pink-editorial | Pink Editorial | `#160B33 / #7B2D52 / #C85080` | Annual reports, data journalism, editorial showcases | Contemporary, editorial, bold |
| vivid--playful-marketing | 03-playful-marketing | `#FFFFFF / #FF6B6B / #4ECDC4` | Marketing campaigns, new product promos, sales events | Youthful, energetic, passionate |

## Black & White (bw)

| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |
| --- | --- | --- | --- | --- |
| bw--brutalist-raw | Brutalist Raw | `#FFFFFF / #000000 / #FF0000` | Avant-garde art shows, experimental design, indie brands | Rebellious, rugged, impactful |
| bw--mono-line | 01-mono-line | `#FFFFFF / #1A1A1A / #C8C8C8` | Minimalist corporate, academic reports, consulting proposals | Calm, restrained, professional |
| bw--swiss-bauhaus | Swiss Bauhaus | `#E63322 / #1C1C1C / #F5F5F5` | Design agencies, architecture firms, art exhibitions | Rational, rigorous, classic |
| bw--swiss-system | Swiss System | `#FFFFFF / #000000 / #FF0000` | Corporate, finance, consulting, professional services | Clean, systematic, bold |

## Mixed / Brand Systems (mixed)

| Directory | Style Name | Primary hex (bg / fg / accent) | Best For | Mood |
| --- | --- | --- | --- | --- |
| mixed--bauhaus-blocks | Bauhaus Color Block | `#F0EBE0 / #1D5C38 / #F4C040` | Creative studios, design portfolios, branding agencies | Bold, modernist, geometric |
| mixed--chromatic-aberration | Chromatic Aberration | `#050814 / #0A1030 / #00F5E4` | Tech startups, AI platforms, creative technology | Futuristic, glitch, cyber |
| mixed--duotone-split | 12 Duotone Split | `#FFFFFF / #2D3436 / #E17055` | Brand launches, architectural design, premium showcases | Bold, architectural, minimal |
| mixed--luxi-scenario | Luxi Scenario Kit | `#0D5E42 / #00D2FF / #F1C40F` | 鹿溪场景套件：仪表盘/工作台/营销/沉浸/物料（**确定性路由**，非随机） | Multi-theme, brand, systematic |
| mixed--spectral-grid | Spectral Grid | `-` | Creative tech, innovation showcases, design conferences | Vibrant, innovative, experimental |
