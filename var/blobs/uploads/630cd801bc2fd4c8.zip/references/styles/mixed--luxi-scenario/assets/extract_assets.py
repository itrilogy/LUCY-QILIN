#!/usr/bin/env python3
"""extract_assets — 从鹿溪设计范式 HTML 抽取 SVG 资产（可重跑）。

源：LUCY-DESIGN/Sample/luxi-scenario-kit-final.html（默认；可用 --src 覆盖）
产物（本目录）：
  logo-lab-mark.svg     主 LOGO（2048 viewBox，绿 #0D5E42 + 青 #00D2FF 官方 path 原样）
  logo-symbol-mark.svg  符号标（48 viewBox，currentColor + --mark-accent 可着色）
  logo-lockup.svg       双标等大并排 lockup（各 64×64 居中，品牌规范）
  icons/*.svg           23 个语义图标 + play（24×24，stroke 1.7，金/青点缀）
  icons/INDEX.md        图标清单（语义 id + 中文名 + 描述）
  illustrations/*.svg   4 个商品预览插画（180×110，符号标已内联化，独立可用）

用法：python3 extract_assets.py [--src 路径] [--out 目录]
"""
import argparse, os, re, sys

DEFAULT_SRC = os.environ.get("LUXI_SOURCE_HTML", "")  # 由调用方传入：--src 或 LUXI_SOURCE_HTML
HERE = os.path.dirname(os.path.abspath(__file__))


def grab(html, anchor, needle, span=4000):
    """自 anchor 起 span 窗口内找首个 needle 正则匹配并返回。"""
    i = html.find(anchor)
    if i < 0:
        return None
    seg = html[i:i + span]
    m = re.search(needle, seg, re.S)
    return m.group(0) if m else None


def grab_svg(html, anchor, span=9000):
    """平衡匹配嵌套 <svg>：自 anchor 起找首个 svg 起点，按层级计数匹配到其闭合。"""
    i = html.find(anchor)
    if i < 0:
        return None
    j = html.find("<svg ", i)
    if j < 0 or j - i > span:
        return None
    depth = 0
    for m in re.finditer(r"<svg\b|</svg>", html[j:j + span]):
        if m.group(0).startswith("</"):
            depth -= 1
            if depth == 0:
                return html[j:j + m.end()]
        else:
            depth += 1
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=DEFAULT_SRC)
    ap.add_argument("--out", default=HERE)
    a = ap.parse_args()
    if not a.src:
        raise SystemExit("需要 --src <html> 或环境变量 LUXI_SOURCE_HTML；本工具不再内置本机路径。")
    html = open(a.src, encoding="utf-8").read()
    out = a.out
    os.makedirs(os.path.join(out, "icons"), exist_ok=True)
    os.makedirs(os.path.join(out, "illustrations"), exist_ok=True)

    # 1) 两个 symbol（官方路径原样）
    lab = re.search(r'<symbol id="luxi-lab-mark"[^>]*>(.*?)</symbol>', html, re.S)
    sym = re.search(r'<symbol id="luxi-symbol-mark"[^>]*>(.*?)</symbol>', html, re.S)
    if not (lab and sym):
        print("ERROR: 未找到 sprite symbol 定义", file=sys.stderr); sys.exit(2)
    lab_inner, sym_inner = lab.group(1).strip(), sym.group(1).strip()

    def svg(vb, inner, extra=""):
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}"{extra}>\n{inner}\n</svg>\n')

    open(os.path.join(out, "logo-lab-mark.svg"), "w", encoding="utf-8").write(
        svg("0 0 2048 2048", lab_inner))
    open(os.path.join(out, "logo-symbol-mark.svg"), "w", encoding="utf-8").write(
        svg("0 0 48 48", sym_inner, ' color="#0D5E42"'))

    # 2) lockup：双标等大并排（各 64×64，间距 12，总 140×64，居中基线）
    lock = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 64" width="140" height="64">\n'
        f'  <g transform="translate(0,0) scale(1.3333)" color="#0D5E42">{sym_inner}</g>\n'
        f'  <g transform="translate(76,0) scale(0.03125)">{lab_inner}</g>\n'
        '</svg>\n')
    open(os.path.join(out, "logo-lockup.svg"), "w", encoding="utf-8").write(lock)

    # 3) 语义图标（data-od-id="fut-*" / immersive-play）
    ids = re.findall(r'data-od-id="(fut-[a-z]+|immersive-play)"', html)
    rows, n = [], 0
    for tid in dict.fromkeys(ids):                     # 去重保序
        s = grab(html, f'data-od-id="{tid}"', r'<svg viewBox="0 0 24 24".*?</svg>')
        if not s:
            continue
        name = grab(html, f'data-od-id="{tid}"', r'font-weight:600;font-size:13px;">([^<]+)', 1500)
        desc = grab(html, f'data-od-id="{tid}"', r'font-size:12px;color:var\(--text-muted\);">([^<]+)', 1500)
        fn = tid.replace("immersive-", "") + ".svg"
        body = re.sub(r'^<svg ', '<svg color="#0D5E42" ', s, count=1)
        open(os.path.join(out, "icons", fn), "w", encoding="utf-8").write(svg("0 0 24 24",
             re.sub(r'^<svg[^>]*>|</svg>$', '', body).strip(), ' color="#0D5E42"'))
        rows.append((tid, fn, (name or "").strip(), (desc or "").strip()))
        n += 1

    with open(os.path.join(out, "icons", "INDEX.md"), "w", encoding="utf-8") as f:
        f.write("# 鹿溪图标集（assets/icons）\n\n")
        f.write("统一规格：`viewBox 0 0 24 24` · `stroke-width 1.7` · `round` 线帽 · "
                "主色取 `color`（默认 #0D5E42，可覆写）· 金 #F1C40F / 青 #00D2FF 为点缀（固定）。\n\n")
        f.write("| 文件 | 语义 id | 名称 | 用途 |\n|---|---|---|---|\n")
        for tid, fn, name, desc in rows:
            f.write(f"| `{fn}` | `{tid}` | {name} | {desc} |\n")
        f.write(f"\n共 {len(rows)} 枚。\n")

    # 4) 商品插画（180×110；<use> 符号标内联化以保证独立可用）
    merch = {}
    for mid in ("merch-card", "merch-tumbler", "merch-pin-metal", "merch-tote-bag"):
        s = grab_svg(html, f'data-od-id="{mid}"')
        if not s:
            continue
        inline = (f'<g transform="scale(0.625)" color="#0D5E42">'
                  f'<g transform="translate(32,41.6) scale(1)">{sym_inner}</g></g>')
        s2 = re.sub(r'<svg[^>]*aria-label="鹿溪符号标"[^>]*>\s*<use[^>]*/>\s*</svg>',
                    f'<g transform="translate(20,26)">{inline}</g>', s, flags=re.S)
        open(os.path.join(out, "illustrations", mid + ".svg"), "w", encoding="utf-8").write(s2 + "\n")
        merch[mid] = True

    print(f"抽取完成 → {out}")
    print(f"  logo-lab-mark.svg / logo-symbol-mark.svg / logo-lockup.svg")
    print(f"  icons/：{len(rows)} 枚 + INDEX.md")
    print(f"  illustrations/：{len(merch)} 个（{', '.join(merch)}）")


if __name__ == "__main__":
    main()
