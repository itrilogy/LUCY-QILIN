# 鹿溪图标集（assets/icons）

统一规格：`viewBox 0 0 24 24` · `stroke-width 1.7` · `round` 线帽 · 主色取 `color`（默认 #0D5E42，可覆写）· 金 #F1C40F / 青 #00D2FF 为点缀（固定）。

| 文件 | 语义 id | 名称 | 用途 |
|---|---|---|---|
| `fut-yuelu.svg` | `fut-yuelu` | font-weight:600;font-size:13px;">跃鹿 · YueLu | font-size:12px;color:var(--text-muted);">任务规划与智能体执行 |
| `fut-xunxi.svg` | `fut-xunxi` | font-weight:600;font-size:13px;">巡溪 · XunXi | font-size:12px;color:var(--text-muted);">全景流程巡检与监控 |
| `fut-mingjian.svg` | `fut-mingjian` | font-weight:600;font-size:13px;">鸣涧 · MingJian | font-size:12px;color:var(--text-muted);">事件感知与应急分发调度 |
| `fut-duyue.svg` | `fut-duyue` | font-weight:600;font-size:13px;">渡越 · DuYue | font-size:12px;color:var(--text-muted);">异构多系统协同与跨越 |
| `fut-lingtong.svg` | `fut-lingtong` | font-weight:600;font-size:13px;">灵瞳 · LingTong | font-size:12px;color:var(--text-muted);">工业多模态高精视觉感知 |
| `fut-xunji.svg` | `fut-xunji` | font-weight:600;font-size:13px;">寻迹 · XunJi | font-size:12px;color:var(--text-muted);">空间定位与三维位姿还原 |
| `fut-ganjie.svg` | `fut-ganjie` | font-weight:600;font-size:13px;">感界 · GanJie | font-size:12px;color:var(--text-muted);">触觉阵列与物理传感融合 |
| `fut-chengxi.svg` | `fut-chengxi` | font-weight:600;font-size:13px;">澄溪 · ChengXi | font-size:12px;color:var(--text-muted);">数据深度清洗与知识蒸馏 |
| `fut-suyuan.svg` | `fut-suyuan` | font-weight:600;font-size:13px;">溯源 · SuYuan | font-size:12px;color:var(--text-muted);">因果逻辑推断与可解释性回溯 |
| `fut-yanzhen.svg` | `fut-yanzhen` | font-weight:600;font-size:13px;">衍真 · YanZhen | font-size:12px;color:var(--text-muted);">蒙特卡洛仿真与多态推演 |
| `fut-wudao.svg` | `fut-wudao` | font-weight:600;font-size:13px;">悟道 · WuDao | font-size:12px;color:var(--text-muted);">大模型深层认知与决策中枢 |
| `fut-zhuji.svg` | `fut-zhuji` | font-weight:600;font-size:13px;">筑基 · ZhuJi | font-size:12px;color:var(--text-muted);">弹性基础设施与算力底座调度 |
| `fut-cuilian.svg` | `fut-cuilian` | font-weight:600;font-size:13px;">淬炼 · CuiLian | font-size:12px;color:var(--text-muted);">模型微调、蒸馏与强化对齐 |
| `fut-zhugui.svg` | `fut-zhugui` | font-weight:600;font-size:13px;">铸规 · ZhuGui | font-size:12px;color:var(--text-muted);">安全合规门限与防护网关 |
| `fut-mogui.svg` | `fut-mogui` | font-weight:600;font-size:13px;">墨规 · MoGui | font-size:12px;color:var(--text-muted);">开放 SDK 与开发者工具链 |
| `fut-qilin.svg` | `fut-qilin` | font-weight:600;font-size:13px;">栖林 · QiLin | font-size:12px;color:var(--text-muted);">集群资产管理与资源池沉淀 |
| `fut-qingxiu.svg` | `fut-qingxiu` | font-weight:600;font-size:13px;">青岫 · QingXiu | font-size:12px;color:var(--text-muted);">微型嵌入式边缘算力端 |
| `fut-yunze.svg` | `fut-yunze` | font-weight:600;font-size:13px;">云泽 · YunZe | font-size:12px;color:var(--text-muted);">湖仓一体异构数据汇聚 |
| `fut-yinquan.svg` | `fut-yinquan` | font-weight:600;font-size:13px;">隐泉 · YinQuan | font-size:12px;color:var(--text-muted);">隐私计算与零知识隔离沙箱 |
| `fut-zhuoying.svg` | `fut-zhuoying` | font-weight:600;font-size:13px;">濯缨 · ZhuoYing | font-size:12px;color:var(--text-muted);">模型自净与对抗样本清洗 |
| `fut-fanzhou.svg` | `fut-fanzhou` | font-weight:600;font-size:13px;">泛舟 · FanZhou | font-size:12px;color:var(--text-muted);">低代码人机协同向导 |
| `fut-shaolu.svg` | `fut-shaolu` | font-weight:600;font-size:13px;">哨鹿 · ShaoLu | font-size:12px;color:var(--text-muted);">前哨威胁侦测与雷达哨兵 |
| `fut-guipu.svg` | `fut-guipu` | font-weight:600;font-size:13px;">归朴 · GuiPu | font-size:12px;color:var(--text-muted);">模型剪枝压缩与边缘轻量归一 |

共 23 枚。
