# 鹿溪风格包 · SVG 资产集（assets/）

> 从鹿溪设计范式源（`LUCY-DESIGN/Sample/luxi-scenario-kit-final.html`）抽取的**可复用图片点缀素材**。
> 全部为独立 SVG（`xmllint` 校验通过），**可直接插入 .pptx**（officecli 实测支持 `--type picture --prop src=x.svg`）。

## 资产清单

| 文件 | 规格 | 用途 |
|---|---|---|
| `logo-lab-mark.svg` | 2048×2048 · 绿 `#0D5E42` + 青 `#00D2FF` | **主 LOGO**（官方路径原样，禁用重绘）——封面/末页/页眉 |
| `logo-symbol-mark.svg` | 48×48 · `color` 与 `--mark-accent` 可变 | **符号标**（角本位 Y+一横）——页脚/卡角/小尺寸点缀 |
| `logo-lockup.svg` | 140×64 · 双标等大并排居中 | 品牌规范「双标等大」lockup——品牌页/物料页 |
| `icons/*.svg` | 24×24 · stroke 1.7 · 金/青点缀 | 23 枚语义图标（清单见 `icons/INDEX.md`：跃鹿/观澜/衡流…） |
| `illustrations/*.svg` | 180×110 / 120×150 / 130×130 | 4 幅商品预览插画（名片/保温杯/金属徽章/帆布袋；符号标已内联化） |

## 使用规范（PPT 场景）

1. **插入方式**（实测 officecli）：
   ```bash
   officecli add "$FILE" /slide[N] --type picture \
     --prop src=<assets>/logo-symbol-mark.svg \
     --prop x=1.5cm --prop y=1cm --prop width=2cm --prop height=2cm --prop alt="鹿溪符号标"
   ```
   - SVG 按 width/height 等比缩放；**必须带 `alt`**（交付门要求 pictures 无 alt 为零）。
2. **着色**：图标与符号标用 `currentColor`；独立文件中已默认 `color="#0D5E42"`——需换色时改文件根 `color`（或另存品牌色变体）。
3. **品牌规范**（不可违背）：
   - 主 LOGO 只用本资产（官方路径），**任何场合不得重绘/变形/加描边**；
   - 「双标等大」并排时用 `logo-lockup.svg`，不手工拼两个不同尺寸的标；
   - 符号标用于点缀，不替代主 LOGO 出现在封面主位；
   - 装饰性点缀**密度克制**：每页 ≤3 处图标/点缀，避免与内容争焦点（pptx-base「less is more」）。
4. **与配色的配合**：图标点缀色（金/青）是设计的一部分；底色按 `tokens.json` 变体（light/dark/ink）取，深色变体下 `color` 改 `#F5F7FA` 或青。

## 再抽取（源更新时）

```bash
python3 assets/extract_assets.py                 # 默认源：LUCY-DESIGN/Sample/luxi-scenario-kit-final.html
python3 assets/extract_assets.py --src <新源.html> --out .
```
脚本特性：sprite symbol 原样导出；图标按 `data-od-id` 语义命名并生成 `icons/INDEX.md`；插画用**平衡匹配**抽取（正确处理嵌套 `<svg>`）并把符号标内联化，保证独立可用。
