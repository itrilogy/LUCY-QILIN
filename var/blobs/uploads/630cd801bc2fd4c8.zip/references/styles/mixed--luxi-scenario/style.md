# Luxi Scenario Kit — 鹿溪场景范式（固定风格包）

> **包 ID**：`mixed--luxi-scenario`（多主题风格包，含 3 个确定性变体）
> **来源**：`LUCY-DESIGN/Sample/luxi-scenario-kit-final.html`（鹿溪设计范式 · 全场景参考套件）
> **性质**：**确定性风格包**——变体由 `scripts/style_route.py` 按固定规则表选取（非随机、非主观判断）；
> 一条命令产出变体与全部 token，任何 agent 对同一输入得到同一结果。
> 品牌内驱："林深见鹿，源启清溪"；法则 L·Link 连接 / U·Unveil 揭示 / X·X-Factor 变量 / I·Iterate 迭代。

## 1. 三个变体与确定性选取（唯一规则）

```
variant = luxi-dark   if env == projection        # 投影/大屏/暗环境
        = luxi-ink    if scene == immersive       # 沉浸/文化/故事/深度阅读
        = luxi-light  otherwise                   # 其余全部
density = compact     if scene in {dashboard, workbench}
        = regular     otherwise
```

- `env` 由**环境判据**唯一决定：用户提到投影/大屏/会场/暗环境 → `projection`；否则 `light`。
- `scene` 由 `style_route.py` 的**固定关键词词典**映射（命中即定；**最长命中词优先**，长度相同再按 `dashboard > workbench > marketing > immersive > collateral` 优先级）——两步都是确定性判据，无主观打分：
  | scene | 关键词（命中任一即入） | 典型用途 |
  |---|---|---|
  | `dashboard` | 看板、仪表盘、KPI、监控、指标、数据大屏、报表 | 运营/监控/汇报数据页 |
  | `workbench` | 工作台、后台、审批、流程、工单、系统操作 | 系统培训/操作手册 |
  | `marketing` | 营销、发布、招募、宣传、推广、品牌、活动 | 对外发布/招募 deck |
  | `immersive` | 沉浸、播放、文化、故事、阅读、人文、叙事 | 文化/品牌故事/深度讲解 |
  | `collateral` | 物料、清单、信笺、周边、Checklist、规范、设计范式、设计系统、套件 | 品牌物料/检查清单/设计规范页 |
- **无随机、无打分、无模型判断**：同一（scene, env）输入永远得到同一变体。

## 2. 三主题 token（唯一事实源；同步于 `tokens.json`）

| token | light | dark | ink（墨·衬线） |
|---|---|---|---|
| 主色 primary | `#0D5E42` | `#14805C` | `#14805C` |
| primary hover/active | `#127A55` / `#0A4A33` | `#17946B` / `#0D5E42` | 同 dark |
| 强调 accent（青） | `#00D2FF` | `#00D2FF` | `#00D2FF` |
| 基石 gold | `#F1C40F` | `#F1C40F` | `#F1C40F` |
| 页底色 bg-page | `#F5F7FA` | `#121A17` | `#0B0C0E` |
| 卡片 bg-card | `#FFFFFF` | `#1A2428` | `#141517` |
| 抬升/下沉 | `#FFFFFF` / `#EEF2F5` | `#22302B` / `#0E1613` | `#1B1D20` / `#08090A` |
| 主文本 text | `#1A2428` | `#E6EFEA` | `#F3EEE6` |
| 次文本 | `#42525C` | `#C3D3CB` | `rgba(243,238,230,.78)` |
| 弱文本 muted | `#64748B` | `#8FA3BF` | `rgba(243,238,230,.55)` |
| 描边（green 透） | 10% / 18% / 32% | 白 8% / 14% / 28% | 暖白 8% / 14% / 26% |
| **字体 body/display** | sans-zh | sans-zh | **serif-zh（宋体优先）** |
| 字体族（PPT 名） | `PingFang SC` | `PingFang SC` | `Songti SC`（备 `Source Han Serif SC`） |
| 等宽 mono | `JetBrains Mono`/`SF Mono`/`Menlo` | 同 | 同 |

**四色基石规则**：绿为基（60–70% 视觉权重）· 青为强调（每页 1 处）· 金仅警示/CTA · 源白为底（深色变体作正文/反白）。语义色（仅数据语境用）：涨 `#22C55E` / 跌 `#EF4444` / 平 `#94A3B8`；告警 `#E74C3C`；信息 `#3498DB`。

## 3. 排印阶梯：网页 px → PPT pt 投影映射（不可 1:1 直搬）

网页 96dpi 的 `1px = 0.75pt`，**直接换算会低于 PPT 投影底线**（title ≥36pt / body ≥18pt）。按下列固定映射使用：

| 网页 token | px | ≈pt | **PPT 使用值** | 场景 |
|---|---|---|---|---|
| fs-display | 40 | 30 | **40–44pt** 封面主标题 | 封面/大标语 |
| fs-h1 | 28 | 21 | **36pt** 页标题（底线） | 内容页标题 |
| fs-h2 | 22 | 16.5 | **24–28pt** 小节标题 | 卡片组标题 |
| fs-h3 | 17 | 12.75 | **20pt** 卡片标题 | 卡片/条目 |
| fs-body | 14 | 10.5 | **18pt** 正文（底线） | 正文/要点 |
| fs-small | 13 | 9.75 | **16pt** 辅助说明 | 注释 |
| fs-caption | 12 | 9 | **14pt** 说明 | 脚注/标签 |
| fs-micro | 11 | 8.25 | **11–12pt** 页脚（下限） | 页脚/来源 |

**间距/圆角/阴影的 PPT 化**：
- 间距 token（4–48px）**只用于相对节奏**：12px→0.4cm、16px→0.5cm、24px→0.8cm、32px→1.0cm；**页级边距一律 pptx-base 底线 ≥1.27cm**。
- 圆角：xs4/sm6→`roundRect` adj≈0.04；tile12/md10→adj≈0.08；lg16→adj≈0.12；pill999→`ellipse` 或高 adj。
- 阴影：**PPT 无 box-shadow** → 用"底色分层（card/sunken）+ 描边（green 18%）"替代；需要悬浮感时用同色系浅一档填充。

## 4. 版式与组件（对应 pptx 实现）

| 范式组件 | 语义 | PPT 实现 |
|---|---|---|
| `tile` / `brick` | 卡片单元 | `roundRect` 卡片（bg-card + 描边 green 18%），网格对齐 ppux-base 12 列 |
| `swatch` / `swatch-chip` | 色板卡 | 小块矩形 + 色值标注（mono 字体，11–12pt） |
| `bar-row` / `bar-track` / `bar` | 比例条（72px/1fr/64px 三列） | 三列网格：标签列 + 轨道矩形（bg-sunken）+ 进度矩形（accent 色）；高度 0.28–0.35cm |
| `check` | 检查清单 | 环节点（小圆）+ 文本；清单页专用 |
| `quote` | 引文 | 左侧 0.14cm 主色竖条 + 20pt 斜体正文 |
| `section-header` | 节标题 | 节页/页内小节标题条（主色或金短线 + 36pt 标题） |
| `grid-2/3/4` | 分栏 | 2/3/4 列卡片网格（间隙 ≥0.76cm） |

## 5. 品牌规范（必须遵守）

1. **双标等大**：主标 + 副标并排、等大（源码 64×64px）、居中；**主标只用官方路径，不重绘**。PPT 上：两枚 logo 同尺寸同基线并排居中（封面/末页）。
2. **角本位符号**：Y + 一横的物料符号标；仅用于品牌页，勿滥用于内容页。
3. **中文优先排印**：中文优先于西文（中文用中文字体族，不套拉丁衬线排中文）；中英混排时数字/英文可走 mono 或 sans。
4. **L-U-X-I 法则落地**：L 连接（页与页用共同元素延续）· U 揭示（逐层展开，非一次倾倒）· X 变量（每页保留 1 个"变量"作为视觉焦点）· I 迭代（同一模板在系列 deck 中复用，不每页发明新版式）。

## 6. 与 pptx-base 底线的协调（冲突时以 pptx-base 为准）

- 字号：本包映射表已保证 ≥36pt/≥18pt 底线；不得为"还原网页观感"而降破底线。
- 对比：light 变体正文 `#1A2428` on `#F5F7FA` ✓；dark/ink 变体须按 pptx-base §Visual delivery floor 校验反白亮度 >80%（`#E6EFEA`、`#F3EEE6` ✓）。
- 页脚/保留区/度量：一律走 pptx-base §Text metrics（本包不另立规则）。

## 7. 用法（确定性调用）

```bash
# 1) 路由：按场景/环境得变体与完整 token（唯一确定）
python3 ../scripts/style_route.py --scene dashboard --env projection
python3 ../scripts/style_route.py --keywords "看板,KPI,大屏"          # 词典自动映射
python3 ../scripts/style_route.py --from-md 某简报_slides.md --json   # 从素材自动判场景
# 2) 依输出 tokens 直接写 officecli 命令（背景/字体/卡片/比例条）
```

## 8. 资产（assets/ — SVG 点缀素材，已资产化）

| 资产 | 规格/数量 | 用途 | 品牌约束 |
|---|---|---|---|
| `assets/logo-lab-mark.svg` | 2048 · 绿+青 | **主 LOGO** | 官方路径，禁重绘/变形 |
| `assets/logo-symbol-mark.svg` | 48 · currentColor | **符号标**（角本位 Y+一横） | 点缀用途，勿占封面主位 |
| `assets/logo-lockup.svg` | 140×64 | 「**双标等大**」并排 lockup | 双标并排的唯一合法形态 |
| `assets/icons/*.svg` | 23 枚 · 24×24 | 语义图标（清单 `assets/icons/INDEX.md`） | 每页点缀 ≤3 处 |
| `assets/illustrations/*.svg` | 4 幅 | 商品预览插画（名片/杯/徽章/帆布袋） | 物料页专用 |

**PPT 插入（实测支持 SVG）**：`officecli add "$FILE" /slide[N] --type picture --prop src=assets/logo-symbol-mark.svg --prop x=..cm --prop y=..cm --prop width=..cm --prop height=..cm --prop alt="…"`（**必须带 alt**）。
深色变体下把图标 `color` 改 `#F5F7FA`/青；抽取与再抽取方法见 `assets/README.md`（`assets/extract_assets.py` 可重跑，源更新时同步）。
