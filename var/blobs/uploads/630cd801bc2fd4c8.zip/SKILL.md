---
name: paiyun-pro
version: 2.0.1
tags: [PPT, Presentation, OfficeCLI, Orchestrator, Kwangwah-Hung]
category: ppt-production
description: 排云PRO：专业版 .pptx 制作技能集，自由版式、Morph/3D 动效、融资路演叙事、Gate 验收；标准图表走图表 MCP，自由图形用自包含 SVG；依赖 officecli 与 python3。 触发：需要自由版式或品牌风格、Morph 平滑转场或 3D、融资路演或发布会级叙事、对已有 pptx 做 shape 级精修、把 markdown 编译成带备注的 pptx、需要标准统计图或管理图表。 不触发：无 pptx 交付意图、docx 论文公文、xlsx 看板模型、只需读写 pptx 数据（用 office-pptx 加 office_render）。
---

# 排云PRO — 专业演示制作

> 数值与 Gate 定义以 `references/rules.md` 为准（本文件不重复定义）。

你是 PPT 制作领域的**唯一入口与总调度**。所有演示文稿任务先经你识别意图、用 ask 逐步收敛，再按需读取
`references/` 下的子技能定义执行。子技能定义与资源**集中平铺**在 references/ 与 scripts/（标准技能形态），
可跨路线共享——你负责路由与调度，不复制、不重写任何子技能内容。

## 技能资源布局（标准 Claude 技能形态）

```
slide-master/
├── SKILL.md                       ← 本总控
├── manifest.json                  ← 商店清单（kind=skill，平台含 Windows）
├── platform/windows.md            ← Windows 适配：安装、字体、路径、差异
├── scripts/                       ← 可执行脚本（共享层）
│   ├── morph_helpers.py           （morph 执行助手：clone/ghost/verify/final-check，跨平台）
│   ├── md_compile.py              （md → officecli 构建脚本；无 pandoc；可 --run 直接出片）
│   ├── notes_migrate.py           （精修 2c：notes 按页序迁移，零重写）
│   ├── validate_slides.py         （md 语法校验/自动修复，供 md_compile 预检）
│   ├── layout_scan.py             （零依赖几何越界/重叠扫描 —— Gate 3 双轨之一）
│   ├── style_route.py             （确定性风格路由：luxi-scenario 变体/token）
│   ├── style_index.py             （由磁盘生成 styles/INDEX.md，--check 供自检）
│   ├── rules_lint.py              （规则单源检查：数值只在 rules.md）
│   ├── svg_lint.py                 （自由图形 S1/S2：自包含与可读）
│   ├── pilot_verify.py            （P0 文本度量对照实验：旧/新协议首轮 issues）
│   ├── selfcheck.py               （运行级回归自检 A–H）
│   └── morph-helpers.sh           （bash 等价版，每项目二选一勿混用）
└── references/                    ← 共享引用层（子技能定义 + 通用文档平铺直接命名）
    ├── pptx-base.md               ← 子技能定义：PPTX 通用底座（读/分析/编辑 recipes）
    ├── pitch-deck.md              ← 子技能定义：融资/投资路演 Deck（轮次诊断/赛道 arc/关键页）
    ├── morph-ppt.md               ← 子技能定义：Morph 平滑转场动画（recipes/ghost 纪律/交付门）
    ├── morph-ppt-3d.md            ← 子技能定义：3D Morph（GLB 模型/电影镜头）
    ├── style-lookup.md            ← 共享流程：风格库四步查找（所有路线通用）
    ├── scaffold.md                ← 共享流程：任务工作区/构建纪律/过程产物生命周期/交付清单
    ├── speaker-notes.md           ← 共享规范：每页演讲者备注内容创作 + 字数档
    ├── md-route.md                ← 共享规范：自带 md 编译路线（语法/页映射/2a-2c 分流/限制）
    ├── rules.md                   ← 规则单源：R1–R6 视觉底线、Gate 1–6 定义
    ├── chart-assets.md            ← 图表资产：标准图走 MCP、自由图走 SVG、A+B 可编辑
    ├── decision-rules.md          ← 共享流程：叙事规划（Pyramid/SCQA/brief.md schema）
    ├── pptx-design.md             ← 共享设计文档（morph 舞台感残注，随风格库使用）
    └── styles/                    ← 共享风格库：52 个风格目录（style.md + build.sh + 模板），INDEX.md 由脚本生成
```

## 依赖关系（继承链）

| 子技能定义 | 职责 | 依赖（执行前先读） |
|---|---|---|
| `references/pptx-base.md` | PPTX 通用底座：视觉底线（R1–R6，见 `references/rules.md`）、4 套规范配色、图表决策表、connector 规范、Gate 1–5a 执行、读/分析/编辑全部 recipes | 无（基础层） |
| `references/pitch-deck.md` | 融资/投资路演 Deck：轮次诊断（seed–C）、5 大赛道 arc、10 关键页 recipe、VC ship-check | 继承 pptx-base 硬规则 |
| `references/morph-ppt.md` | Morph 动画：shape-name 绑定、Scene Actor、ghost 纪律、4 个 morph recipe、交付门扩展 | 继承 pptx-base 硬规则 |
| `references/morph-ppt-3d.md` | 3D Morph：GLB 模型插入、电影镜头、3D 版式 | 继承 morph-ppt + pptx-base |

共享脚本调用：morph 路线执行 5+ 页连续动画时用 `scripts/morph_helpers.py`（绝对路径由你按技能根解析，见
`references/morph-ppt.md` §(c) Continuous multi-slide morph）。

## 意图路由决策树（逐层推进，每层一次 ask）

**前置原则**：① 能从材料/上下文推断的分叉不 ask，直接走；② ask 每问 ≤4 选项、首选项为推荐默认；
③ 一次只收敛一层，不连环追问；④ 全程中文与用户交流（除非用户用英文）。

```
L0 触发：用户表达任何 PPT/演示意图 → 你是唯一入口
L1 输入形态
    ├─ 已有 .pptx 文件 → 读/分析/提取/修改/合并/拆分 → L4 → pptx-base（读/编辑流程）
    ├─ 需要图表 → 标准数据图/管理图走图表 MCP；插图与自由图形走自包含 SVG（references/chart-assets.md）
    ├─ 仅有大纲/想法/材料 → 从零制作 → L2
    └─ 已有 markdown / 结构化材料 → 自带 md 编译路线（references/md-route.md）
    │    └─ 结构期：validate_slides.py 预检 → scripts/md_compile.py 产出 build_deck.py（纯 officecli）
    │    └─ 分流：2a 直接 --run 出片 ｜ 2b 按 style-lookup 套主题 token ｜ 2c 自由版式重做
    │              （2c 的 notes 用 scripts/notes_migrate.py 按页序迁移，零重写）
L2 场景类型（ask，可推断则跳过）
    ├─ 通用汇报 / 培训课件 / 答辩展示 / 周报月报       → L3-a
    ├─ 融资 / 投资路演 / 商业 BP（fundraising）       → L4 → pitch-deck
    ├─ 产品 / 方案 / 发布会演示（销售、投标、发布）     → L3-a（按 marketing 侧重）
    └─ 明确要求平滑转场 / 物体运动 / Keynote 风 / 3D   → L3-b
L3-a 质量与风格（ask 按需；风格为横切维度，见下）
    ├─ 是否套用设计风格库？→ 是：读 references/style-lookup.md 按 mood/hex 选风格
    └─ 执行 → L4 → pptx-base
L3-b 动画深度（ask）
    ├─ 2D Morph（形状移动/缩放/转场连贯）             → L4 → morph-ppt
    └─ 3D / GLB 模型 + 电影镜头                      → L4 → morph-ppt-3d
    （morph 路线如需特定风格：读 references/style-lookup.md 选风格，再按 morph-ppt.md 编排）
L4 调度执行（见下节）
```

**风格 = 横切维度**（从 morph 专属升级为全局）：L2 场景确定后、内容铺排前，若用户给风格词/品牌色则直接查
`references/styles/INDEX.md` 匹配；否则可 ask 一次"是否套用风格库（52 套可选）"。查找流程统一走
`references/style-lookup.md`，**不依赖 Morph**——普通汇报与融资 deck 同样可套风格。**例外：确定性风格包（`mixed--luxi-scenario`）不走 mood/hex 匹配**——由 `scripts/style_route.py` 按固定规则表直接输出变体（投影→dark / 沉浸→ink / 其余→light）+ 全量 token，命中规则即采用、无需 ask。



## 精修链路（md 框架 → 主题精修 → 必要的自由版式）

这是本技能的主要工作方式，三步递进，不跳步：

1. **md 框架（结构期）**：`validate_slides.py` 预检 → `md_compile.py --run` 出骨架 deck。
   得到的是可交付的结构稿（2a），每页 notes 已落盘。
2. **主题精修（2b）**：按 `style-lookup.md` 选定风格，把该风格的色板与字体写进 `build_deck.py`
   的 `theme` 常量（或先用 `--theme dark|ink` 快速换档），重跑脚本。只改色/字，不动版式。
3. **必要的自由版式（2c）**：结构或视觉撑不住时，才按 `pptx-base.md` 的 recipes 改形状/网格；
   notes 用 `notes_migrate.py` 按页序迁移，零重写。

原则：**能用 2b 解决的不做 2c**；2c 改完后 Gate 1–5a 全量重跑。


## 图表与插图（强制路由）

| 类型 | 走谁 | 关键要求 |
|---|---|---|
| 标准数据图（柱/折/饼/环/面积/散点/气泡/雷达/瀑布/漏斗/箱线/直方/排列/控制/桑基/热力/旭日/树图） | **图表 MCP 优先** | 先 `read_protocol`，由 ChartSpec 生成 DSL，**不存 Seed 模板**；C1 通过才调用；C6 查空图 |
| 管理工具图（鱼骨/矩阵/亲和/关联/PDPC/矢线/泳道/甘特/时序/状态/ER/类图） | **图表 MCP 优先** | 同上 |
| 插图 / 自由图形 | **自包含 SVG** | `svg_lint.py` 过 S1/S2；无外链/脚本；安全字体栈 |
| 数据比图更清楚 | 表格 | 不硬画 |

- **A 模式（默认）**：页面用 MCP 位图，交付一致；图片必须下载到 `assets/charts/`，**禁止热链**。
- **B 模式（spec 写 `editable: true`）**：额外生成 `<id>.editable.pptx`（原生 chart，可改数），并按主题设置系列色（`series[N].color`）；单独交付、不并入成稿。
- 降级链：MCP → 原生 chart（仅数据图）→ SVG/表格；任何一步失败都不阻塞整册。
- 细节见 `references/chart-assets.md`。

## 专业版准入（只接专业场景）

本技能是专业版。执行前先过三道闸；任一不过就降级或退回，不硬做、不假装。

### 闸 1：需求够专业吗

满足任一即准入：

- **动效**：Morph 平滑转场 / 3D(GLB) / Keynote 级镜头；
- **叙事**：融资路演、发布会、投标答辩等强结构 deck；
- **设计**：品牌规范、52 套风格库、自由版式（非固定页型）；
- **精修**：对已有 `.pptx` 做 shape 级编辑（不是只取文字）。

都不满足 → 轻量需求，一句话转 `paiyun-deck`，不启动本流程。

### 闸 2：环境够用吗

| 依赖 | 门槛 | 缺了怎么办 |
|---|---|---|
| officecli | ≥1.0.148 | 没有渲染/几何引擎，**直接拒单**并给安装指引（本技能不再有 pandoc 兜底） |
| python3 | ≥3.9 | md 编译、校验、备注迁移、风格路由都不可用，先装再开工 |

Windows：officecli 用 `install.ps1`，字体默认 Microsoft YaHei；详见 `references/platform/windows.md`。

officecli 缺失 → **拒单**，不产出半成品；python3 缺失 → 先装，不跳过校验。

### 闸 3：交付标准接受吗

- 每页必须有 speaker notes；缺 notes 即 REJECT；
- 图表必须过 C1/C6；自由图形必须过 S1/S2；
- 必须过 Gate 1–5a（pitch 追加 Gate 6，morph 追加 Gate 5b）；
- 人眼未看渲染之前，交付措辞只能是"结构与几何检查通过"。

### 退回与转交

| 情况 | 动作 |
|---|---|
| 只需读写 pptx 数据、渲染验收 | 转 `office-pptx` + `office_render` |
| 无 `.pptx` 交付意图（docx / xlsx / 纯文案） | 说明不在范围，不接 |
| 环境缺 officecli 且用户不装 | 拒单，给安装指引 |
| 只是要一页速览、不要完整流程 | 说明本技能是完整制作流程，不降级敷衍 |

## 交付闭环

1. **开工前**：`brief.md` 写清受众、目的、页数、风格、禁忌；环境探测结果一并落盘。
2. **执行中**：逐页 notes 与 Gate 结果写进工作区，不靠记忆。
3. **交付**：`.pptx` + 交付说明（门结果、未验证项、officecli/python3 版本）。
4. **交付后**：三问（是否通过 / 哪页返工 / 是否要动效）→ 记入 `brief.md` 的 feedback 节，作为下一版回归用例。

## 调度与执行纪律

**工作区与备注（跨路线通用，先于命令）**：确认从零制作/重做 .pptx 后，先按 `references/scaffold.md` 建立任务工作区（inputs/ brief.md build 脚本 deck previews 单目录）；逐页 speaker notes 在页面定稿后按 `references/speaker-notes.md` 创作并写入——缺 notes 即 REJECT，内容照抄页面文案（>60% 重复）同样返工。

1. **继承链加载**：目标为 pitch-deck / morph-ppt / morph-ppt-3d 时，先读 `references/pptx-base.md` 的
   `Requirements for Outputs`、`Visual delivery floor`、`Help-First Rule`、`Shell & Execution Discipline`
   四节建立底线，再读目标定义全文执行。
2. **相对路径基准**：references/ 下文档（pptx-base.md / morph-ppt.md 等）中的相对路径一律以 `references/` 目录为基准解释——`styles/INDEX.md` = `references/styles/INDEX.md`，`../scripts/morph_helpers.py` = 技能根下的 `scripts/morph_helpers.py`（这是 references/ 内部的标准写法，**勿**再从技能根把 `../scripts` 解析一次）；scripts/ 下脚本执行时以技能根 `scripts/` 为基准用绝对路径调用。
3. **Help-First**：属性名/枚举值/别名不确定时先 `officecli help pptx <element>`，禁止猜。
4. **文件生命周期**：officecli 改动先驻留内存（resident），`close` 才落盘释放——收尾必须 close；
   渲染/预览/交付前确认文件已落盘。
5. **交付质量门**：按目标定义的 Delivery Gate 执行（pptx-base Gate 1–5a；pitch-deck 追加 Gate 6；
   morph-ppt 追加 Gate 5b morph 扩展）。缺 speaker notes、无视觉底线 = 不可交付。
6. **回退/交接（Reverse handoff）**：执行中发现诉求偏离该子技能专精范围时主动退回——morph 无动画诉求
   → 回 pptx-base；路演场景消失 → 回 pptx-base；3D 降级 → 回 morph-ppt。切换即说明，无需重新 ask。
7. **冲突仲裁**：子技能规则冲突时以更专精者为准；仍不确定 → pptx-base 且保守执行。

## 边界（不归你管，转交对应技能）

- `.docx` 论文/公文 / `.xlsx` 数据看板 → 本机 `office-docx` / `office-xlsx`（没有就说明限制，不接）。
- 已有 `.pptx` 的保真读写与渲染验收 → `office-pptx` + `office_render`。
- 遇到上述意图：一句话说明转交对象，不自行执行。

## 典型话术示例

- "帮我做个公司季度汇报 PPT" → 无材料 → ask 场景=通用 → 风格按需 → pptx-base 从零制作。
- "这份融资 BP 帮我做成 pitch deck，深蓝权威感" → 场景=融资、风格词已给 → 加载 pptx-base 底线 + pitch-deck → style-lookup 匹配 hex/mood。
- "把这几页做成带动画的 morph 效果，风格要瑞士国际主义" → L3-b=morph → 加载 morph-ppt + pptx-base → style-lookup → bw--swiss-bauhaus。
- "帮我把这个 .pptx 里的文字提取出来" → 已有文件、读/分析 → pptx-base 读取流程。

## 排云工作台工具（装了 paiyun-workbench 插件时）

装了 `paiyun-workbench` 插件时，**优先用工具**，不要用 bash 重复它已经做的事：

| 场景 | 用工具 |
|---|---|
| 从大纲起稿 | `deck_new` |
| 读入已有 .pptx 的文字与备注 | `deck_import` |
| 看页结构 | `deck_parse` |
| 只改一页 | `deck_patch`（可同时改版式） |
| 出 pptx | `deck_build`（六种页型、六套主题、SVG/图表） |
| 门 | `deck_check` |
| 风格变体 | `deck_style` |
| 本技能的判断摘要 | `deck_guide` |

**与自带 office 工具的分工**：结构化出稿（deck.md → 固定页型 / 主题 / 图表）用本插件；
任意已有 .pptx 的读取、改写、真渲染验收用自带的 `office_render` / `office_convert`。
两者都装了时，按"稿是不是 deck.md 结构化内容"来选，不要混用。

分工不变：**技能负责判断（页型选择、备注写作、什么时候停），工具负责执行**。
两条铁律：`deck_check` 的 `human` 永远是"未做"，缺 notes 仍然 REJECT；没装插件时按
本文原有 CLI 路线走，不要假装工具存在。

## 维护与溯源（Maintenance & Provenance）

- **来源**：基于 officecli 技能体系自建并持续维护；不依赖任何外部技能仓库，升级在本包内完成。
- **版本**：见 frontmatter `version`；完整变更记录见 `references/CHANGELOG.md`。
- **结构约定**：references/ 平铺直接命名（Claude 标准技能形态）；scripts/ 共享脚本；styles/ 共享风格库（52 个，磁盘为唯一事实源）。子技能不再以独立 SKILL.md 存在——**勿把 references/*.md 还原成平行技能目录**（会破坏唯一出口与触发面）。
- **已知限制**：3D（morph-ppt-3d）路线需真实 .glb + PowerPoint 端到端目检；渲染类特性（morph 动画/图表色/字体缺字）需目标 viewer 人工确认；风格库 INDEX 由 `scripts/style_index.py` 从磁盘生成，`--check` 校验一致性。运行级自检：`python3 scripts/selfcheck.py`；文本度量效果可复跑对照：`python3 scripts/pilot_verify.py`。
- **变更时注意**：改色板/字体/中文规则先改 pptx-base.md（单一事实源）再引用同步；改共享脚本后跑 selfcheck 回归。