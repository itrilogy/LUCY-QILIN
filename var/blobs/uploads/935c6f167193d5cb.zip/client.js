// paiyun-workbench —— Client 半区。
//
// 一个侧栏入口 + 一个中央整页：左页列表、中编辑区、右实时预览。
// 所有读写都走 Host 的 paiyun Remote（与工具同一组服务方法）。

window.__ModuleLoader__.load({
  id: 'paiyun-workbench',
  factory(require) {
    const React = require('react')
    const h = React.createElement

    const PANEL_ID = 'paiyun-workbench'
    const NS = 'paiyun-workbench'
    const DICT = { zh: { nav: '排云' }, en: { nav: 'Paiyun' } }
    const ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="6" y="12" width="52" height="34" rx="5" fill="#0D5E42"/><rect x="13" y="19" width="24" height="4" rx="2" fill="#F1C40F"/><rect x="13" y="27" width="38" height="3" rx="1.5" fill="#F5F7FA"/><rect x="13" y="34" width="30" height="3" rx="1.5" fill="#F5F7FA"/><rect x="13" y="41" width="16" height="3" rx="1.5" fill="#00D2FF"/><rect x="24" y="50" width="16" height="3" rx="1.5" fill="#0D5E42"/></svg>'

    const identity = (value) => value
    const codec = (symbol) => ({ mode: 'strict', typeSymbol: symbol, create: () => ({ parse: identity }) })
    const param = (name, required) => ({
      name, wire: name, source: 'json',
      ...(required ? {} : { acceptsUndefined: true }),
      codec: codec(`paiyun-workbench#${name}`),
    })
    const RESULTS = {
      list: 'PageList', stat: 'FileStat', recent: 'RecentList', preview: 'PreviewDeck', setStyle: 'SetStyleResult',
      about: 'AboutInfo', read: 'PageContent', new: 'NewResult', importPptx: 'ImportResult', patch: 'PatchResult',
      build: 'BuildResult', check: 'CheckReport', style: 'StyleRoute', guide: 'Guide',
    }
    const descriptor = (method, parameters) => ({
      id: `paiyun-workbench#paiyun/${method}`,
      service: 'paiyun', namespace: 'paiyun', method,
      invocation: { kind: 'direct' }, parameters,
      result: codec(`paiyun-workbench#${RESULTS[method]}`),
    })
    const CONTRIBUTION = {
      package: 'paiyun-workbench',
      descriptors: [
        descriptor('list', [param('path', true)]),
        descriptor('stat', [param('path', true)]),
        descriptor('recent', []),
        descriptor('preview', [param('path', true), param('max', false), param('variant', false)]),
        descriptor('setStyle', [param('path', true), param('variant', false)]),
        descriptor('about', []),
        descriptor('sample', [param('dir', false)]),
        descriptor('browse', [param('path', false)]),
        descriptor('read', [param('path', true), param('pageId', true)]),
        descriptor('new', [param('path', true), param('title', true), param('outline', false)]),
        descriptor('importPptx', [param('pptx', true), param('out', false)]),
        descriptor('patch', [param('path', true), param('pageId', true), param('title', false), param('body', false), param('notes', false), param('layout', false), param('subtitle', false)]),
        descriptor('build', [param('path', true), param('variant', false), param('out', false)]),
        descriptor('check', [param('path', true), param('pptx', false)]),
        descriptor('style', [param('scene', false), param('env', false), param('keywords', false)]),
        descriptor('guide', [param('topic', false)]),
      ],
    }

    const C = {
      border: 'var(--dsw-alias-border, rgba(128,128,128,0.25))',
      borderStrong: 'var(--dsw-alias-border-strong, rgba(128,128,128,0.45))',
      selected: 'var(--dsw-alias-bg-selected, rgba(128,128,128,0.12))',
      accent: 'var(--dsw-alias-accent, #0D5E42)',
      danger: 'var(--dsw-alias-danger, #EF4444)',
      warn: 'var(--dsw-alias-warning, #F59E0B)',
      ok: 'var(--dsw-alias-success, #22C55E)',
      muted: 'var(--dsw-alias-text-secondary, rgba(128,128,128,0.85))',
      elevated: 'var(--dsw-alias-bg-elevated, #ffffff)',
    }
    const S = {
      root: { position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', gap: 12, padding: 20, boxSizing: 'border-box', color: 'inherit', overflow: 'hidden', fontSize: 13, lineHeight: 1.5 },
      header: { display: 'flex', alignItems: 'flex-start', gap: 16, flexWrap: 'wrap' },
      titleWrap: { flex: '1 1 220px', minWidth: 180, display: 'flex', gap: 10, alignItems: 'flex-start' },
      title: { fontSize: 17, fontWeight: 600, margin: 0 },
      subtitle: { fontSize: 12, color: C.muted, margin: '2px 0 0', wordBreak: 'break-all' },
      row: { display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' },
      input: { flex: '1 1 280px', minWidth: 160, padding: '7px 10px', borderRadius: 8, border: `1px solid ${C.border}`, background: 'transparent', color: 'inherit', font: 'inherit', outline: 'none' },
      select: { padding: '7px 8px', borderRadius: 8, border: `1px solid ${C.border}`, background: 'transparent', color: 'inherit', font: 'inherit' },
      grid: { flex: '1 1 auto', display: 'grid', gridTemplateColumns: '212px minmax(0, 1fr) minmax(280px, 34%)', gap: 12, minHeight: 0 },
      pane: { border: `1px solid ${C.border}`, borderRadius: 10, padding: 12, overflow: 'auto', minHeight: 0 },
      sectionLabel: { fontSize: 11, letterSpacing: '0.04em', textTransform: 'uppercase', color: C.muted, margin: '0 0 8px' },
      pageRow: { display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '7px 8px', borderRadius: 8, border: '1px solid transparent', background: 'transparent', color: 'inherit', font: 'inherit', cursor: 'pointer', textAlign: 'left' },
      pageRowActive: { border: `1px solid ${C.border}`, background: C.selected },
      badge: { fontSize: 10, padding: '1px 6px', borderRadius: 999, border: `1px solid ${C.border}`, color: C.muted, flex: '0 0 auto' },
      pageTitle: { flex: '1 1 auto', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
      dot: { width: 6, height: 6, borderRadius: 999, flex: '0 0 auto' },
      label: { fontSize: 12, color: C.muted, margin: '12px 0 6px' },
      area: { width: '100%', boxSizing: 'border-box', padding: '8px 10px', borderRadius: 8, border: `1px solid ${C.border}`, background: 'transparent', color: 'inherit', font: 'inherit', resize: 'vertical', outline: 'none' },
      chipRow: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' },
      chip: { display: 'flex', alignItems: 'center', gap: 6, padding: '5px 10px', borderRadius: 999, border: `1px solid ${C.border}`, background: 'transparent', color: 'inherit', font: 'inherit', cursor: 'pointer' },
      toast: { padding: '8px 12px', borderRadius: 8, fontSize: 12 },
      previewFrame: { width: '100%', aspectRatio: '16 / 9', border: `1px solid ${C.border}`, borderRadius: 8, overflow: 'hidden', background: 'rgba(128,128,128,0.06)' },
      empty: { border: `1px dashed ${C.border}`, borderRadius: 8, padding: 18, textAlign: 'center', color: C.muted, fontSize: 12 },
      overlay: { position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 10 },
      modal: { background: C.elevated, borderRadius: 12, padding: 16, maxWidth: 1080, width: '100%', maxHeight: '90%', overflow: 'auto', boxShadow: '0 12px 40px rgba(0,0,0,0.3)' },
    }

    function Btn({ children, onClick, kind = 'ghost', disabled, title }) {
      const [hover, setHover] = React.useState(false)
      const base = {
        padding: '7px 12px', borderRadius: 8, font: 'inherit', cursor: disabled ? 'default' : 'pointer',
        border: `1px solid ${kind === 'primary' ? 'transparent' : C.border}`,
        background: kind === 'primary' ? C.accent : 'transparent',
        color: kind === 'primary' ? '#fff' : 'inherit',
        opacity: disabled ? 0.5 : 1,
        transition: 'background 120ms ease, border-color 120ms ease',
        ...(hover && !disabled ? { borderColor: C.borderStrong, background: kind === 'primary' ? C.accent : C.selected } : {}),
      }
      return h('button', { type: 'button', style: base, onClick: disabled ? undefined : onClick, title, disabled, onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false) }, children)
    }

    function Segmented({ value, onChange, items }) {
      return h('div', { style: { display: 'inline-flex', border: `1px solid ${C.border}`, borderRadius: 999, padding: 2, gap: 2 } },
        items.map((item) => h('button', {
          key: item.value, type: 'button', onClick: () => onChange(item.value),
          style: { padding: '5px 12px', borderRadius: 999, border: 'none', font: 'inherit', cursor: 'pointer', background: item.value === value ? C.selected : 'transparent', color: 'inherit', opacity: item.value === value ? 1 : 0.75 },
        }, item.label)),
      )
    }

    function sanitizeSvg(svg) {
      return String(svg)
        .replace(/^<svg /, '<svg style="width:100%;height:auto;display:block" ')
        .replace(/<script[\s\S]*?<\/script>/gi, '')
        .replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*')/gi, '')
        .replace(/javascript:/gi, '')
    }

    const marks = { ok: '✓', issues: '✕', warnings: '!', unavailable: '—' }
    const tone = { ok: C.ok, issues: C.danger, warnings: C.warn, unavailable: C.muted }

    function ReportBody({ report }) {
      if (!report) return h('div', { style: { color: C.muted, fontSize: 12 } }, '还没有检查结果。')
      const rows = []
      const add = (name, status, detail) => rows.push(h('div', { key: name, style: { display: 'flex', gap: 8, marginBottom: 8 } },
        h('span', { style: { width: 72, color: C.muted, fontSize: 12 } }, name),
        h('span', { style: { width: 14, color: tone[status] || C.muted } }, marks[status] || '?'),
        h('span', { style: { flex: '1 1 auto', fontSize: 12, wordBreak: 'break-word' } }, detail || status),
      ))
      if (report.md) add('Markdown', report.md.status, report.md.issues?.length ? `${report.md.issues.length} 条` : '通过')
      if (report.ids) add('页 id', report.ids.status, `${report.ids.total} 页`)
      if (report.notes) add('备注', report.notes.status, `${report.notes.covered}/${report.notes.contentPages}`)
      if (report.structure) add('结构', report.structure.ok ? 'ok' : 'issues', report.structure.problems?.join('；') || `${report.structure.entries} 个部件`)
      if (report.geometry) add('框体', report.geometry.status, report.geometry.warnings?.length ? `${report.geometry.warnings.length} 条` : '无越界')
      return h('div', null,
        h('div', { style: S.sectionLabel }, '机器已过'),
        ...rows,
        h('div', { style: { ...S.sectionLabel, marginTop: 10 } }, '需人看'),
        h('div', { style: { display: 'flex', gap: 8, marginBottom: 6 } },
          h('span', { style: { width: 72, color: C.muted, fontSize: 12 } }, '渲染'),
          h('span', { style: { width: 14, color: C.warn } }, '!'),
          h('span', { style: { fontSize: 12 } }, report.human?.render || 'not-done'),
        ),
        h('div', { style: { display: 'flex', gap: 8 } },
          h('span', { style: { width: 72, color: C.muted, fontSize: 12 } }, '缺字'),
          h('span', { style: { width: 14, color: C.warn } }, '!'),
          h('span', { style: { fontSize: 12 } }, report.human?.fonts || 'unknown'),
        ),
      )
    }

    function PanelPage(props) {
      const face = props
      const stored = (() => {
        try { return window.localStorage.getItem('paiyun-workbench:path') || '' } catch { return '' }
      })()
      const [mode, setMode] = React.useState('edit')
      const [path, setPathRaw] = React.useState(stored || 'deck.md')
      const [pptx, setPptx] = React.useState('')
      const [title, setTitle] = React.useState('')
      const [outline, setOutline] = React.useState('')
      const [variant, setVariant] = React.useState('')
      const [pages, setPages] = React.useState([])
      const [selected, setSelected] = React.useState('')
      const [draft, setDraft] = React.useState({ title: '', body: '', notes: '', layout: 'bullets', subtitle: '' })
      const [preview, setPreview] = React.useState(null)
      const [previewError, setPreviewError] = React.useState('')
      const [report, setReport] = React.useState(null)
      const [reportOpen, setReportOpen] = React.useState(false)
      const [zoom, setZoom] = React.useState(0)
      const [recent, setRecent] = React.useState([])
      const [aboutInfo, setAboutInfo] = React.useState(null)
      const [browse, setBrowse] = React.useState(null)
      const [browseTarget, setBrowseTarget] = React.useState('deck')
      const [error, setError] = React.useState('')
      const [status, setStatus] = React.useState('')
      const [busy, setBusy] = React.useState(false)
      const stampRef = React.useRef(0)
      const thumbsRef = React.useRef({})
      const busyRef = React.useRef(false)
      busyRef.current = busy

      const setPath = (value) => {
        setPathRaw(value)
        try { window.localStorage.setItem('paiyun-workbench:path', value) } catch { /* ignore */ }
      }
      const run = async (fn) => {
        setBusy(true); setError(''); setStatus('')
        try { await fn() } catch (err) { setError(err && err.message ? err.message : String(err)) } finally { setBusy(false) }
      }

      const openBrowse = (target) => run(async () => {
        setBrowseTarget(target)
        const current = target === 'pptx' ? pptx : path
        const dir = current && current.includes('/') ? current.slice(0, current.lastIndexOf('/')) : undefined
        setBrowse(await face.call('browse', dir))
      })

      const chooseEntry = (entry) => run(async () => {
        if (entry.kind === 'dir') {
          setBrowse(await face.call('browse', entry.path))
          return
        }
        if (browseTarget === 'pptx') {
          setPptx(entry.path)
        } else {
          setPath(entry.path)
          setBrowse(null)
          await load(entry.path)
          return
        }
        setBrowse(null)
      })

      const refreshPreview = async (target = path, v = variant) => {
        try {
          const result = await face.call('preview', target, undefined, v || undefined)
          setPreview(result)
          setPreviewError('')
        } catch (err) {
          setPreview(null)
          setPreviewError(err && err.message ? err.message : '预览生成失败')
        }
      }

      const openPage = async (id, target = path) => {
        const page = await face.call('read', target, id)
        setSelected(id)
        setDraft({ title: page.title || '', body: page.body || '', notes: page.notes || '', layout: page.layout || 'bullets', subtitle: page.subtitle || '' })
      }

      const load = async (target) => {
        const info = await face.call('stat', target)
        stampRef.current = info.exists ? info.mtimeMs : 0
        const list = await face.call('list', target)
        setPages(list.pages || [])
        setStatus(`已载入 ${list.total} 页`)
        const first = (list.pages || []).find((page) => page.editable)
        if (first) await openPage(first.id, target)
        await refreshPreview(target)
      }

      const refresh = () => run(() => load(path))

      const save = () => run(async () => {
        const result = await face.call('patch', path, selected, draft.title, draft.body, draft.notes, draft.layout, draft.subtitle)
        if (result.checks) setReport({ md: result.checks.md, notes: result.checks.notes })
        await load(path)
        setStatus('已保存这一页')
      })

      const build = () => run(async () => {
        const result = await face.call('build', path, variant || undefined)
        setReport(result.checks || null)
        setStatus(`已生成 ${result.pages} 页 / ${result.notesCount} 条备注`)
        setRecent((await face.call('recent')).items || [])
      })

      const check = () => run(async () => {
        setReport(await face.call('check', path))
        setReportOpen(true)
        setStatus('检查完成')
      })

      const importDeck = () => run(async () => {
        if (!pptx.trim()) throw new Error('填一个 .pptx 路径')
        const result = await face.call('importPptx', pptx.trim(), undefined)
        setPath(result.deck)
        await load(result.deck)
        setMode('edit')
        setStatus(`已导入 ${result.slides} 页，读出 ${result.notesFound} 条备注`)
      })

      const createDeck = () => run(async () => {
        if (!title.trim()) throw new Error('填一个标题')
        if (!path.trim()) throw new Error('填一个 deck.md 输出路径')
        const result = await face.call('new', path.trim(), title.trim(), outline)
        await load(result.deck)
        setMode('edit')
        setStatus(`已新建 ${result.pages} 页；${result.missingNotes} 页待补备注`)
      })

      const openRecent = (item) => run(async () => {
        if (item.deck) { setPath(item.deck); await load(item.deck); setStatus(`已接入 ${item.title || item.deck}`); return }
        if (item.pptx) {
          const result = await face.call('importPptx', item.pptx, undefined)
          setPath(result.deck); await load(result.deck); setStatus('已从 pptx 导入并接入')
        }
      })

      const applyStyle = (next) => run(async () => {
        setVariant(next)
        if (!path) return
        await face.call('setStyle', path, next || undefined)
        await refreshPreview(path, next)
        setStatus(next ? `风格已固定：${next}` : '风格改为自动路由')
      })

      React.useEffect(() => {
        face.call('recent').then((r) => setRecent(r.items || [])).catch(() => {})
        if (stored) face.call('list', stored).then(() => load(stored)).catch(() => {})
        // eslint-disable-next-line
      }, [])

      React.useEffect(() => {
        // 选中页变化时，把它的缩略图滚进视野（pageIndex 在渲染后段才定义，这里自行算）
        const idx = pages.findIndex((page) => page.id === selected)
        const node = thumbsRef.current[(idx >= 0 ? idx : 0) + 1]
        if (node && typeof node.scrollIntoView === 'function') node.scrollIntoView({ block: 'nearest' })
      }, [selected, preview, pages])

      React.useEffect(() => {
        const timer = setInterval(async () => {
          if (busyRef.current) return
          try {
            face.call('recent').then((r) => setRecent(r.items || [])).catch(() => {})
            if (!path) return
            const info = await face.call('stat', path)
            if (info.exists && info.mtimeMs && info.mtimeMs !== stampRef.current) {
              stampRef.current = info.mtimeMs
              await load(path)
            }
          } catch { /* 下一轮再试 */ }
        }, 3000)
        return () => clearInterval(timer)
      }, [path])

      const fileName = path.split('/').filter(Boolean).pop() || path
      const pageIndex = pages.findIndex((page) => page.id === selected)
      const slide = preview && preview.slides[pageIndex >= 0 ? pageIndex : 0]

      const header = h('div', { style: S.header },
        h('div', { style: S.titleWrap },
          h('span', { style: { width: 26, height: 26, flex: '0 0 auto', marginTop: 2 }, dangerouslySetInnerHTML: { __html: ICON_SVG } }),
          h('div', null,
            h('h1', { style: S.title }, '排云'),
            h('p', { style: S.subtitle }, pages.length ? `${fileName} · ${pages.length} 页` : '从一份稿、一份 pptx，或一个标题开始'),
          ),
        ),
        h(Segmented, {
          value: mode,
          onChange: (next) => { setMode(next); setError(''); setStatus('') },
          items: [
            { value: 'edit', label: '编辑现有' },
            { value: 'import', label: '从 pptx 导入' },
            { value: 'create', label: '新建' },
          ],
        }),
        h(Btn, { onClick: () => run(async () => setAboutInfo(await face.call('about'))) }, '关于'),
        h(Btn, { onClick: face.back }, '返回会话'),
      )

      const recentRow = h('div', { style: S.chipRow },
        h('span', { style: { fontSize: 12, color: C.muted } }, '最近产物'),
        h('button', {
          type: 'button', style: S.chip, disabled: busy,
          onClick: () => run(async () => {
            const dir = path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : undefined
            const result = await face.call('sample', dir)
            setPath(result.deck)
            await load(result.deck)
            setStatus('已打开版式示例（九种页型）')
          }),
        }, '版式示例'),
        recent.length
          ? recent.map((item) => h('button', {
              key: `${item.at}-${item.deck || item.pptx}`, type: 'button', style: S.chip, onClick: () => openRecent(item), disabled: busy, title: item.deck || item.pptx,
            }, `${item.title || '未命名'} · ${item.deck ? 'deck.md' : 'pptx'}`))
          : h('span', { style: { fontSize: 12, color: C.muted } }, '还没有——用工具生成一次，或从 pptx 导入'),
      )

      const toolbar = mode === 'import'
        ? h('div', { style: S.row },
            h('input', { style: S.input, value: pptx, placeholder: '已有 .pptx 的路径', onChange: (e) => setPptx(e.target.value) }),
            h(Btn, { onClick: () => openBrowse('pptx'), disabled: busy }, '浏览…'),
            h(Btn, { kind: 'primary', onClick: importDeck, disabled: busy }, '导入并编辑'),
            h('span', { style: { fontSize: 12, color: C.muted } }, '只取文字与备注，版式会重置'),
          )
        : mode === 'create'
          ? h('div', null,
              h('div', { style: S.row },
                h('input', { style: S.input, value: title, placeholder: '标题', onChange: (e) => setTitle(e.target.value) }),
                h('input', { style: S.input, value: path, placeholder: '写出到哪个 deck.md', onChange: (e) => setPath(e.target.value) }),
                h(Btn, { kind: 'primary', onClick: createDeck, disabled: busy }, '创建'),
              ),
              h('textarea', { style: { ...S.area, minHeight: 64, marginTop: 8 }, value: outline, placeholder: '每行一个页标题；以 "# " 开头的是章节页', onChange: (e) => setOutline(e.target.value) }),
            )
          : h('div', null,
              h('div', { style: S.row },
                h('input', { style: S.input, value: path, placeholder: 'deck.md 路径（相对工作区或绝对路径）', onChange: (e) => setPath(e.target.value), onKeyDown: (e) => { if (e.key === 'Enter') refresh() } }),
                h(Btn, { onClick: () => openBrowse('deck'), disabled: busy }, '浏览…'),
                h(Btn, { onClick: refresh, disabled: busy }, '刷新'),
              ),
              h('div', { style: { ...S.row, marginTop: 8 } },
                h(Btn, { kind: 'primary', onClick: build, disabled: busy || !path }, '生成 pptx'),
                h(Btn, { onClick: check, disabled: busy || !path }, '检查'),
                h('span', { style: { flex: '1 1 auto' } }),
                h('span', { style: { fontSize: 12, color: C.muted } }, '风格'),
                h('select', { style: S.select, value: variant, onChange: (e) => applyStyle(e.target.value), disabled: busy },
                  h('option', { value: '' }, '自动'),
                  h('option', { value: 'luxi-light' }, '浅色'),
                  h('option', { value: 'luxi-dark' }, '投影深色'),
                  h('option', { value: 'luxi-ink' }, '沉浸墨色'),
                  h('option', { value: 'swiss' }, '瑞士红'),
                  h('option', { value: 'navy' }, '藏青金'),
                  h('option', { value: 'earth' }, '大地棕'),
                ),
              ),
            )

      const editor = h('div', { style: S.pane },
        selected
          ? selected === 'cover'
            ? h('div', null,
                h('div', { style: S.sectionLabel }, '封面'),
                h('div', { style: S.label }, '标题'),
                h('input', { style: S.area, value: draft.title, onChange: (e) => setDraft({ ...draft, title: e.target.value }) }),
                h('div', { style: S.label }, '副标题'),
                h('input', { style: S.area, value: draft.subtitle || '', onChange: (e) => setDraft({ ...draft, subtitle: e.target.value }) }),
                h('div', { style: { ...S.row, marginTop: 10 } },
                  h(Btn, { kind: 'primary', onClick: save, disabled: busy }, '保存封面'),
                  h('span', { style: { fontSize: 12, color: C.muted } }, '写入 frontmatter'),
                ),
              )
            : h('div', null,
                h('div', { style: S.sectionLabel }, '当前页'),
                h('input', { style: S.area, value: draft.title, onChange: (e) => setDraft({ ...draft, title: e.target.value }) }),
                h('div', { style: S.label }, '正文'),
                h('textarea', { style: { ...S.area, minHeight: 140 }, value: draft.body, onChange: (e) => setDraft({ ...draft, body: e.target.value }) }),
                h('div', { style: { ...S.row, marginTop: 8 } },
                  h('span', { style: { fontSize: 12, color: C.muted } }, '版式'),
                  h('select', { style: S.select, value: draft.layout || 'bullets', onChange: (e) => setDraft({ ...draft, layout: e.target.value }) },
                    h('option', { value: 'bullets' }, '要点'),
                    h('option', { value: 'two-col' }, '两栏'),
                    h('option', { value: 'kpi' }, '指标卡'),
                    h('option', { value: 'quote' }, '引述'),
                    h('option', { value: 'table' }, '表格'),
                    h('option', { value: 'figure' }, '图版'),
                    h('option', { value: 'split' }, '图文分栏'),
                    h('option', { value: 'timeline' }, '时间线'),
                  ),
                ),
                h('div', { style: S.label }, '备注（内容页必填）'),
                h('textarea', { style: { ...S.area, minHeight: 80 }, value: draft.notes, onChange: (e) => setDraft({ ...draft, notes: e.target.value }) }),
                h('div', { style: { ...S.row, marginTop: 10 } },
                  h(Btn, { kind: 'primary', onClick: save, disabled: busy }, '保存这一页'),
                  h('span', { style: { fontSize: 12, color: C.muted } }, '只改这一页，其余页字节不变'),
                ),
              )
          : h('div', { style: S.empty }, '先选一种进入方式：编辑现有、从 pptx 导入，或新建。'),
      )

      const previewPane = h('div', { style: S.pane },
        h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 } },
          h('div', { style: S.sectionLabel }, `预览 · ${preview ? `${preview.total} 页` : '—'}`),
          h('div', { style: { fontSize: 11, color: C.muted } }, '点击缩略图放大'),
        ),
        previewError
          ? h('div', { style: { ...S.empty, borderColor: C.danger, color: C.danger } },
              h('div', null, '预览生成失败'),
              h('div', { style: { fontSize: 11, marginTop: 6, wordBreak: 'break-word' } }, previewError),
              h('div', { style: { marginTop: 10 } }, h(Btn, { onClick: () => run(() => refreshPreview()) }, '重试')),
            )
          : preview
            ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: 10 } },
                preview.slides.map((slideItem) => h('button', {
                  key: slideItem.number,
                  type: 'button',
                  ref: (node) => { thumbsRef.current[slideItem.number] = node },
                  onClick: () => setZoom(slideItem.number),
                  style: {
                    padding: 0, border: `1px solid ${slideItem.number === (pageIndex >= 0 ? pageIndex : 0) + 1 ? C.borderStrong : C.border}`,
                    borderRadius: 8, overflow: 'hidden', background: 'transparent', color: 'inherit', cursor: 'zoom-in', textAlign: 'left',
                    boxShadow: slideItem.number === (pageIndex >= 0 ? pageIndex : 0) + 1 ? `0 0 0 2px ${C.selected}` : 'none',
                  },
                  title: `${slideItem.number}. ${slideItem.title || ''}`,
                },
                  h('div', { style: { width: '100%', aspectRatio: '16 / 9', overflow: 'hidden', background: 'rgba(128,128,128,0.06)' }, dangerouslySetInnerHTML: { __html: sanitizeSvg(slideItem.svg) } }),
                  h('div', { style: { display: 'flex', justifyContent: 'space-between', padding: '5px 8px', fontSize: 11, color: C.muted } },
                    h('span', null, `${slideItem.number}. ${slideItem.title || '未命名'}`),
                    h('span', null, '放大'),
                  ),
                ))
              )
            : h('div', { style: S.empty }, '还没有可预览的页面'),
        h('div', { style: { fontSize: 11, color: C.muted, marginTop: 8 } }, '线框预览：结构可信，字体与换行以 PowerPoint 为准'),
      )

      const body = h('div', { style: S.grid },
        h('div', { style: S.pane },
          h('div', { style: S.sectionLabel }, `页 · ${pages.length}`),
          pages.length
            ? pages.map((page) => h('button', {
                key: page.id, type: 'button', onClick: () => (page.editable ? run(() => openPage(page.id)) : null),
                style: { ...S.pageRow, ...(page.id === selected ? S.pageRowActive : {}) },
              },
                h('span', { style: S.badge }, page.kind === 'cover' ? '封面' : page.kind === 'section' ? '章节' : '内容'),
                h('span', { style: S.pageTitle }, page.title || '未命名'),
                h('span', { style: { ...S.dot, background: page.hasNotes || page.kind !== 'content' ? C.ok : C.warn } }),
              ))
            : h('div', { style: { fontSize: 12, color: C.muted } }, '还没有加载稿件。'),
        ),
        editor,
        previewPane,
      )

      const toast = error
        ? h('div', { style: { ...S.toast, border: `1px solid ${C.danger}`, color: C.danger } }, error)
        : status
          ? h('div', { style: { ...S.toast, border: `1px solid ${C.border}`, color: C.muted } }, status)
          : null

      const zoomSlide = preview && zoom ? preview.slides[zoom - 1] : null
      const zoomModal = zoomSlide
        ? h('div', { style: S.overlay, onClick: () => setZoom(0) },
            h('div', { style: S.modal, onClick: (e) => e.stopPropagation() },
              h('div', { style: { ...S.row, justifyContent: 'space-between', marginBottom: 10 } },
                h('span', { style: { fontSize: 12, color: C.muted } }, `第 ${zoom} / ${preview.total} 页 · ${zoomSlide.title || ''}`),
                h('div', { style: S.row },
                  h(Btn, { onClick: () => setZoom(Math.max(1, zoom - 1)), disabled: zoom <= 1 }, '‹ 上一页'),
                  h(Btn, { onClick: () => setZoom(Math.min(preview.total, zoom + 1)), disabled: zoom >= preview.total }, '下一页 ›'),
                  h(Btn, { onClick: () => setZoom(0) }, '关闭'),
                ),
              ),
              h('div', { style: { border: `1px solid ${C.border}`, borderRadius: 8, overflow: 'hidden' }, dangerouslySetInnerHTML: { __html: sanitizeSvg(zoomSlide.svg) } }),
            ),
          )
        : null

      const reportModal = reportOpen
        ? h('div', { style: S.overlay, onClick: () => setReportOpen(false) },
            h('div', { style: { ...S.modal, maxWidth: 520 }, onClick: (e) => e.stopPropagation() },
              h('div', { style: { ...S.row, justifyContent: 'space-between', marginBottom: 8 } },
                h('strong', null, '检查结果'),
                h(Btn, { onClick: () => setReportOpen(false) }, '关闭'),
              ),
              h(ReportBody, { report }),
            ),
          )
        : null

      const aboutModal = aboutInfo
        ? h('div', { style: S.overlay, onClick: () => setAboutInfo(null) },
            h('div', { style: { ...S.modal, maxWidth: 560 }, onClick: (e) => e.stopPropagation() },
              h('div', { style: { display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 } },
                h('span', { style: { width: 28, height: 28 }, dangerouslySetInnerHTML: { __html: ICON_SVG } }),
                h('strong', null, aboutInfo.title),
                h('span', { style: { fontSize: 12, color: C.muted } }, `v${aboutInfo.version} · ${aboutInfo.name}`),
              ),
              h('div', { style: { fontSize: 12, color: C.muted, marginBottom: 10 } }, aboutInfo.copyright),
              h('pre', { style: { fontSize: 11, whiteSpace: 'pre-wrap', margin: 0, color: C.muted } }, aboutInfo.license),
              h('div', { style: { ...S.sectionLabel, marginTop: 12 } }, '第三方'),
              h('pre', { style: { fontSize: 11, whiteSpace: 'pre-wrap', margin: 0, color: C.muted } }, aboutInfo.notices),
              h('div', { style: { ...S.row, justifyContent: 'flex-end', marginTop: 12 } }, h(Btn, { onClick: () => setAboutInfo(null) }, '关闭')),
            ),
          )
        : null

      const browseModal = browse
        ? h('div', { style: S.overlay, onClick: () => setBrowse(null) },
            h('div', { style: { ...S.modal, maxWidth: 640 }, onClick: (e) => e.stopPropagation() },
              h('div', { style: { ...S.row, justifyContent: 'space-between', marginBottom: 8 } },
                h('span', { style: { fontSize: 12, color: C.muted, wordBreak: 'break-all' } }, browse.dir),
                h('div', { style: S.row },
                  h(Btn, { onClick: () => run(async () => setBrowse(await face.call('browse', browse.parent))), disabled: !browse.parent }, '上一级'),
                  h(Btn, { onClick: () => setBrowse(null) }, '关闭'),
                ),
              ),
              h('div', { style: { maxHeight: 420, overflow: 'auto', border: `1px solid ${C.border}`, borderRadius: 8 } },
                browse.entries.length
                  ? browse.entries.map((entry) => h('button', {
                      key: entry.path,
                      type: 'button',
                      onClick: () => chooseEntry(entry),
                      style: { display: 'flex', gap: 8, width: '100%', textAlign: 'left', padding: '7px 10px', border: 'none', borderBottom: `1px solid ${C.border}`, background: 'transparent', color: 'inherit', font: 'inherit', cursor: 'pointer' },
                    },
                      h('span', { style: { width: 16, color: C.muted } }, entry.kind === 'dir' ? '▸' : '·'),
                      h('span', { style: { flex: '1 1 auto' } }, entry.name),
                      h('span', { style: { fontSize: 11, color: C.muted } }, entry.kind === 'dir' ? '目录' : entry.name.split('.').pop()),
                    ))
                  : h('div', { style: { ...S.empty, border: 'none' } }, '这个目录里没有 .md / .pptx'),
              ),
            ),
          )
        : null

      return h('div', { style: S.root }, header, toolbar, recentRow, toast, body, zoomModal, reportModal, browseModal, aboutModal)
    }

    function slidesReady(pages, index) {
      return index > 0
    }

    function PanelIcon() {
      return h('svg', { viewBox: '0 0 64 64', width: 18, height: 18, 'aria-hidden': true, style: { display: 'block' }, dangerouslySetInnerHTML: { __html: ICON_SVG.replace(/^<svg[^>]*>|<\/svg>$/g, '') } })
    }

    function createFace(ctx) {
      const mount = ctx.remote && typeof ctx.remote.$mount === 'function' ? ctx.remote.$mount(CONTRIBUTION) : Promise.resolve()
      const ARITY = { list: 1, stat: 1, recent: 0, preview: 3, setStyle: 2, about: 0, sample: 1, browse: 1, read: 2, new: 3, importPptx: 2, patch: 7, build: 3, check: 2, style: 3, guide: 1 }
      const pad = (method, args) => {
        const out = args.slice()
        while (out.length < (ARITY[method] || 0)) out.push(undefined)
        return out
      }
      const call = async (method, ...args) => {
        await mount
        const remote = ctx.get('remote.paiyun')
        if (!remote || typeof remote[method] !== 'function') throw new Error('remote.paiyun 不可用（远程未挂载）')
        const result = await remote[method](...pad(method, args))
        if (result && result.ok === false) {
          const e = result.error || {}
          throw new Error(`${e.code || 'failed'}: ${e.message || ''}`)
        }
        return result && result.ok === true ? result.value : result
      }
      const back = () => {
        const layout = ctx.get('layout')
        if (layout && typeof layout.selectPanel === 'function') layout.selectPanel(null)
      }
      return { call, back }
    }

    function apply(ctx) {
      if (ctx.locale && typeof ctx.locale.register === 'function') {
        ctx.effect(() => ctx.locale.register(NS, DICT), 'paiyun-workbench: dictionaries')
      }
      const t = (key) => {
        try { return ctx.locale && typeof ctx.locale.bind === 'function' ? ctx.locale.bind(NS)(key) : '排云' } catch { return '排云' }
      }
      const face = createFace(ctx)
      ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({ name: 'sidebar.panellist', id: PANEL_ID, order: 2, label: () => t('nav'), locale: NS }, PanelIcon))
      ctx.slots.inject('main', () => ctx.slots.register({ name: 'main', key: PANEL_ID, locale: NS, inject: () => face }, PanelPage))
    }

    return { inject: ['slots', 'remote', 'locale', 'layout'], apply, NS }
  },
})
