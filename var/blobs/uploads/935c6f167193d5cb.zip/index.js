// Host 半区：把服务层注册成 6 个模型工具。
//
// 面板（P1）会用同一组服务方法（一个操作两个调用者），这里只做参数与错误的转译：
// 失败一律返回 { ok:false, error:{ code, message } }，不抛异常打断回合。

import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { readFileSync } from 'node:fs'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { createService, ServiceError } from './lib/service.js'
import { SLIDE_MASTER_MANIFEST, SlideMasterRemote } from './lib/remote.js'

export const name = 'paiyun-workbench'
export const inject = ['tools', 'typert']

const ROOT = dirname(fileURLToPath(import.meta.url))

// 内置技能：随包携带，注册进 ctx.skills（source=runtime），模型按 description 命中后按需加载。
function loadSkill() {
  const raw = readFileSync(join(ROOT, 'assets', 'skill.md'), 'utf8')
  const match = raw.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/)
  const front = match ? match[1] : ''
  const description = ((front.match(/^description:\s*(.+)$/m) || [])[1] || 'Paiyun deck workbench: build .pptx from deck.md').trim()
  return { description, content: (match ? match[2] : raw).trim() }
}

function render(value) {
  return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
}

// 宿主要求工具返回值是无损 JSON：undefined / NaN / 函数都不行。
// 统一走一次 JSON 往返，把这些值收敛掉。
function toJson(value) {
  return value === undefined ? null : JSON.parse(JSON.stringify(value))
}

function wrap(fn) {
  return async (args) => {
    try {
      return toJson(await fn(args))
    } catch (error) {
      const code = error instanceof ServiceError ? error.code : 'failed'
      const message = error instanceof Error ? error.message : String(error)
      return { ok: false, error: { code, message } }
    }
  }
}

export function apply(ctx, config = {}) {
  const service = createService({ root: ROOT, workspaceRoot: config.workspaceRoot })

  ctx.effect(() => ctx.typert.register(SLIDE_MASTER_MANIFEST), 'paiyun-workbench: typert manifest')
  new SlideMasterRemote(ctx, service)

  // 技能注册是可选的：宿主没有 skills 服务时插件照常工作。
  if (typeof ctx.inject === 'function') ctx.inject(['skills'], (scoped) => {
    try {
      const skill = loadSkill()
      scoped.effect(() => scoped.skills.register({
        name: 'paiyun-deck',
        description: skill.description,
        content: skill.content,
        source: 'runtime',
        whenToUse: '用户要产出或修改 .pptx 演示文稿、把 md/大纲变成 PPT、给 deck 套主题或加图表时。',
        invocation: { modelInvocable: true, userInvocable: true },
      }), 'paiyun-workbench: built-in skill')
    } catch (error) {
      ctx.logger?.warn?.('paiyun-workbench: 技能注册失败 ' + (error && error.message ? error.message : error))
    }
  })

  ctx.tools.register(
    defineTool({
      name: 'deck_parse',
      description: 'List the pages of a deck.md: id, kind, title, whether it has notes. Returns an index, not the full text.',
      parameters: {
        path: { type: 'string', required: true, description: 'deck.md 路径；相对路径按会话工作区解析' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.parse),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_patch',
      description: 'Rewrite one page of deck.md by page id. Keeps other pages byte-identical, snapshots before writing, and refuses a page that breaks the structure.',
      parameters: {
        path: { type: 'string', required: true },
        pageId: { type: 'string', required: true, description: 'deck_parse 返回的 id；封面用 cover' },
        title: { type: 'string', description: '新标题；不改就不传' },
        subtitle: { type: 'string', description: '封面副标题（仅 pageId=cover）' },
        body: { type: 'string', description: '新正文（Markdown 行）；不改就不传' },
        notes: { type: 'string', description: '新备注；内容页必须非空' },
        layout: {
          type: 'string',
          description: '版式：bullets | two-col | kpi | quote | table | figure | split | timeline',
          enum: ['bullets', 'two-col', 'kpi', 'quote', 'table', 'figure', 'split', 'timeline'],
        },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.patch),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_new',
      description: 'Create a new deck.md from a title and a one-line-per-page outline. Pages start without notes; deck_check will flag them until they are written.',
      parameters: {
        path: { type: 'string', required: true, description: '要写出的 deck.md 路径' },
        title: { type: 'string', required: true },
        outline: { type: 'string', description: '每行一个页标题；以 "# " 开头的是章节页' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.createFromOutline),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_import',
      description: 'Read text and speaker notes out of an existing .pptx and write a deck.md. Layout is not preserved; only content is.',
      parameters: {
        pptx: { type: 'string', required: true, description: '已有 .pptx 路径' },
        out: { type: 'string', description: '写出的 deck.md 路径；默认同名 .md' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.importPptx),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_build',
      description: 'Compose a .pptx from deck.md using the bundled OOXML skeleton (no pandoc, no officecli). Returns the path, page count, notes count and a check report.',
      parameters: {
        path: { type: 'string', required: true },
        variant: { type: 'string', description: '主题：luxi-light / luxi-dark / luxi-ink / swiss / navy / earth；不传则按关键词路由', enum: ['luxi-light', 'luxi-dark', 'luxi-ink', 'swiss', 'navy', 'earth'] },
        out: { type: 'string', description: '输出路径；默认与 deck.md 同名 .pptx' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.build),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_figure',
      description: 'Generate an SVG figure (flow / progress / compare / icon) to paste into a deck page as a ```svg block. No args lists the available kinds.',
      parameters: {
        kind: { type: 'string', description: 'flow | progress | compare | icon；不传则列出可用图示' },
        items: { type: 'string', description: 'flow 的步骤，逗号分隔（2–5 个）' },
        value: { type: 'number', description: 'progress 的百分比 0–100' },
        label: { type: 'string', description: 'progress 的标签' },
        left: { type: 'string', description: 'compare 的左侧文字' },
        right: { type: 'string', description: 'compare 的右侧文字' },
        name: { type: 'string', description: 'icon 名称：check / cross / arrow / target / clock / chart' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.figure),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_check',
      description: 'Report machine-checkable gates separately: markdown syntax, page ids, notes coverage, package structure, estimated box overflow. Never returns a single pass flag; visual checks stay "not-done".',
      parameters: {
        path: { type: 'string', required: true },
        pptx: { type: 'string', description: '可选：同时检查一个已存在的 pptx 文件的结构' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.check),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_style',
      description: 'Deterministic style route: same input gives the same variant and tokens. No scoring, no model judgement.',
      parameters: {
        scene: { type: 'string', description: 'dashboard | workbench | marketing | immersive | collateral' },
        env: { type: 'string', description: 'projection 或 light', enum: ['projection', 'light'] },
        keywords: { type: 'string', description: '一段文字；按最长关键词命中判场景' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.style),
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'deck_guide',
      description: 'Return one section of the bundled deck playbook (about 200 lines total). Call without a topic to list topics.',
      parameters: {
        topic: { type: 'string', description: '序号（"3"）或标题片段（"备注"）' },
      },
      output: { schema: { type: 'json' }, render: (_args, value) => render(value) },
      execute: wrap(service.guide),
    }),
  )
}
