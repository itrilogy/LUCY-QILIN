---
title: 排云 · 版式全集
subtitle: 九种页型 + 图示 + 图表
---

# 结构

## 要点页（bullets）

- 一条结论放在最上面
- 下面三条支撑
- 每页只讲一件事

::: notes
要点页是最常用的页型；一页不超过六条，超过就拆页。
:::

## 两栏对照（two-col）

- 左栏讲现状
- 手工排版、逐页对齐
- 换人接手就重来
- 右栏讲做法
- 模板固定、结构可验
- 稿与产物都能重生

::: notes
两栏按行数对半切：前半左栏，后半右栏。
:::

## 四个指标（kpi）

- 83% | 首轮收敛率
- 12 页 | 单册页数
- 3 轮 | 返工轮次
- 60 KB | 插件体积

::: notes
指标卡最多四张；每个数配一个标签，不写解释。
:::

## 一句话（quote）

- 判断留在技能，执行进工具，视觉交给矢量。
- —— 设计原则

::: notes
引述页只放一句话，署名单独一行。
:::

## 列宽表（table）

::: luxi {layout=table cols=2,5,3}

- 项 | 说明 | 状态
- 写出器 | 骨架合成、存储式 ZIP | 完成
- 图示 | flow / compare / progress | 完成
- 图表 | bar / line / pie | 完成

::: notes
列宽用 cols=权重 指定，不必凑成 100。
:::

## 时间线（timeline）

::: luxi {layout=timeline}

- 2024 | 手工排版
- 2025 | 命令行编译
- 2026 | 自包含插件

::: notes
时间线最多五步，标签在上、说明在下。
:::

## 流程（figure + flow）

::: luxi {layout=figure}

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 180"><rect x="0" y="40" width="170" height="100" rx="10" fill="#0D5E42" opacity="0.12"/><rect x="196" y="40" width="170" height="100" rx="10" fill="#0D5E42" opacity="0.24"/><rect x="392" y="40" width="170" height="100" rx="10" fill="#0D5E42" opacity="0.36"/><rect x="588" y="40" width="170" height="100" rx="10" fill="#0D5E42" opacity="0.48"/><text x="85" y="98" text-anchor="middle" font-size="20" fill="#0D5E42" font-family="PingFang SC">收集</text><text x="281" y="98" text-anchor="middle" font-size="20" fill="#0D5E42" font-family="PingFang SC">编译</text><text x="477" y="98" text-anchor="middle" font-size="20" fill="#0D5E42" font-family="PingFang SC">校验</text><text x="673" y="98" text-anchor="middle" font-size="20" fill="#0D5E42" font-family="PingFang SC">交付</text></svg>
```

四步：收集 → 编译 → 校验 → 交付

::: notes
图版页的正文第一行会作为图注。
:::

## 图文分栏（split）

::: luxi {layout=split}

- 左边写结论
- 右边放示意图
- 一页只讲一件事

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect width="400" height="300" fill="#F5F7FA"/><circle cx="200" cy="130" r="72" fill="#0D5E42"/><rect x="120" y="225" width="160" height="14" rx="7" fill="#00D2FF"/></svg>
```

::: notes
分栏页适合"结论 + 示意"，左边三条以内。
:::

## 柱状图（chart bar）

```chart
type: bar
title: 2026 年季度收入（万元）
categories: Q1, Q2, Q3, Q4
series: 收入 = 12, 18, 15, 24
series: 成本 = 8, 11, 10, 14
```

::: notes
柱状图最多三组系列；数值进缓存，不嵌 xlsx。
:::

## 折线图（chart line）

```chart
type: line
title: 月活（千）
categories: 1月, 2月, 3月, 4月, 5月, 6月
series: 月活 = 32, 41, 45, 58, 66, 79
```

::: notes
折线适合趋势；点数超过 12 个改按季度。
:::
