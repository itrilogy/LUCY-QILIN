---
name: paiyun-deck
description: 用排云工作台从 deck.md / 大纲 / 已有 pptx 产出 .pptx 演示文稿。触发：做/改 PPT、幻灯片、演示文稿、课件、汇报、路演、发布会 deck；把 md 或大纲变成 pptx；给 deck 套主题、加图表与示意图。不触发：只写文案不要 pptx、Word/Excel、任意已有 pptx 的保真编辑。
---

# 排云 · 演示工作台

你是"结构化出稿"的调度者：内容先成为 `deck.md`，再由工作台的写出器生成 `.pptx`。
判断留在这里，执行交给 `deck_*` 工具。

## 什么时候用本技能

- 用户要**一份新的 pptx**：从大纲、Markdown、一段素材开始。
- 用户要**改现有稿的内容**：按页改文字与备注，或换版式/主题。
- 用户要**把别人的 pptx 读成可编辑的页**（只取文字与备注，版式会重置）。

## 什么时候不要用

- 用户要**保真修改**已有 pptx 的版式/形状 → 用自带的 `office_pptx` 技能与 `office_render`。
- 只要纯文档（docx/xlsx）或只要文案 → 不要建稿。
- 要 morph / 3D / 自由画布 → 本工作台不做，明确告知。

## 标准流程

1. **定入口**：从零（`deck_new`）/ 导入（`deck_import`）/ 已有 `deck.md`（直接 `deck_parse`）。
2. **看页**：`deck_parse` 拿页索引（id / 类型 / 有无备注），不要猜页 id。
3. **选页型**：按内容选 `layout`——要点 `bullets`、对照 `two-col`、指标 `kpi`（`值 | 标签`）、
   引述 `quote`、表格 `table`（`cols=权重` 可选）、图 `figure`、图文 `split`、时间线 `timeline`。
4. **改页**：`deck_patch` 一次改一页；内容页没有备注会被拒写——先想清楚这页要讲什么。
5. **加图**：`deck_figure` 生成 `flow / progress / compare / icon` 的 SVG，放进页面的 ` ```svg ` 代码块；
   趋势用 ` ```chart `（bar / line / pie）。
6. **选主题**：`deck_style` 或直接给 `deck_build` 传 variant（六套）；把选择写进稿的 `style:`。
7. **出片**：`deck_build`；再 `deck_check` 看五项门。
8. **交付**：报告 `pptx` 路径 + 页数 + 备注数，并说明"渲染未验证"。

## 硬规则

- 每页内容页必须有 `::: notes`，三拍：记住什么 / 凭什么 / 接下来干什么；照抄页面文案（重复 >60%）返工。
- 一页一件事：要点 ≤6 条、指标卡 ≤4 张、时间线 ≤5 步、表格 ≤6 行；超了就拆页，不缩字号。
- `deck_check` 的 `human.render` 永远是 `not-done`：不要在交付里写"视觉已确认"。
- 导入丢图/图表是设计如此：`warnings` 里有什么就向用户报什么，不隐瞒。
- 不用 bash 重复工具已经做的事；工具失败时读 `error.code` 再决定重试或换路。
