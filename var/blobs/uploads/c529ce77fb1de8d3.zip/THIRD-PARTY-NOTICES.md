# 第三方声明

知林的 Host 不使用第三方 npm 运行时依赖。Client 的 `client.js` **本地打包**了 Mermaid 及其传递依赖，因此运行期不联网、不安装 npm 包，但插件包内包含以下第三方代码。

## 打包进 client.js

| 组件 | 版本 | 许可证 |
|---|---|---|
| Mermaid | 11.17.2 | MIT |
| markdown-it | 15.0.3 | MIT |
| markdown-it-task-lists | 2.1.1 | MIT |
| @mermaid-js/parser | 1.2.1 | MIT |
| d3 及 d3-* 模块 | 7.9.2 | ISC |
| dagre-d3-es | 7.0.14 | MIT |
| DOMPurify | 3.4.18 | MPL-2.0 OR Apache-2.0 |
| cytoscape | 3.35.0 | MIT |
| cytoscape-fcose | 2.2.0 | MIT |
| KaTeX | 0.16.47 | MIT |
| roughjs | 4.6.6 | MIT |
| marked | 16.4.2 | MIT |
| dayjs | 1.11.23 | MIT |
| stylis | 4.4.0 | MIT |
| khroma | 2.1.0 | 包元数据未声明；见上游仓库 |

Mermaid 还包含若干传递依赖；完整列表可用构建目录的 `pnpm licenses list --prod` 生成。以上组件均为 MIT/ISC/BSD/Apache-2.0 等宽松许可；DOMPurify 为 MPL-2.0 OR Apache-2.0，使用时保留其许可证与版权声明。

## 不打包

- **React**：由 DeepSeek Harness Web Client 的共享模块表提供，本插件只 `require('react')`，不复制、不打包。
- **Node.js 内置模块**：`node:fs/promises`、`node:path`、`node:os`、`node:crypto`，随宿主运行时提供。
- **知识包内容**：由用户从栖林商店或本地目录提供，版权归各知识包作者所有；本插件不改变其许可。
- **字体/图标**：本插件图标为原创 SVG，遵循鹿溪设计范式；不含第三方字体文件。

## 构建

Mermaid 只在构建期安装（`devDependencies`），运行期不安装：

```bash
pnpm add -D esbuild@0.25.12 mermaid@11.17.2
node scripts/build-client.mjs
```

升级 Mermaid 时重新生成 `client.js`，并复核本文件的版本与许可证。
