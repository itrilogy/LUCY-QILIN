/**
 * 知林 Host 半边。
 *
 * 职责：
 *   1. 扫描本地知识根，解析知识包，建立可重建的索引；
 *   2. 给浏览器提供精确的 /api/knowledge 路由（仅 owner Peer）；
 *   3. 给 agent 提供 knowledge_* 工具与 zhilin-intake 技能；
 *   4. 把「入库」写成可重复执行的动作：校验 → 复制到主根 → 原子更新 library.json。
 *
 * 不依赖任何 DSH 的 Client 包；只使用 Node 内置模块与 Cordis 生命周期。
 */

import fs from 'node:fs/promises'
import { KnowledgeLibrary } from './src/library.js'
import {
  libraryOverview, metadataStats, noteBrief, notePath, packageProfile,
  relatedNotes, searchIndexes, searchNotes, tagStats,
} from './src/retrieval.js'

const API_PATH = '/api/knowledge'
const ROUTE_LABEL = 'zhilin: /api/knowledge'

const JSON_HEADERS = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store',
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: JSON_HEADERS })
}

function errorResponse(error) {
  const code = error && error.code ? String(error.code) : 'INTERNAL'
  const status = code === 'NOT_FOUND' ? 404
    : code === 'TARGET_EXISTS' ? 409
      : code === 'TOO_LARGE' ? 413
        : code === 'INTERNAL' ? 500 : 400
  return json({ ok: false, error: { code, message: error instanceof Error ? error.message : String(error) } }, status)
}

function readBody(request) {
  return request.json().catch(() => ({}))
}

async function readLocal(url, limit) {
  try {
    const text = await fs.readFile(url, 'utf8')
    return text.slice(0, limit)
  } catch {
    return ''
  }
}

async function loadAbout() {
  const pkg = JSON.parse(await fs.readFile(new URL('./package.json', import.meta.url), 'utf8'))
  return {
    name: pkg.name,
    version: pkg.version,
    title: '知林 · 知识包阅读器',
    copyright: 'Copyright © 2026 kwangwah（鹿溪 LUCY）. All rights reserved.',
    homepage: 'https://github.com/itrilogy/LUCY-QILIN',
    description: pkg.description,
    stack: [
      { name: 'Mermaid', version: pkg.devDependencies?.mermaid || '11.17.2', license: 'MIT' },
      { name: 'markdown-it', version: pkg.devDependencies?.['markdown-it'] || '15.0.3', license: 'MIT' },
      { name: 'markdown-it-task-lists', version: pkg.devDependencies?.['markdown-it-task-lists'] || '2.1.1', license: 'MIT' },
    ],
    license: await readLocal(new URL('./LICENSE', import.meta.url), 900),
    notices: await readLocal(new URL('./THIRD-PARTY-NOTICES.md', import.meta.url), 700),
  }
}

async function allIndexes(library) {
  const scan = await library.scan()
  const indexes = []
  for (const item of scan.packages) {
    try { indexes.push(await library.index(item.id, item.version)) } catch { /* 单包坏了不影响总览 */ }
  }
  return indexes
}

function buildTools(library) {
  const text = (args, value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]
  const object = (properties, required = []) => ({
    type: 'object',
    properties,
    required,
    additionalProperties: false,
  })

  return [
    {
      name: 'knowledge_list',
      description: '列出本地知林知识库里的知识包（id、版本、标题、分类、密级、篇数）。可选 query 过滤 id/标题/分类。',
      parameters: object({ query: { type: 'string', description: '可选，按 id、标题或分类过滤' } }),
      output: { schema: object({ ok: { type: 'boolean' }, packages: { type: 'array', items: { type: 'object' } }, roots: { type: 'array', items: { type: 'string' } } }), render: text },
      async execute(args) {
        const scan = await library.scan()
        const query = String(args.query || '').trim().toLowerCase()
        const packages = scan.packages.filter((item) => !query
          || item.id.toLowerCase().includes(query)
          || item.title.toLowerCase().includes(query)
          || JSON.stringify(item.taxonomy).toLowerCase().includes(query))
        return { ok: true, packages, roots: scan.roots }
      },
    },
    {
      name: 'knowledge_search',
      description: '检索知识包里的笔记（对象级，不返回全文）。query 支持 tag:topic/x、type:guide_note、status:evergreen、security:public、package:id、引号短语与 -排除；field 控制摘要/标题/标签优先。给出 packageId 时只搜这一包，否则搜全部包；返回标题、一句话摘要、匹配原因与片段。',
      parameters: object({
        query: { type: 'string', description: '检索式。空格分隔多词；可用 tag:/type:/status:/security:/package: 过滤，引号短语，-排除' },
        packageId: { type: 'string', description: '可选，知识包 id' },
        version: { type: 'string', description: '可选，精确版本；省略时用最新版' },
        limit: { type: 'number', description: '最多返回条数，默认 10，上限 100' },
        field: { type: 'string', enum: ['all', 'summary', 'title', 'tags'], description: '检索字段：all 全文、summary 摘要优先、title 标题、tags 标签；默认 all' },
      }, ['query']),
      output: { schema: object({ ok: { type: 'boolean' }, hits: { type: 'array', items: { type: 'object' } } }), render: text },
      async execute(args) {
        const field = args.field || 'all'
        const mode = field === 'summary' ? 'summary' : field === 'title' ? 'title' : field === 'tags' ? 'tags' : 'hybrid'
        const limit = args.limit || 10
        const hits = args.packageId
          ? searchNotes(await library.index(args.packageId, args.version), args.query, { mode, limit })
          : searchIndexes(await allIndexes(library), args.query, { mode, limit })
        return { ok: true, hits: hits.map((hit) => ({ ...hit, matchedField: field })) }
      },
    },
    {
      name: 'knowledge_read',
      description: '读取知识包里的一篇笔记。返回题头、正文、标题锚点与链接；正文默认截断到 12000 字。',
      parameters: object({
        packageId: { type: 'string', description: '知识包 id' },
        file: { type: 'string', description: '笔记文件名，例如 01-知识包是什么.md；也可用去扩展名的篇名' },
        version: { type: 'string', description: '可选，精确版本' },
        maxChars: { type: 'number', description: '正文最多字符数，默认 12000，上限 40000' },
      }, ['packageId', 'file']),
      output: { schema: object({ ok: { type: 'boolean' }, note: { type: 'object' } }), render: text },
      async execute(args) {
        const result = await library.readNote(args.packageId, args.version, args.file)
        const max = Math.max(1000, Math.min(40000, Number(args.maxChars) || 12000))
        const body = String(result.note.body || '')
        const truncated = body.length > max
        return { ok: true, note: { ...result.note, body: truncated ? body.slice(0, max) : body, truncated } }
      },
    },
    {
      name: 'knowledge_intake',
      description: '把一个知识包目录登记进本地知林知识库：校验清单与入口、复制到主根、原子更新 library.json。幂等，不修改源目录。',
      parameters: object({
        path: { type: 'string', description: '知识包目录的绝对路径（含 manifest.json）' },
        id: { type: 'string', description: '可选，必须与清单 id 一致' },
        version: { type: 'string', description: '可选，必须与清单版本一致' },
      }, ['path']),
      output: { schema: object({ ok: { type: 'boolean' }, package: { type: 'object' }, target: { type: 'string' }, reused: { type: 'boolean' } }), render: text },
      async execute(args) {
        const result = await library.intake(args.path, { id: args.id, version: args.version })
        return { ok: true, ...result }
      },
    },
    {
      name: 'knowledge_graph',
      description: '返回一个知识包的图数据：notes、edges、facets、meta。用于回答「哪些笔记相连/哪些标签是桥」。',
      parameters: object({
        packageId: { type: 'string', description: '知识包 id' },
        version: { type: 'string', description: '可选，精确版本' },
      }, ['packageId']),
      output: { schema: object({ ok: { type: 'boolean' }, package: { type: 'object' }, nodes: { type: 'array', items: { type: 'object' } }, edges: { type: 'array', items: { type: 'object' } }, facets: { type: 'object' }, meta: { type: 'object' } }), render: text },
      async execute(args) {
        const index = await library.index(args.packageId, args.version)
        return {
          ok: true,
          package: { id: index.id, version: index.version, title: index.title },
          nodes: index.notes.map((note) => ({ stem: note.stem, title: note.title, type: note.type, status: note.status, tags: note.tags, security_level: note.security_level })),
          edges: index.edges,
          facets: index.facets,
          meta: index.meta,
        }
      },
    },
    {
      name: 'knowledge_overview',
      description: '库级总览：有多少知识包、总笔记数、链接数、标签数，type/status/security/taxonomy 分布与 top 标签。模型应先调这个再决定去哪个包。',
      parameters: object({}),
      output: {
        schema: object({
          ok: { type: 'boolean' }, packageCount: { type: 'number' }, noteCount: { type: 'number' },
          linkCount: { type: 'number' }, orphanCount: { type: 'number' }, updated: { type: 'string' },
          packages: { type: 'array', items: { type: 'object' } }, types: { type: 'object' },
          statuses: { type: 'object' }, security: { type: 'object' }, taxonomy: { type: 'object' },
          topTags: { type: 'array', items: { type: 'object' } }, tagCount: { type: 'number' },
        }),
        render: text,
      },
      async execute() {
        return { ok: true, ...libraryOverview(await allIndexes(library)) }
      },
    },
    {
      name: 'knowledge_package',
      description: '知识包画像：分类/密级/入口/统计、标签分面、type/status/security 分布，以及每篇笔记的一句话摘要。用于在不读全文的情况下认识一个包。',
      parameters: object({
        packageId: { type: 'string', description: '知识包 id' },
        version: { type: 'string', description: '可选，精确版本' },
        limitNotes: { type: 'number', description: '最多返回多少篇摘要，默认 60，上限 200' },
      }, ['packageId']),
      output: {
        schema: object({
          ok: { type: 'boolean' }, package: { type: 'object' }, stats: { type: 'object' },
          facets: { type: 'object' }, meta: { type: 'object' }, notes: { type: 'array', items: { type: 'object' } },
          truncated: { type: 'boolean' },
        }),
        render: text,
      },
      async execute(args) {
        const index = await library.index(args.packageId, args.version)
        return { ok: true, ...packageProfile(index, { limitNotes: args.limitNotes }) }
      },
    },
    {
      name: 'knowledge_related',
      description: '给定一篇笔记，返回相关笔记：链接（出链/反链）、共享标签、同 type/status、摘要词重叠。适合多步检索时从一篇扩散。',
      parameters: object({
        packageId: { type: 'string', description: '知识包 id' },
        file: { type: 'string', description: '源笔记文件名或去扩展名的篇名' },
        version: { type: 'string', description: '可选，精确版本' },
        limit: { type: 'number', description: '最多返回条数，默认 10，上限 50' },
      }, ['packageId', 'file']),
      output: {
        schema: object({
          ok: { type: 'boolean' }, package: { type: 'object' }, source: { type: 'object' },
          related: { type: 'array', items: { type: 'object' } },
        }),
        render: text,
      },
      async execute(args) {
        const index = await library.index(args.packageId, args.version)
        const source = (index.notes || []).find((note) => note.file === args.file || note.stem === String(args.file).replace(/\.md$/, ''))
        if (!source) throw Object.assign(new Error(`没有这篇笔记：${args.file}`), { code: 'NOT_FOUND' })
        return {
          ok: true,
          package: { id: index.id, version: index.version, title: index.title },
          source: { file: source.file, stem: source.stem, title: source.title, summary: source.summary, type: source.type, status: source.status, tags: source.tags },
          related: relatedNotes(index, args.file, { limit: args.limit }),
        }
      },
    },
    {
      name: 'knowledge_path',
      description: '链接路径：默认入口 → 指定笔记，或 from → to。返回经过的笔记、标题与长度。用于判断一篇笔记在阅读结构中的位置。',
      parameters: object({
        packageId: { type: 'string', description: '知识包 id' },
        from: { type: 'string', description: '可选，起点篇名；省略时用入口' },
        to: { type: 'string', description: '可选，终点篇名；省略时用入口' },
        version: { type: 'string', description: '可选，精确版本' },
      }, ['packageId']),
      output: {
        schema: object({
          ok: { type: 'boolean' }, package: { type: 'object' }, from: { type: 'string' },
          to: { type: 'string' }, length: { type: 'number' }, path: { type: 'array', items: { type: 'object' } },
        }),
        render: text,
      },
      async execute(args) {
        const index = await library.index(args.packageId, args.version)
        const result = notePath(index, { from: args.from, to: args.to })
        if (!result) throw Object.assign(new Error('需要 from 或 to'), { code: 'BAD_REQUEST' })
        return {
          ok: true,
          package: { id: index.id, version: index.version, title: index.title },
          from: result.from, to: result.to, length: result.length ?? -1, path: result.path,
        }
      },
    },
    {
      name: 'knowledge_brief',
      description: '结构化 brief：给若干篇笔记，返回标题、一句话摘要、标题层级、出链/反链与可选短摘录，不返回全文。用于多步检索后的上下文拼装。',
      parameters: object({
        packageId: { type: 'string', description: '知识包 id' },
        files: { type: 'array', items: { type: 'string' }, description: '笔记文件名或篇名数组' },
        version: { type: 'string', description: '可选，精确版本' },
        maxChars: { type: 'number', description: '总字符预算，默认 12000，上限 40000' },
        includeExcerpt: { type: 'boolean', description: '是否附 400 字短摘录，默认 false' },
      }, ['packageId', 'files']),
      output: {
        schema: object({
          ok: { type: 'boolean' }, package: { type: 'object' }, notes: { type: 'array', items: { type: 'object' } },
          chars: { type: 'number' }, truncated: { type: 'boolean' },
        }),
        render: text,
      },
      async execute(args) {
        const index = await library.index(args.packageId, args.version)
        return {
          ok: true,
          package: { id: index.id, version: index.version, title: index.title },
          ...noteBrief(index, args.files, { maxChars: args.maxChars, includeExcerpt: args.includeExcerpt === true }),
        }
      },
    },
    {
      name: 'knowledge_tags',
      description: '标签分布与共现：四分面计数、tag → 包映射、标签对共现（count/lift）。用于回答「哪些标签是桥」「这个主题在哪些包」。',
      parameters: object({
        packageId: { type: 'string', description: '可选，只统计这个包；省略统计全库' },
        version: { type: 'string', description: '可选，精确版本' },
        limit: { type: 'number', description: '共现最多返回条数，默认 12' },
      }),
      output: {
        schema: object({
          ok: { type: 'boolean' }, facets: { type: 'object' }, tagCount: { type: 'number' },
          noteCount: { type: 'number' }, cooccurrence: { type: 'array', items: { type: 'object' } },
          truncated: { type: 'boolean' },
        }),
        render: text,
      },
      async execute(args) {
        const indexes = args.packageId ? [await library.index(args.packageId, args.version)] : await allIndexes(library)
        return { ok: true, ...tagStats(indexes, { limit: args.limit, facetLimit: args.limit }) }
      },
    },
    {
      name: 'knowledge_metadata',
      description: '元数据分布与映射：type/status/security 计数、taxonomy 三段分布、包清单。用于先判断“有哪些形态/密级/业务线”。',
      parameters: object({
        packageId: { type: 'string', description: '可选，只看这个包；省略看全库' },
        version: { type: 'string', description: '可选，精确版本' },
      }),
      output: {
        schema: object({
          ok: { type: 'boolean' }, types: { type: 'object' }, statuses: { type: 'object' },
          security: { type: 'object' }, taxonomy: { type: 'object' }, packages: { type: 'array', items: { type: 'object' } },
        }),
        render: text,
      },
      async execute(args) {
        const indexes = args.packageId ? [await library.index(args.packageId, args.version)] : await allIndexes(library)
        return { ok: true, ...metadataStats(indexes) }
      },
    },
  ]
}

const INTAKE_SKILL = `# 知林 · 知识包入库

当栖林安装计划带 \`post_install.op = knowledge_intake\`，或用户要求把知识包放进本地知识库时，用本流程。

1. 先确认目录里有 \`manifest.json\`，且 \`kind\` 为 \`knowledge\`。不要手工改清单、移动文件或写 \`library.json\`。
2. 调用 \`knowledge_intake\`，参数：
   - \`path\`：解压后的知识包目录绝对路径，例如 \`\${KNOWLEDGE_ROOT}/<id>/<version>\`；
   - \`id\` / \`version\`：安装计划里给出的精确值，可选但建议传。
3. 工具会校验入口、复制到主根（默认 \`~/.qilin/knowledge\`，可用 \`QILIN_KNOWLEDGE_ROOT\` 覆盖）、原子更新 \`library.json\`。重复调用是幂等的。
4. 返回 package id / version / target；把 target 原样告诉用户。失败时按 error.code 处理：
   - \`BAD_MANIFEST\` / \`BAD_ENTRY\`：包本身不合格，不要重试；
   - \`TARGET_EXISTS\`：同 id/version 已存在且清单不同，让用户决定保留哪一份；
   - \`TOO_LARGE\`：单篇超过 256KiB，按商店规则拒收。
5. 不要因为入库失败而删除源目录；源目录留给用户清理或重试。

入库只做「登记与复制」。密级 \`security_level\` 是声明，不是访问控制；不要声称已做权限隔离。
`

const RETRIEVAL_SKILL = `# 知林 · 知识检索

目标：让模型先“认识对象”，再按需取上下文；不把知识库当全文语料倒出来。

## 工具顺序

1. \`knowledge_overview\`：先看有多少包、总笔记/链接/标签数，以及 type/status/security/taxonomy 分布。回答“库里有什么”先调这个。
2. \`knowledge_package\`：选定包后看包画像：分类、密级、入口、统计、标签分面，以及每篇的一句话摘要。用它决定“读哪几篇”。
3. \`knowledge_search\`：对象级检索。query 支持：
   - \`tag:topic/foo\`、\`type:guide_note\`、\`status:evergreen\`、\`security:public\`、\`package:<id>\`；
   - 引号短语（\`"人才盘点"\`）与 \`-排除词\`；
   - \`field=summary\` 只搜摘要，\`field=title\` 只搜标题，\`field=tags\` 只搜标签，默认全文 BM25。
4. \`knowledge_brief\`：对候选 1–5 篇取结构化 brief（摘要、标题层级、出链/反链），默认不返回全文；需要原句时才 \`knowledge_read\`，并只取必要段落。
5. \`knowledge_related\`：从一篇扩散到相关笔记（链接/共享标签/同 type/summary 词重叠）。
6. \`knowledge_path\`：看一篇在阅读结构中的位置，或两点之间的最短链接路径。
7. \`knowledge_tags\` / \`knowledge_metadata\`：回答“哪些标签是桥”“各形态/密级如何分布”。

## 单步与多步

- 单步：用户问“有哪些知识包/某个标签有什么” → \`knowledge_overview\` 或 \`knowledge_tags\`。
- 两步：用户问“某个主题在哪” → \`knowledge_overview\` 选包 → \`knowledge_package\` 看摘要 → 选定 1–3 篇。
- 三步：复杂问题 → \`knowledge_search\` 找候选 → \`knowledge_brief\` 拼上下文 → \`knowledge_related\`/\`knowledge_path\` 补一跳。

## 规则

- 摘要是一等对象描述，优先用摘要和标签判断相关性；不要默认 \`knowledge_read\` 全文。
- 返回对象必须带 \`packageId\`、\`version\`、\`file\`；引用时写 \`<id>@<version>/<file>\`。
- 一次输出控制在 1–5 篇；\`knowledge_brief\` 有 maxChars 预算，不要把所有笔记塞进上下文。
- 没有命中就换标签/元数据过滤或换包，不要编造笔记。
- 密级是声明，不是访问控制；不要声称按密级做了权限隔离。
`

export function apply(ctx, config = {}) {
  const library = new KnowledgeLibrary(config)

  // 1) 浏览器数据通路：一个精确路径，用 op 区分读操作。
  ctx.inject(['connection'], (scope) => {
    const route = {
      path: API_PATH,
      methods: ['GET', 'POST'],
      requestBody: 'buffered',
      async fetch(request) {
        try {
          const url = new URL(request.url)
          if (request.method === 'POST') {
            const body = await readBody(request)
            const op = String(body.op || url.searchParams.get('op') || '')
            if (op === 'intake') {
              const result = await library.intake(body.path, { id: body.id, version: body.version })
              return json({ ok: true, ...result })
            }
            if (op === 'remove') {
              const result = await library.remove(body.id, body.version)
              return json({ ok: true, ...result })
            }
            if (op === 'rescan') {
              library.invalidate()
              return json({ ok: true, ...(await library.scan()) })
            }
            return json({ ok: false, error: { code: 'BAD_OP', message: `未知 POST op：${op}` } }, 400)
          }

          const op = String(url.searchParams.get('op') || 'packages')
          if (op === 'packages') return json({ ok: true, ...(await library.scan()) })
          if (op === 'about') return json({ ok: true, about: await loadAbout() })
          if (op === 'library') return json({ ok: true, library: await library.library() })
          if (op === 'index') {
            const index = await library.index(url.searchParams.get('id') || '', url.searchParams.get('version') || '', {
              fresh: url.searchParams.get('fresh') === '1',
            })
            return json({ ok: true, index })
          }
          if (op === 'note') {
            const result = await library.readNote(
              url.searchParams.get('id') || '',
              url.searchParams.get('version') || '',
              url.searchParams.get('file') || '',
            )
            return json({ ok: true, ...result })
          }
          if (op === 'search') {
            const field = url.searchParams.get('field') || 'all'
            const mode = field === 'summary' ? 'summary' : field === 'title' ? 'title' : field === 'tags' ? 'tags' : 'hybrid'
            const limit = Number(url.searchParams.get('limit') || 20)
            const id = url.searchParams.get('id') || ''
            const version = url.searchParams.get('version') || ''
            const indexes = id ? [await library.index(id, version)] : await allIndexes(library)
            const hits = id ? searchNotes(indexes[0], url.searchParams.get('q') || '', { mode, limit }) : searchIndexes(indexes, url.searchParams.get('q') || '', { mode, limit })
            const titles = new Map(indexes.map((item) => [`${item.id}@${item.version}`, item.title]))
            return json({
              ok: true,
              hits: hits.map((hit) => ({
                ...hit,
                matchedField: field,
                package: { id: hit.packageId, version: hit.version, title: titles.get(`${hit.packageId}@${hit.version}`) || hit.packageId },
              })),
            })
          }
          return json({ ok: false, error: { code: 'BAD_OP', message: `未知 GET op：${op}` } }, 400)
        } catch (error) {
          return errorResponse(error)
        }
      },
    }
    scope.effect(() => scope.connection.fetch.register(route), ROUTE_LABEL)
  })

  // 2) Agent 工具。tools 不存在时插件仍然可以只做阅读器。
  ctx.inject(['tools'], (scope) => {
    scope.effect(() => {
      const disposers = buildTools(library).map((tool) => scope.tools.register(tool))
      return () => { for (const dispose of disposers) dispose() }
    }, 'zhilin: knowledge tools')
  })

  // 3) 嵌入技能，让 agent 知道入库这件事该调用哪个工具。
  ctx.inject(['skills'], (scope) => {
    scope.effect(() => scope.skills.register({
      name: 'zhilin-intake',
      description: '把知识包登记进本地知林知识库；校验目录并更新 library.json。',
      whenToUse: '当栖林安装计划带 post_install.op=knowledge_intake，或用户要求把知识包放入本地知识库时。',
      content: INTAKE_SKILL,
      invocation: { modelInvocable: true, userInvocable: true },
    }), 'zhilin: intake skill')
    scope.effect(() => scope.skills.register({
      name: 'zhilin-retrieval',
      description: '用知林工具做对象级知识检索：总览、包画像、摘要检索、brief、相关与路径，而不是全文倾倒。',
      whenToUse: '当用户问知识库里有什么、某个主题在哪、需要从知识包取上下文或做多步检索时。',
      content: RETRIEVAL_SKILL,
      invocation: { modelInvocable: true, userInvocable: true },
    }), 'zhilin: retrieval skill')
  })
}
