/**
 * 知林 · 全局知识根解析。
 *
 * 约定（与栖林安装器一致）：
 *   1. 显式配置的 roots；
 *   2. QILIN_KNOWLEDGE_ROOT；
 *   3. ~/.qilin/knowledge。
 *
 * 知识根是「用户级」目录，不跟随 Session 的 cwd，因此任何 DSH 会话看到的是同一批包。
 */

import os from 'node:os'
import path from 'node:path'

export const LIBRARY_FILE = 'library.json'
export const QUARANTINE_DIR = 'quarantine'
export const TRASH_DIR = '.trash'

/** 全局默认知识根；与 store/paths.py 的 default_knowledge_root() 同一约定。 */
export function defaultKnowledgeRoot() {
  const env = process.env.QILIN_KNOWLEDGE_ROOT
  if (env && env.trim()) return path.resolve(expandHome(env.trim()))
  return path.join(os.homedir(), '.qilin', 'knowledge')
}

export function expandHome(value) {
  const text = String(value || '').trim()
  if (text === '~') return os.homedir()
  if (text.startsWith('~/') || text.startsWith('~\\')) return path.join(os.homedir(), text.slice(2))
  return text
}

/**
 * 归一化配置：roots 去重、绝对化；primaryRoot 必须属于 roots。
 * @param {{ roots?: string[]|string, primaryRoot?: string }} [config]
 */
export function resolveRoots(config = {}) {
  const configured = Array.isArray(config.roots) ? config.roots : config.roots ? [config.roots] : []
  const roots = []
  for (const item of configured) {
    if (typeof item !== 'string' || !item.trim()) continue
    const resolved = path.resolve(expandHome(item))
    if (!roots.includes(resolved)) roots.push(resolved)
  }
  if (roots.length === 0) roots.push(defaultKnowledgeRoot())
  const primary = config.primaryRoot && String(config.primaryRoot).trim()
    ? path.resolve(expandHome(config.primaryRoot))
    : roots[0]
  return { roots, primaryRoot: roots.includes(primary) ? primary : roots[0] }
}

/** 把相对路径解析到根内；越界抛错。 */
export function inside(root, ...parts) {
  const base = path.resolve(root)
  const target = path.resolve(base, ...parts.map((part) => String(part)))
  const relative = path.relative(base, target)
  if (relative === '') return target
  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    throw Object.assign(new Error('路径越出知识根'), { code: 'PATH_OUTSIDE_ROOT' })
  }
  return target
}

export function libraryPath(root) {
  return path.join(path.resolve(root), LIBRARY_FILE)
}

export function packagePath(root, id, version) {
  return inside(root, id, version)
}

/** 安全文件名：知识包 id/version 只允许字母数字、点、下划线与连字符。 */
export function safeSegment(value) {
  const text = String(value || '').trim()
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(text)) {
    throw Object.assign(new Error(`不安全的路径段：${text}`), { code: 'BAD_SEGMENT' })
  }
  return text
}
