/**
 * 知林 · 面向大模型的知识检索。
 *
 * 目标不是“把正文倒给模型”，而是：
 *   1. 先让模型知道有哪些包、每个包的元数据与一句话摘要；
 *   2. 用字段权重、BM25、标签/元数据过滤，确定“对象”（包/笔记/标签）；
 *   3. 再多步走到 brief / related / path / read，按预算取上下文。
 *
 * 本文件只做纯计算，不读盘；index 由 src/library.js 提供。
 */

import { makeSnippet } from './parser.js'

const CJK = /[\u3400-\u9fff\uf900-\ufaff]/
const CJK_RUN = /[\u3400-\u9fff\uf900-\ufaff]+/g
const ASCII_WORD = /[a-z0-9][a-z0-9._-]*/g
const K1 = 1.2
const B = 0.75
const FIELD_WEIGHTS = { title: 3, summary: 2.4, tags: 2, headings: 1.2, body: 1 }
const STATS_CACHE = new WeakMap()

/** 中文按二元组、英文按词；单字查询保留单字。 */
export function tokenize(text, { unigrams = false } = {}) {
  const value = String(text || '').toLowerCase()
  const tokens = []
  for (const match of value.matchAll(ASCII_WORD)) tokens.push(match[0])
  for (const run of value.match(CJK_RUN) || []) {
    if (run.length === 1) { tokens.push(run); continue }
    for (let i = 0; i < run.length - 1; i += 1) tokens.push(run.slice(i, i + 2))
    if (unigrams) for (const char of run) tokens.push(char)
  }
  return tokens
}

function countTokens(tokens) {
  const map = new Map()
  for (const token of tokens) map.set(token, (map.get(token) || 0) + 1)
  return map
}

function noteText(index, note) {
  return index?._text?.get(note.stem) ?? ''
}

function noteHeadings(note) {
  return (note.headings || []).map((heading) => heading.text || '').join(' ')
}

function buildStats(index) {
  const cached = STATS_CACHE.get(index)
  if (cached) return cached
  const notes = Array.isArray(index?.notes) ? index.notes : []
  const docs = notes.map((note) => {
    const fields = {
      title: tokenize(note.title),
      summary: tokenize(note.summary),
      tags: tokenize((note.tags || []).join(' ')),
      headings: tokenize(noteHeadings(note)),
      body: tokenize(noteText(index, note)),
    }
    const all = new Set()
    const counts = {}
    let length = 0
    for (const [field, tokens] of Object.entries(fields)) {
      counts[field] = countTokens(tokens)
      for (const token of tokens) all.add(token)
      length += tokens.length
    }
    return { note, fields, counts, all, length }
  })
  const df = new Map()
  for (const doc of docs) for (const token of doc.all) df.set(token, (df.get(token) || 0) + 1)
  const totalLength = docs.reduce((sum, doc) => sum + doc.length, 0)
  const stats = { docs, df, n: docs.length, avgLength: docs.length ? totalLength / docs.length : 1 }
  STATS_CACHE.set(index, stats)
  return stats
}

/** 解析 tag: / type: / status: / security: / package: / updated: 与引号短语、-排除。 */
export function parseQuery(input) {
  const filters = { tags: [], types: [], statuses: [], security: [], packages: [], updated: null }
  const phrases = []
  const excludes = []
  const terms = []
  const pattern = /"([^"]+)"|'([^']+)'|(\S+)/g
  for (const match of String(input || '').matchAll(pattern)) {
    const raw = (match[1] || match[2] || match[3] || '').trim()
    if (!raw) continue
    if (raw.startsWith('-') && raw.length > 1) { excludes.push(raw.slice(1).toLowerCase()); continue }
    const colon = raw.indexOf(':')
    if (colon > 0) {
      const key = raw.slice(0, colon).toLowerCase()
      const value = raw.slice(colon + 1).trim()
      if (key === 'tag' && value) { filters.tags.push(value); continue }
      if (key === 'type' && value) { filters.types.push(value); continue }
      if (key === 'status' && value) { filters.statuses.push(value); continue }
      if (key === 'security' && value) { filters.security.push(value); continue }
      if (key === 'package' && value) { filters.packages.push(value); continue }
      if (key === 'updated' && value) { filters.updated = value; continue }
    }
    if (match[1] || match[2]) phrases.push(raw.toLowerCase())
    else terms.push(raw)
  }
  return {
    text: terms.join(' ').trim(),
    phrases,
    excludes,
    filters,
    hasFilters: filters.tags.length + filters.types.length + filters.statuses.length + filters.security.length + filters.packages.length > 0 || Boolean(filters.updated),
  }
}

function tagMatches(note, wanted) {
  return (note.tags || []).some((tag) => tag === wanted || (!wanted.includes('/') && tag.endsWith(`/${wanted}`)))
}

function matchFilters(note, filters, packageId) {
  if (filters.packages.length && !filters.packages.includes(packageId)) return false
  if (filters.types.length && !filters.types.includes(note.type)) return false
  if (filters.statuses.length && !filters.statuses.includes(note.status)) return false
  if (filters.security.length && !filters.security.includes(note.security_level)) return false
  if (filters.tags.length && !filters.tags.every((tag) => tagMatches(note, tag))) return false
  if (filters.updated) {
    const value = String(note.updated || '')
    const matched = /^(>=|<=|>|<)?(\d{4}-\d{2}-\d{2})$/.exec(filters.updated)
    if (matched) {
      const op = matched[1] || '>='
      const date = matched[2]
      if (op === '>=' && value < date) return false
      if (op === '<=' && value > date) return false
      if (op === '>' && value <= date) return false
      if (op === '<' && value >= date) return false
    }
  }
  return true
}

function bm25(tf, length, avgLength) {
  if (!tf) return 0
  const norm = 1 - B + B * (length / Math.max(1, avgLength))
  return (tf * (K1 + 1)) / (tf + K1 * norm)
}

function noteObject(index, note) {
  return {
    packageId: index.id,
    packageTitle: index.title,
    version: index.version,
    file: note.file,
    stem: note.stem,
    title: note.title,
    summary: note.summary,
    type: note.type,
    status: note.status,
    security_level: note.security_level,
    tags: note.tags,
    updated: note.updated,
    backlinkCount: note.backlinkCount,
    outlinkCount: note.outlinkCount,
  }
}

/**
 * 单包检索。mode:
 *   summary — 只搜标题/摘要/标签；
 *   title   — 只搜标题；
 *   tags    — 只搜标签；
 *   hybrid  — 全字段 BM25（默认）。
 */
export function searchNotes(index, input, options = {}) {
  const query = parseQuery(input)
  const mode = ['summary', 'title', 'tags', 'hybrid'].includes(options.mode) ? options.mode : 'hybrid'
  const limit = Math.max(1, Math.min(100, Number(options.limit) || 20))
  const stats = buildStats(index)
  const terms = [...new Set([...tokenize(query.text), ...query.phrases.flatMap((phrase) => tokenize(phrase))])]
  const fields = mode === 'summary' ? ['title', 'summary', 'tags']
    : mode === 'title' ? ['title']
      : mode === 'tags' ? ['tags']
        : ['title', 'summary', 'tags', 'headings', 'body']
  const results = []
  for (const doc of stats.docs) {
    const note = doc.note
    if (!matchFilters(note, query.filters, index.id)) continue
    if (query.excludes.length && query.excludes.some((term) => doc.all.has(term))) continue
    let score = 0
    const why = []
    for (const term of terms) {
      const df = stats.df.get(term) || 0
      const idf = Math.log(1 + (stats.n - df + 0.5) / (df + 0.5))
      let termScore = 0
      for (const field of fields) {
        const tf = doc.counts[field].get(term) || 0
        if (!tf) continue
        termScore += FIELD_WEIGHTS[field] * bm25(tf, doc.length, stats.avgLength) * idf
      }
      if (termScore > 0) {
        score += termScore
        if (!why.includes('text')) why.push('text')
      }
    }
    for (const phrase of query.phrases) {
      const lower = phrase.toLowerCase()
      if (String(note.title).toLowerCase().includes(lower)) { score += 8; if (!why.includes('phrase:title')) why.push('phrase:title') }
      else if (String(note.summary).toLowerCase().includes(lower)) { score += 5; if (!why.includes('phrase:summary')) why.push('phrase:summary') }
      else if (String(noteText(index, note)).toLowerCase().includes(lower)) { score += 2; if (!why.includes('phrase:body')) why.push('phrase:body') }
    }
    if (score === 0 && !query.hasFilters && terms.length > 0) continue
    if (terms.length === 0 && query.hasFilters) score = 1
    if (terms.length === 0 && !query.hasFilters) continue
    const matchedTags = query.filters.tags.filter((tag) => tagMatches(note, tag))
    if (matchedTags.length) why.push('filter:tag')
    if (query.filters.types.length) why.push('filter:type')
    if (query.filters.statuses.length) why.push('filter:status')
    if (query.filters.security.length) why.push('filter:security')
    const snippet = String(note.summary || '').toLowerCase().includes((query.text || '').toLowerCase()) && query.text
      ? makeSnippet(note.summary, query.text, 90)
      : makeSnippet(noteText(index, note), (query.text || query.phrases[0] || ''), 90)
    results.push({ ...noteObject(index, note), score: Math.round(score * 1000) / 1000, why, snippet })
  }
  results.sort((a, b) => b.score - a.score || String(b.updated).localeCompare(String(a.updated)))
  return results.slice(0, limit)
}

/** 跨包检索：逐包调用，合并排序。 */
export function searchIndexes(indexes, input, options = {}) {
  const limit = Math.max(1, Math.min(100, Number(options.limit) || 20))
  const hits = []
  for (const index of indexes) {
    for (const hit of searchNotes(index, input, { ...options, limit })) hits.push(hit)
  }
  hits.sort((a, b) => b.score - a.score || String(b.updated).localeCompare(String(a.updated)))
  return hits.slice(0, limit)
}

/** 包画像：元数据 + 每篇一句话摘要，供模型先“认识对象”。 */
export function packageProfile(index, options = {}) {
  const limit = Math.max(1, Math.min(200, Number(options.limitNotes) || 60))
  const notes = (index.notes || []).slice(0, limit).map((note) => ({
    file: note.file,
    stem: note.stem,
    title: note.title,
    summary: note.summary,
    type: note.type,
    status: note.status,
    security_level: note.security_level,
    tags: note.tags,
    updated: note.updated,
    backlinkCount: note.backlinkCount,
    outlinkCount: note.outlinkCount,
  }))
  const facets = {}
  for (const facet of ['topic', 'entity', 'method', 'source']) {
    facets[facet] = (index.facets?.[facet] || []).slice(0, 12).map((tag) => ({
      id: tag.id, facet: tag.facet, slug: tag.slug, count: tag.count,
    }))
  }
  return {
    package: {
      id: index.id,
      version: index.version,
      title: index.title,
      summary: index.summary,
      taxonomy: index.taxonomy,
      security_level: index.security_level,
      scope: index.scope,
      entry: index.entry,
      path: index.path,
    },
    stats: index.stats,
    facets,
    meta: index.meta,
    notes,
    truncated: (index.notes || []).length > notes.length,
  }
}

/** 库级总览：包、笔记、标签、元数据分布。 */
export function libraryOverview(indexes) {
  const packages = []
  const types = {}
  const statuses = {}
  const security = {}
  const taxonomy = { category: {}, domain: {}, kind: {} }
  const tags = new Map()
  let noteCount = 0
  let linkCount = 0
  let orphanCount = 0
  let updated = ''
  for (const index of indexes) {
    noteCount += index.stats?.notes || 0
    linkCount += index.stats?.links || 0
    orphanCount += index.stats?.orphans || 0
    for (const note of index.notes || []) if (note.updated && note.updated > updated) updated = note.updated
    for (const [key, count] of Object.entries(index.meta?.type || {})) types[key] = (types[key] || 0) + count
    for (const [key, count] of Object.entries(index.meta?.status || {})) statuses[key] = (statuses[key] || 0) + count
    for (const [key, count] of Object.entries(index.meta?.security || {})) security[key] = (security[key] || 0) + count
    const tax = index.taxonomy || {}
    for (const [key, bucket] of [['business_category', 'category'], ['business_domain', 'domain'], ['knowledge_kind', 'kind']]) {
      if (!tax[key]) continue
      taxonomy[bucket][tax[key]] = (taxonomy[bucket][tax[key]] || 0) + 1
    }
    for (const facet of ['topic', 'entity', 'method', 'source']) {
      for (const tag of index.facets?.[facet] || []) {
        const current = tags.get(tag.id) || { id: tag.id, facet, count: 0, packages: [] }
        current.count += tag.count
        if (!current.packages.includes(index.id)) current.packages.push(index.id)
        tags.set(tag.id, current)
      }
    }
    packages.push({
      id: index.id,
      version: index.version,
      title: index.title,
      summary: index.summary,
      taxonomy: index.taxonomy,
      security_level: index.security_level,
      scope: index.scope,
      notes: index.stats?.notes || 0,
      links: index.stats?.links || 0,
      tags: index.stats?.tags || 0,
    })
  }
  return {
    packageCount: packages.length,
    noteCount,
    linkCount,
    orphanCount,
    updated,
    packages,
    types,
    statuses,
    security,
    taxonomy,
    topTags: [...tags.values()].sort((a, b) => b.count - a.count).slice(0, 15),
    tagCount: tags.size,
  }
}

/** 标签分布与共现；用于回答“哪些标签是桥”。 */
export function tagStats(indexes, options = {}) {
  const limit = Math.max(1, Math.min(100, Number(options.limit) || 12))
  const facetLimit = Math.max(1, Math.min(100, Number(options.facetLimit) || 12))
  const facets = { topic: [], entity: [], method: [], source: [] }
  const tagCounts = new Map()
  const pairCounts = new Map()
  let noteCount = 0
  for (const index of indexes) {
    for (const note of index.notes || []) {
      noteCount += 1
      const tags = [...new Set(note.tags || [])]
      for (const tag of tags) tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1)
      for (let i = 0; i < tags.length; i += 1) {
        for (let j = i + 1; j < tags.length; j += 1) {
          const pair = [tags[i], tags[j]].sort().join('\u0000')
          pairCounts.set(pair, (pairCounts.get(pair) || 0) + 1)
        }
      }
    }
    for (const facet of ['topic', 'entity', 'method', 'source']) {
      for (const tag of index.facets?.[facet] || []) {
        const found = facets[facet].find((item) => item.id === tag.id)
        if (found) { found.count += tag.count; if (!found.packages.includes(index.id)) found.packages.push(index.id) }
        else facets[facet].push({ id: tag.id, facet, count: tag.count, packages: [index.id] })
      }
    }
  }
  let truncated = false
  for (const list of Object.values(facets)) {
    list.sort((a, b) => b.count - a.count)
    if (list.length > facetLimit) { list.length = facetLimit; truncated = true }
  }
  const cooccurrence = [...pairCounts.entries()].map(([pair, count]) => {
    const [a, b] = pair.split('\u0000')
    const ca = tagCounts.get(a) || 0
    const cb = tagCounts.get(b) || 0
    const lift = ca && cb ? (count * noteCount) / (ca * cb) : 0
    return { a, b, count, lift: Math.round(lift * 100) / 100 }
  }).sort((a, b) => b.count - a.count || b.lift - a.lift).slice(0, limit)
  if (cooccurrence.length >= limit) truncated = true
  return { facets, tagCount: tagCounts.size, noteCount, cooccurrence, truncated }
}

/** 元数据分布与映射。 */
export function metadataStats(indexes) {
  const types = {}
  const statuses = {}
  const security = {}
  const taxonomy = { category: {}, domain: {}, kind: {} }
  const packages = []
  for (const index of indexes) {
    for (const [key, count] of Object.entries(index.meta?.type || {})) types[key] = (types[key] || 0) + count
    for (const [key, count] of Object.entries(index.meta?.status || {})) statuses[key] = (statuses[key] || 0) + count
    for (const [key, count] of Object.entries(index.meta?.security || {})) security[key] = (security[key] || 0) + count
    const tax = index.taxonomy || {}
    for (const [key, bucket] of [['business_category', 'category'], ['business_domain', 'domain'], ['knowledge_kind', 'kind']]) {
      if (tax[key]) taxonomy[bucket][tax[key]] = (taxonomy[bucket][tax[key]] || 0) + 1
    }
    packages.push({ id: index.id, version: index.version, title: index.title, taxonomy: index.taxonomy, security_level: index.security_level, scope: index.scope })
  }
  return { types, statuses, security, taxonomy, packages }
}

/** 相关笔记：链接 + 共享标签 + 同 type/status + 摘要词重叠。 */
export function relatedNotes(index, file, options = {}) {
  const limit = Math.max(1, Math.min(50, Number(options.limit) || 10))
  const source = (index.notes || []).find((note) => note.file === file || note.stem === String(file).replace(/\.md$/, ''))
  if (!source) return null
  const sourceTags = new Set(source.tags || [])
  const sourceTokens = new Set([...tokenize(source.title), ...tokenize(source.summary)])
  const inbound = new Map((index.backlinks?.[source.stem] || []).map((link) => [link.from, true]))
  const outbound = new Map((index.edges || []).filter((edge) => edge.from === source.stem).map((edge) => [edge.to, true]))
  const scores = new Map()
  const add = (stem, score, reason) => {
    if (stem === source.stem) return
    const current = scores.get(stem) || { score: 0, reasons: [] }
    current.score += score
    if (!current.reasons.includes(reason)) current.reasons.push(reason)
    scores.set(stem, current)
  }
  for (const stem of outbound.keys()) add(stem, 3, 'outlink')
  for (const stem of inbound.keys()) add(stem, 2.5, 'backlink')
  for (const note of index.notes || []) {
    if (note.stem === source.stem) continue
    const tags = new Set(note.tags || [])
    const shared = [...sourceTags].filter((tag) => tags.has(tag))
    if (shared.length) {
      const union = new Set([...sourceTags, ...tags]).size
      add(note.stem, 4 * (shared.length / Math.max(1, union)), `shared-tag:${shared.slice(0, 3).join(',')}`)
    }
    if (note.type && note.type === source.type) add(note.stem, 0.8, 'same-type')
    if (note.status && note.status === source.status) add(note.stem, 0.3, 'same-status')
    const tokens = new Set([...tokenize(note.title), ...tokenize(note.summary)])
    const overlap = [...sourceTokens].filter((token) => tokens.has(token)).length
    if (overlap) add(note.stem, 1.5 * overlap / Math.max(1, sourceTokens.size), 'summary-overlap')
  }
  const byStem = new Map((index.notes || []).map((note) => [note.stem, note]))
  return [...scores.entries()]
    .filter(([stem]) => byStem.has(stem))
    .map(([stem, value]) => ({ ...noteObject(index, byStem.get(stem)), score: Math.round(value.score * 1000) / 1000, reasons: value.reasons }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
}

/** 链接路径：默认入口 → 指定笔记；也可 from → to。 */
export function notePath(index, options = {}) {
  const byStem = new Map((index.notes || []).map((note) => [note.stem, note]))
  const normalize = (value) => String(value || '').replace(/\.md$/, '')
  let from = normalize(options.from)
  let to = normalize(options.to)
  if (!from && !to) return null
  if (!from) from = index.entryStem
  if (!to) to = index.entryStem
  if (!byStem.has(from) || !byStem.has(to)) return { from, to, length: null, path: [] }
  const adjacency = new Map()
  for (const edge of index.edges || []) {
    if (!adjacency.has(edge.from)) adjacency.set(edge.from, [])
    if (!adjacency.has(edge.to)) adjacency.set(edge.to, [])
    adjacency.get(edge.from).push(edge.to)
    adjacency.get(edge.to).push(edge.from)
  }
  const queue = [from]
  const previous = new Map([[from, null]])
  while (queue.length) {
    const current = queue.shift()
    if (current === to) break
    for (const next of adjacency.get(current) || []) {
      if (previous.has(next)) continue
      previous.set(next, current)
      queue.push(next)
    }
  }
  if (!previous.has(to)) return { from, to, length: null, path: [] }
  const stems = []
  for (let current = to; current; current = previous.get(current)) stems.unshift(current)
  return { from, to, length: stems.length - 1, path: stems.map((stem) => noteObject(index, byStem.get(stem))) }
}

/** 结构化 brief：摘要、标题、出链/反链；不返回全文。 */
export function noteBrief(index, files, options = {}) {
  const maxChars = Math.max(1000, Math.min(40000, Number(options.maxChars) || 12000))
  const found = []
  let used = 0
  for (const file of files || []) {
    const note = (index.notes || []).find((item) => item.file === file || item.stem === String(file).replace(/\.md$/, ''))
    if (!note) continue
    const outlinks = [...new Set((index.edges || []).filter((edge) => edge.from === note.stem).map((edge) => edge.to))]
    const backlinks = [...new Set((index.backlinks?.[note.stem] || []).map((link) => link.from))]
    const item = {
      ...noteObject(index, note),
      headings: (note.headings || []).map((heading) => heading.text),
      outlinks,
      backlinks,
      excerpt: options.includeExcerpt ? String(noteText(index, note)).slice(0, 400) : '',
    }
    const size = JSON.stringify(item).length
    if (used + size > maxChars && found.length) break
    found.push(item)
    used += size
  }
  return { notes: found, chars: used, truncated: found.length < (files || []).length }
}
