/**
 * 知林 · 本地统一知识库。
 *
 * 事实源是知识根下的 `<id>/<version>/` 目录；library.json 只是可重建的索引缓存。
 * 读操作永远不依赖 library.json，写操作（入库/移除）才更新它。
 *
 * 本模块只使用 Node 内置模块，不依赖 DSH 服务，便于单测与在 Host 里复用。
 */

import fs from 'node:fs/promises'
import path from 'node:path'
import crypto from 'node:crypto'
import {
  buildIndex, compareVersion, isNoteFile, packageSummary, parseFrontmatter,
  parseHeadings, parseWikiLinks, searchIndex,
} from './parser.js'
import {
  LIBRARY_FILE, QUARANTINE_DIR, TRASH_DIR, inside, libraryPath, packagePath,
  resolveRoots, safeSegment,
} from './paths.js'

const MAX_MANIFEST_BYTES = 1024 * 1024
const MAX_NOTE_BYTES = 256 * 1024
const CACHE_TTL_MS = 3000

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex')
}

function isHidden(name) {
  return String(name || '').startsWith('.')
}

async function readDirSafe(dir) {
  try {
    return await fs.readdir(dir, { withFileTypes: true })
  } catch (error) {
    if (error && (error.code === 'ENOENT' || error.code === 'ENOTDIR')) return []
    throw error
  }
}

async function readJsonSafe(file) {
  try {
    const text = await fs.readFile(file, 'utf8')
    if (Buffer.byteLength(text, 'utf8') > MAX_MANIFEST_BYTES) throw new Error('manifest 过大')
    return { value: JSON.parse(text), text }
  } catch (error) {
    if (error && error.code === 'ENOENT') return null
    throw error
  }
}

function summaryFromManifest(root, id, version, manifest, noteCount, warning) {
  const knowledge = manifest && typeof manifest.knowledge === 'object' ? manifest.knowledge : {}
  return {
    id,
    version,
    title: String((manifest && manifest.title) || id),
    summary: String((manifest && manifest.summary) || ''),
    taxonomy: knowledge.taxonomy && typeof knowledge.taxonomy === 'object' ? knowledge.taxonomy : {},
    security_level: String(knowledge.security_level || ''),
    scope: String(knowledge.scope || ''),
    entry: String(knowledge.entry || ''),
    notes: noteCount,
    root,
    path: packagePath(root, id, version),
    warning: warning || '',
  }
}

export class KnowledgeLibrary {
  constructor(config = {}) {
    this.config = config && typeof config === 'object' ? config : {}
    const resolved = resolveRoots(this.config)
    this.roots = resolved.roots
    this.primaryRoot = resolved.primaryRoot
    this.cache = new Map()
  }

  describeRoots() {
    return {
      roots: [...this.roots],
      primaryRoot: this.primaryRoot,
      library: libraryPath(this.primaryRoot),
      env: process.env.QILIN_KNOWLEDGE_ROOT ? 'QILIN_KNOWLEDGE_ROOT' : '~/.qilin/knowledge',
    }
  }

  invalidate(id, version) {
    for (const key of [...this.cache.keys()]) {
      if (!id || key.includes(`/${id}/`) || key.endsWith(`/${id}`)) this.cache.delete(key)
    }
    if (!id) this.cache.clear()
    if (version) this.cache.delete(`${id}@${version}`)
  }

  /** 扫描全部根，返回包摘要（不读正文）。 */
  async scan() {
    const packages = []
    const warnings = []
    const seen = new Map()
    for (const root of this.roots) {
      const idEntries = await readDirSafe(root)
      for (const idEntry of idEntries) {
        if (!idEntry.isDirectory() || isHidden(idEntry.name) || idEntry.name === QUARANTINE_DIR) continue
        const id = idEntry.name
        let idSafe = true
        try { safeSegment(id) } catch { idSafe = false }
        if (!idSafe) {
          warnings.push({ rule: 'PACKAGE_ID', message: `跳过不安全的包 id：${id}`, root })
          continue
        }
        const idDir = path.join(root, id)
        const versionEntries = await readDirSafe(idDir)
        for (const versionEntry of versionEntries) {
          if (!versionEntry.isDirectory() || isHidden(versionEntry.name)) continue
          const version = versionEntry.name
          try { safeSegment(version) } catch {
            warnings.push({ rule: 'PACKAGE_VERSION', message: `跳过不安全的版本：${id}/${version}`, root })
            continue
          }
          const dir = packagePath(root, id, version)
          let parsed
          try {
            parsed = await readJsonSafe(path.join(dir, 'manifest.json'))
          } catch (error) {
            warnings.push({ rule: 'MANIFEST', message: `读不了 ${id}/${version} 的 manifest：${error.message}`, root })
            continue
          }
          if (!parsed || !parsed.value || typeof parsed.value !== 'object') continue
          if (parsed.value.kind !== 'knowledge') {
            warnings.push({ rule: 'PACKAGE_KIND', message: `${id}/${version} 不是知识包（kind=${parsed.value.kind || '?'}）`, root })
            continue
          }
          let noteCount = 0
          for (const entry of await readDirSafe(dir)) {
            if (entry.isFile() && isNoteFile(entry.name)) noteCount += 1
          }
          const key = `${id}@${version}`
          if (seen.has(key)) {
            warnings.push({ rule: 'DUPLICATE', message: `${key} 同时存在于 ${seen.get(key)} 与 ${root}；使用前者`, root })
            continue
          }
          seen.set(key, root)
          packages.push(summaryFromManifest(root, id, version, parsed.value, noteCount))
        }
      }
    }

    const byId = new Map()
    for (const item of packages) {
      if (!byId.has(item.id)) byId.set(item.id, [])
      byId.get(item.id).push(item)
    }
    for (const [id, versions] of byId) {
      versions.sort((a, b) => compareVersion(b.version, a.version))
      const latest = versions.find((item) => !item.version.includes('-')) || versions[0]
      for (const item of versions) item.latest = item.version === latest.version
      if (versions[0].latest === false) versions[0].latest = true
    }
    packages.sort((a, b) => compareVersion(b.version, a.version) || a.id.localeCompare(b.id, 'zh'))
    return { ...this.describeRoots(), packages, warnings }
  }

  async find(id, version) {
    if (!id) throw Object.assign(new Error('缺少知识包 id'), { code: 'BAD_REQUEST' })
    safeSegment(id)
    if (version) safeSegment(version)
    const scan = await this.scan()
    const matches = scan.packages.filter((item) => item.id === id && (!version || item.version === version))
    if (matches.length === 0) throw Object.assign(new Error(`没有找到知识包 ${id}${version ? `@${version}` : ''}`), { code: 'NOT_FOUND' })
    matches.sort((a, b) => compareVersion(b.version, a.version))
    return matches[0]
  }

  /** 读一篇目录并构建索引；带 3 秒 TTL 缓存。 */
  async index(id, version, { fresh = false } = {}) {
    const found = await this.find(id, version)
    const cacheKey = `${found.id}@${found.version}`
    const cached = this.cache.get(cacheKey)
    if (!fresh && cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.index

    const dir = found.path
    const manifestFile = path.join(dir, 'manifest.json')
    const manifestParsed = await readJsonSafe(manifestFile)
    if (!manifestParsed) throw Object.assign(new Error('知识包缺少 manifest.json'), { code: 'NOT_FOUND' })
    const manifest = manifestParsed.value
    const files = []
    const warnings = []
    for (const entry of await readDirSafe(dir)) {
      if (!entry.isFile() || !isNoteFile(entry.name)) continue
      const file = path.join(dir, entry.name)
      let info
      try { info = await fs.lstat(file) } catch { continue }
      if (info.isSymbolicLink()) {
        warnings.push({ rule: 'NOTE_SYMLINK', message: `跳过符号链接笔记 ${entry.name}` })
        continue
      }
      if (info.size > MAX_NOTE_BYTES) {
        warnings.push({ rule: 'NOTE_FILE', message: `${entry.name} 超过 256KiB，未载入` })
        continue
      }
      let text
      try { text = await fs.readFile(file, 'utf8') } catch (error) {
        warnings.push({ rule: 'NOTE_FILE', message: `读不了 ${entry.name}：${error.message}` })
        continue
      }
      files.push({ name: entry.name, text, size: info.size, mtime: info.mtimeMs })
    }
    const index = buildIndex({ manifest, id: found.id, version: found.version, root: found.root, files })
    index.manifest_sha256 = sha256(manifestParsed.text)
    index.warnings = [...warnings, ...index.warnings]
    index.path = dir
    this.cache.set(cacheKey, { at: Date.now(), index })
    return index
  }

  /** 读一篇正文；索引里只回元数据，正文按需取。 */
  async readNote(id, version, file) {
    const index = await this.index(id, version)
    const note = index.notes.find((item) => item.file === file || item.stem === file.replace(/\.md$/, ''))
    if (!note) throw Object.assign(new Error(`没有这篇笔记：${file}`), { code: 'NOT_FOUND' })
    const full = path.join(index.path, note.file)
    const info = await fs.lstat(full)
    if (info.isSymbolicLink()) throw Object.assign(new Error('拒绝读取符号链接笔记'), { code: 'BAD_PATH' })
    if (info.size > MAX_NOTE_BYTES) throw Object.assign(new Error('笔记超过 256KiB'), { code: 'TOO_LARGE' })
    const text = await fs.readFile(full, 'utf8')
    const parsed = parseFrontmatter(text)
    return {
      package: { id: index.id, version: index.version, title: index.title },
      note: {
        ...note,
        frontmatter: parsed.fields,
        body: parsed.body,
        headings: parseHeadings(parsed.body),
        links: parseWikiLinks(text),
      },
    }
  }

  /**
   * 搜索。给出 id 时搜单包，否则搜全部包；返回带包身份的结果。
   * @param {string} query
   * @param {{ id?: string, version?: string, limit?: number }} [options]
   */
  async search(query, options = {}) {
    const limit = Math.max(1, Math.min(100, Number(options.limit) || 30))
    if (!String(query || '').trim()) return []
    if (options.id) {
      const index = await this.index(options.id, options.version)
      return searchIndex(index, query, limit, { field: options.field }).map((hit) => ({
        ...hit,
        package: { id: index.id, version: index.version, title: index.title },
      }))
    }
    const scan = await this.scan()
    const hits = []
    for (const item of scan.packages) {
      if (hits.length >= limit * 2) break
      try {
        const index = await this.index(item.id, item.version)
        for (const hit of searchIndex(index, query, limit, { field: options.field })) {
          hits.push({ ...hit, package: { id: index.id, version: index.version, title: index.title } })
          if (hits.length >= limit * 2) break
        }
      } catch {
        // 一个包坏了不影响其他包的搜索。
      }
    }
    hits.sort((a, b) => b.score - a.score || a.package.id.localeCompare(b.package.id))
    return hits.slice(0, limit)
  }

  /** 读取或重建 library.json；读不到时返回扫描结果，不写盘。 */
  async library() {
    try {
      const parsed = await readJsonSafe(libraryPath(this.primaryRoot))
      if (parsed && parsed.value && Array.isArray(parsed.value.packages)) return parsed.value
    } catch {
      // 缓存坏了就重建，不阻断阅读。
    }
    const scan = await this.scan()
    return {
      version: 1,
      generated_at: new Date().toISOString(),
      roots: scan.roots,
      primaryRoot: scan.primaryRoot,
      packages: scan.packages,
    }
  }

  /** 原子写 library.json。失败不阻断包本身可用。 */
  async writeLibrary() {
    const scan = await this.scan()
    const value = {
      version: 1,
      generated_at: new Date().toISOString(),
      roots: scan.roots,
      primaryRoot: scan.primaryRoot,
      packages: scan.packages,
    }
    await fs.mkdir(this.primaryRoot, { recursive: true })
    const target = libraryPath(this.primaryRoot)
    const temp = `${target}.${process.pid}.${Date.now()}.tmp`
    await fs.writeFile(temp, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
    try {
      await fs.rename(temp, target)
    } catch (error) {
      // Windows 上覆盖已存在的文件可能报 EEXIST/EPERM；先删再换，失败仍抛给调用方。
      if (error && (error.code === 'EEXIST' || error.code === 'EPERM')) {
        await fs.rm(target, { force: true })
        await fs.rename(temp, target)
      } else {
        throw error
      }
    }
    return value
  }

  /**
   * 入库：校验、复制到主根、更新 library.json。幂等。
   * 不移动源目录，避免把下载缓存或用户目录改坏；源目录可以稍后自行清理。
   * @param {string} sourcePath
   * @param {{ id?: string, version?: string }} [expected]
   */
  async intake(sourcePath, expected = {}) {
    if (!sourcePath || typeof sourcePath !== 'string') throw Object.assign(new Error('缺少知识包路径'), { code: 'BAD_REQUEST' })
    const source = path.resolve(sourcePath)
    const info = await fs.stat(source).catch(() => null)
    if (!info || !info.isDirectory()) throw Object.assign(new Error('知识包路径不是目录'), { code: 'BAD_REQUEST' })

    const manifestParsed = await readJsonSafe(path.join(source, 'manifest.json'))
    if (!manifestParsed) throw Object.assign(new Error('目录里没有 manifest.json'), { code: 'BAD_MANIFEST' })
    const manifest = manifestParsed.value
    if (!manifest || typeof manifest !== 'object' || manifest.kind !== 'knowledge') {
      throw Object.assign(new Error('不是知识包（kind 必须是 knowledge）'), { code: 'BAD_MANIFEST' })
    }
    const id = String(expected.id || manifest.id || '').trim()
    const version = String(expected.version || manifest.version || '').trim()
    safeSegment(id)
    safeSegment(version)
    if (manifest.id && manifest.id !== id) throw Object.assign(new Error(`清单 id ${manifest.id} 与请求 ${id} 不一致`), { code: 'BAD_MANIFEST' })
    if (manifest.version && manifest.version !== version) throw Object.assign(new Error(`清单版本 ${manifest.version} 与请求 ${version} 不一致`), { code: 'BAD_MANIFEST' })

    // 先构建一次索引：没有入口/没有笔记的目录不进库。
    const files = []
    for (const entry of await readDirSafe(source)) {
      if (!entry.isFile() || !isNoteFile(entry.name)) continue
      const full = path.join(source, entry.name)
      const fileInfo = await fs.lstat(full)
      if (fileInfo.isSymbolicLink()) throw Object.assign(new Error(`知识包里有符号链接：${entry.name}`), { code: 'BAD_PATH' })
      if (fileInfo.size > MAX_NOTE_BYTES) throw Object.assign(new Error(`笔记超过 256KiB：${entry.name}`), { code: 'TOO_LARGE' })
      files.push({ name: entry.name, text: await fs.readFile(full, 'utf8'), size: fileInfo.size, mtime: fileInfo.mtimeMs })
    }
    if (files.length === 0) throw Object.assign(new Error('知识包没有笔记'), { code: 'EMPTY_PACKAGE' })
    const index = buildIndex({ manifest, id, version, root: source, files })
    if (!index.entryStem || !index.notes.some((note) => note.stem === index.entryStem)) {
      throw Object.assign(new Error('入口文件不在包里'), { code: 'BAD_ENTRY' })
    }

    const target = packagePath(this.primaryRoot, id, version)
    const same = path.resolve(source) === path.resolve(target)
    let reused = same
    if (!same) {
      const existing = await fs.stat(target).catch(() => null)
      if (existing) {
        reused = true
        const existingManifest = await readJsonSafe(path.join(target, 'manifest.json'))
        if (!existingManifest || sha256(existingManifest.text) !== sha256(manifestParsed.text)) {
          throw Object.assign(new Error(`目标已存在且清单不同：${target}`), { code: 'TARGET_EXISTS' })
        }
      } else {
        await fs.mkdir(path.dirname(target), { recursive: true })
        try {
          await fs.cp(source, target, { recursive: true, errorOnExist: true, force: false })
        } catch (error) {
          await fs.rm(target, { recursive: true, force: true }).catch(() => {})
          throw Object.assign(new Error(`复制知识包失败：${error.message}`), { code: 'COPY_FAILED' })
        }
      }
    }

    this.invalidate(id, version)
    const library = await this.writeLibrary()
    const entry = library.packages.find((item) => item.id === id && item.version === version)
    return { package: entry || packageSummary(index), target, reused }
  }

  /** 移除一个版本：移到 .trash，可手工恢复；更新 library.json。 */
  async remove(id, version) {
    safeSegment(id)
    safeSegment(version)
    const target = packagePath(this.primaryRoot, id, version)
    const info = await fs.stat(target).catch(() => null)
    if (!info || !info.isDirectory()) throw Object.assign(new Error('没有这个版本'), { code: 'NOT_FOUND' })
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const trash = inside(this.primaryRoot, TRASH_DIR, id, `${version}-${stamp}`)
    await fs.mkdir(path.dirname(trash), { recursive: true })
    try {
      await fs.rename(target, trash)
    } catch {
      await fs.cp(target, trash, { recursive: true, errorOnExist: false, force: true })
      await fs.rm(target, { recursive: true, force: true })
    }
    this.invalidate(id, version)
    await this.writeLibrary()
    return { id, version, trash }
  }
}
