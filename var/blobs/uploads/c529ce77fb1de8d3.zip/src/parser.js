/**
 * 知林 · 知识包解析器。
 *
 * 只做「读」需要的解析，不复制商店校验器的拒收逻辑。与 store/validator/knowledge.py
 * 保持同一口径的关键点：
 *   - 题头是行式 YAML 子集，不是完整 YAML；
 *   - 链接只认 [[篇名]] / [[篇名|显示]] / [[篇名#标题]]，![[...]] 也算目标；
 *   - 代码块与行内代码里的链接/标题不算；
 *   - 锚点是标题原文，不是 slug。
 *
 * 本文件不访问文件系统，便于用 node:test 直接跑 golden case。
 */

const FENCE = /```[\s\S]*?```/g
const INLINE_CODE = /`[^`\n]*`/g
const WIKI = /!\[\[([^\]]+)\]\]|\[\[([^\]]+)\]\]/g
const HEADING = /^(#{1,6})\s+(.+?)\s*#*\s*$/gm
const NOTE_FILE = /^\d{2}-.+\.md$/

/** 把代码块/行内代码替换成等长空白，保留换行，供链接与标题扫描使用。 */
export function stripCode(text) {
  return String(text)
    .replace(FENCE, (block) => block.replace(/[^\n]/g, ' '))
    .replace(INLINE_CODE, (span) => ' '.repeat(span.length))
}

function unquote(value) {
  const text = String(value ?? '').trim()
  if (text.length >= 2 && ((text.startsWith('"') && text.endsWith('"')) || (text.startsWith("'") && text.endsWith("'")))) {
    return text.slice(1, -1)
  }
  return text
}

/**
 * 读题头。返回 { fields, body, hasFrontmatter }。
 * fields 的值是 string 或 string[]；空列表返回 []。
 */
export function parseFrontmatter(input) {
  const text = String(input ?? '').replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n')
  if (!text.startsWith('---\n')) return { fields: {}, body: text, hasFrontmatter: false }
  const end = text.indexOf('\n---', 4)
  if (end < 0) return { fields: {}, body: text, hasFrontmatter: false }
  const block = text.slice(4, end)
  const body = text.slice(end + 4).replace(/^\n/, '')
  return { fields: parseFieldBlock(block), body, hasFrontmatter: true }
}

/** 行式 YAML 子集。折叠标量只保留原文，不做语义解析。 */
export function parseFieldBlock(block) {
  const raw = new Map()
  let current = null
  let scalar = null
  for (const line of String(block).split('\n')) {
    if (scalar !== null) {
      if (line.startsWith('  ') || line.startsWith('\t') || line.trim() === '') {
        raw.get(scalar).value.push(line.trim())
        continue
      }
      scalar = null
    }
    if (current && /^\s*-\s+/.test(line)) {
      const entry = raw.get(current)
      if (!entry) continue
      entry.items.push(unquote(line.replace(/^\s*-\s+/, '')))
      continue
    }
    const matched = /^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$/.exec(line)
    if (!matched) continue
    current = matched[1]
    const value = matched[2].trim()
    const entry = { value: '', items: [], block: false }
    raw.set(current, entry)
    if (['>', '|', '>-', '|-', '>+', '|+'].includes(value)) {
      entry.block = true
      entry.value = []
      scalar = current
      continue
    }
    if (value.startsWith('[') && value.endsWith(']') && !value.startsWith('[[')) {
      const inner = value.slice(1, -1).trim()
      entry.items = inner
        ? inner.split(',').map((item) => unquote(item)).filter((item) => item.length > 0)
        : []
      continue
    }
    entry.value = unquote(value)
  }

  const fields = {}
  for (const [key, entry] of raw) {
    if (entry.block) fields[key] = entry.value.join('\n').trim()
    else if (entry.items.length > 0) fields[key] = entry.items
    else if (entry.value === '[]') fields[key] = []
    else fields[key] = entry.value
  }
  return fields
}

/** 把可能是单值/数组的字段统一成字符串数组。 */
export function asList(value) {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean)
  if (typeof value === 'string' && value.trim()) return [value.trim()]
  return []
}

/** 解析正文里的 wiki 链接；embed 记下 ![[...]] 形式。 */
export function parseWikiLinks(text) {
  const found = []
  const plain = stripCode(text)
  for (const match of plain.matchAll(WIKI)) {
    const raw = (match[1] || match[2] || '').trim()
    if (!raw) continue
    const pipe = raw.indexOf('|')
    const head = pipe >= 0 ? raw.slice(0, pipe) : raw
    const display = pipe >= 0 ? raw.slice(pipe + 1).trim() : ''
    const hash = head.indexOf('#')
    const target = (hash >= 0 ? head.slice(0, hash) : head).trim()
    const anchor = hash >= 0 ? head.slice(hash + 1).trim() : ''
    if (!target) continue
    found.push({ target, anchor, display, embed: Boolean(match[1]) })
  }
  return found
}

/** 标题原文与层级；锚点比较用 text。 */
export function parseHeadings(text) {
  const found = []
  for (const match of stripCode(text).matchAll(HEADING)) {
    const title = match[2].trim()
    if (title) found.push({ level: match[1].length, text: title })
  }
  return found
}

/** 显示标题：题头 title，否则去掉 NN- 前缀的文件名。 */
export function displayTitle(note) {
  const title = typeof note?.fields?.title === 'string' ? note.fields.title.trim() : ''
  if (title) return title
  const stem = String(note?.stem || note?.file || '').replace(/\.md$/, '')
  return stem.replace(/^\d{2}-/, '') || stem
}

/** 字数：中日韩字符按字，拉丁按词。只用于统计展示，不参与校验。 */
export function wordCount(text) {
  const cjk = (String(text).match(/[\u3400-\u9fff\uf900-\ufaff]/g) || []).length
  const latin = (String(text).replace(/[\u3400-\u9fff\uf900-\ufaff]/g, ' ').match(/[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*/g) || []).length
  return cjk + latin
}

/** 纯文本摘要片段；用于搜索结果，不试图保留 Markdown。 */
export function makeSnippet(text, query, radius = 56) {
  const plain = stripCode(text).replace(/!\[\[[^\]]*\]\]/g, '').replace(/\[\[([^\]]+)\]\]/g, (_, raw) => raw.split('|')[0].split('#')[0]).replace(/[#>*_`~|-]/g, ' ').replace(/\s+/g, ' ').trim()
  const needle = String(query || '').trim().toLowerCase()
  if (!needle) return plain.slice(0, radius * 2)
  const at = plain.toLowerCase().indexOf(needle)
  if (at < 0) return plain.slice(0, radius * 2)
  const start = Math.max(0, at - radius)
  const end = Math.min(plain.length, at + needle.length + radius)
  return `${start > 0 ? '…' : ''}${plain.slice(start, end)}${end < plain.length ? '…' : ''}`
}

/** 语义化版本比较；知识包版本来自 manifest，不依赖 npm。 */
export function compareVersion(a, b) {
  const parse = (value) => {
    const text = String(value || '0.0.0').trim().replace(/^v/, '')
    const [core, pre = ''] = text.split('-', 2)
    const numbers = core.split('.').map((part) => {
      const n = Number.parseInt(part, 10)
      return Number.isFinite(n) ? n : 0
    })
    while (numbers.length < 3) numbers.push(0)
    return { numbers, pre }
  }
  const left = parse(a)
  const right = parse(b)
  for (let i = 0; i < 3; i += 1) {
    if (left.numbers[i] !== right.numbers[i]) return left.numbers[i] - right.numbers[i]
  }
  if (!left.pre && right.pre) return 1
  if (left.pre && !right.pre) return -1
  return left.pre.localeCompare(right.pre, 'en')
}

export function isNoteFile(name) {
  return NOTE_FILE.test(String(name || ''))
}

/**
 * 由一篇篇已读入的笔记构建包索引。
 * @param {{ manifest: object, id?: string, version?: string, root?: string, files: Array<{name: string, text: string, mtime?: number, size?: number}> }} input
 */
export function buildIndex(input) {
  const manifest = input?.manifest && typeof input.manifest === 'object' ? input.manifest : {}
  const knowledge = manifest.knowledge && typeof manifest.knowledge === 'object' ? manifest.knowledge : {}
  const id = String(input.id || manifest.id || '')
  const version = String(input.version || manifest.version || '')
  const files = Array.isArray(input.files) ? input.files : []

  const notes = []
  const byStem = new Map()
  for (const file of files) {
    if (!isNoteFile(file.name)) continue
    const stem = file.name.replace(/\.md$/, '')
    const parsed = parseFrontmatter(file.text)
    const note = {
      file: file.name,
      stem,
      title: '',
      fields: parsed.fields,
      body: parsed.body,
      headings: parseHeadings(parsed.body),
      links: parseWikiLinks(file.text),
      tags: asList(parsed.fields.tags),
      aliases: asList(parsed.fields.aliases),
      summary: typeof parsed.fields.summary === 'string' ? parsed.fields.summary : '',
      type: typeof parsed.fields.type === 'string' ? parsed.fields.type : '',
      status: typeof parsed.fields.status === 'string' ? parsed.fields.status : '',
      updated: typeof parsed.fields.updated === 'string' ? parsed.fields.updated : '',
      created: typeof parsed.fields.created === 'string' ? parsed.fields.created : '',
      security_level: typeof parsed.fields.security_level === 'string' ? parsed.fields.security_level : '',
      domain: typeof parsed.fields.domain === 'string' ? parsed.fields.domain : '',
      knowledge_kind: typeof parsed.fields.knowledge_kind === 'string' ? parsed.fields.knowledge_kind : '',
      size: file.size || 0,
      mtime: file.mtime || 0,
      words: wordCount(parsed.body),
      warnings: [],
    }
    note.title = displayTitle(note)
    notes.push(note)
    byStem.set(stem, note)
  }

  const headingSet = new Map()
  for (const note of notes) {
    headingSet.set(note.stem, new Set(note.headings.map((heading) => heading.text)))
  }

  const edges = []
  const seenEdges = new Set()
  const backlinks = new Map()
  const inbound = new Map()
  for (const note of notes) {
    for (const link of note.links) {
      if (!byStem.has(link.target)) {
        note.warnings.push({ rule: 'NOTE_LINK', message: `[[${link.target}]] 在这组笔记里没有对应文件` })
        continue
      }
      if (link.anchor && !headingSet.get(link.target).has(link.anchor)) {
        note.warnings.push({ rule: 'NOTE_ANCHOR', message: `[[${link.target}#${link.anchor}]] 的目标里没有这个标题` })
      }
      if (link.target === note.stem) continue
      const edgeKey = `${note.stem}\u0000${link.target}\u0000${link.anchor}`
      if (seenEdges.has(edgeKey)) continue
      seenEdges.add(edgeKey)
      edges.push({ from: note.stem, to: link.target, anchor: link.anchor, display: link.display, embed: link.embed })
      inbound.set(link.target, (inbound.get(link.target) || 0) + 1)
      if (!backlinks.has(link.target)) backlinks.set(link.target, [])
      backlinks.get(link.target).push({ from: note.stem, anchor: link.anchor })
    }
  }

  const entryStem = String(knowledge.entry || '').replace(/\.md$/, '')
  for (const note of notes) {
    const count = inbound.get(note.stem) || 0
    if (note.stem !== entryStem && count === 0) {
      note.warnings.push({ rule: 'NOTE_ORPHAN', message: '这篇没有任何入链；入口篇应链接到它', severity: 'warning' })
    }
  }

  const facets = { topic: [], entity: [], method: [], source: [], other: [] }
  const facetMap = new Map()
  for (const note of notes) {
    for (const tag of note.tags) {
      const slash = tag.indexOf('/')
      const facet = slash > 0 ? tag.slice(0, slash) : 'other'
      const slug = slash > 0 ? tag.slice(slash + 1) : tag
      const key = `${facet}/${slug}`
      if (!facetMap.has(key)) {
        facetMap.set(key, { id: key, facet, slug, count: 0, notes: [] })
        if (!facets[facet]) facets[facet] = []
        facets[facet].push(facetMap.get(key))
      }
      const item = facetMap.get(key)
      item.count += 1
      item.notes.push(note.stem)
    }
  }
  for (const list of Object.values(facets)) list.sort((a, b) => b.count - a.count || a.slug.localeCompare(b.slug, 'zh'))

  const meta = { type: {}, status: {}, security: {} }
  for (const note of notes) {
    for (const [key, field] of [['type', note.type], ['status', note.status], ['security', note.security_level]]) {
      if (!field) continue
      meta[key][field] = (meta[key][field] || 0) + 1
    }
  }

  const warnings = notes.flatMap((note) => note.warnings.map((warning) => ({ ...warning, file: note.file, stem: note.stem })))
  const textByStem = new Map(notes.map((note) => [note.stem, note.body]))
  const result = {
    id,
    version,
    root: String(input.root || ''),
    manifest,
    title: String(manifest.title || id || '未命名知识包'),
    summary: String(manifest.summary || ''),
    description: String(manifest.description || ''),
    taxonomy: knowledge.taxonomy && typeof knowledge.taxonomy === 'object' ? knowledge.taxonomy : {},
    security_level: String(knowledge.security_level || ''),
    scope: String(knowledge.scope || ''),
    language: String(knowledge.language || ''),
    license: String(knowledge.license || ''),
    vocabulary: String(knowledge.vocabulary || ''),
    topics: asList(knowledge.topics),
    producer: String(knowledge.producer || ''),
    entry: String(knowledge.entry || ''),
    entryStem,
    notes: notes.map(({ fields, body, links, ...rest }) => ({
      ...rest,
      linkCount: links.length,
      backlinkCount: backlinks.get(rest.stem)?.length || 0,
      outlinkCount: edges.filter((edge) => edge.from === rest.stem).length,
    })),
    edges,
    backlinks: Object.fromEntries(backlinks),
    facets,
    meta,
    warnings,
    stats: {
      notes: notes.length,
      links: edges.length,
      orphans: notes.filter((note) => note.warnings.some((warning) => warning.rule === 'NOTE_ORPHAN')).length,
      tags: facetMap.size,
      words: notes.reduce((total, note) => total + note.words, 0),
    },
  }
  // 正文不进 JSON；服务端搜索与摘要通过这个不可枚举表取。
  Object.defineProperty(result, '_text', { value: textByStem, enumerable: false })
  return result
}

/**
 * 搜索包索引。query 支持空格分隔的多词，全部命中才返回；中文按子串。
 * 排序：标题 > 别名/摘要 > 标签 > 正文；同分按 updated 倒序。
 */
export function searchIndex(index, query, limit = 30, options = {}) {
  const field = ['all', 'summary', 'title', 'tags'].includes(options.field) ? options.field : 'all'
  const terms = String(query || '').trim().toLowerCase().split(/\s+/).filter(Boolean)
  if (terms.length === 0) return []
  const notes = Array.isArray(index?.notes) ? index.notes : []
  const hits = []
  for (const note of notes) {
    const rawBody = index?._text?.get(note.stem) ?? ''
    const fields = {
      title: String(note.title || '').toLowerCase(),
      stem: String(note.stem || '').toLowerCase(),
      aliases: (note.aliases || []).join(' ').toLowerCase(),
      summary: String(note.summary || '').toLowerCase(),
      tags: (note.tags || []).join(' ').toLowerCase(),
      body: String(rawBody).toLowerCase(),
    }
    const selected = field === 'all'
      ? ['title', 'stem', 'aliases', 'summary', 'tags', 'body']
      : field === 'title' ? ['title', 'stem']
        : field === 'tags' ? ['tags']
          : ['summary']
    const weights = { title: 120, stem: 80, aliases: 45, summary: 35, tags: 30, body: 10 }
    let score = 0
    let matched = true
    for (const term of terms) {
      let termScore = 0
      for (const key of selected) {
        if (!fields[key].includes(term)) continue
        termScore += weights[key]
        if (key === 'body') termScore += Math.min(20, (fields[key].split(term).length - 1) * 2)
      }
      if (termScore === 0) {
        matched = false
        break
      }
      score += termScore
    }
    if (!matched) continue
    const snippet = field === 'summary'
      ? makeSnippet(note.summary || '', terms[0], 90)
      : field === 'title'
        ? makeSnippet(note.summary || note.title || '', terms[0], 90)
        : field === 'tags'
          ? (note.tags || []).join(' · ')
          : makeSnippet(rawBody, terms[0])
    hits.push({
      stem: note.stem,
      file: note.file,
      title: note.title,
      type: note.type,
      status: note.status,
      tags: note.tags,
      summary: note.summary,
      updated: note.updated,
      score,
      matchedField: field,
      snippet,
    })
  }
  hits.sort((a, b) => b.score - a.score || String(b.updated).localeCompare(String(a.updated)))
  return hits.slice(0, Math.max(1, Math.min(200, limit)))
}

/** 包摘要，供侧栏与 library.json 使用。 */
export function packageSummary(index) {
  return {
    id: index.id,
    version: index.version,
    title: index.title,
    summary: index.summary,
    taxonomy: index.taxonomy,
    security_level: index.security_level,
    scope: index.scope,
    entry: index.entry,
    notes: index.stats.notes,
    links: index.stats.links,
    orphans: index.stats.orphans,
    tags: index.stats.tags,
    words: index.stats.words,
    root: index.root,
    manifest_sha256: index.manifest_sha256 || '',
  }
}
