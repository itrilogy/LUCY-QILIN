#!/usr/bin/env python3
"""复盘简报 PPT 构建脚本 — 两段式 2b（pandoc 编译 + officecli 主题精修）· 可整体重跑。

流程：pandoc 编译 md（文本期产物）→ officecli 主题级精修（背景/字体/配色/装饰签名）→ 质量门。
风格：dark--blueprint-grid（Deep Blue 1B3A5C 底 / Bright Blue 4A90D9 / White / Gold E8C547）。
用法：python3 build-复盘简报.py
"""
import subprocess, sys, os, re, json

DOC = os.path.dirname(os.path.abspath(__file__))
os.chdir(DOC)
MD, PPTX = "复盘简报_slides.md", "复盘简报.pptx"
BG, TITLE_C, BODY_C, GOLD, CN = "1B3A5C", "4A90D9", "FFFFFF", "E8C547", "微软雅黑"
SECTION_LEADS = ("一、", "二、", "三、", "四、", "五、")


def run(*a, check=True):
    r = subprocess.run(list(a), capture_output=True, text=True)
    if check and r.returncode != 0:
        print("FAIL:", " ".join(a)[:110], "\n", r.stderr.strip()[-200:]); sys.exit(1)
    return r.stdout


def slides():
    line = run("officecli", "view", PPTX, "outline").split("\n")[0]
    m = re.search(r"(\d+)\s+slides", line)
    return int(m.group(1)) if m else 0


def shapes(i):
    return json.loads(run("officecli", "get", PPTX, f"/slide[{i}]", "--depth", "1", "--json")) \
        .get("data", {}).get("results", [{}])[0].get("children", [])


# 1) 文本期 → pptx（fresh 编译，保证可重跑）
print("[1/3] pandoc 编译 …")
run("pandoc", MD, "-t", "pptx", "-o", PPTX, "--slide-level=2")
n = slides()
print(f"      编译完成：{n} 页")

# 2) 2b 主题精修
print("[2/3] officecli 主题精修 …")
run("officecli", "open", PPTX)
for i in range(1, n + 1):
    run("officecli", "set", PPTX, f"/slide[{i}]", "--prop", f"background={BG}")
    # 顶部金线（blueprint 风格签名；细且贴边，不遮内容）
    run("officecli", "add", PPTX, f"/slide[{i}]", "--type", "shape",
        "--prop", "name=_sig-topline", "--prop", "geometry=rect", "--prop", f"fill={GOLD}",
        "--prop", "line=none", "--prop", "x=0cm", "--prop", "y=0cm",
        "--prop", "width=33.87cm", "--prop", "height=0.09cm")
    for k in shapes(i):
        f = k.get("format", {})
        ph = f.get("phType") or ""
        path = k.get("path")
        text = f.get("text") or ""
        if not path:
            continue
        if f.get("isTitle") or ph in ("title", "ctrTitle"):
            if ph == "ctrTitle":                                   # 封面主标题
                run("officecli", "set", PPTX, path, "--prop", f"font={CN}",
                    "--prop", "color=FFFFFF", "--prop", "size=40", "--prop", "bold=true")
            elif text.strip().startswith(SECTION_LEADS):           # Section 页
                run("officecli", "set", PPTX, path, "--prop", f"font={CN}",
                    "--prop", f"color={GOLD}", "--prop", "size=36", "--prop", "bold=true")
            else:                                                  # 内容页标题
                run("officecli", "set", PPTX, path, "--prop", f"font={CN}",
                    "--prop", f"color={TITLE_C}", "--prop", "size=30", "--prop", "bold=true")
        elif ph == "subtitle":
            run("officecli", "set", PPTX, path, "--prop", f"font={CN}",
                "--prop", f"color={TITLE_C}", "--prop", "size=20")
        elif ph == "body" or f.get("type") == "placeholder":
            run("officecli", "set", PPTX, path, "--prop", f"font={CN}",
                "--prop", f"color={BODY_C}", "--prop", "size=20")
# 2.5) 采纳 view issues 的 suggest.height（P0 度量协议第一手段：官方修复值，一轮闭环）
for _round in range(3):
    out = run("officecli", "view", PPTX, "issues")
    fixed = 0
    for m in re.finditer(r"(/slide\[\d+\]/shape\[@id=\d+\])[^\n]*?suggest\.height=([\d.]+)cm", out):
        run("officecli", "set", PPTX, m.group(1), "--prop", f"height={m.group(2)}cm", check=False)
        fixed += 1
    if fixed == 0:
        break
    print(f"      采纳 suggest.height 修复 {fixed} 框（第 {_round + 1} 轮）")
run("officecli", "close", PPTX)
run("officecli", "validate", PPTX)
print("      主题精修完成（背景/字体/配色/签名线 + 溢出闭环）")

# 3) 质量门
print("[3/3] 质量门 …")
issues = run("officecli", "view", PPTX, "issues")
m = re.search(r"Found (\d+) issue", issues)
print(f"      issues = {m.group(1) if m else 0}")
stats = run("officecli", "view", PPTX, "stats")
print("      " + " | ".join(l.strip() for l in stats.splitlines()
                            if "Slides" in l or "Text" in l or "Words" in l or "Pictures" in l))
notes = json.loads(run("officecli", "query", PPTX, "notes", "--json"))["data"]["results"]
print(f"      notes = {len(notes)} 条")
print("构建完成：", PPTX)
