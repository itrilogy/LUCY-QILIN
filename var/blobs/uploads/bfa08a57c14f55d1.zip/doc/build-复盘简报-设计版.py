#!/usr/bin/env python3
"""复盘简报 · 风格化设计版（2c 自由版式重做）— 蓝图网格风格 + 视觉体系。

风格：dark--blueprint-grid 深度应用
  · 蓝图网格底纹（4A90D9 @0.15，横 3 竖 4）
  · 顶部金色签名线 E8C547 / 页脚页码 / 章节巨型数字（opacity 0.15）
  · 卡片体系（roundRect 22456B 底 + 3A6EA5 描边）、KPI 大数字卡、阶梯时间线、双列对比
度量：P0 §Text metrics —— 框高 = ceil(行数)×size×1.2 + 7.2pt（全角=1.2×size pt）
流程：建 deck → 逐页背景/网格/内容 → close → validate → issues 闭环（采纳 suggest.height）
      → notes 迁移（scripts/notes_migrate.py，从 2b 版按页序复制）
用法：python3 build-复盘简报-设计版.py
"""
import subprocess, sys, os, re, json

DOC = os.path.dirname(os.path.abspath(__file__))
os.chdir(DOC)
PPTX = sys.argv[1] if len(sys.argv) > 1 else "复盘简报-设计版.pptx"   # 可指定输出名（避免占用冲突）
MD = "复盘简报_slides.md"                                            # notes 的唯一事实源
BG, GRID, GOLD = "1B3A5C", "4A90D9", "E8C547"
WHITE, BODY, CARD, EDGE, MUTED = "FFFFFF", "D6E4F5", "22456B", "3A6EA5", "8FB4D9"
CN = "微软雅黑"
PT2CM = 28.3465
W, H = 33.87, 19.05


def run(*a, check=True):
    r = subprocess.run(list(a), capture_output=True, text=True)
    if check and r.returncode != 0:
        print("FAIL:", " ".join(a)[:130], "\n", r.stderr.strip()[-200:]); sys.exit(1)
    return r.stdout


def batch(cmds):
    r = subprocess.run(["officecli", "batch", PPTX], input=json.dumps(cmds, ensure_ascii=False),
                       capture_output=True, text=True)
    if r.returncode != 0:
        print("BATCH FAIL:", r.stderr.strip()[-250:]); sys.exit(1)


def est_lines(text, size, w):
    cw = size * 1.2
    eff = w * PT2CM - 14.4
    per = max(1, int(eff // cw))
    # 显式换行按段分别计算行数后求和（P0 补充条款：多段文本的行数 = Σ 各段行数）
    return sum(max(1, -(-len(seg) // per)) for seg in text.split("\n"))


def est_h(text, size, w):
    return round((est_lines(text, size, w) * size * 1.2 + 7.2) / PT2CM, 2)


def shape(slide, x, y, w, h, **p):
    """add shape with props."""
    cmd = ["officecli", "add", PPTX, f"/slide[{slide}]", "--type", "shape",
           "--prop", f"x={x}cm", "--prop", f"y={y}cm", "--prop", f"width={w}cm", "--prop", f"height={h}cm"]
    for k, v in p.items():
        cmd += ["--prop", f"{k}={v}"]
    run(*cmd)


def text(slide, s, x, y, w, size, color=BODY, bold=False, name=None, align="left", font=CN):
    h = est_h(s, size, w)
    p = dict(text=s, **{"font": font}, size=size, color=color, dense="")
    del p["dense"]
    if bold:
        p["bold"] = "true"
    if name:
        p["name"] = name
    if align != "left":
        p["align"] = align
    shape(slide, x, y, w, h, **p)
    return h


def card(slide, x, y, w, h, fill=CARD, edge=EDGE):
    shape(slide, x, y, w, h, geometry="roundRect", fill=fill,
          line="none")


def grid(slide):
    """蓝图网格（batch 提速）+ 顶部金线 + 页脚"""
    cmds = []
    for i in range(1, 4):                       # 横线 3
        cmds.append({"command": "add", "parent": f"/slide[{slide}]", "type": "shape",
                     "props": {"name": f"_h{i}", "geometry": "rect", "fill": GRID, "opacity": "0.13",
                               "line": "none", "x": "0cm", "y": f"{i * 4.76}cm",
                               "width": f"{W}cm", "height": "0.03cm"}})
    for i in range(1, 5):                       # 竖线 4
        cmds.append({"command": "add", "parent": f"/slide[{slide}]", "type": "shape",
                     "props": {"name": f"_v{i}", "geometry": "rect", "fill": GRID, "opacity": "0.13",
                               "line": "none", "x": f"{i * 6.774}cm", "y": "0cm",
                               "width": "0.03cm", "height": f"{H}cm"}})
    cmds.append({"command": "add", "parent": f"/slide[{slide}]", "type": "shape",
                 "props": {"name": "_topline", "geometry": "rect", "fill": GOLD, "line": "none",
                           "x": "0cm", "y": "0cm", "width": f"{W}cm", "height": "0.1cm"}})
    cmds.append({"command": "add", "parent": f"/slide[{slide}]", "type": "shape",
                 "props": {"name": "_footline", "geometry": "rect", "fill": EDGE, "opacity": "0.5",
                           "line": "none", "x": "1.5cm", "y": "18.10cm", "width": "30.87cm", "height": "0.03cm"}})
    batch(cmds)
    # 页脚：y 18.22 + 9pt 行高 0.635cm = 18.86cm < 19.05（底部保留 ≥0.19cm；layout_scan 复检）
    text(slide, "slide-master 实战复盘 · 2026-09-09", 1.5, 18.22, 20, 9, MUTED)
    text(slide, f"{slide:02d}", 31, 18.22, 1.4, 9, MUTED, align="right")


def new_slide():
    run("officecli", "add", PPTX, "/", "--type", "slide", "--prop", "layout=blank",
        "--prop", f"background={BG}")
    n = int(run("officecli", "view", PPTX, "outline").split("\n")[0].split("|")[-1].split()[0])
    return n


def page_title(slide, t):
    shape(slide, 1.5, 1.05, 3.2, 0.1, geometry="rect", fill=GOLD, line="none")
    text(slide, t, 1.5, 1.45, 30, 30, GOLD, bold=True)


def section(slide, num, t):
    text(slide, num, 2.2, 3.2, 12, 140, GRID, bold=True, name="_bignum")
    run("officecli", "set", PPTX, f"/slide[{slide}]/shape[@name=_bignum]", "--prop", "opacity=0.16")
    shape(slide, 6.0, 11.9, 6.0, 0.12, geometry="rect", fill=GOLD, line="none")
    text(slide, t, 6.0, 8.2, 24, 40, WHITE, bold=True)


# ============ 构建 ============
print("[1/4] 建 deck 与 19 页（自由版式）…")
if os.path.exists(PPTX):
    os.remove(PPTX)
run("officecli", "create", PPTX)
run("officecli", "open", PPTX)

# 1 封面
s = new_slide(); grid(s)
shape(s, 0, 14.2, W, 0.14, geometry="rect", fill=GOLD, line="none")
text(s, "slide-master 实战复盘与优化规划", 2.5, 6.4, 28.9, 44, WHITE, bold=True, align="center")
text(s, "一次真实生成任务的成本复盘 · 根因定位 · 下一轮优化规划", 2.5, 10.6, 28.9, 18, GRID, align="center")
text(s, "信息中心 · 洪光华   |   2026-09-09", 2.5, 15.2, 28.9, 14, MUTED, align="center")

# 2 节一
s = new_slide(); grid(s); section(s, "01", "复盘概览")

# 3 复盘对象与实战任务（4 KPI 卡）
s = new_slide(); grid(s); page_title(s, "复盘对象与实战任务")
kpis = [("复盘对象", "slide-master v1.1.0", GRID), ("实战任务", "调研报告 md → 12 页简报", WHITE),
        ("实测产物", "483 文本块 · 840 字", GOLD), ("演讲备注", "12 页全覆盖", GRID)]
for i, (lab, val, c) in enumerate(kpis):
    x = 1.5 + i * 8.0
    card(s, x, 5.2, 7.5, 9.5)
    text(s, lab, x + 0.55, 6.0, 6.4, 14, GOLD, bold=True)
    text(s, val, x + 0.55, 8.2, 6.4, 18, c, bold=(c != GRID))

# 4 决策链（5 步流程）
s = new_slide(); grid(s); page_title(s, "决策链：L0–L4 路由")
steps = [("L1", "输入形态", "无既有 pptx"), ("L2", "场景判定", "通用汇报"), ("风格", "横切维度", "style-lookup"),
         ("L4", "执行载体", "Python 495 命令"), ("交付", "质量门", "三件套")]
for i, (k, t1, t2) in enumerate(steps):
    x = 0.9 + i * 6.62
    card(s, x, 6.2, 5.6, 6.4)
    text(s, k, x + 0.5, 6.9, 4.6, 16, GOLD, bold=True)
    text(s, t1, x + 0.5, 8.6, 4.6, 14, WHITE, bold=True)
    text(s, t2, x + 0.5, 10.4, 4.6, 13, BODY)
    if i < 4:
        shape(s, x + 5.65, 8.9, 0.82, 0.06, geometry="rect", fill=GOLD, line="none")

# 5 节二
s = new_slide(); grid(s); section(s, "02", "过程与证据")

# 6 终态质量门证据（5 行表格式）
s = new_slide(); grid(s); page_title(s, "终态质量门证据")
rows = [("结构校验 validate", "零错误", "通过"), ("溢出项 view issues", "83 → 0", "三轮收敛"),
        ("占位符扫描", "0 命中", "干净"), ("演讲备注", "12 / 12 页", "全覆盖"),
        ("越界扫描 DOM", "11 / 12 页为 0", "S1 为设计 bleed")]
for i, (a, b, c) in enumerate(rows):
    y = 4.8 + i * 2.62
    shape(s, 1.5, y, 0.14, 2.2, geometry="rect", fill=GOLD if i % 2 == 0 else GRID, line="none")
    text(s, a, 2.1, y + 0.35, 12, 16, WHITE, bold=True)
    text(s, b, 15.0, y + 0.28, 8, 18, GOLD, bold=True)
    text(s, c, 23.5, y + 0.42, 9, 14, MUTED)

# 7 执行载体（4 卡）
s = new_slide(); grid(s); page_title(s, "执行载体：为什么用 Python")
cards = [("中文长文本", "命令行需处理美元符 / 引号 / 换行三层转义，量一大风险线性放大"),
         ("规则版面", "每页 5–15 个形状，循环与几何函数化收益最大"),
         ("失败恢复", "脚本即状态：可 rm 后整体重跑，不手工续补"),
         ("一处封装", "自动行高估计算法收敛所有文本框几何")]
for i, (t1, t2) in enumerate(cards):
    x = 1.5 + (i % 2) * 16.0
    y = 5.0 + (i // 2) * 6.4
    card(s, x, y, 15.0, 5.6)
    text(s, "0%d" % (i + 1), x + 0.6, y + 0.5, 3, 22, GOLD, bold=True)
    text(s, t1, x + 2.6, y + 0.62, 11.6, 16, WHITE, bold=True)
    text(s, t2, x + 0.7, y + 2.5, 13.6, 14, BODY)

# 8 节三
s = new_slide(); grid(s); section(s, "03", "成本复盘")

# 9 成本时间线（阶梯）
s = new_slide(); grid(s); page_title(s, "成本时间线：83 到 0")
tl = [("轮 0", "全量构建", "83", 8.6), ("轮 1", "单行余量", "17", 4.2), ("轮 2", "行数估算", "3", 2.0), ("轮 3", "定长修正", "0", 0.9)]
for i, (r, act, val, bh) in enumerate(tl):
    x = 1.5 + i * 8.0
    base = 12.6
    if float(val) > 0:
        shape(s, x, base - bh, 6.9, bh, geometry="roundRect", fill=CARD, line=EDGE)
    text(s, val, x, base - bh - 2.6, 6.9, 40, GOLD if val != "0" else GRID, bold=True, align="center")
    text(s, r, x, base + 0.35, 6.9, 15, WHITE, bold=True, align="center")
    text(s, act, x, base + 1.9, 6.9, 13, MUTED, align="center")

# 10 问题聚类（5 类）
s = new_slide(); grid(s); page_title(s, "问题聚类：五类根因")
cl = [("C1", "页脚小字溢出", "约 12 条", "0.6cm 框放 9.5pt：内边距吃掉可用高"),
      ("C2", "短标签两行溢出", "多条", "中文全角宽度未估算"),
      ("C3", "结构性遮挡", "6 条以上", "元素纵向预算未做，底卡压页脚"),
      ("C4", "标题折行压内容", "1 条", "标题全角超 20 字即折行"),
      ("C5", "装饰性 bleed 误报", "2 条", "设计意图，非缺陷")]
for i, (k, t1, freq, why) in enumerate(cl):
    y = 4.7 + i * 2.68
    card(s, 1.5, y, 30.87, 2.3, fill=CARD)
    text(s, k, 2.2, y + 0.55, 2, 16, GOLD, bold=True)
    text(s, t1, 4.4, y + 0.52, 7.6, 15, WHITE, bold=True)
    text(s, freq, 12.4, y + 0.55, 4, 14, GOLD)
    text(s, why, 17.0, y + 0.6, 14.8, 13, MUTED)

# 11 收敛工具（公式卡）
s = new_slide(); grid(s); page_title(s, "收敛工具：行数感知估算器")
fx = [("全角字宽", "≈ 0.0353 cm/pt（按字号）"), ("有效宽", "= 框宽 − 0.56 cm（左右内边距）"),
      ("最小高", "= 行数 × 0.0423 × 字号 + 0.42cm")]
for i, (t1, t2) in enumerate(fx):
    x = 1.5 + i * 10.6
    card(s, x, 5.0, 9.9, 5.2)
    text(s, t1, x + 0.6, 5.7, 8.7, 16, GOLD, bold=True)
    text(s, t2, x + 0.6, 7.7, 8.7, 14, BODY)
shape(s, 1.5, 11.6, 0.16, 4.6, geometry="rect", fill=GOLD, line="none")
text(s, "接入后 83 → 17，配合结构重排 → 0。教训：应固化进技能，忌每次由 agent 推导。",
     2.3, 12.2, 29.5, 20, WHITE, bold=True)

# 12 Gate 3 工具链
s = new_slide(); grid(s); page_title(s, "Gate 3 工具链成本")
g3 = [("截图命令", "宿主无 headless，直接失败"), ("Puppeteer + Edge", "成功，需指定浏览器路径"),
      ("DOM 越界扫描", "零依赖、覆盖全部页面")]
for i, (t1, t2) in enumerate(g3):
    y = 5.0 + i * 3.3
    card(s, 1.5, y, 18.5, 2.9)
    text(s, "0%d" % (i + 1), 2.2, y + 0.6, 2, 18, GOLD, bold=True)
    text(s, t1, 4.4, y + 0.55, 6.6, 16, WHITE, bold=True)
    text(s, t2, 11.2, y + 0.62, 8.4, 13, BODY)
card(s, 21.3, 5.0, 11.07, 9.5)
text(s, "结论", 22.0, 5.7, 9.7, 17, GOLD, bold=True)
text(s, "应脚本化为 Gate 3 前置检查；判读改「截图 + DOM」双轨，DOM 为 MUST。",
     22.0, 7.8, 9.7, 15, WHITE)

# 13 节四
s = new_slide(); grid(s); section(s, "04", "根因定位")

# 14 G1–G8（8 卡）
s = new_slide(); grid(s); page_title(s, "技能缺口：G1 到 G8")
gs = [("G1", "溢出防护协议缺失"), ("G2", "中英混排宽度参考缺失"), ("G3", "footer 保留区未约定"),
      ("G4", "标题单行宽度速查缺失"), ("G5", "font/font.ea 规范未成文"), ("G6", "Python build 模板缺失"),
      ("G7", "单页信息量预算缺失"), ("G8", "备注字数无按页反推")]
for i, (k, t1) in enumerate(gs):
    x = 1.5 + (i % 4) * 7.97
    y = 5.0 + (i // 4) * 5.6
    card(s, x, y, 7.47, 4.8)
    text(s, k, x + 0.5, y + 0.5, 3, 18, GOLD, bold=True)
    text(s, t1, x + 0.5, y + 2.3, 6.5, 13, WHITE)

# 15 工具链与规划问题
s = new_slide(); grid(s); page_title(s, "工具链与规划问题")
left = ["T1 截图环境依赖未写清", "T2 缺 DOM 越界扫描脚本", "T3 需「截图 + DOM」双轨判读"]
right = ["P1 决策期缺内容密度自检", "P2 未先薄验证再全量铺开"]
for i, t1 in enumerate(left):
    y = 5.2 + i * 3.0
    card(s, 1.5, y, 15.0, 2.5)
    text(s, t1, 2.3, y + 0.68, 13.4, 15, WHITE)
for i, t1 in enumerate(right):
    y = 5.2 + i * 3.0 + 0.6
    card(s, 17.37, y, 15.0, 2.5)
    text(s, t1, 18.17, y + 0.68, 13.4, 15, WHITE)

# 16 节五
s = new_slide(); grid(s); section(s, "05", "优化规划")

# 17 P0
s = new_slide(); grid(s); page_title(s, "P0：文本度量协议（最高优先）")
p0 = ["固化估算器与字号速查表", "标题单行速查：36pt 不超 20 全角",
      "footer 保留区：内容底不超 17.9cm", "字体双写规范与读回校验"]
for i, t1 in enumerate(p0):
    y = 5.0 + i * 2.9
    shape(s, 1.5, y, 0.14, 2.4, geometry="rect", fill=GOLD, line="none")
    text(s, t1, 2.3, y + 0.55, 18, 18, WHITE, bold=True)
card(s, 21.3, 5.0, 11.07, 9.5)
text(s, "目标", 22.0, 5.8, 9.7, 17, GOLD, bold=True)
text(s, "中文高密度 deck\n首轮溢出\n≤ 10 条", 22.0, 7.6, 9.7, 26, WHITE, bold=True)

# 18 P1/P2 与试点验证
s = new_slide(); grid(s); page_title(s, "P1 / P2 与试点验证")
card(s, 1.5, 5.0, 15.0, 9.5)
text(s, "P1 · 工具链脚本化", 2.3, 5.8, 13.4, 17, GOLD, bold=True)
text(s, "越界扫描脚本化\n目检改双轨判读\n首页薄验证先校准", 2.3, 8.2, 13.4, 15, WHITE)
card(s, 17.37, 5.0, 15.0, 9.5)
text(s, "P2 · 规划与预算", 18.17, 5.8, 13.4, 17, GOLD, bold=True)
text(s, "单页预算：正文 ≤200 字\n备注换算：12 页 ≤210 字/页\n试点：同源材料 8 页对照", 18.17, 8.2, 13.4, 15, WHITE)

# 19 结论
s = new_slide(); grid(s); page_title(s, "结论与不做清单")
cc = ["复杂度来自未文档化的隐性规则", "修复方向：从推导改为查表复用", "范围护栏：不动风格库与专精规则"]
for i, t1 in enumerate(cc):
    y = 5.0 + i * 3.0
    card(s, 1.5, y, 22, 2.6)
    text(s, "0%d" % (i + 1), 2.2, y + 0.62, 2, 17, GOLD, bold=True)
    text(s, t1, 4.4, y + 0.62, 18.6, 16, WHITE)
card(s, 1.5, 14.4, 30.87, 2.9)
text(s, "保持零第三方依赖 · 保持唯一出口 · 经验留在技能里，而不是留在这次会话里",
     2.3, 15.25, 29, 16, GOLD, bold=True, align="center")

run("officecli", "close", PPTX)

# P0 溢出闭环（含落盘后复检：view issues 输出可能滞后于写盘）
print("[2/4] 溢出闭环（采纳 suggest.height）…")
run("officecli", "close", PPTX)
for _round in range(4):
    out = run("officecli", "view", PPTX, "issues")
    m = re.search(r"Found (\d+) issue", out)
    n = int(m.group(1)) if m else 0
    if n == 0:
        print(f"      issues = 0（第 {_round} 轮复检）"); break
    print(f"      本轮 issues = {n}，采纳 suggest.height …")
    run("officecli", "open", PPTX)
    for mm in re.finditer(r"(/slide\[\d+\]/shape\[@id=\d+\])[^\n]*?suggest\.height=([\d.]+)cm", out):
        run("officecli", "set", PPTX, mm.group(1), "--prop", f"height={mm.group(2)}cm", check=False)
    run("officecli", "close", PPTX)
run("officecli", "validate", PPTX)

# notes：从 md 直接解析并写入（唯一事实源），随后落盘复检
print("[3/4] notes 从 md 直写 …")


def notes_from_md(path):
    """md → {页序号: 备注}；页序与 pandoc --slide-level=2 一致（封面=1，其后每个 #/## 各一页）。"""
    page, out, cur = 1, {}, None
    for ln in open(path, encoding="utf-8"):
        s = ln.rstrip("\n")
        if cur is not None:
            if s.strip() == ":::":
                out[page] = "\n".join(cur).strip(); cur = None
            else:
                cur.append(s)
            continue
        if s.startswith("::: notes"):
            cur = []
        elif s.startswith("# ") or s.startswith("## "):
            page += 1
    return out


notes = notes_from_md(MD)
run("officecli", "open", PPTX)
for n, t in sorted(notes.items()):
    run("officecli", "remove", PPTX, f"/slide[{n}]/notes", check=False)
    run("officecli", "add", PPTX, f"/slide[{n}]", "--type", "notes", "--prop", f"text={t}")
run("officecli", "close", PPTX)
# 落盘复检（独立进程读磁盘，排除 resident 内存假象）
got = json.loads(run("officecli", "query", PPTX, "notes", "--json"))["data"]["results"]
print(f"      写入 {len(notes)} 条 · 落盘复检 {len(got)} 条")
assert len(got) == len(notes), f"notes 落盘校验失败：{len(got)} != {len(notes)}"

# 质量门
print("[4/4] 质量门 …")
out = run("officecli", "view", PPTX, "issues")
m = re.search(r"Found (\d+) issue", out)
print(f"      issues = {m.group(1) if m else 0}")
r = subprocess.run([sys.executable, "../scripts/layout_scan.py", PPTX, "--quiet"],
                   capture_output=True, text=True)
print("      " + (r.stdout.strip().splitlines()[0] if r.stdout else r.stderr[-120:]))
assert r.returncode == 0, "layout_scan 发现几何越界"
stats = run("officecli", "view", PPTX, "stats")
print("      " + " | ".join(l.strip() for l in stats.splitlines()
                            if "Slides" in l or "Text" in l or "Pictures" in l))
notes = json.loads(run("officecli", "query", PPTX, "notes", "--json"))["data"]["results"]
print(f"      notes = {len(notes)} 条")
print("交付：", PPTX)
