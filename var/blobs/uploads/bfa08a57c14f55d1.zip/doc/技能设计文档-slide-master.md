# slide-master 技能设计文档（SDD · Software Design Document）

| 项 | 值 |
|---|---|
| 文档版本 | 1.0（对应技能 v1.3.1） |
| 文档性质 | **系统规格说明**（与《工程笔记》互补：笔记记"怎么做的"，本文记"长什么样、为何这样设计、接口是什么、如何扩展与验收"） |
| 阅读对象 | 技能维护者、验收评审人、后续接手 Agent |
| 核验方式 | 文中所有路径/命令/数量均可在 `Harness/SKILL/slide-master` 下直接复跑核对 |

---

## 1 概述

### 1.1 定位（一句话）

slide-master 是 **PPT 生产领域的唯一入口技能**：把"要一份 .pptx"的诉求，经确定性意图路由，调度受管的子技能定义与共享资产，产出通过三重质量门、含演讲备注、可重跑复现的演示文稿。

### 1.2 设计目标（可度量）

| 编号 | 目标 | 度量 |
|---|---|---|
| G1 | 稳定产出高质量 deck | 首轮 `view issues` ≤10 且闭环至 0（对照实验：83→0） |
| G2 | 生产可复现 | 一切产物由脚本生成，`rm` + 重跑即重建 |
| G3 | 风格可选且可确定 | 52 风格库 + 确定性风格包（同一输入恒同变体） |
| G4 | 备注质量可控 | content 页 100% 带 notes，字数按风格档 + 落盘复检 |
| G5 | 可长期维护 | 单一事实源 + CHANGELOG + 版本元数据 + 变更同步清单 |
| G6 | 零第三方依赖 | 仅依赖 officecli + pandoc + Python 标准库 |

### 1.3 非目标（明确不做）

- 不做 Word/Excel 生产（转交 `officecli-academic-paper/word-form/data-dashboard/xlsx`）；
- 不做纯文本写作/叙事规划（decision-rules 仅供内部调度，不作为触发面）；
- 不引入第三方 PPTX 库（python-pptx/pptxgenjs 等）；
- 不把 `references/*.md` 还原为平行技能目录（保持唯一出口）。

### 1.4 术语

| 术语 | 定义 |
|---|---|
| 受管模块 / 子技能定义 | `references/*.md` 中的场景化执行规则（无独立 SKILL.md） |
| 继承链 | 场景层（pitch/morph/3d）执行前必读 pptx-base 的硬规则四节 |
| P0 协议 | §6.4 的文本度量协议 |
| 文本期 / 几何期 | 两段式流水线的 markdown 阶段 / officecli 版式阶段 |
| 确定性风格包 | 变体由规则函数唯一确定的风格包（当前：luxi-scenario） |
| 标准物 | 规范化 Markdown 笔记源（素材加工的产物，build 只消费标准物）——概念承自 web-slide-forge §0 |
| 研究链 / 四代 | `pandoc-slide-compiler` → `notes-to-static-site` → `web-slide-forge` → `slide-master`（见 §2.5） |

---

## 2 系统架构

### 2.1 四层架构

```
┌ 决策层（1 文件）───────────────────────────────────────────────┐
│ SKILL.md — 触发契约 · L0–L4 意图路由 · 调度纪律 7 条 · 边界 · 维护溯源 │
└───────────────────────────────────────────────────────────────┘
        ↓ 按路线加载（继承链：先 pptx-base 底线，再目标定义）
┌ 流程规范层（跨路线共享）────────────────────────────────────────┐
│ pipeline（两段式） scaffold（脚手架） speaker-notes（备注）        │
│ style-lookup（风格查找） pandoc-route（md 路线） decision-rules（叙事）│
└───────────────────────────────────────────────────────────────┘
        ↓ 执行定义（继承硬规则）
┌ 执行层（场景定义）─────────────────────────────────────────────┐
│ pptx-base（底座）pitch-deck（路演+Gate6）morph-ppt（动效+Gate5b） │
│ morph-ppt-3d（3D，继承 morph）                                  │
└───────────────────────────────────────────────────────────────┘
        ↓ 调用
┌ 资产层 ────────────────────────────────────────────────────────┐
│ scripts/（8 个可执行）  styles/（52 风格 + luxi 包含 30 SVG 资产）│
└───────────────────────────────────────────────────────────────┘
```

### 2.2 职责矩阵（做什么 / 不做什么）

| 层 | 做 | 不做 |
|---|---|---|
| SKILL.md | 识别意图、逐层 ask、路由、仲裁、转交边界 | 不复制子技能内容、不写具体命令 |
| 流程规范层 | 定义跨路线流程与规范（工作区/备注/风格/编译/叙事） | 不含场景专精规则 |
| 执行层 | 场景化规则、recipes、质量门判据 | 不重复 pptx-base 底线（引用） |
| 资产层 | 可执行脚本、风格与视觉资产 | 不含流程决策 |

### 2.3 依赖关系（继承链）

| 执行定义 | 依赖（执行前必读） |
|---|---|
| `references/pptx-base.md` | 无（底座） |
| `references/pitch-deck.md` | pptx-base 硬规则四节（Requirements / Visual delivery floor / Help-First / Shell & Execution Discipline） |
| `references/morph-ppt.md` | 同上 |
| `references/morph-ppt-3d.md` | morph-ppt + pptx-base |

### 2.4 运行时数据流

```
用户请求
 → [决策层] 触发契约命中 → L1 输入形态判定（编辑/从零/markdown）
 → [决策层] L2 场景 → L3 质量与风格（style-lookup 或 style_route）/ 动画深度
 → [流程层] scaffold 建工作区（默认 workdir）→ speaker-notes 规范就位
 → [执行层] 加载继承链 → 按 recipes 写 build 脚本（或 pandoc 编译）
 → [资产层] 调用 scripts（helpers/迁移/路由）+ styles 资产（含 SVG）
 → [门禁] validate → issues 闭环 → layout_scan → notes 复检 → （morph/pitch 专项门）
 → [交付] 三件套 + 目标 viewer 目检提示 + notes 就位
```

---

### 2.5 设计沿革与思想传承（四代研究链）

slide-master 是同一研究脉络的**第四代**；前三代技能在本机留存（详见工程笔记第零章与附录 E）：

| 代 | 技能（时间） | 命题 | 关键遗产 → slide-master 落点 |
|---|---|---|---|
| 一 | `pandoc-slide-compiler`（2026-06-30） | md → pandoc 编译 .pptx | 5 风格备注字数档 → `speaker-notes.md`；Markdown 语法契约 → `pandoc-route.md`；`validate_slides.py` → `scripts/` |
| 二 | `notes-to-static-site`（2026-08-11） | 笔记 → 静态文档站 | 六阶段工作流 → 决策树+门禁；中文处理经验 → §中文排版；红线/断言 → 质量门 |
| 三 | `web-slide-forge`（2026-09-08） | md → 双模态浏览器站 | **§0「生产是两段式」→ `pipeline.md`**；**CSS 变量主题 + `mood--name` 命名 → `styles/` 风格体系**；**`init_workspace` 就地工作文件夹 → `scaffold.md` 默认落 workdir**；`precheck`/`--verify`/`smoke_test` → 预检/闭环门/`selfcheck.py` |
| 四 | `slide-master`（2026-09-08 起） | 素材/md → **.pptx**（自由版式+动效+风格） | 前三代方法论总成 + officecli 引擎 |

**传承判定依据**（可核验）：
- web-slide-forge §0 原文："技能的生产是**两段式**：build 只消费'标准物'……任意素材都**不直接进 build**"——与 `pipeline.md` 文本期/几何期同义；
- web-slide-forge `assets/themes/dark--premium-navy.css`、`light--minimal-corporate.css`——与风格库目录命名**同名同构**；
- web-slide-forge §12 原文："`init_workspace.py` …（标准物/产物**就地落在你的工作文件夹，不用 /tmp**）"——与 `scaffold.md` 默认工作区约定一致；
- web-slide-forge §13 声明**替代**前两代技能（doc 模式替代 static-site、slide 模式替代 pandoc 编译）。

## 3 组件规格

### 3.1 SKILL.md（139 行）

| 段 | 规格 |
|---|---|
| frontmatter | 必需：`name`（唯一，`slide-master`）· `description`（触发契约，见 §4.1）· `version`（语义化）· `tags`/`category`（分类） |
| 资源布局 | 技能目录树（含 scripts/references/styles 说明）——变更时必须同步 |
| 依赖关系 | 继承链表（§2.3） |
| 意图路由决策树 | L0–L4 伪代码块 + 前置原则 + 风格横切说明 |
| 调度与执行纪律 | 7 条（继承链加载 / 相对路径基准 / Help-First / 文件生命周期 / 交付门 / Reverse handoff / 冲突仲裁）+ 工作区与备注前置段 |
| 边界 | 转交对象与话术（docx/xlsx 系 / pandoc 直编） |
| 典型话术示例 | ≥4 条路由示例 |
| 维护与溯源 | 来源、版本、结构约定（禁还原平行技能）、已知限制、变更注意 |

**约束**：正文只做"路由与纪律"，不得内嵌场景 recipes；路径引用以技能根为基准。

### 3.2 references/ 十二篇（规格摘要）

| 文件 | 职责 | 关键接口 | 依赖 |
|---|---|---|---|
| `pptx-base.md` | 底座：视觉底线/度量协议 P0/读改写 recipes/Design Principles/Gate 1–3/陷阱库 | 被全部执行层继承 | 无 |
| `pitch-deck.md` | 融资路演：轮次诊断→赛道→10+2 recipes→VC ship-check→Gate 6 | 输出单 .pptx | pptx-base |
| `morph-ppt.md` | Morph 动效：命名系统/Scene Actor/ghost 纪律/4 recipes/Gate 5b-morph | 调 `morph_helpers.py` | pptx-base |
| `morph-ppt-3d.md` | 3D：兼容门/模型发现流/镜头语言/尺寸规则/4 产物 | 输出 4 件（含 .glb） | morph-ppt + pptx-base |
| `pipeline.md` | 两段式分流（2a/2b/2c）与成本模型 | 决定是否进几何期 | pandoc-route / scaffold |
| `pandoc-route.md` | pandoc 路线规范：语法全量/层级铁律/5 风格档/编译命令/自检 | 引 `validate_slides.py` | 素材 md |
| `scaffold.md` | 工作区（默认 workdir）/构建纪律/产物生命周期/交付清单 | 三件套约定 | pptx-base 度量 |
| `speaker-notes.md` | 备注创作：三拍结构/字数档/按页反推/写入校验 | 各子技能 notes 规则指向此 | — |
| `style-lookup.md` | 风格查找四步 + 缺失回退 + 确定性包路由节 | 引 `styles/INDEX.md`、`style_route.py` | styles/ |
| `decision-rules.md` | 叙事规划（Pyramid/SCQA/brief.md schema） | 内部调度调用 | — |
| `pptx-design.md` | morph 舞台感设计残注（对比度公式/轨道/演员区间） | 随 style-lookup 使用 | pptx-base |
| `CHANGELOG.md` | 版本变更记录（v1.0→v1.3.1） | 与 frontmatter.version 同步 | — |

### 3.3 scripts/ 八个（CLI 契约）

| 脚本 | 用途 | CLI | 退出码 | 依赖 |
|---|---|---|---|---|
| `morph_helpers.py` | morph 执行助手 | `clone/ghost/verify/final-check/clean-accumulation` | 0/1 | officecli |
| `morph-helpers.sh` | 上述的 bash 等价 | 同名函数 | — | officecli/bc |
| `notes_migrate.py` | 两段式 2c：notes 按页序迁移 | `<old> <new> [--dry-run] [--overwrite]` | 0/1 | officecli |
| `validate_slides.py` | pandoc md 语法校验/自动修复 | `<md> [--fix] [--json] [--pandoc]` | 0/1 | 无 |
| `layout_scan.py` | 零依赖几何越界/重叠扫描（Gate 3 双轨之一） | `<deck\|html> [--allow RE] [--overlap] [--quiet]` | 0/1 | officecli(导出 html) |
| `style_route.py` | 确定性风格路由 | `--scene/--env/--keywords/--from-md/--json/--list` | 0/2 | 读 tokens.json |
| `selfcheck.py` | 运行级回归（五路线） | 无参 | 0/1 | officecli(+pandoc 可选) |
| `pilot_verify.py` | P0 对照实验 | 无参 | 0/1 | officecli(+pandoc 可选) |

**通用契约**：只读不写用户文件（除自建临时目录）；失败以非零退出码 + stderr 说明；不依赖第三方库。

### 3.4 styles/ 风格体系

**风格目录 schema**（52 个目录，`<mood>--<name>/`）：

```
<风格目录>/
├── style.md          # 必需：设计理念/配色（bg/fg/accent hex）/字体/标志手法
├── build.sh          # 可选：演示脚本（坐标有已知 bug，仅供技法参考）
└── <template>.pptx   # 可选：模板
```

**INDEX.md 规范**：主表（目录/名称/主色三元组/适用/气质）+ 场景分组表 + 头部告示（技法参考声明、坐标 bug 声明、上游缺失条目与回退规则）。

**luxi 包特例**（`mixed--luxi-scenario/`）：额外含 `tokens.json`（机器可读）与 `assets/`（30 SVG）。

### 3.5 资产体系（assets/）

| 资产类 | 规格 | 命名 | 用法约束 |
|---|---|---|---|
| 主 LOGO | 2048 viewBox，绿+青官方 path | `logo-lab-mark.svg` | 禁重绘/变形/加描边 |
| 符号标 | 48 viewBox，currentColor 可着色 | `logo-symbol-mark.svg` | 点缀用途，不占封面主位 |
| 双标 lockup | 140×64，等大并排居中 | `logo-lockup.svg` | 双标并排唯一合法形态 |
| 语义图标 | 24×24，stroke 1.7，金/青点缀 | `icons/<语义>.svg` + `INDEX.md` | 每页 ≤3 处 |
| 物料插画 | 180×110 等 | `illustrations/<name>.svg` | 物料页专用；符号标已内联化 |
| 抽取器 | 可重跑 | `extract_assets.py` | 源更新时同步 |

**插入契约**：`--type picture --prop src=<asset>.svg --prop alt=<文本>`（alt 必填；SVG 实测可直接插入）。

---

## 4 接口契约

### 4.1 触发契约（description 规范）

必须包含四要素：
1. **交付契约**：「当且仅当用户诉求是【产出或加工一份 .pptx 文件】时」；
2. **触发词**：中文 + 英文，场景词以"…的 PPT"形式限定（避免裸词误触发）；
3. **DO NOT 清单**：docx/xlsx/纯文本写作/叙述规划（含转交对象名）；
4. **能力声明**：从零/编辑/morph/3D/风格/两段式。

### 4.2 意图路由契约

```
L1 输入形态 → L2 场景 → L3 质量与风格 / 动画深度 → L4 调度执行
ask 规则：能推断不问；每问 ≤4 选项、推荐默认在前；一次一层；中文（除非用户英文）
边界：命中转交对象（docx/xlsx/纯编译）→ 一句话转交，不自行执行
```

### 4.3 风格路由契约（确定性）

```
输入：(scene ∈ 5 值, env ∈ {light, projection})
规则：env==projection → luxi-dark；scene==immersive → luxi-ink；否则 luxi-light
密度：scene ∈ {dashboard, workbench} → compact，否则 regular
scene 判定：关键词词典，最长命中优先（length desc），同长按固定 priority，无命中→缺省 marketing
输出：variant + density + 全量 tokens + type_scale_ppt_pt + radius_ppt_adj + rule_trace
保证：同输入恒同输出（无随机/无打分/无模型判断）
```

### 4.4 质量门契约

| 门 | 命令 | 通过标准 | 失败动作 |
|---|---|---|---|
| Gate 1 schema | `officecli validate` | 无错误 | 修复重跑 |
| Gate 2 溢出/格式 | `officecli view issues` | 计数 0 | 采纳 `suggest.height` 闭环 |
| Gate 2b 占位符 | `view text` + grep | 0 命中 | 补内容 |
| **Gate 3 几何（MUST）** | `layout_scan.py <deck>` | 违规 0 | 调坐标/字体尺寸 |
| Gate 3 视觉（可选） | 截图/HTML 判读 | 逐项清单 | 记录"未视觉验证"项 |
| Gate 5b-morph | 四循环 | 全部 OK | 修 ghost/配对 |
| Gate 6 pitch | 六段检查 | 全部 OK | 修叙事/数字 |
| notes 门 | 落盘复检 `query notes` | 条数 == 预期 | 重写并复检 |

### 4.5 脚手架契约

- 产出默认落 **workdir**；`inputs/`（素材多时）与 `.previews/`（交付前删）；
- 三件套：`<主题>.pptx` + build 脚本（可重跑）+ `brief.md`（两段式时 md 即规划记录）；
- 构建纪律：单次构建（create→open→批量→close→validate）、不依赖 auto-flush、坐标即代码。

---

## 5 关键设计决策（ADR）

### ADR-1 单一出口 vs 多技能并行
- **背景**：4 个 PPT 技能并行时触发面重叠、规则冲突。
- **选项**：A 多技能并行；B 单一总控 + 受管模块。
- **决策**：B。**理由**：触发唯一、规则仲裁明确、资源可共享。**后果**：需自建路由与继承链。

### ADR-2 references 平铺 vs modules 嵌套
- **背景**：初版用 `modules/<name>/MODULE.md` 组织子技能。
- **决策**：改为 `references/*.md` 平铺（Claude 标准技能形态）。
- **理由**：避免无谓子目录、资源可上提共享、宿主不会把子文档误当独立技能。**后果**：命名需自明（`pptx-base.md` 而非 `base.md`）。

### ADR-3 共享层 vs 逐处复制
- **背景**：morph-ppt-3d 曾整表复制 pptx-base 的色板/字体。
- **决策**：单一事实源 + 引用（删除重复表）。
- **理由**：改动只改一处；防止版本漂移。**后果**：引用关系需维护（变更同步清单）。

### ADR-4 两段式 vs 单段式
- **背景**：纯 officecli 逐 shape 构建成本高（SAFTI 495 命令 + 83 缺陷收敛）。
- **决策**：引入两段式（文本期 markdown / 几何期 officecli），按视觉档位分流 2a/2b/2c。
- **理由**：内容/备注在 markdown 阶段最省；实测命令量 1 vs 63。**后果**：需要 pandoc 互通保障（notes 落盘/迁移）。

### ADR-5 P0 查表 vs 即时推导
- **背景**：溢出闭环占 SAFTI 总成本 60%，根因是"判定规则未文档化"。
- **决策**：把度量写成协议（公式 + 速查表 + `suggest.height` 首选）。
- **理由**：查表成本 ≪ 推导；对照实验 83→0。**后果**：系数与 officecli 版本耦合（需注明实测基线）。

### ADR-6 确定性路由 vs 主观选择
- **背景**：风格选择若靠模型判断则不可复现。
- **决策**：确定性风格包用规则函数（枚举 + 词典 + 固定次序）。
- **理由**：可复现、可审计、可测试。**后果**：新场景需扩词典（确定性维护）。

### ADR-7 资产内嵌风格包 vs 集中资产库
- **决策**：资产随风格包（`styles/<包>/assets/`）。
- **理由**：风格与资产强耦合、随包一起版本化；避免全局资产库的命名冲突。**后果**：跨风格通用资产需复制（暂未出现该需求）。

### ADR-8 Gate 双轨（几何 + 截图）
- **背景**：`view issues` 漏报轻微越界（实测页脚越界 7.9pt 而 issues=0）；截图依赖宿主浏览器（本机无 headless）。
- **决策**：几何扫描（零依赖，MUST）+ 截图判读（可选增强）。
- **理由**：可用性 + 覆盖率双保障。**后果**：几何扫描不覆盖渲染类问题（颜色/字体/动画）→ 仍需目标 viewer 目检。

---

### ADR-9 静态站路线：分工而非合并
- **背景**：三代 `web-slide-forge` 已能产出浏览器双模态站（doc + slide），为何四代还要回到 .pptx？
- **选项**：A 把静态站并入 slide-master；B 保持独立技能、slide-master 专注 .pptx。
- **决策**：B。**理由**：① .pptx 是政务/企业刚需交付格式（静态站不能替代）；② 静态站自有适用场合（内网部署/培训访问/知识库，用户明确"后续会用到其他场合"）；③ 两者在"标准物（规范化 Markdown）"层面天然衔接。**后果**：技能库中两者并存，方法论共享而产物形态分工。

### ADR-10 命名与 token 体系：传承 web-slide-forge
- **背景**：风格库需要一套可扩展的命名与 token 规范。
- **决策**：沿用三代的 `<mood>--<name>` 目录命名（`dark--premium-navy` 等）与 token 化（CSS 变量 → JSON token）。
- **理由**：命名语义自明（mood 前缀可用于查找与分组）、token 化利于机器消费与跨形态复用。**后果**：`styles/INDEX.md` 按 mood 分组；luxi 包用 `tokens.json` 承接 token 化。

### ADR-11 两段式概念的起源与"回到 PPTX"
- **背景**：一/二代分别验证了"编译式 pptx"与"静态站"，三代用"两段式 + 标准物契约"统一了它们——素材先加工为规范笔记源，再由 build 消费。
- **决策**：四代把该范式移植到 PPTX 生产（文本期 markdown → 几何期 officecli），并保留 pandoc 作为文本期引擎。
- **理由**：实证有效（命令量 1 vs 63；内容/备注在文本期最省）；且避开"从零发明流程"。**后果**：`pipeline.md` 成为核心流程文档；`pandoc-route.md` 承接一代的 pandoc 规范。

## 6 数据与格式规格

### 6.1 tokens.json schema（luxi 包）

```jsonc
{
  "pack": "luxi-scenario", "dir": "mixed--luxi-scenario", "source": "<源文件>",
  "brand": { "name", "slogan", "laws": {L,U,X,I}, "rules": [..] },
  "cornerstone": { primary, accent_cyan, gold, origin_white },
  "semantic": { alert, info, up, down, flat },
  "fonts": { sans_zh[], serif_zh[], mono[] },
  "type_scale_web_px": {...}, "type_scale_ppt_pt": {...},
  "radius_ppt_adj": {...},
  "variants": { "luxi-<theme>": { scene_default[], bg, card, raised, sunken, text, text_secondary,
                                  muted, inverse, primary, primary_hover, primary_active,
                                  accent, gold, border{subtle,line,strong}, font_body, font_display, font_mono } },
  "routing": { note, env_values[], scene_values[], priority[], tie_break, keywords{scene:[..]},
               rules[{if,variant}], density{compact[],regular[]} },
  "ppt_adaptation": { px_to_pt, font_floor_note, spacing_map_cm{}, page_margin_min_cm, shadow_policy },
  "assets": { dir, logo_main, logo_symbol, logo_lockup, icons, illustrations, count,
              pptx_insert, alt_required, brand_rules[], reextract }
}
```

### 6.2 度量协议（P0）规格

```
内边距：上/下 3.6pt、左/右 7.2pt（合计 7.2 / 14.4pt）
行高：1.2 × size
need = ceil(行数) × size × 1.2 pt
usable = 框高pt − 7.2pt
行数：自动换行 = ceil(等效宽 / (框宽−14.4pt))；显式换行 = Σ 各段
全角字宽 = 1.2 × size pt = 0.0423 cm/pt（半角 ≈0.5×，空格 ≈0.3×）
修复首选：采纳 view issues 的 suggest.height（官方值）
基线：officecli 1.0.148 + 微软雅黑/PingFang 实测
```

### 6.3 notes 规格

三拍结构（结论/支撑 2–3 点/收束过渡）· 45–90 秒（中文 120–240 字）· 字数档 per 风格（formal 80–150 / tech 60–120 / training 120–200 / creative 80–150 / executive 30–60）· 按页反推（T 分钟 ≈ T×200 字 → 单页上限）· 禁止照抄页面（>60% 重复即返工）· **写入后必须落盘复检条数**。

---

## 7 质量属性

| 属性 | 设计手段 |
|---|---|
| 可复现性 | 一切产物由脚本生成；`rm` + 重跑 = 重建；写死 token 常量与资产绝对路径 |
| 可验证性 | 可执行门禁（validate/issues/layout_scan/notes 复检）+ 回归脚本（selfcheck/pilot_verify） |
| 可维护性 | 单一事实源；变更同步清单（见 §8.5）；CHANGELOG；版本元数据；来源溯源段 |
| 可扩展性 | 扩展点：风格包 / 脚本 / 子技能定义 / 资产（见 §8） |
| 兼容性 | officecli **1.0.148**（度量系数与 prop 名基线）；pandoc **3.10.1**（`--slide-level=2` 语义）；Python **3.9**（仅标准库）；无 headless 浏览器时降级为几何门 |

---

## 8 扩展指南（维护手册）

### 8.1 新增风格包（六步）
1. 取源范式 → 抽 token（色/字/距/圆角/阴影）；2. 尺度转译（px→pt 投影映射）；3. 组件 PPT 化；4. 落 `styles/<mood>--<name>/style.md`（+ `tokens.json` 若需机器消费）；5. 视觉资产化（如需 → `assets/`，用平衡匹配抽取）；6. 登记 `INDEX.md`（主表 + 分组表）+ 全库计数同步。

### 8.2 新增脚本
放 `scripts/`；仅依赖 officecli/标准库；提供 CLI + 退出码语义；在 SKILL.md 资源布局登记；如属回归范畴 → 加入 `selfcheck.py`。

### 8.3 新增子技能定义
放 `references/<scene>.md`；frontmatter 不必需（受管文档）；正文声明继承关系与交付门；在 SKILL.md 依赖表登记；**不得**创建平行 SKILL.md。

### 8.4 新增资产
随风格包 `assets/`；命名语义化；通过 `xmllint` 校验；更新该包 README 与 tokens.json；插入必带 alt。

### 8.5 变更同步清单（改一处要同步的清单）
| 变更 | 必须同步 |
|---|---|
| 风格数量 | SKILL.md 资源布局/描述、style-lookup、INDEX、morph×2、pptx-design、decision-rules 的计数表述 |
| 色板/字体/中文规则 | 只改 `pptx-base.md`（单一事实源），其余引用不复制 |
| 脚本文件名 | 引用它的全部文档（曾发生 helpers 改名） |
| frontmatter.version | CHANGELOG 新增段；维护溯源段 |
| 触发面（description） | 决策树与边界的转交对象保持一致 |

---

## 9 验收标准（技能级）

### 9.1 结构验收
- [ ] 目录形态为 SKILL.md + references/ + scripts/（+ styles/assets）
- [ ] `references/` 内无 SKILL.md（不为平行技能）
- [ ] 风格目录数 == INDEX 登记数 == 文档表述数（磁盘为唯一事实源）
- [ ] 每个脚本可 `py_compile` / `bash -n`

### 9.2 功能验收（命令级）
- [ ] `python3 scripts/selfcheck.py` → PASS 5 / FAIL 0
- [ ] `python3 scripts/style_route.py --keywords …` → 输出稳定（同输入同输出）
- [ ] `python3 scripts/layout_scan.py <deck>` → 违规 0
- [ ] `python3 scripts/validate_slides.py <md> --pandoc` → 通过
- [ ] 任一实战 deck：`validate` 通过 + `issues` 0 + notes 条数正确

### 9.3 质量验收（指标）
| 指标 | 阈值 |
|---|---|
| 首轮 issues | ≤10（目标 0） |
| 几何越界 | 0 |
| notes 覆盖率 | 100%（content 页） |
| 图片 alt 缺失 | 0 |
| 路由确定性 | 100% |
| 三件套齐全 | 100% |

### 9.4 回归验收
- [ ] `pilot_verify.py` 对照结果：新协议首轮 0（不低于基线 83 的改善）
- [ ] CHANGELOG 与 version 一致；维护溯源段更新

---

## 10 风险与限制

| 风险/限制 | 说明 | 缓解 |
|---|---|---|
| officecli 版本耦合 | 度量系数、prop 名以 1.0.148 实测为准 | 协议注明基线；升级后重跑 pilot_verify 校准 |
| 渲染类无法自动验证 | 动画/图表色/字体缺字需真实 viewer | 交付提示目检；morph 明确 Renderer honesty |
| 3D 未端到端 | 无真实 .glb 跑通 3D 渲染（CLI 层已验证） | 标注"未验证"；模型发现流含联网兜底 |
| 截图依赖宿主浏览器 | 本机无 headless | Gate 3 以几何扫描为 MUST，截图降级可选 |
| 风格库上游漂移 | 51 风格源自上游，索引曾不一致 | 磁盘为事实源 + 缺失条目告示与回退 |
| 单点复杂度 | SKILL.md 承载路由，描述变更影响触发 | description 收敛规程（§4.1）+ 触发冒烟 |

---

## 附录

### A. 组件清单速查

| 类别 | 数量 | 清单 |
|---|---|---|
| 入口 | 1 | SKILL.md |
| 子技能定义 | 4 | pptx-base / pitch-deck / morph-ppt / morph-ppt-3d |
| 流程规范 | 6 | pipeline / scaffold / speaker-notes / style-lookup / pandoc-route / decision-rules |
| 设计文档 | 1 | pptx-design |
| 变更记录 | 1 | CHANGELOG |
| 脚本 | 8 | morph_helpers / morph-helpers.sh / notes_migrate / validate_slides / layout_scan / style_route / selfcheck / pilot_verify |
| 风格 | 52 目录 + 30 SVG 资产 | styles/（含 mixed--luxi-scenario/） |
| **前期技能（研究链，独立于本技能）** | 3 | `pandoc-slide-compiler`（2 文件）· `notes-to-static-site`（3 文件）· `web-slide-forge`（27 文件）——传承关系见 §2.5 |

### B. 命令索引

```bash
# 健康检查全套
python3 scripts/selfcheck.py && python3 scripts/pilot_verify.py
# 路由
python3 scripts/style_route.py --scene dashboard --env projection --json
# 几何门
python3 scripts/layout_scan.py <deck> [--overlap]
# pandoc 路线
python3 scripts/validate_slides.py <md> --pandoc && pandoc <md> -t pptx -o out.pptx --slide-level=2
python3 scripts/notes_migrate.py old.pptx new.pptx
# morph
python3 scripts/morph_helpers.py clone|ghost|verify|final-check <deck> …
# 资产再抽取
python3 references/styles/mixed--luxi-scenario/assets/extract_assets.py
```

### C. 变更记录
见 `references/CHANGELOG.md`（v1.0 → v1.3.1）；本文档随技能版本同步修订。
