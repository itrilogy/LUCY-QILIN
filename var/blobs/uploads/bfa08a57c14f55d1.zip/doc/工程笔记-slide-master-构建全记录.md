# slide-master 工程笔记 —— 从 officecli 生态到自主确定性风格体系的构建全记录

> **文档性质**：工程过程全记录（事无巨细版），面向**工程报告与验收材料**编写——可按章摘取、可作为附件提交、可对照核查。
> **对象**：`slide-master` v1.3.1（`/Users/kwangwah/Obsidian/Harness/SKILL/slide-master`）
> **记录范围**：从发现 AionUi/officecli 生态起，到自建确定性风格包与资产体系止，含全部关键命令、实测数据、设计决策与版本演进。
> **诚实边界**：文中所有数字均来自本机实测（officecli 1.0.148 / pandoc 3.10.1 / Python 3.9）；未验证项在文中显式标注「未验证」。

---

## 摘要（一页纸）

本项目把「用 AI 稳定产出高质量 PPT」从经验性试错转化为可复现的工程体系，核心成果：

| 维度 | 成果 | 量化 |
|---|---|---|
| **能力底座** | 发现并接入 officecli（CLI 化 PPT/Word/Excel 操作引擎） | CLI v1.0.148，动词集 13 类 |
| **技能架构** | 单一出口技能 + 受管子技能 + 共享资源层 | SKILL.md 139 行 / references 12 文档 3410 行 / scripts 8 个 1892 行 |
| **风格体系** | 风格库 + 引入外部设计范式 + 自建确定性风格包 | 52 风格目录 + 鹿溪包（3 变体）+ 30 个 SVG 资产 |
| **意图路由** | 触发契约 + L0–L4 决策树 + 确定性风格路由 | 描述收敛消除误触发；风格路由 100% 确定 |
| **生产流程** | 两段式流水线（文本期/几何期）+ 三重质量门 | 首轮溢出 83 → 0（对照实验）；几何越界 0 |
| **工程保障** | 回归脚本 + 实战反哺机制 | selfcheck（5 路线）/ pilot_verify（对照）/ layout_scan（几何门） |
| **研究基础** | 同脉络四代演进（前三代技能留存可查） | pandoc-slide-compiler(06-30) → notes-to-static-site(08-11) → web-slide-forge(09-08) → slide-master；方法论文档化传承（见第零章） |

**关键结论**：AI 做 PPT 的质量瓶颈不是"审美"，而是**未文档化的隐性规则**——把度量、布局、交付纪律变成"查表/可运行检查"后，首轮缺陷从 83 条降到 0 条。

---

## 第零章 前期研究脉络（2026-06 → 2026-09）

> 本章为后补增补章：slide-master 不是凭空设计，而是**同一条研究脉络的第四代成果**。前三代技能（pandoc-slide-compiler → notes-to-static-site → web-slide-forge）在文件系统中有完整留存，本章给出**逐项证据**——这些证据是结题材料中"前期研究基础"的直接依据。

### 0.1 四代时间线（文件系统实证）

```bash
cd /Users/kwangwah/Obsidian/Harness/SKILL
for d in pandoc-slide-compiler notes-to-static-site web-slide-forge; do
  printf "%-24s " "$d"; ls -ldT "$d" | awk '{print $6, $7, $8, $9}'; done
```

| 代 | 技能 | 目录时间 | 文件数 | 核心命题 |
|---|---|---|---|---|
| 一代 | `pandoc-slide-compiler` | **2026-06-30** | 2（SKILL.md + validate_slides.py 400 行） | Markdown → **pandoc 编译 .pptx** |
| 二代 | `notes-to-static-site` | **2026-08-11** | 3（SKILL.md + build_site.py + validate_site.py） | 笔记集合 → **静态文档站点**（在线/本地双模式） |
| 三代 | `web-slide-forge` | **2026-09-08** | 27（SKILL.md + 7 个 Python 脚本 + 3 基础 CSS + 2 主题 + 4 JS 引擎 + 模板/示例/vendor） | Markdown → **浏览器双模态站点**（doc + slide），并**声明替代前两代** |
| 四代 | `slide-master` | 2026-09-08 起 | references 12 + scripts 8 + styles 52 + 资产 30 | Markdown/素材 → **.pptx**（officecli 引擎 + 前三代方法论总成） |

> 时间线命令输出（实测）：`pandoc-slide-compiler Jun 30 17:08` → `notes-to-static-site Aug 11 15:02` → `web-slide-forge Sep 8 23:02`。四代并非简单重做，而是**命题在"呈现形态"上循环、方法论逐代沉淀**。

### 0.2 一代：pandoc-slide-compiler（2026-06-30）——编译式 PPT 生产

**能力**：把素材（或已有 PPT 架构）规范为 Pandoc Slide Shows Markdown，用 `pandoc -t pptx` 直接编译；**零第三方 PPTX 库**（非 md2pptx / 非 python-pptx）。

**留下的设计资产**（后被 slide-master v1.2.0 全量吸收）：
- **5 种演示风格档**：`formal`(备注 80–150 字) / `tech`(60–120) / `training`(120–200) / `creative`(80–150) / `executive`(30–60)——现为 `speaker-notes.md` 的字数档；
- **Markdown 语法全量契约**：`#` Section 页 / `##` 内容页 / `::: notes` 强制块 / 层级铁律（`#` 页禁正文）/ 物理格式铁律（前后空行）——现为 `pandoc-route.md`；
- **编译命令与自检清单**：`--slide-level=2`（缺省会压成 2 页，后经实测再确认）+ `validate_slides.py`（语法校验/自动修复，并入 `scripts/`）；
- **不支持项清单**：HTML/Mermaid/显式 Layout 等 → 后来的"文本期/几何期"边界判定的雏形。

**当时的局限（促成下一代）**：pandoc 只能产出占位符版式，无法自由布局/图表/动效；且 .pptx 交付场景受限。

### 0.3 二代：notes-to-static-site（2026-08-11）——从"文件"转向"站点"

**能力**：既有 Markdown 笔记集合 → 完整静态站点（index + 分组页 + assets），资源**在线（CDN）/ 本地（内网离线零外链）双模式**，内置生成与全量校验脚本。

**留下的设计资产**：
- **六阶段工作流**：侦察 → 规划 → 生成 → 资源策略 → 校验 → 交付（slide-master 决策树与门禁流程的思想先声）；
- **顺序敏感的 md→HTML 管线 7 步**：callout 预处理 / 标题锚点（**正则须支持非 ASCII**、中文 id 需 `unquote` 双比对）/ mermaid `html.unescape` / wiki 链接路由——为后续一切"中文内容处理"积累了硬经验；
- **8 项自动断言校验 + 5 条红线**（不虚构/不改源/离线外链归零/锚点唯一/失败整体回滚）——slide-master 质量门与红线的直接前身；
- **离线优先原则**（local 模式外链必须归零）——现为 G6"零第三方依赖"。

### 0.4 三代：web-slide-forge（2026-09-08）——方法论集大成 + 双模态

**能力**：Markdown → 浏览器**双模态**站点：`doc`（类 GitBook 文档站）+ `slide`（全画幅浏览器演示：键盘导航/备注面板/逐条显示/CSS 转场）；支持 Obsidian 特性与手绘代码块（`rough:` / `p5brush:` 浏览器端渲染，**vendor 内嵌、构建零联网**）。

**它是 slide-master 方法论的主要源头**（逐项对照见 §0.5），其中**三处是直接同构**：

1. **§0 原文即写明"两段式"**：
   > "技能的生产是**两段式**：build 只消费'标准物'——符合本契约的规范化笔记源。任意素材都**不直接进 build**，须先经①前置工艺加工为笔记源，再经②precheck 自检确认达标。"
   → 这是 slide-master `pipeline.md`"文本期/几何期"与"素材→内容定稿"概念的**直接出处**。
2. **主题体系即风格库原型**：§7 用 CSS 变量做 token（配色/字体/字号），主题命名 **`dark--premium-navy` / `light--minimal-corporate`**——与 slide-master 风格库 `<mood>--<name>` 命名**完全一致**（52 风格库继承此约定）。
3. **脚手架即"默认落工作文件夹"**：§12 `init_workspace.py ./my-workspace ...`（注释原文"标准物/产物就地落在你的工作文件夹，**不用 /tmp**"）→ slide-master `scaffold.md`"默认产出落 workdir"的出处。

**其它可复用资产**：`precheck_notes.py`（标准物质量门，FAIL 非零）→ 素材预检；`--verify`（构建后自动校验、失败非零）→ 构建脚本内嵌门禁；`smoke_test.py`（双模式冒烟）→ `selfcheck.py`；7 脚本的"脚本即模式"约定（无 `--mode` 参数，编译脚本即模式）→ slide-master scripts 层。

**§13 替代说明（原文实证）**：web-slide-forge 声明**完全替代** `notes-to-static-site`（doc 模式，功能超集）与 `pandoc-slide-compiler`（slide 模式，浏览器直接演示）——即前三代在此收敛为一个"浏览器站"体系。

### 0.5 思想传承矩阵（三代 → slide-master）

| 设计元素 | 起源（证据位置） | slide-master 落点 |
|---|---|---|
| **两段式生产** | web-slide-forge §0「生产是两段式：素材→标准物→build」 | `pipeline.md` 文本期/几何期 + 2a/2b/2c |
| **标准物契约 + 前置质量门** | web-slide-forge `precheck_notes.py`；notes-to-static-site §6 校验清单 | `validate_slides.py` 预检 + 继承链加载 + `scaffold.md` 交付清单 |
| **主题 token 化 + mood--name 命名** | web-slide-forge §7（CSS 变量 + `dark--premium-navy`） | `styles/` 52 风格目录 + `tokens.json`（luxi 包） |
| **工作区脚手架** | web-slide-forge §12 `init_workspace.py`（就地工作文件夹、不用 /tmp） | `scaffold.md`「默认落 workdir」 |
| **单命令闭环校验** | web-slide-forge `--verify`；notes-to-static-site 校验脚本全绿 | build 脚本内嵌三重门（issues 闭环 / layout_scan / notes 复检） |
| **冒烟/回归脚本** | web-slide-forge `smoke_test.py` | `selfcheck.py`（五路线）+ `pilot_verify.py`（对照实验） |
| **演示备注规范** | web-slide-forge slide 模式备注面板（`::: notes`）；pandoc-slide-compiler `::: notes` 强制块 + 字数档 | `speaker-notes.md`（三拍结构 + 5 风格字数档 + 按页反推） |
| **动画/转场** | web-slide-forge `incremental` + CSS 转场 + slide-engine.js | `morph-ppt.md`（Morph 动效 + Gate 5b-morph 四循环） |
| **保真红线** | notes-to-static-site §7（不虚构/存疑保留/不改源）；web-slide-forge §0.2 规则 3 | pptx-base「Copy reads human」+「不臆造 style.md 内容」等红线 |
| **离线/零外链原则** | notes-to-static-site local 模式外链归零；web-slide-forge vendor 内嵌零联网 | G6「零第三方依赖」（仅 officecli/pandoc/Python 标准库） |
| **中文处理经验** | notes-to-static-site（非 ASCII 锚点正则、中文 id unquote） | `pptx-base.md` §中文排版（字体族/投影映射/文本框放宽 20–30%） |
| **多呈现形态问题** | 三代分别在 pptx / doc 站 / 双模态站上验证 | 四代回到 .pptx（officecli 引擎），方法论全量复用 |

### 0.6 脉络结论（结题视角）

1. **命题演进**：呈现形态在"PPTX 文件 → 静态文档站 → 双模态浏览器站 → 回到 PPTX"上循环，而**方法论单向沉淀**（两段式/标准物/主题 token/脚手架/门禁/冒烟每代继承不丢）。
2. **为什么最终穿透到 officecli**：浏览器站路线（web-slide-forge）不产出 `.pptx` 文件交付物，而 PPT 仍是政务与企业场景的刚需交付格式；因此第四代回到 PPTX，但不再从零摸索——**直接移植前三代方法论**，并以 officecli 作为"文件级操作引擎"替代浏览器渲染引擎。
3. **分工而非合并**：web-slide-forge 的静态站设计"后续会用到其他场合"（内网部署/培训访问/知识库），故**保持独立技能**；slide-master 专注 `.pptx`——两者在"标准物（规范化 Markdown）"层面天然衔接。
4. **前期研究基础的可验证性**：三代技能的 SKILL.md 与脚本在本机完整留存（文件数 2/3/27），时间戳、替代声明、设计契约均可直接引用为结题材料证据。

---

## 第一章 缘起与侦察：officecli 是如何被找到的

### 1.1 起点：机器上的另一个 AI 工具

工程起点源于对 `AionUi.app`（v2.2.1，Electron，`com.aionui.app`）的检查。侦察命令与关键发现：

```bash
# 1) 定位应用与数据目录
ls /Applications | grep -i aion          # → AionUi.app
mdfind -name "aionui" | head              # → ~/Library/Application Support/AionUi/...
# 2) 数据目录真实结构（~/.aionui 是符号链接）
ls -la ~/Library/Application\ Support/AionUi/aionui/
#   builtin-skills/（22 顶层 + auto-inject 内嵌 5 = 26 个技能）
#   session-skills/ · conversations/ · runtime/ · *.db
readlink ~/.aionui                        # → .../Application Support/AionUi/aionui
```

### 1.2 技能体系盘点（26 个内置技能）

```bash
ls ~/.aionui/builtin-skills/
# 运维类：aionui-config / aionui-troubleshooting / aionui-webui-{setup,public}
# auto-inject 组：officecli / aionui-config / session-message / skill-creator / cron
# Office 链：officecli-{docx,xlsx,pptx,word-form,academic-paper,financial-model,pitch-deck,data-dashboard}
# 动效：morph-ppt / morph-ppt-3d / mermaid / pdf
# 社交/内容：x-recruiter / xiaohongshu-recruiter / moltbook / story-roleplay
# 其它：openclaw-setup / weixin-file-send
cat ~/.aionui/builtin-skills/.version     # → 0.2.1+builtin-skills.f5b0319a4c8dff0ebac32cc9
```

数据库侧证据（技能注册表与来源）：

```bash
sqlite3 ~/.aionui/aionui-backend.db ".schema skills"
# id/user_id/name/description/path/source(user|builtin|extension|cron)/enabled
sqlite3 ~/.aionui/aionui-backend.db "SELECT source,COUNT(*) FROM skills GROUP BY source;"
# → builtin|26
```

### 1.3 officecli 本体确认

```bash
ls -la /opt/homebrew/bin/officecli     # → Cellar/officecli/1.0.148
officecli --version                     # → 1.0.148
officecli help | grep -E "watch|raw-set|validate|view"
# open/watch/unwatch/view/raw/raw-set/add-part/validate ... 动词集完备
```

**能力结论**：officecli 是"文档即数据库"式 CLI——`view/get/query/add/set/remove/batch/validate/raw-set` 覆盖读写改验全链路，且支持 resident（常驻进程加速）、`watch`（实时预览）、`batch`（批量）。这是后续一切自动化的地基。

### 1.4 为什么选它：与替代路径的对比

| 路径 | 局限（当时评估） | officecli 的优势 |
|---|---|---|
| python-pptx | 只能操作对象模型，无渲染/校验/预览 | 内置 `validate`/`view html`/`view issues` |
| 手写 OOXML | 成本极高、易碎 | `raw-set` 作为兜底而非主路径 |
| pandoc 直编 | 只能占位符版式，无法自由布局 | 自由画布 + 与 pandoc 互通（后验证） |

---

## 第二章 架构决策：三次演进与最终形态

### 2.1 第一版：技能移植（扁平 17 项）

从 AionUi 复制 17 个通用技能到 `Harness/AionUI/`（A 档 13：officecli 8 专项 + morph×2 + pdf + skill-creator + mermaid；B 档 4：recruiter×2 + moltbook + story-roleplay）。

### 2.2 第二版：收编为受管模块（`modules/<name>/MODULE.md`）

问题暴露：**4 个 PPT 技能并行存在 → 触发面相互重叠**（officecli-pptx 与 pitch-deck/morph-ppt 抢触发）。第一轮方案把子技能收编为一个总控技能下的嵌套模块：

```
slide-master/modules/{pptx-base,pitch-deck,morph-ppt,morph-ppt-3d}/MODULE.md
```

### 2.3 第三版（现行）：回归 Claude 标准技能形态（平铺）

评审确认"嵌套 `modules/x/MODULE.md` 属于无谓子目录"，改为**标准技能形态**：

```
slide-master/
├── SKILL.md                     ← 唯一入口（总控）
├── references/                  ← 子技能定义 + 通用规范（平铺直接命名）
│   ├── pptx-base.md · pitch-deck.md · morph-ppt.md · morph-ppt-3d.md
│   ├── style-lookup.md · scaffold.md · speaker-notes.md
│   ├── pipeline.md · pandoc-route.md · decision-rules.md · pptx-design.md
│   ├── CHANGELOG.md · styles/（52 风格目录）
└── scripts/                     ← 共享脚本层（8 个）
```

配套的一致性治理（实测计数修偏）：
- 风格数量以**磁盘为唯一事实源**（当年把 52/55/50+ 三种说法统一为 51；引入鹿溪包后统一为 **52**）；
- `INDEX.md` 标注 3 个上游缺失条目并给出回退规则；
- 全部内部路径引用改为以 `references/` 为基准。

### 2.4 共享层抽象原则（可复用的架构决策）

| 原则 | 落地 |
|---|---|
| 单一事实源 | 色板/字体/中文规则只在 `pptx-base.md` 定义，其余引用不复制（曾删除 morph-ppt-3d 中重复的 10 色板/8 字体整表） |
| 通用流程上提 | 风格查找（style-lookup）、叙事规划（decision-rules）、备注规范（speaker-notes）、脚手架（scaffold）跨路线共享 |
| 可执行资产独立 | `scripts/`（脚本）与 `styles/`（风格+资产）与文档分离，互不内嵌 |

### 2.5 最终四层架构

```
决策层 SKILL.md（触发契约 + L0–L4 路由 + 纪律 + 边界）
   ↓ 按路线加载
流程规范层 references/*.md（pipeline/scaffold/speaker-notes/style-lookup/pandoc-route/decision-rules）
   ↓ 执行定义（继承 pptx-base 底线）
执行层 references/{pptx-base,pitch-deck,morph-ppt,morph-ppt-3d,pandoc-route}.md
   ↓ 调用
资产层 scripts/（8 脚本）+ styles/（52 风格 + 30 SVG 资产）
```

---

## 第三章 风格体系：如何结合外部设计范式

### 3.1 风格库的来路与治理

风格库（`styles/`，52 目录）源自 morph-ppt 的设计风格集合：每个风格含 `style.md`（设计理念/配色/字体/标志手法）+ 可选 `build.sh`（演示脚本，**坐标有已知排版 bug，仅供技法参考**）+ 模板 pptx。

治理要点（实测教训）：
- 磁盘计数与索引不一致 → 以磁盘为准，`INDEX.md` 标注缺失条目并写回退规则；
- 数量表述散落多处（SKILL/style-lookup/morph×2/pptx-design/decision-rules）→ 每次变更全库同步。

### 3.2 四步查找流程（style-lookup.md）

```
1 浏览 INDEX（按 mood/品牌 hex 匹配） → 2 读 style.md（设计理念）
→ 3 看 build.sh（只学技法，不抄坐标） → 4 在自己的网格数学上应用
```
原则：**"learn the approach, do not copy coordinates"**——风格库是灵感源而非模板库。

### 3.3 引入外部范式的通用方法论（以鹿溪为例）

```
源资产（HTML/设计规范）→ ① token 抽取（色/字/距/圆角/阴影）
→ ② 尺度转译（px→pt 投影映射，不可 1:1）
→ ③ 组件 PPT 化（CSS 阴影/圆角 → 底色分层/roundRect）
→ ④ 落为风格包（style.md + tokens.json）
→ ⑤ 视觉资产化（SVG 抽取）
→ ⑥ 路由登记（mood 匹配或确定性规则）
```

---

## 第四章 动效专精：Morph 与 3D 的实现细节

### 4.1 Morph 原理（PowerPoint 原生）

Morph 转场通过**相邻页同名形状**插值实现位移/缩放/旋转/颜色。因此本质是**命名纪律**而非 CLI 功能：

| 前缀 | 角色 | 生命周期 |
|---|---|---|
| `!!scene-*` | 场景装饰（背景环/带） | 全程存在，极少 ghost |
| `!!actor-*` | 内容演员 | 引入→演变→**ghost 到 `x=36cm`** 退出 |
| `#sN-*` | 每页内容 | 页内新增，下页 ghost |

关键机制（实测）：
- `transition=morph` 设置在**目标页**；漏设 = 静默退化为淡入；
- CLI 会给 morph 页所有形状名自动加 `!!` 前缀，但 `@name=` 选择器仍可解析（前后缀容错）；
- **几何差异阈值**：≥5cm 位移 / ≥15° 旋转 / ≥30% 尺寸差，否则"无可见动画"。

### 4.2 Ghost 纪律与 helpers（`scripts/morph_helpers.py`）

**核心陷阱（M-2）**：每页是独立画布——演员在 N 页 ghost 后，N+1 页会"复活"。必须**每页重复 ghost**。

helpers 四函数（实测可用）：

```bash
python3 scripts/morph_helpers.py clone <deck> <from> <to>   # 克隆页 + 自动 transition=morph + 打印 shape 列表
python3 scripts/morph_helpers.py ghost <deck> <slide> <idx...>  # 按索引 ghost 到 x=36cm
python3 scripts/morph_helpers.py verify <deck> <slide>      # 校验 transition + 未 ghost 内容 + 重复内容
python3 scripts/morph_helpers.py final-check <deck>         # 全 deck 校验 + ghost 累积检测
```

实现细节：
- 克隆用 `officecli add <deck> / --from /slide[N]`（实测有效，返回 `Copied to /slide[<N+1>]`）；
- 累积检测：`query 'shape[x>=34cm]'` 计数超 `max(50, slides×4)` 即 REJECT；
- `clean-accumulation` 修复曾存在**逻辑矛盾**（删除 `!!` ghost 会破坏退出配对）与**路径 bug**（全局 `/shape[@id=]` 被 CLI 拒绝："Cannot resolve @id= outside of a slide context"）——已重写为：按 query 返回的**完整 slide 路径**删除、**永不删 `!!` ghost**、阈值与 final-check 对齐（冒烟 PASS）。

### 4.3 交付门 Gate 5b-morph（四循环，全部可执行）

```bash
# 5b-1 actor 泄漏检测（应已退出却仍在可视区）
for N in $(seq 1 $NSLIDES); do officecli get … | jq 'select(startswith("!!actor-")) | select(x<33.87)' …
# 5b-2 相邻页无运动检测（≥3 个 !! 形状各变 ≥1 属性）
# 5b-3 配对名一致性（相邻页共享 ≥2 个 !! 名）
# 5b-4 内容 ghost 泄漏（#s(N-1)- 应已移出）
```
要点：`officecli query` **无 `^=` 前缀选择器**，需用 `get --depth 1 --json + jq startswith()`。

### 4.4 3D（GLB）扩展实现

- **元素**：officecli 有 `model3d` 元素（`--type 3dmodel` / `model3d` 均实测可用），属性 `src`(alias `path`)、`x/y/width/height`、`rotation`(alias `rotx/roty/rotz`)；
- **不可 clone**：模型克隆后不能 Morph，且同一页出现两个同名 model3d 会导致 PowerPoint 修复式删除内容 → 必须**每页重新 add**（同名）；
- **尺寸对比规则**：相邻页模型面积比 ≥1.5× 或 ≤0.67×（视觉能量）；
- **镜头语言**：roty 轨道 30–90°/页、rotx 范围 −25~+40、全 deck 总弧 180–360°；
- **模型获取**：兼容门（仅 .glb）→ 模型发现流（Sketchfab API / Poly Pizza / Khronos 样例）→ 用户确认后下载 → 校验（存在/扩展名/≤50MB）；网络不可达时兜底（重试/请用户提供/降级为普通 morph）。
- **未验证**：无真实 .glb 的端到端 3D 渲染（CLI 层已验证支持）。

### 4.5 实测陷阱库（节选）

| 编号 | 陷阱 | 对策 |
|---|---|---|
| M-1 | morph 后形状名被加 `!!` 前缀 | `@name=` 仍可解析；jq 过滤用 `startswith("!!actor-")` |
| M-2 | ghost 累积（每页独立） | 每页重复 ghost；final-check 兜底 |
| M-4 | 试图用 `morph.duration=` 等伪属性 | 用 `transition=morph-slow/-fast/morph-<ms>` 速记 |
| M-6 | `<a:br/>` 当换行 | 逐段 `add --type paragraph` |
| C-P-* | connector 需 `tailEnd=triangle`、`@id=` 跨页引用、图表色被渲染器归一化 | 见 pptx-base §Known Issues |

---

## 第五章 自主范式设计：鹿溪场景包的完整构建

### 5.1 源范式评估

源：`LUCY-DESIGN/Sample/luxi-scenario-kit-final.html`（91.6KB，鹿溪设计范式·全场景参考套件）。

| 项 | 抽取结果 |
|---|---|
| 品牌四色基石 | 绿 `#0D5E42`（主，60–70%）· 青 `#00D2FF`（强调，每页一处）· 金 `#F1C40F`（警示/CTA）· 源白 `#F5F7FA`（底） |
| 语义色 | 涨 `#22C55E` / 跌 `#EF4444` / 平 `#94A3B8` / 告警 `#E74C3C` / 信息 `#3498DB` |
| 三主题 | light（文档/看板）· dark（投影，`#121A17` 底）· ink（墨色 `#0B0C0E` + **中文衬线** Songti SC，文化深读） |
| 字体族 | sans-zh（PingFang SC…）/ serif-zh（Songti SC…）/ mono（JetBrains Mono…） |
| 排印阶梯 | display 40 / h1 28 / h2 22 / h3 17 / body 14 / small 13 / caption 12 / micro 11（px） |
| 间距/圆角/阴影 | space 4–48px 八档；radius xs4–lg16 + pill；阴影四档 + focus 环 |
| 品牌法则 | **L**ink 连接 · **U**nveil 揭示 · **X**-Factor 变量 · **I**terate 迭代 |
| 品牌规范 | 双标等大（64×64 并排居中，主标禁重绘）· 角本位符号（Y+一横）· 中文优先排印 |
| 组件 | tile/brick（卡）· swatch（色板）· bar-row（比例条 72/1fr/64px）· check（清单）· quote（引文） |

### 5.2 转译设计的三个关键判断

1. **px 不可 1:1 转 pt**：96dpi 下 `1px=0.75pt`，`fs-body 14px→10.5pt` 低于 PPT 投影底线（body≥18pt）。
   解法：**投影档位映射表**——display 40px→42pt / h1 28px→36pt / body 14px→18pt / micro 11px→12pt（放大 1.2–1.7×，按层级递增）。
2. **PPT 无 box-shadow**：悬浮感改用"底色分层（card `#FFFFFF` / sunken `#EEF2F5`）+ 描边（绿 18%）"。
3. **圆角映射**：xs4/sm6→`roundRect` adj 0.04；tile/md→0.08；lg16→0.12；pill→`ellipse`。

### 5.3 风格包四件套（成品形态）

| 件 | 文件 | 作用 |
|---|---|---|
| 规范 | `styles/mixed--luxi-scenario/style.md` | 三变体 token 表 + 排印映射 + 组件 PPT 化 + 品牌规范 + 资产索引 |
| 机器 token | `.../tokens.json` | 三变体全量 token + 路由规则/词典/优先级 + PPT 适配参数 + 资产登记（可直接被脚本消费） |
| 路由 | `scripts/style_route.py` | 确定性变体选择（见第六章） |
| 资产 | `.../assets/`（30 SVG + README + 抽取器） | 论见 §5.4 |

### 5.4 SVG 资产化工程（从设计到可复用素材）

抽取产物（30 个独立 SVG，`xmllint` 全部 well-formed）：

| 资产 | 规格 | 来源处理 |
|---|---|---|
| `logo-lab-mark.svg` | 2048 viewBox，绿+青 | **主 LOGO**，sprite `<symbol>` 官方 path **原样导出**（禁重绘） |
| `logo-symbol-mark.svg` | 48 viewBox | 符号标；保留 `currentColor` + `--mark-accent` 可着色 |
| `logo-lockup.svg` | 140×64 | **合成**：双标等大并排（各 64×64，居中），落实品牌规范 |
| `icons/*.svg`（23） | 24×24，stroke 1.7 | 按 `data-od-id` 语义命名（如 `fut-yuelu`＝跃鹿 YueLu），生成 `INDEX.md` 清单 |
| `illustrations/*.svg`（4） | 180×110 等 | 商品预览（名片/保温杯/金属徽章/帆布袋）；**符号标内联化**保证独立可用 |

工程细节（两个真实的坑与修复）：
1. **嵌套 `<svg>` 截断**：插画内含内联符号标 `<svg>`，非贪婪正则 `.*?</svg>` 在第一个内层闭合处截断 → 2 个文件 xmllint 报错。修复：写**平衡匹配**函数（层级计数 `<svg`/`</svg>`）。
2. **PPT 可用性实测**：`officecli add --type picture --prop src=x.svg` → `Added picture`，`stats Pictures=2`——**SVG 可直接插入 pptx**（并强制要求带 `alt`）。

可重跑：`python3 assets/extract_assets.py [--src 源.html]`（源更新时同步，产物含清单）。

---

## 第六章 确定性风格：规则路由的设计

### 6.1 设计约束：非随机、非判断

要求：**同一输入恒得同一输出**，不允许"模型主观挑风格"或随机。故设计为纯规则函数：

```
variant = luxi-dark   if env == projection      # 投影/大屏/暗环境
        = luxi-ink    if scene == immersive     # 沉浸/文化/故事/深度阅读
        = luxi-light  otherwise
density = compact     if scene ∈ {dashboard, workbench} else regular
scene   = 关键词词典映射：最长命中词优先（length desc）；同长按固定 priority；无命中 → 缺省 marketing
```

### 6.2 规则的可解释性设计

- **env** 由环境判据唯一决定（提到投影/大屏/会场 → projection）；
- **scene** 由**固定词典**映射，词典与优先级写在 `tokens.json`（数据而非代码，可审计）；
- **歧义处理用确定性规则**：初版"品牌故事"被 marketing 的"品牌"抢先 → 改为**最长匹配优先**（"品牌故事"4 字 > "品牌"2 字），并把长词补入 immersive 词典——规则可解释、可复现、无主观。

### 6.3 实现与接口（`scripts/style_route.py`）

```bash
python3 style_route.py --scene dashboard --env projection   # → luxi-dark / compact
python3 style_route.py --keywords "看板,KPI,数据大屏"        # → dashboard / luxi-light / compact
python3 style_route.py --keywords "品牌故事,文化叙事"        # → immersive / luxi-ink
python3 style_route.py --from-md <素材.md> --json           # 从素材自动判场景 + 输出全量 token
python3 style_route.py --list                               # 列出包/变体/规则/词典
```
输出含：`variant / density / tokens（bg/card/primary/accent/gold/text/muted/font…）/ type_scale_ppt_pt / radius_ppt_adj / rule_trace`——**可直接驱动 officecli 命令**。

### 6.4 与底线的协调

路由输出**不豁免** pptx-base 底线：字号映射表已保证 ≥36pt/≥18pt；dark/ink 变体须过对比度底线（反白亮度 >80%，实测 `#E6EFEA`/`#F3EEE6` ✓）；页脚/度量一律走 P0 协议。

---

## 第七章 意图路由：技能入口的设计

### 7.1 description 即触发契约

初版描述过宽（把"叙事规划器 decision-rules"与实现细节写进触发面；裸词"演示/宣讲/发布会"无交付限定）→ 会把非 PPT 请求吸入。收敛为**交付契约**：

> 「**当且仅当**用户诉求是【产出或加工一份 .pptx 演示文稿文件】时」+ 限定触发词（以"…的 PPT"形式）+ 完整 DO NOT（docx/xlsx/纯文本写作/叙述规划类）

收敛后：误触发面显著缩小；边界转交对象明确（officecli-academic-paper / officecli-data-dashboard / pandoc-slide-compiler）。

### 7.2 L0–L4 决策树（逐层 ask）

```
L0 触发 → L1 输入形态（已有 pptx 编辑 / 从零制作 / markdown 走两段式）
→ L2 场景（通用汇报 | 融资路演 | 产品方案 | 动效）→ L3 质量与风格 / 动画深度 → L4 调度执行
前置原则：能推断的不 ask；每问 ≤4 选项；一次一层；中文交互。
```

### 7.3 边界与回退

- **Reverse handoff**：执行中诉求偏离子技能专精 → 主动退回（morph 无动画→pptx-base；路演消失→pptx-base；3D 降级→morph-ppt），无需重新 ask；
- **冲突仲裁**：以更专精的子技能为准，不确定则回 pptx-base 保守执行。

### 7.4 风格横切维度

风格从 morph 专属升级为**全路线横切**：任何 deck（汇报/路演/动效）都可套风格；确定性风格包例外——命中规则即采用，无需 ask。

---

## 第八章 生产流程设计

### 8.1 两段式流水线（pipeline.md）

核心洞察：把生产切成**文本期（便宜）**与**几何期（贵）**：

| 段 | 载体 | 成本 | 说明 |
|---|---|---|---|
| 文本期 | markdown（`::: notes`） | 低 | 内容/分页/备注一次成文 |
| 几何精修 | `pandoc --reference-doc` + officecli 批量 set | 低-中 | 品牌模板 + 字体配色 |
| 自由版式 | officecli build 脚本（逐 shape） | 高 | 卡片/图表/morph 唯一途径 |

**分流 2a/2b/2c**：朴素直通（省 ≈90%）｜主题精修（性价比最高）｜自由重做（notes 用 `notes_migrate.py` 按页序迁移，零重写）。

跨工具链实测（这是两段式成立的基础）：
- `pandoc <md> -t pptx -o x.pptx --slide-level=2`（**该参数必需**，缺省会把全部内容压成 2 页）；
- pandoc 的 `::: notes` **逐页写入 pptx**，且 **officecli 可完整读出**（`query notes --json`）；
- 最小实验（A–D 四类操作：open/set shape/set placeholder/add shape）证明 **officecli 不会破坏 pandoc 写入的 notes**。

### 8.2 脚手架与产物生命周期（scaffold.md）

- **默认产出落当前工作目录（workdir）**，不另建任务文件夹；子目录仅 `inputs/`（素材多时）与 `.previews/`（交付前删除）；
- 三件套：`<主题>.pptx` + 可重跑 build 脚本 + `brief.md`（规划记录）；
- **失败恢复**：修脚本 → `rm` deck → 从 `create` 整建重跑（禁止残稿手补）。

### 8.3 构建纪律（officecli 实操基线）

1. **单次构建**：create → open 一次 → 同进程内完成全部 add/batch → close → validate；
2. 不依赖 auto-flush；任何外部读取/validate 前必须 `close`；
3. 逐页顺序：bg → decoration → title → body → notes；
4. 坐标即代码（全部写进 build 脚本）。

### 8.4 质量门体系（三道 + 专项）

| 门 | 内容 | 实现 |
|---|---|---|
| Gate 1 | schema | `officecli validate` |
| Gate 2 / 2b | 溢出与格式 / 占位符 | `view issues` = 0 / 文本 grep |
| **Gate 3** | **几何扫描（MUST，零依赖）** + 截图判读（可选） | `scripts/layout_scan.py`（解析 `view html` 绝对坐标，判定越界/重叠） |
| 溢出闭环 | 采纳官方 `suggest.height` | close→读 issues→set height→close（复检，因输出可能滞后） |
| notes 保障 | 从 md 直写 + 落盘复检 | 写入后 close → 独立进程读回断言条数（zip 级可复核 notesSlide） |
| Gate 5b-morph / Gate 6 | morph 四循环 / pitch 六检查 | 见第四章 / pitch-deck.md |

### 8.5 回归体系

- `scripts/selfcheck.py`：五路线冒烟（pptx-base 中文+$转义+notes+validate+几何门 / pitch / morph helpers / 3D 前置探测 / 两段式 pandoc+迁移）——**PASS 5 / FAIL 0**；
- `scripts/pilot_verify.py`：P0 文本度量对照实验（见 §11.2）。

---

## 第九章 关键技术发现库（实测教训）

| # | 现象 | 根因 | 对策 | 证据 |
|---|---|---|---|---|
| 1 | 文本溢出首轮 83 条 | 无度量协议，靠猜 | P0 §Text metrics：内边距 **上/下 3.6pt、左/右 7.2pt**；行高 **1.2×size**；全角宽 **1.2×size pt**（0.0423cm/pt） | 实测 need/usable 反推 + HTML `padding`/`line-height` |
| 2 | 多段文本仍溢出 | 行数按整串算 | 显式换行 **Σ 各段行数** | 实战暴露（slide[18] 3 行溢出） |
| 3 | 轻微越界 issues 不报 | `view issues` 覆盖面有限 | 几何门 `layout_scan`（实测页脚越界 7.9pt 而 issues=0） | 38 条违规被扫出 |
| 4 | 页脚出界 | y+行高 > 19.05cm | 页脚几何约束（9pt 安全起 y=18.2cm） | 修复后越界 0 |
| 5 | notes 莫名"丢失" | 依赖中间 deck 迁移 + 静默跳过 + 只看输出末行 | **md 直写 + 落盘复检** | 实验证明 officecli 不抹 notes；zip 级 13 个 notesSlide |
| 6 | 全局 `remove /shape[@id=]` 失败 | 缺 slide 上下文被 CLI 拒绝 | 用 query 返回的完整路径 | `Cannot resolve @id= outside of a slide context` |
| 7 | 中文渲染字体错 | 未指定时走主题（ea=等线） | 单写 `font=` 即双槽生效（实测） | readback `font/font.latin/font.ea` 一致 |
| 8 | `--prop edge=` 报 UNSUPPORTED | 拼写错误 | 正确属性名 `line` | 构建失败日志 |
| 9 | 缺 `--slide-level=2` 全压 2 页 | pandoc 默认 slide-level 过高 | 编译必带该参数 | 实测 2 页 vs 19 页 |
| 10 | 嵌套 `<svg>` 抽取被截断 | 非贪婪正则 | 平衡匹配函数 | 2 文件 xmllint 报错 → 修复 |
| 11 | `view issues` 输出滞后 | resident 写盘时序 | close 后复检循环 | 闭环机制 |
| 12 | clean-accumulation 删 `!!` ghost | 与 ghost 纪律矛盾 | 永不删 `!!`；只删 content ghost | 冒烟 PASS |
| 13 | 风格数量表述漂移 | 多文档手写数字 | 磁盘为唯一事实源 + 全库同步 | 51→52 同步 6 处 |
| 14 | morph 页形状名带 `!!` | CLI 自动前缀 | `@name=` 容错解析；jq 用精确前缀 | M-1 |
| 15 | 插入图片缺 alt | 漏传 | 规范强制 `--prop alt=` | stats `Pictures without alt text: 0` |

---

## 第十章 版本演进史

| 版本 | 主题 | 关键变更 |
|---|---|---|
| v1.0（成型） | 架构整合 + 审核修复 | 收编 4 子技能 → references 平铺；共享层抽象；description 收敛；G1–G5/H1–H6 修复（含 clean 重写、helpers 改名） |
| v1.1.0 | 工程化补齐 | scaffold / speaker-notes / CHANGELOG / selfcheck / 版本元数据 / description 收敛 |
| v1.2.0 | 两段式 + pandoc 合并 + P0 | pipeline.md；吸收 pandoc-slide-compiler（语法/风格档/编译/校验脚本）；P0 §Text metrics；notes_migrate；selfcheck 加两段式回归 |
| v1.2.1 | P0 补充 + 2c 实战 | 多段行数 Σ；溢出闭环强化（落盘复检）；实战数据（首轮 0） |
| v1.2.2 | layout_scan + 页脚几何 + notes 策略 | 几何门落地（Gate 3 双轨）；页脚几何约束；notes 直写+复检；resident 实验结论 |
| v1.3.0 | 鹿溪风格包 + 确定性路由 | mixed--luxi-scenario（3 变体）；style_route.py；style-lookup 路由节；INDEX 登记；风格库 51→52 |
| **v1.3.1** | **SVG 资产化** | 30 个 SVG 资产 + 抽取器 + README；tokens.json assets 段（5 条品牌规则）；PPT 可用性实测 |

---

## 第十一章 实战验证

### 11.1 基线（SAFTI 调研简报，外部复盘）

12 页中文高密度简报：首轮 **83 条 issue**（5 类：页脚小字/短标签换行/结构遮挡/标题折行/装饰误报），三轮收敛至 0；measured 成本分布：文本溢出闭环 60%、结构返工 25%、工具链搭建 15%。

### 11.2 对照实验（pilot_verify.py）

同素材 10 页，三种构建对照：

| 指标 | 基线 | 旧协议(0.05cm/pt) | **新协议(P0)** |
|---|---|---|---|
| 首轮 issues | 83 | 33 | **0** |
| 结构性返工页 | 4/12 | 10/10 | **0/10** |
| 修复闭环（suggest.height） | — | 33→0 | — |
| 两段式（pandoc） | — | — | 命令数 **1 vs 63**、notes 10/10 |

### 11.3 复盘简报 2b → 2c

- **2b（pandoc + 主题精修）**：19 页，深色蓝本网格；issues 首轮 1 → 闭环 0；
- **2c（自由版式重做）**：19 页 / 454 元素；修正多段行数后 **首轮 0**；notes 13 条迁移；
- 随后修复用户实测反馈（页脚越界 + notes 缺失）→ v2 版：几何越界 **0**、notes **zip 级 13 个 notesSlide**、validate PASS。

### 11.4 鹿溪范式介绍 deck（风格包首次端到端）

- 路由：`collateral/light → luxi-light`（确定性）；
- 7 页 / 202 元素 / **12 张 SVG 资产图（0 缺 alt）** / notes 6 条（zip 级验证）；
- issues 首轮 8 → 闭环 **0**；**layout_scan 越界 0**（页脚几何自始合规）。

---

## 第十二章 方法论沉淀（供工程报告 / 验收引用）

### 12.1 六条工程原则

1. **单一事实源**：色板/字体/规则只定义一次，其余引用（消除 3 类重复表）。
2. **磁盘即事实**：计数、资产、索引以磁盘为准，文档随动（风格 51→52 全库同步）。
3. **可重跑即可复现**：一切产出来自脚本；失败即 `rm` + 整建重跑。
4. **确定性优先**：能查表的不用推导，能规则的不用判断（风格路由 100% 确定）。
5. **门禁替代目检**：可运行的检查（issues/几何/notes 复检）作 MUST，人工目检作补充。
6. **实战反哺闭环**：每次真实任务暴露的缺口 → 当轮写入技能（本记录 §9 的 15 条教训均来自实战）。

### 12.2 可复用资产清单（验收计量建议）

| 类别 | 数量 | 计量口径 |
|---|---|---|
| 技能文档 | SKILL.md 139 行 + references 12 篇 3410 行 | `wc -l` |
| 执行脚本 | 8 个 1892 行（morph_helpers / notes_migrate / validate_slides / layout_scan / pilot_verify / selfcheck / style_route / morph-helpers.sh） | `ls scripts/` |
| 风格资产 | 52 风格目录 + 30 个 SVG（3 主视觉 + 23 图标 + 4 插画） | `ls \| wc -l`、`xmllint` |
| 质量门 | 3 道通用门 + 2 组专项门（morph/pitch）+ 2 个回归脚本 | 可执行 |
| 实战验证 | 4 个 deck（SAFTI 基线 / 复盘简报 2b+2c-v2 / 鹿溪介绍）+ 1 组对照实验 | 产物 + 报告 |

### 12.3 验收指标口径建议（可直接填表）

| 指标 | 定义 | 基线 → 现状 |
|---|---|---|
| 首轮缺陷数 | 新 deck 首次 `view issues` 计数 | 83 → **0**（对照实验） |
| 结构性返工页 | 需重排的页数 | 4/12 → **0/10** |
| 几何越界 | `layout_scan` 违规数 | 未检测 → **0**（强制门） |
| 备注覆盖率 | content 页含 notes 比例 | 100%（zip 级可核） |
| 命令成本 | 同素材构建命令数 | 63（officecli）→ **1**（pandoc 2a） |
| 资产复用 | SVG 资产数 / 缺 alt 数 | 30 / **0** |
| 回归通过率 | selfcheck | **PASS 5 / FAIL 0** |
| 确定性 | 同一路由输入变体一致率 | **100%**（规则函数） |

---

## 附录

### A. 文件清单与规模（v1.3.1 实测）

```
slide-master/
├── SKILL.md                        139 行（触发契约/决策树/纪律/维护溯源）
├── references/                     12 篇 · 3410 行
│   ├── pptx-base.md（582+）· pitch-deck.md（826）· morph-ppt.md（547）· morph-ppt-3d.md（583+）
│   ├── style-lookup.md · scaffold.md · speaker-notes.md · pipeline.md · pandoc-route.md
│   ├── decision-rules.md · pptx-design.md · CHANGELOG.md
│   └── styles/                     52 个风格目录（含 mixed--luxi-scenario/：style.md + tokens.json + assets/30 SVG）
├── scripts/                        8 个 · 1892 行
└── doc/                            本工程笔记 + 实战产物（3 pptx + 3 build 脚本 + 1 md + 预览）
总体积 2.8M · 总 md 70 个
```

### B. 命令速查

```bash
# 文档读写改验
officecli open <f> · view <f> outline|text|issues|stats|html|annotated · get <f> /slide[N] --depth 1
officecli add|set|remove <f> <path> --prop k=v · batch（stdin JSON）· validate <f> · query <f> '<selector>'
# 动效
python3 scripts/morph_helpers.py clone|ghost|verify|final-check <deck> …
# 两段式
pandoc <md> -t pptx -o <out> --slide-level=2 · python3 scripts/validate_slides.py <md> --pandoc
python3 scripts/notes_migrate.py <旧> <新>
# 质量与回归
python3 scripts/layout_scan.py <deck> [--overlap] · python3 scripts/selfcheck.py · python3 scripts/pilot_verify.py
# 风格
python3 scripts/style_route.py --scene <scene> --env <env> [--json]
python3 references/styles/mixed--luxi-scenario/assets/extract_assets.py [--src 源.html]
```

### C. 版本-特性对照（验收自查表）

| 特性 | 引入版本 | 可验证方式 |
|---|---|---|
| 唯一出口 + L0–L4 路由 | v1.0 | SKILL.md 决策树 + 触发冒烟 |
| 两段式流水线 | v1.2.0 | `pipeline.md` + 命令数对照 |
| P0 文本度量 | v1.2.0/1/2 | `pilot_verify.py` 对照 |
| 几何门 layout_scan | v1.2.2 | `layout_scan.py` 退出码 |
| 鹿溪确定性风格包 | v1.3.0 | `style_route.py` 输出一致性 |
| SVG 资产体系 | v1.3.1 | `xmllint` + `extract_assets.py` 重跑 |

### D. 术语表

| 术语 | 含义 |
|---|---|
| 受管模块/子技能定义 | `references/*.md` 中的场景化规则（不再是独立 SKILL.md） |
| 四色基石 | 鹿溪品牌用色纪律：绿主/青强调/金警示/源白底 |
| 确定性风格包 | 变体由规则函数唯一确定的风格包（luxi-scenario） |
| P0 协议 | 文本度量协议（内边距/行高/字宽/多段行数/suggest.height 首选） |
| 文本期 / 几何期 | 两段式的 markdown 阶段与 officecli 版式阶段 |
| Layout Scan | 零依赖几何越界扫描（解析 view html 绝对坐标） |
| 溯源 | 技能来源记录（AionUi builtin-skills 0.2.1+f5b0319）与同步策略 |

---

### E. 前期技能资产与证据（四代研究链存档）

**E.1 三代技能文件清单（本机实测）**

```bash
# 一代（2026-06-30）
pandoc-slide-compiler/
├── SKILL.md            （语法全量/5 风格档/编译命令/自检清单/不支持项）
└── validate_slides.py  （400 行：语法校验 + 自动修复）
# 二代（2026-08-11）
notes-to-static-site/
├── SKILL.md            （六阶段工作流/管线 7 步/8 断言校验/5 红线）
└── assets/{build_site.py, validate_site.py}
# 三代（2026-09-08，27 文件）
web-slide-forge/
├── SKILL.md            （§0 两段式+标准物契约 / §4 工作流 / §7 主题体系 / §9 文件结构 / §12 编译命令 / §13 替代说明）
├── assets/build_site.py · build_presentation.py · validate_site.py · precheck_notes.py
│   · init_workspace.py · download_deps.py · smoke_test.py
├── assets/css/{doc-base,slide-base,hand-drawn}.css
├── assets/js/{slide-engine,doc-search,rough-renderer,p5brush-renderer}.js
├── assets/themes/{light--minimal-corporate,dark--premium-navy}.css   ← 风格库命名源头
├── assets/templates/{doc_shell,slide_shell}.html
├── assets/vendor/{mermaid,p5,rough,p5.brush,brush}.min.js            ← 内嵌、构建零联网
└── assets/examples/demo/{01-开场,02-进阶}.md
```

**E.2 关键证据引用（可直接摘入结题材料）**

| 证据 | 出处 | 原文/事实 |
|---|---|---|
| 两段式生产概念 | web-slide-forge §0 | "技能的生产是**两段式**：build 只消费'标准物'……任意素材都**不直接进 build**" |
| 主题命名约定 | web-slide-forge §7 / assets/themes/ | `dark--premium-navy`、`light--minimal-corporate`（与 slide-master 风格库同名同构） |
| 脚手架就地原则 | web-slide-forge §12 | "`init_workspace.py` 初始化工作区脚手架（标准物/产物**就地落在你的工作文件夹，不用 /tmp**）" |
| 前置质量门 | web-slide-forge §12 | "标准物预检（生产前提：素材加工质量门，**FAIL 项返回非零**）" |
| 单命令闭环 | web-slide-forge §12 | "`--verify`：构建成功后自动执行 validate_site.py，**失败即非零退出**" |
| 三代替代声明 | web-slide-forge §13 | 完全替代 `notes-to-static-site`（doc 模式）与 `pandoc-slide-compiler`（slide 模式） |
| 备注规范源头 | pandoc-slide-compiler §A.2 | 5 风格备注字数档（30–200 字）→ 现 speaker-notes.md |
| 中文处理经验 | notes-to-static-site §5 | 锚点正则须支持非 ASCII；中文 id 需 `unquote` 双比对 |
| 离线原则 | notes-to-static-site §7 · web-slide-forge §7 | local 模式外链归零；vendor 内嵌零联网 |

**E.3 四代能力对照**

| 维度 | 一代 pandoc | 二代 static-site | 三代 web-slide-forge | 四代 slide-master |
|---|---|---|---|---|
| 输入 | 素材/PPT 架构 md | 笔记集合 md | 笔记集合 md（双模态） | 素材/md（含 pptx 编辑） |
| 输出 | .pptx（占位符版式） | doc 静态站 | doc + slide 双站 | **.pptx（自由版式/动效/风格）** |
| 呈现引擎 | pandoc | Python md→HTML | Python + 浏览器 JS 引擎 | **officecli（文件级）+ pandoc（文本期）** |
| 主题/风格 | 5 风格档（措辞/备注） | 单模板 | CSS 变量主题（2 套） | **52 风格库 + 确定性风格包** |
| 质量门 | 语法自检清单 | 8 断言 + 5 红线 | precheck + validate + --verify | **三重门 + 溢出闭环 + 几何扫描 + notes 复检** |
| 回归 | 无 | 校验脚本 | smoke_test | selfcheck（5 路线）+ pilot_verify（对照） |
| 方法论遗产 | 备注档/语法契约 | 工作流/中文处理/红线 | **两段式/标准物/token 主题/脚手架** | 全量继承 + 深化 |

---

*本笔记由 slide-master 构建过程全程实测整理；所有命令与数字可在本机复跑核对（`python3 scripts/selfcheck.py`、`pilot_verify.py`、`style_route.py`）。*
