#!/usr/bin/env python3
"""鹿溪设计范式 · 介绍 deck（luxi-light 变体 · 7 页）—— 风格包首次端到端实战。

路由（确定性）：python3 ../scripts/style_route.py --keywords "设计范式,设计系统,套件"
  → scene=collateral / env=light → variant=luxi-light / density=regular
规范依据：styles/mixed--luxi-scenario/style.md（四色基石 · 排印投影映射 · 品牌五护栏）
资产：styles/mixed--luxi-scenario/assets/（主标/符号标/lockup/图标；SVG 直插，必带 alt）
质量门：issues 闭环（采纳 suggest.height）→ close 落盘 → 复检 → layout_scan 几何门 → notes 落盘复检
用法：python3 build-鹿溪范式介绍.py [输出名.pptx]
"""
import subprocess, sys, os, re, json

DOC = os.path.dirname(os.path.abspath(__file__))
os.chdir(DOC)
PPTX = sys.argv[1] if len(sys.argv) > 1 else "鹿溪设计范式介绍.pptx"
ASSETS = os.path.abspath(os.path.join(DOC, "..", "references", "styles", "mixed--luxi-scenario", "assets"))

# —— luxi-light token（来自 tokens.json，确定性取值）——
BG, CARD, SUNKEN = "F5F7FA", "FFFFFF", "EEF2F5"
GREEN, CYAN, GOLD, ORIGIN = "0D5E42", "00D2FF", "F1C40F", "F5F7FA"
TEXT, TEXT2, MUTED = "1A2428", "42525C", "64748B"
UP, DOWN, FLAT, ALERT, INFO = "22C55E", "EF4444", "94A3B8", "E74C3C", "3498DB"
CN, MONO = "PingFang SC", "JetBrains Mono"
PT2CM, W, H = 28.3465, 33.87, 19.05
results = []


def run(*a, check=True):
    r = subprocess.run(list(a), capture_output=True, text=True)
    if check and r.returncode != 0:
        print("FAIL:", " ".join(a)[:130], "\n", r.stderr.strip()[-200:]); sys.exit(1)
    return r.stdout


def batch(cmds):
    r = subprocess.run(["officecli", "batch", PPTX], input=json.dumps(cmds, ensure_ascii=False),
                       capture_output=True, text=True)
    if r.returncode != 0:
        print("BATCH FAIL:", r.stderr.strip()[-250:]); sys.exit(1)


def est_lines(text, size, w):
    per = max(1, int((w * PT2CM - 14.4) // (size * 1.2)))
    return sum(max(1, -(-len(seg) // per)) for seg in text.split("\n"))


def est_h(text, size, w):
    return round((est_lines(text, size, w) * size * 1.2 + 7.2) / PT2CM, 2)


def shape(s, x, y, w, h, **p):
    cmd = ["officecli", "add", PPTX, f"/slide[{s}]", "--type", "shape",
           "--prop", f"x={x}cm", "--prop", f"y={y}cm", "--prop", f"width={w}cm", "--prop", f"height={h}cm"]
    for k, v in p.items():
        cmd += ["--prop", f"{k}={v}"]
    run(*cmd)


def text(s, t, x, y, w, size, color=TEXT, bold=False, align="left", font=CN, name=None, opacity=None):
    p = dict(text=t, size=size, color=color, font=font)
    if bold:
        p["bold"] = "true"
    if align != "left":
        p["align"] = align
    if name:
        p["name"] = name
    if opacity:
        p["opacity"] = opacity
    shape(s, x, y, w, est_h(t, size, w), **p)


def pic(s, fn, x, y, w, h, alt):
    run("officecli", "add", PPTX, f"/slide[{s}]", "--type", "picture",
        "--prop", f"src={os.path.join(ASSETS, fn)}", "--prop", f"x={x}cm", "--prop", f"y={y}cm",
        "--prop", f"width={w}cm", "--prop", f"height={h}cm", "--prop", f"alt={alt}")


def card(s, x, y, w, h, fill=CARD, line=GREEN, lw="0.75pt"):
    shape(s, x, y, w, h, geometry="roundRect", fill=fill, line=line, lineWidth=lw)


def new_slide():
    run("officecli", "add", PPTX, "/", "--type", "slide", "--prop", "layout=blank",
        "--prop", f"background={BG}")
    return int(run("officecli", "view", PPTX, "outline").split("\n")[0].split("|")[-1].split()[0])


def chrome(s):
    """页眉绿带 + 页脚线 + 页脚文本（符合 P0 页脚几何：y18.22 + 9pt = 18.86cm）"""
    batch([
        {"command": "add", "parent": f"/slide[{s}]", "type": "shape",
         "props": {"name": "_topband", "geometry": "rect", "fill": GREEN, "line": "none",
                   "x": "0cm", "y": "0cm", "width": f"{W}cm", "height": "0.12cm"}},
        {"command": "add", "parent": f"/slide[{s}]", "type": "shape",
         "props": {"name": "_footline", "geometry": "rect", "fill": GREEN, "opacity": "0.18",
                   "line": "none", "x": "1.5cm", "y": "18.10cm", "width": "30.87cm", "height": "0.03cm"}},
    ])
    text(s, "鹿溪设计范式 · LUXI DESIGN", 1.5, 18.22, 20, 9, MUTED)
    text(s, f"{s:02d}", 31, 18.22, 1.4, 9, MUTED, align="right")


def page_title(s, t):
    shape(s, 1.5, 1.15, 2.6, 0.12, geometry="rect", fill=CYAN, line="none")
    t2 = t.split(" · ")[0]
    text(s, t, 1.5, 1.52, 30.8, 36, GREEN, bold=True)
    return t2


NOTES = {
    2: "这页讲品牌内核：四个字母是一条工作法——链接信息、揭示层次、保留变量、持续迭代；右下角是角本位符号标，两条鹿角加一横，是这个体系的最小识别单元。",
    3: "四色基石是本范式的用色纪律：鹿溪绿占六到七成做基底，青色每页只出现一次做强调，金色只用于警示和行动号召，源白作底色。下方是数据专用的涨跌平语义色。",
    4: "三个主题覆盖三种阅读场景：浅色适合文档与看板，深色适合投影，墨色配宋体适合文化叙事。右侧是排印阶梯——网页字号必须按投影档位放大，不能一比一直搬，否则会低于可读底线。",
    5: "组件与场景一一对应：卡片、比例条、清单、引文四类元件支撑五个场景——经营看板、工作台、对外营销、沉浸叙事与品牌物料。场景不是风格，是选型的入口。",
    6: "资产已经全部向量化：主标用官方路径，符号标可与文字同色，双标并排必须等大。二十三枚语义图标和四幅物料预览可直接嵌入，每页点缀不超过三处，避免与内容争焦点。",
    7: "最后是五条品牌护栏：主标不重绘、双标只用等大组合、符号标不占主位、点缀克制、插图必须带替代文本。守住这五条，任何一份产出都会仍然是鹿溪。",
}


# ============ 构建（7 页）============
print("[1/4] 构建 7 页（luxi-light 自由版式）…")
if os.path.exists(PPTX):
    os.remove(PPTX)
run("officecli", "create", PPTX); run("officecli", "open", PPTX)

# P1 封面
s = new_slide(); chrome(s)
shape(s, 0, 14.6, W, 0.14, geometry="rect", fill=GREEN, line="none")
pic(s, "logo-lab-mark.svg", 14.635, 3.3, 4.6, 4.6, "鹿溪联合创新实验室主标")
text(s, "鹿溪设计范式", 2.5, 8.9, 28.87, 44, GREEN, bold=True, align="center")
text(s, "LUXI DESIGN · 全场景参考套件", 2.5, 11.7, 28.87, 18, TEXT2, align="center")
text(s, "林深见鹿，源启清溪", 2.5, 13.3, 28.87, 20, CYAN, bold=True, align="center")

# P2 品牌内核 L-U-X-I
s = new_slide(); chrome(s); page_title(s, "品牌内核 · L-U-X-I 法则")
laws = [("L", "Link", "连接", "信息成链，页与页共享元素"), ("U", "Unveil", "揭示", "逐层展开，不一次倾倒"),
        ("X", "X-Factor", "变量", "每页保留一个视觉焦点"), ("I", "Iterate", "迭代", "同模板复用，不每页发明")]
for i, (k, en, cn, d) in enumerate(laws):
    x = 1.5 + i * 7.97
    card(s, x, 5.0, 7.47, 7.4)
    text(s, k, x + 0.6, 5.6, 6.3, 46, GREEN, bold=True)
    text(s, f"{en} · {cn}", x + 0.6, 8.9, 6.3, 16, CYAN, bold=True)
    text(s, d, x + 0.6, 10.6, 6.3, 14, TEXT2)
pic(s, "logo-symbol-mark.svg", 1.5, 13.6, 1.5, 1.5, "鹿溪角本位符号标")
text(s, "角本位符号标 · Y + 一横 —— 体系的最小识别单元（与文字同色，可缩放至 24pt 行高）",
     3.4, 14.0, 29, 16, TEXT2)

# P3 四色基石 + 语义色
s = new_slide(); chrome(s); page_title(s, "四色基石 · 语义色")
stones = [(GREEN, "鹿溪绿", "#0D5E42", "基色 · 60–70% 视觉权重"), (CYAN, "青", "#00D2FF", "强调 · 每页仅一处"),
          (GOLD, "金", "#F1C40F", "警示 / 行动号召 · 少量"), (ORIGIN, "源白", "#F5F7FA", "底色 · 深色变体作正文")]
for i, (c, name, hexv, use) in enumerate(stones):
    x = 1.5 + i * 7.97
    card(s, x, 4.9, 7.47, 6.2, fill=CARD)
    shape(s, x + 0.5, 5.4, 6.47, 2.2, geometry="roundRect", fill=c, line="none")
    text(s, name, x + 0.6, 7.9, 6.3, 16, TEXT, bold=True)
    text(s, hexv, x + 0.6, 9.4, 6.3, 13, MUTED, font=MONO)
    text(s, use, x + 0.6, 10.4, 6.3, 12, TEXT2)
text(s, "语义色（数据语境专用）", 1.5, 11.6, 12, 15, GREEN, bold=True)
sem = [(UP, "涨"), (DOWN, "跌"), (FLAT, "平"), (ALERT, "告警"), (INFO, "信息")]
for i, (c, lab) in enumerate(sem):
    x = 1.5 + i * 4.1
    shape(s, x, 12.9, 0.9, 0.9, geometry="roundRect", fill=c, line="none")
    text(s, lab, x + 1.2, 13.0, 2.4, 15, TEXT2)

# P4 三主题 × 排印阶梯
s = new_slide(); chrome(s); page_title(s, "三主题 · 排印阶梯")
themes = [("light", BG, CARD, GREEN, "PingFang SC", "文档 / 看板"), ("dark", "121A17", "1A2428", "14805C", "PingFang SC", "投影 / 大屏"),
          ("ink", "0B0C0E", "141517", "14805C", "Songti SC", "文化 / 深读")]
for i, (name, b, c, pri, ft, use) in enumerate(themes):
    y = 4.9 + i * 3.1
    card(s, 1.5, y, 14.2, 2.8)
    shape(s, 2.1, y + 0.5, 1.0, 1.8, geometry="roundRect", fill=b, line="B7C3CC")
    shape(s, 3.25, y + 0.5, 1.0, 1.8, geometry="roundRect", fill=c, line="B7C3CC")
    shape(s, 4.4, y + 0.5, 1.0, 1.8, geometry="roundRect", fill=pri, line="none")
    text(s, f"data-theme=\"{name}\"", 5.8, y + 0.45, 5.6, 15, TEXT, bold=True, font=MONO)
    text(s, f"{ft} · {use}", 5.8, y + 1.65, 9.4, 13, TEXT2)
text(s, "排印阶梯（网页 px → PPT 投影 pt）", 17.0, 4.6, 15.4, 16, GREEN, bold=True)
scale = [("fs-display", "40px", "42pt", "封面主标"), ("fs-h1", "28px", "36pt", "页标题"),
         ("fs-h2", "22px", "26pt", "小节"), ("fs-body", "14px", "18pt", "正文（底线）"),
         ("fs-caption", "12px", "14pt", "说明"), ("fs-micro", "11px", "12pt", "页脚")]
for i, (tk, px, pt, use) in enumerate(scale):
    y = 6.6 + i * 1.72
    card(s, 17.0, y, 15.37, 1.5, fill=SUNKEN, line="none")
    text(s, tk, 17.5, y + 0.28, 5.6, 13, TEXT2, font=MONO)
    text(s, f"{px} → {pt}", 23.2, y + 0.24, 5.4, 14, GREEN, bold=True, font=MONO)
    text(s, use, 28.8, y + 0.3, 3.2, 12, MUTED)

# P5 组件与场景
s = new_slide(); chrome(s); page_title(s, "组件 · 场景矩阵")
scenes = [("经营看板", GREEN, "KPI / 监控 / 报表"), ("工作台", GREEN, "流程 / 审批 / 工单"),
          ("对外营销", CYAN, "发布 / 招募 / 活动"), ("沉浸叙事", GOLD, "文化 / 故事 / 深读"),
          ("品牌物料", TEXT2, "清单 / 信笺 / 巡检")]
for i, (n, c, d) in enumerate(scenes):
    x = 1.5 + i * 6.1
    card(s, x, 4.9, 5.62, 3.4)
    shape(s, x + 0.5, 5.4, 0.5, 0.5, geometry="ellipse", fill=c, line="none")
    text(s, n, x + 1.2, 5.34, 4.1, 16, TEXT, bold=True)
    text(s, d, x + 0.5, 6.5, 4.8, 12, MUTED)
text(s, "核心组件（PPT 化实现）", 1.5, 9.0, 14, 16, GREEN, bold=True)
comps = [("tile / brick 卡片", "roundRect + 描边（绿 18%）", 1.5), ("bar 比例条", "轨道 + 进度双矩形", 9.5),
         ("check 清单", "环节点 + 文本行", 17.5), ("quote 引文", "主色竖条 + 斜体正文", 25.5)]
for name, how, x in comps:
    card(s, x, 10.2, 7.37, 4.6, fill=CARD)
    text(s, name, x + 0.5, 10.8, 6.4, 15, TEXT, bold=True)
    text(s, how, x + 0.5, 12.2, 6.4, 13, TEXT2)
    if "bar" in name:
        shape(s, x + 0.5, 14.0, 6.4, 0.34, geometry="roundRect", fill=SUNKEN, line="none")
        shape(s, x + 0.5, 14.0, 4.2, 0.34, geometry="roundRect", fill=CYAN, line="none")
    elif "check" in name:
        for j in range(3):
            shape(s, x + 0.5 + j * 2.1, 14.0, 0.42, 0.42, geometry="ellipse", fill=GREEN, line="none")
    elif "quote" in name:
        shape(s, x + 0.5, 13.9, 0.14, 0.75, geometry="rect", fill=GREEN, line="none")

# P6 资产
s = new_slide(); chrome(s); page_title(s, "资产 · 主标与点缀素材")
card(s, 1.5, 4.9, 9.6, 6.4)
pic(s, "logo-lab-mark.svg", 2.3, 5.4, 3.0, 3.0, "鹿溪主标（官方路径）")
text(s, "主标 · logo-lab-mark.svg", 5.7, 5.9, 5.2, 15, TEXT, bold=True)
text(s, "2048 viewBox · 绿+青 · 禁重绘", 5.7, 7.3, 5.2, 12, MUTED)
card(s, 11.6, 4.9, 9.6, 6.4)
pic(s, "logo-symbol-mark.svg", 12.4, 5.4, 2.6, 2.6, "鹿溪符号标")
text(s, "符号标 · logo-symbol-mark.svg", 15.5, 5.9, 5.4, 15, TEXT, bold=True)
text(s, "48 viewBox · 可着任意色", 15.5, 7.3, 5.4, 12, MUTED)
card(s, 21.7, 4.9, 10.67, 6.4)
pic(s, "logo-lockup.svg", 22.4, 5.6, 4.6, 2.1, "双标等大 lockup")
text(s, "双标等大 lockup", 27.4, 5.9, 4.6, 15, TEXT, bold=True)
text(s, "并排唯一合法形态", 27.4, 7.3, 4.6, 12, MUTED)
text(s, "语义图标 23 枚（24×24 · stroke 1.7 · 金/青点缀）", 1.5, 11.9, 20, 15, GREEN, bold=True)
icons = ["fut-yuelu.svg", "fut-duyue.svg", "fut-lingtong.svg", "fut-qingxiu.svg", "fut-zhugui.svg", "fut-mingjian.svg"]
for i, fn in enumerate(icons):
    x = 1.5 + i * 2.6
    pic(s, "icons/" + fn, x, 13.3, 1.6, 1.6, f"鹿溪图标 {fn[:-4]}")
text(s, "＋ 4 幅物料预览插画", 18.0, 13.9, 12, 14, TEXT2)

# P7 收束
s = new_slide(); chrome(s); page_title(s, "品牌规范 · 五条护栏")
rules = ["主标只用官方路径资产，禁止重绘、变形与加描边", "「双标等大」并排仅使用 lockup 组合",
         "符号标用于点缀，不替代主标出现在封面主位", "每页图标与点缀不超过三处，克制优先",
         "插图必须携带替代文本（alt），确保无障碍与检索"]
for i, t in enumerate(rules):
    y = 4.9 + i * 2.05
    card(s, 1.5, y, 30.87, 1.8, fill=SUNKEN, line="none")
    text(s, f"0{i+1}", 2.1, y + 0.35, 1.6, 15, CYAN, bold=True, font=MONO)
    text(s, t, 4.1, y + 0.36, 27.6, 15, TEXT)
pic(s, "logo-lockup.svg", 13.6, 15.4, 6.6, 3.0, "鹿溪双标等大组合")
text(s, "林深见鹿 · 源启清溪", 1.5, 15.9, 11, 16, GREEN, bold=True)
text(s, "LUXI DESIGN SYSTEM · v1.3", 21.4, 16.0, 11, 14, MUTED, align="right", font=MONO)

run("officecli", "close", PPTX)

# 溢出闭环（落盘后复检）
print("[2/4] 溢出闭环 …")
for _ in range(4):
    out = run("officecli", "view", PPTX, "issues")
    m = re.search(r"Found (\d+) issue", out)
    n = int(m.group(1)) if m else 0
    if n == 0:
        print("      issues = 0"); break
    print(f"      issues = {n} → 采纳 suggest.height")
    run("officecli", "open", PPTX)
    for mm in re.finditer(r"(/slide\[\d+\]/shape\[@id=\d+\])[^\n]*?suggest\.height=([\d.]+)cm", out):
        run("officecli", "set", PPTX, mm.group(1), "--prop", f"height={mm.group(2)}cm", check=False)
    run("officecli", "close", PPTX)
run("officecli", "validate", PPTX)

# notes（按页直写 + 落盘复检）
print("[3/4] notes 写入 …")
run("officecli", "open", PPTX)
for n, t in sorted(NOTES.items()):
    run("officecli", "remove", PPTX, f"/slide[{n}]/notes", check=False)
    run("officecli", "add", PPTX, f"/slide[{n}]", "--type", "notes", "--prop", f"text={t}")
run("officecli", "close", PPTX)
got = json.loads(run("officecli", "query", PPTX, "notes", "--json"))["data"]["results"]
print(f"      写入 {len(NOTES)} · 落盘复检 {len(got)}")
assert len(got) == len(NOTES), f"notes 落盘校验失败 {len(got)} != {len(NOTES)}"

# 质量门
print("[4/4] 质量门 …")
out = run("officecli", "view", PPTX, "issues")
print("      issues =", (re.search(r"Found (\d+) issue", out) or [0, "?"])[1])
r = subprocess.run([sys.executable, "../scripts/layout_scan.py", PPTX, "--quiet"], capture_output=True, text=True)
print("      " + (r.stdout.strip().splitlines()[0] if r.stdout else r.stderr[-120:]))
assert r.returncode == 0, "layout_scan 几何越界"
s2 = run("officecli", "view", PPTX, "stats")
print("      " + " | ".join(l.strip() for l in s2.splitlines() if "Slides" in l or "Pictures" in l or "Text" in l))
print("交付：", PPTX)
