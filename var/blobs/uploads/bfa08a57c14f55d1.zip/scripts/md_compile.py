#!/usr/bin/env python3
"""md_compile.py —— 不依赖 pandoc 的 markdown → pptx 编译器。

把 `*_slides.md` 解析成页模型，再生成一个只用 officecli 的 `build_deck.py`；
可选直接执行（--run），产出 .pptx 并跑 officecli validate。

约定（与 references/pptx-base.md 一致）：
  # 一级标题      → 封面标题（frontmatter 的 title 优先）
  ## 二级标题     → 内容页
  - 列表项        → 项目符号
  ::: notes ... ::: → 该页 speaker notes

用法：
  python3 scripts/md_compile.py deck.md --out build/ [--run] [--theme accent]
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys as _sys
import sys
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Page:
    kind: str                      # cover | section | content
    title: str
    bullets: list[str] = field(default_factory=list)
    body: list[str] = field(default_factory=list)
    notes: str = ""
    assets: list[dict] = field(default_factory=list)   # ```chart / ```svg 围栏


def parse_front(text: str) -> tuple[dict, str]:
    match = re.match(r"^---\n([\s\S]*?)\n---\n?", text)
    if not match:
        return {}, text
    meta = {}
    for line in match.group(1).splitlines():
        if ":" in line and not line.strip().startswith("#"):
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip().strip("\"'")
    return meta, text[match.end():]


def parse_notes(lines: list[str], index: int) -> tuple[str, int]:
    collected: list[str] = []
    i = index
    while i < len(lines):
        line = lines[i]
        if line.strip() == ":::":
            return "\n".join(collected).strip(), i + 1
        collected.append(line.rstrip())
        i += 1
    return "\n".join(collected).strip(), i


def _inline_list(value: str) -> list[str]:
    value = value.strip().strip("[]")
    return [item.strip().strip("\"'") for item in value.split(",") if item.strip()]


def parse_chart_spec(raw: str) -> dict:
    """解析 ```chart 围栏里的 ChartSpec（id/type/title/unit/source/categories/series）。"""
    spec: dict = {"series": []}
    current_series: dict | None = None
    for line in raw.splitlines():
        line = line.rstrip()
        if not line.strip() or line.strip().startswith("#"):
            continue
        if line.lstrip().startswith("- "):
            item = line.lstrip()[2:]
            if ":" in item:
                key, value = item.split(":", 1)
                key, value = key.strip(), value.strip()
                if key == "name":
                    current_series = {"name": value}
                    spec["series"].append(current_series)
                elif current_series is not None:
                    current_series[key] = value
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key, value = key.strip(), value.strip()
        if key == "series":
            continue
        if key == "name":
            current_series = {"name": value}
            spec["series"].append(current_series)
            continue
        if key == "values":
            if current_series is not None:
                current_series["values"] = [float(v) for v in _inline_list(value)]
            continue
        if key == "categories":
            spec["categories"] = _inline_list(value)
        elif key in ("id", "type", "title", "unit", "source", "caption"):
            spec[key] = value
    return spec


def parse_slides(md: str) -> list[Page]:
    meta, body = parse_front(md)
    pages: list[Page] = []
    current: Page | None = None
    lines = body.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("# ") and not line.startswith("## "):
            title = line[2:].strip()
            if not pages and not meta.get("title"):
                current = Page("cover", title)
                pages.append(current)
            else:
                current = Page("section", title)
                pages.append(current)
            i += 1
            continue
        if line.startswith("## "):
            current = Page("content", line[3:].strip())
            pages.append(current)
            i += 1
            continue
        if current is None:
            i += 1
            continue
        fence = re.match(r"^\s*```\s*(chart|svg)\s*$", line)
        if fence:
            kind = fence.group(1)
            block: list[str] = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                block.append(lines[i])
                i += 1
            i += 1  # 跳过收尾围栏
            raw = "\n".join(block).strip()
            asset = {"kind": kind, "raw": raw}
            if kind == "chart":
                asset["spec"] = parse_chart_spec(raw)
            current.assets.append(asset)
            continue
        if line.strip() == "::: notes":
            notes, i = parse_notes(lines, i + 1)
            current.notes = notes
            continue
        stripped = line.strip()
        if not stripped:
            i += 1
            continue
        if stripped.startswith(("- ", "* ", "+ ")):
            current.bullets.append(stripped[2:].strip())
        elif stripped.startswith("#"):
            pass
        else:
            current.body.append(stripped)
        i += 1

    if meta.get("title"):
        cover = Page("cover", meta["title"], body=[meta["subtitle"]] if meta.get("subtitle") else [])
        pages = [cover] + [p for p in pages if p.kind != "cover"]
    elif pages and pages[0].kind == "cover" and meta.get("subtitle"):
        pages[0].body.append(meta["subtitle"])
    return pages


def hex_or(value: str, fallback: str) -> str:
    value = (value or "").lstrip("#")
    return value if re.fullmatch(r"[0-9A-Fa-f]{6}", value) else fallback


def default_font() -> str:
    return "Microsoft YaHei" if _sys.platform.startswith("win") else "PingFang SC"


def _rgba_to_hex(value: str, bg: str) -> str:
    match = re.match(r"rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)", value or "")
    if not match:
        return hex_or(value, bg)
    r, g, b = (float(match.group(i)) for i in (1, 2, 3))
    alpha = float(match.group(4)) if match.group(4) else 1.0
    br, bg_, bb = (int(bg[i:i+2], 16) for i in (0, 2, 4))
    mix = lambda fg, base: int(round(fg * alpha + base * (1 - alpha)))
    return "%02X%02X%02X" % (mix(r, br), mix(g, bg_), mix(b, bb))


def theme_from_asset(theme: str) -> dict:
    """从随包 tokens.json 的 variants 取色；取不到就用内置安全色。"""
    fallback = {"bg": "FFFFFF", "fg": "1C1C1C", "accent": "0D5E42", "muted": "5B6770", "cover_bg": "0D5E42", "cover_fg": "FFFFFF"}
    root = Path(__file__).resolve().parent.parent
    path = root / "references/styles/mixed--luxi-scenario/tokens.json"
    if not path.is_file():
        return fallback
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return fallback
    variants = data.get("variants") or {}
    key = {"light": "luxi-light", "dark": "luxi-dark", "ink": "luxi-ink"}.get(theme, theme)
    block = variants.get(key) or variants.get("luxi-light") or {}
    bg = hex_or(block.get("bg"), fallback["bg"])
    fg = _rgba_to_hex(block.get("text"), bg) if block.get("text") else fallback["fg"]
    muted = _rgba_to_hex(block.get("muted"), bg) if block.get("muted") else fallback["muted"]
    accent = hex_or(block.get("primary"), fallback["accent"])
    r, g, b = (int(accent[i:i+2], 16) for i in (0, 2, 4))
    cover_fg = "FFFFFF" if (0.299 * r + 0.587 * g + 0.114 * b) < 160 else bg
    return {"bg": bg, "fg": fg, "accent": accent, "muted": muted, "cover_bg": accent, "cover_fg": cover_fg}


def emit_script(pages: list[Page], theme: dict, deck_name: str, font: str) -> str:
    t = theme
    calls: list[list[str]] = [["create"], ["open"]]
    for index, page in enumerate(pages, start=1):
        if page.kind == "cover":
            bg, fg, title_size, body_size = t["cover_bg"], t["cover_fg"], 44, 22
            title_y, body_y = "6.0cm", "10.2cm"
            body_color = t["cover_fg"]
        elif page.kind == "section":
            bg, fg, title_size, body_size = t["bg"], t["accent"], 40, 20
            title_y, body_y = "7.0cm", "11cm"
            body_color = t["muted"]
        else:
            bg, fg, title_size, body_size = t["bg"], t["fg"], 32, 20
            title_y, body_y = "1.2cm", "3.4cm"
            body_color = t["muted"]
        slide = f"/slide[{index}]"
        calls.append(["add", "/", "--type", "slide", "--prop", "layout=blank", "--prop", f"background={bg}"])
        calls.append(["add", slide, "--type", "shape", "--prop", f"text={page.title}",
                      "--prop", "x=1.5cm", "--prop", f"y={title_y}", "--prop", "width=30cm", "--prop", "height=2.4cm",
                      "--prop", f"size={title_size}", "--prop", "bold=true", "--prop", f"color={fg}", "--prop", "font=PingFang SC"])
        if page.body:
            calls.append(["add", slide, "--type", "shape", "--prop", f"text={chr(10).join(page.body)}",
                          "--prop", "x=1.5cm", "--prop", f"y={body_y}", "--prop", "width=30cm", "--prop", "height=2cm",
                          "--prop", f"size={body_size}", "--prop", f"color={body_color}", "--prop", "font=PingFang SC"])
        if page.bullets:
            calls.append(["add", slide, "--type", "shape", "--prop", f"text={chr(10).join(page.bullets)}",
                          "--prop", "list=bullet",
                          "--prop", "x=1.5cm", "--prop", "y=4.6cm", "--prop", "width=30cm", "--prop", "height=13cm",
                          "--prop", f"size={body_size}", "--prop", f"color={t['fg']}", "--prop", "font=PingFang SC",
                          "--prop", "lineSpacing=1.3"])
        if page.notes:
            calls.append(["add", slide, "--type", "notes", "--prop", f"text={page.notes}"])
    calls.append(["close"])
    calls.append(["validate"])

    body = json.dumps(calls, ensure_ascii=False, indent=1)
    return (
        "#!/usr/bin/env python3\n"
        '"""由 md_compile.py 生成：只用 officecli，无 pandoc。"""\n'
        "import os, subprocess, sys\n\n"
        f"FILE = {json.dumps(deck_name)}\n"
        f"CALLS = {body}\n"
        f"PAGES = {len(pages)}\n\n"
        "subprocess.run(['officecli', 'close', FILE], capture_output=True)\n"
        "if os.path.exists(FILE):\n"
        "    os.remove(FILE)\n\n"
        "def run(*args):\n"
        "    proc = subprocess.run(args, capture_output=True, text=True)\n"
        "    if proc.returncode != 0:\n"
        "        sys.stderr.write(proc.stdout + proc.stderr)\n"
        "        raise SystemExit('officecli 失败: ' + ' '.join(args))\n\n"
        "for args in CALLS:\n"
        "    run('officecli', args[0], FILE, *args[1:])\n"
        'print("built ' + deck_name + ' pages=" + str(PAGES))\n'
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="markdown → pptx（officecli 路线，无 pandoc）")
    parser.add_argument("source", help="slides markdown")
    parser.add_argument("--out", default="build", help="输出目录")
    parser.add_argument("--theme", default="light", help="light | dark | ink")
    parser.add_argument("--font", default="auto", help="auto | 字体族名（Windows 默认 Microsoft YaHei）")
    parser.add_argument("--run", action="store_true", help="生成后立即执行")
    args = parser.parse_args()

    source = Path(args.source)
    if not source.is_file():
        print(f"找不到 {source}", file=sys.stderr)
        return 2
    pages = parse_slides(source.read_text(encoding="utf-8"))
    if not pages:
        print("没有解析到页面", file=sys.stderr)
        return 2

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    deck_name = out / (source.stem.replace("_slides", "") + ".pptx")
    font = default_font() if args.font == "auto" else args.font
    script = emit_script(pages, theme_from_asset(args.theme), deck_name.name, font)
    build = out / "build_deck.py"
    build.write_text(script, encoding="utf-8")
    (out / "pages.json").write_text(
        json.dumps([p.__dict__ for p in pages], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    compiled = subprocess.run([sys.executable, "-m", "py_compile", str(build)], capture_output=True, text=True)
    if compiled.returncode != 0:
        print(compiled.stderr, file=sys.stderr)
        return 3

    print(f"解析 {len(pages)} 页 → {build}")
    if not args.run:
        print("下一步：cd 到输出目录执行 python3 build_deck.py（需 officecli）")
        return 0
    if not shutil.which("officecli"):
        print("officecli 不在 PATH，无法执行；脚本已生成。", file=sys.stderr)
        return 4
    return subprocess.run([sys.executable, str(build.resolve())], cwd=out).returncode


if __name__ == "__main__":
    raise SystemExit(main())
