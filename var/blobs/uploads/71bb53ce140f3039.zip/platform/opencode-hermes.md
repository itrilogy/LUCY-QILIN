# OpenCode Hermes 平台适配与抽象工具调度指南

> **适用环境**: OpenCode Hermes (`opencode-hermes`) | **系统平台**: 全平台 (`platforms: ["any"]`)
> **适配技能**: 公文协同撰写引擎 (`gov-unified-writer`)
> **适配说明**: 在 OpenCode Hermes 环境中，支持通过 `@references/` 语法按阶段装载规则文件，并使用文件读写与 Bash 工具绑定下方九类抽象原语。

## 1. 抽象工具能力层映射 (Abstract Capability Primitives)

为确保技能在 `platforms: ["any"]` 及不同宿主客户端下具备一致的执行确定性，技能文档与各专项 Agent 统一通过以下**九类抽象工具原语**声明操作。宿主在运行时自动将其绑定至当前环境的等效原生工具：

| 抽象能力原语 | 语义职责 | 常见宿主工具实现映射（按当前可用工具自动绑定） |
|:---|:---|:---|
| **`[FILE_READ]`** | 读取纯文本文件、配置、规则法典或切片内容 | `read_file` / `Read` / `view_file` / `cat` |
| **`[FILE_WRITE]`** | 创建全新文件或写入临时切片文件 (`temp_chunk.md`) | `write_file` / `Write` / `create_file` |
| **`[FILE_EDIT]`** | 对已有文件执行局部精确文本替换（严禁整篇误覆写） | `edit_file` / `Edit` / `replace` / `str_replace` |
| **`[DIR_SEARCH]`** | 目录列举、文件名通配扫描或正文正则检索 | `glob` / `Glob` / `ls` / `LS` / `search_content` / `Grep` / `rg` |
| **`[SHELL_EXEC]`** | 在终端执行内置零依赖 Python 标准库脚本 | `run_command` / `Bash` / `run_shell_command` / `terminal` |
| **`[WEB_QUERY]`** | 外部权威政策、学术文献或行业基准检索与网页抓取 | `web_search` / `search_web` + `web_fetch` / `read_url` |
| **`[AGENT_DELEGATE]`** | 唤醒或委派阶段专项 Agent（支持独立子会话或当前会话角色切换降级） | `invoke_subagent` / `run_skill` / `Task` / `delegate_task`；若宿主无独立子智能体工具，则自动降级为**当前会话按序通过 `[FILE_READ]` 加载 `references/` 下的对应 Agent 规则文件并切换角色执行** |
| **`[MCP_DISCOVER]`** | 探测运行期已挂载的绘图 MCP 工具与协议资源：先检索工具列表与路由/治理资源（如 `intents` / `governance`），优先选择专业 CORE 工具；在调用绘图前**必须先调用 MCP 自带的协议查询工具或读取对应 Resource 获取完整语法与红线** | `list_resources` / `read_resource` / MCP 协议查询工具（不预设服务端 URL；若无匹配绘图 MCP 则直入本地降级路径） |
| **`[MCP_CALL]`** | 严格按 `[MCP_DISCOVER]` 获取的完整协议与 Schema 调用绘图 MCP（纯文本 `dsl` 入参时严禁包 Markdown 代码围栏或直接传原始 JSON 对象，若返回校验错误可按骨架提示自修正重试 1 次），并**原样内嵌其返回的 `![图标题](地址)` 图片语法**；无服务或失败时降级 Mermaid / VChart-SVG | `call_mcp_tool` / 宿主 MCP 工具调用；降级协议见 `references/unified_file_handling_protocol.md §6` |

---

## 2. 路径寻址与字面量拼接契约 (Path Resolution Contract)

1. **`${SKILL_ROOT}` 解析**：指向本技能包安装根目录（即 `SKILL.md` 所在目录）。
   - 在调用 **`[SHELL_EXEC]`** 执行脚本时，所有路径参数必须使用双引号包裹（如 `python3 "${SKILL_ROOT}/scripts/extract_pdf.py" "<输入路径>"`），防止空格或中文路径截断。
   - 在调用 **`[FILE_READ]` / `[FILE_WRITE]` / `[FILE_EDIT]`** 等文件 API 时，由于原生文件工具不经过 Shell 变量展开，Agent 必须在内存中将技能根目录与相对路径（如 `references/...`）**拼接为完整的绝对路径字面量字符串**再传入，严禁向文件 API 直接传入含 `${SKILL_ROOT}` 字面量的未展开字符串。
2. **工作区五层脚手架锚定**：所有项目产出物均严格落盘在工作区（`${PROJECT_ROOT}`）的五层脚手架目录（`00_Meta_Config/`、`01_*`、`02_*`、`03_*`、`04_*`）内，遵循 `references/unified_file_handling_protocol.md`。

---

## 3. 核心脚本与章节挂起调度协议 (Execution & Checkpoint Protocol)

1. **脚手架部署**：通过 `[SHELL_EXEC]` 调用 `python3 "${SKILL_ROOT}/scripts/init_gov_scaffold.py"` 初始化工作区目录树及 `00_Meta_Config/` 配置文件。
2. **异构素材降维**：遇到 `.pdf`、`.docx`、`.xlsx`、`.csv` 文件，禁止直接用 `[FILE_READ]` 硬读二进制内容，必须先通过 `[SHELL_EXEC]` 调用 `python3 "${SKILL_ROOT}/scripts/extract_pdf.py"` 提取为 Markdown 纯文本。
3. **长文本与增量池安全追加**：先通过 `[FILE_WRITE]` 写入临时文件，再通过 `[SHELL_EXEC]` 调用 `python3 "${SKILL_ROOT}/scripts/doc_append_helper.py" --mode a` 追加至目标账本或长文档。
4. **章节级分段挂起**：在生成多章节长文档时，每次委派仅生成单一章节或单一附件。落盘并更新进度账本后输出 `[流程挂起]` 信号，由用户或主控确认后再推进下一章节，保持上下文窗口清洁。
