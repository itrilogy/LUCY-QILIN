# 统一脚手架与文件处理规范 (Unified Scaffold & File Handling Protocol)

> **适用范围**: 本技能集群全阶段（脚手架部署、素材入仓、格式降维、增量知识池落盘、章节切片生成与终稿/审计组装）。
> **核心目标**: 在全平台（`platforms: ["any"]`）与任意宿主客户端环境下，建立统一的**五层工作区脚手架范式**与**确定性文件 I/O 协议**，消除硬编码路径、命令行转义崩溃与版本覆写风险。

---

## 1. 跨集群五层工作区脚手架范式 (Unified 5-Layer Workspace Scaffold)

无论在哪个业务领域（公文撰写、学术论文、QC 课题、科技项目），由脚手架脚本（`scripts/init_gov_scaffold.py`）生成的项目工作区统一遵循以下**五层逻辑拓扑与命名法则**：

| 层级 | 目录命名规范 | 职责边界与读写权限 | 跨集群对应目录 |
|:---|:---|:---|:---|
| **L0 全局总控层** | `00_Meta_Config/`（公文集群同步维护 `00_Meta_Config/`） | **全局配置、可配置插槽与状态账本**：存放 `config.yaml`（或 `00_Project_State.json`）、进度总账（`*PROGRESS*.md`）、全局意图与文献/资产追踪表。支持配置企业名称（`org_name`/`lead_unit`）、专家/作者署名（`expert_signature`/`person_name`/`author_name`）及行业规则插槽（`industry_rule_slot`）。 | `00_Meta_Config/`、`00_Meta_Config/` |
| **L1 原始素材与意向层** | `01_*`（如 `01_Raw_Data/`、`01_Original_Materials/`、`01_意向诊断阶段/`、`01_Intent_Review/`） | **原始素材保真仓与立项诊断区**：原始输入素材**只读隔离**，严禁直接修改或删除；所有异构二进制文件在此层通过 `extract_pdf.py` 降维为纯文本。 | `01_Raw_Data/`、`01_Original_Materials/`、`01_意向诊断阶段/`、`01_Intent_Review/` |
| **L2 知识资产与蓝图层** | `02_*` / `material_knowledge/` / `paradigms/` | **结构化事实池、增量知识池与施工蓝图**：存放拆解后的事实台账（`Fact_Pool.md`、`8Dim_Fact_Ledger.md`）、四大资产池（真问题/技术方法/术语/命名范式）及章节施工大纲（`MANIFEST.md`、`Paradigm_Mapping_Table.json`）。 | `02_Blueprint/`、`02_Research_Assets/`、`01_意向诊断阶段/02_支撑背调/`、`material_knowledge/` |
| **L3 原子生产与切片层** | `03_*` / `02_成果撰写阶段/` / `drafts/` | **章节级分段生产车间**：Agent 按章节或附件（`SEC-01`、`01_选择课题`、`ATT01~ATT16`）在此层生成独立的原子切片或初稿（`draft.md`、`chunk_SEC-*_draft.md`），物理隔离单次生成体积。 | `03_Drafts/`、`03_Documentation_Build/`、`02_成果撰写阶段/`、`drafts/` |
| **L4 终稿交付与审计层** | `04_*` / `03_末端评审阶段/` / `drafts/final/` | **终末组装定稿与三引擎审计区**：存放最高版本缝合后的定稿（`polished.md`、`polished_final.md`、`FINAL_PAPER_SUBMISSION.md`）、单体审计报告及问题/收益增量池聚合报告。 | `04_Final/`、`04_Audit_Review/`、`03_末端评审阶段/`、`drafts/final/` |

---

## 2. 异构文档格式降维协议 (Format Downgrade Protocol)

面对用户提供的 `.pdf`、`.docx`、`.xlsx`、`.csv` 等异构文件，**严禁使用原生文件读取原语直接读取二进制文件**（会导致乱码或撑爆上下文），统一调用内置的纯标准库提取引擎 `scripts/extract_pdf.py` 进行降维提取：

```bash
# 单文件提取（自动识别 .txt / .md / .csv / .docx / .xlsx / .pdf）
python3 "${SKILL_ROOT}/scripts/extract_pdf.py" "<源文件路径>" --output "<目标纯文本.md>"

# 目录批量提取（自动遍历子目录并输出为 Markdown）
python3 "${SKILL_ROOT}/scripts/extract_pdf.py" --input-dir "<源目录>" --output-dir "<提取输出目录>"
```

| 格式 | 解析机制 | 外部依赖要求 |
|:---|:---|:---|
| `.txt` / `.md` | UTF-8 容错直读 | 零第三方库依赖 |
| `.csv` | 标准库 `csv` 自动格式化为 Markdown 表格 | 零第三方库依赖 |
| `.docx` | 标准库 `zipfile` + `xml.etree.ElementTree` 解析 `word/document.xml`（含段落与内嵌表格） | 零第三方库依赖 |
| `.xlsx` | 标准库 `zipfile` + `xml.etree.ElementTree` 解析 `workbook.xml`、`sharedStrings.xml` 与各 Sheet 数据 | 零第三方库依赖 |
| `.pdf` | 多级自动探测降级：`pypdf` → `pdfminer` → `fitz` → 系统 `pdftotext` → 输出标准化转换指引 | 按需降级，不抛未捕获异常 |

---

## 3. 素材入仓与相对路径保真 (Relative-Path Fidelity)

1. **只读隔离**：用户原始素材目录（`source_dir`）仅作只读源，所有处理均在工作区入仓副本上执行，严禁对原始素材执行删除或移动。
2. **层级保真**：入仓搬运使用 `shutil.copy2` 并保留源目录的相对路径层级树（Relative Path Tree），防止不同子目录下的同名文件在扁平化拷贝时相互覆写。
3. **黑名单过滤**：遍历素材时自动跳过 `.git`、`node_modules`、`__pycache__`、`.DS_Store` 等隐藏目录与缓存文件。

---

## 4. 长文本与增量池安全追加协议 (Safe Append Protocol)

在写入跨章节长文档、更新进度账本（`PROGRESS`）或向增量知识池追加记录时，**严禁在 Shell 命令行中直接通过 `echo`、`cat <<EOF` 或 `python -c` 拼接长文本**（极易因引号、LaTeX 公式、代码块或中文标点引发转义截断或文件覆盖）。

必须统一执行两步安全追加法：
1. 使用宿主平台的**文件全量写入原语**将新增片段写入临时文件（如 `temp_chunk.md`）；
2. 调用内置安全追加脚本完成落盘：
   ```bash
   python3 "${SKILL_ROOT}/scripts/doc_append_helper.py" --source "temp_chunk.md" --target "<目标文件路径>" --mode a
   ```

---

## 5. 无版本号固定文件名与历史版本保护 (Clean Naming & Version Supremacy)

1. **主文件名去版本号**：技能内部的规则文件、脚本文件、主初稿（`draft.md`）与主精加工稿（`polished.md`）均使用**不带版本号的稳定文件名**，确保跨阶段 Agent 引用路径恒定不变。文档自身的演进版本统一记录在 YAML Frontmatter 的 `version` 字段或文末元数据行中。
2. **结构性重写递增后缀**：当某章节草稿因结构调整需整章重写时，**严禁覆写原文件**，通过追加 `_v2`、`_v3` 后缀新建文件（如 `chunk_SEC-01_v2_draft.md`）。
3. **局部靶向修订**：当质检仅要求修改某一段落或脱敏词时，使用宿主平台的**局部文本替换原语**在当前最高版本文件上原地精确替换。
4. **终稿最高版本缝合**：在最终组装定稿时，按章节序号遍历草稿目录；若同一章节存在多个版本，**仅提取最高版本文件**参与拼接，自动忽略历史旧稿。

---

## 6. 统一图表生成与渲染兜底协议 (MCP 优先 + Mermaid / VChart-SVG 降级)

当任务需要生成架构图、流程图、泳道图、因果分析图、统计分布图或定量对比图时，**禁止预设固定 MCP 地址或硬编码私有工具细节**，统一按以下“运行期 MCP 两步查询绘制 + 本地双引擎降级”协议执行：

### 6.1 Track A：运行期 MCP 四步协同绘制（第一优先级）
1. **资源与路由探测 (`[MCP_DISCOVER]`)**：探测宿主当前已连接的绘图 MCP 服务，检查其工具列表与 MCP Resource（如意图路由目录、协议治理规则）。若 MCP 同时提供**专业领域 CORE 工具**（如标准 QC 统计/因果图、企业泳道流程图等）与通用救济工具（Mermaid / VChart），优先匹配专业 CORE 工具，避免用通用图替代专业终稿。
2. **先查完整协议 (`[MCP_DISCOVER]`)**：因 MCP 工具列表通常仅暴露精简简介，调用具体渲染工具前，**必须**先通过该 MCP 自带的协议查询工具（如有）或读取对应 Resource 获取完整语法细则、注释符号约定与输出红线。
3. **合规构造并调用 (`[MCP_CALL]`)**：按 MCP Schema 与查到的实时范式构造入参：
   - 若工具入参为纯文本 `dsl` 字符串，**禁止包含 Markdown 代码围栏（```` ``` ````）与多余解释性前后缀**，并按 MCP 自身外壳要求组织文本（如需要文本壳时保留外壳而不直接传裸 JSON 对象）；尺寸参数采用 MCP 默认值或按可读比例传参。
   - 若首次调用返回校验报错与修正骨架提示，对照实时协议修正重试 1 次；若仍失败或环境无对应 MCP 工具，立即转入 Track B。
4. **原样挂载返回结果**：若 MCP 返回 `![图标题](返回的图片地址)` Markdown 图片语法，**原样嵌入正文或资产清单**，禁止擅自拆解降级为纯文本超链接。

### 6.2 Track B：无匹配 MCP 时的原生降级双引擎（兜底路径）
仅当当前运行环境**未挂载绘图 MCP**、MCP 不支持目标图表类型、或调用不可达时，切入以下完全自包含的本地降级引擎（注意：本节降级格式不可反向混用于 Track A 的纯文本 MCP 入参）：

- **Track B1 — Mermaid（结构、流程、泳道与计划类）**：
  - 适用图种：流程图 (`flowchart`)、跨部门泳道逻辑 (`flowchart` subgraph 泳道分栏)、系统架构图 (`architecture-beta` / `flowchart`)、时序图 (`sequenceDiagram`)、状态图 (`stateDiagram-v2`)、类图 (`classDiagram`)、ER 图 (`erDiagram`)、甘特图 (`gantt`)、思维导图 (`mindmap`)、时间线 (`timeline`)、象限图 (`quadrantChart`)、层级方案分解树等。
  - 输出形式：生成符合防错规则（英文节点 ID、含特殊字符标签加引号、无歧义方向声明）的独立 `mermaid` 代码块（```` ```mermaid ... ``` ````）；若工作区要求静态图片交付且宿主支持导出，可同步导出为 SVG。

- **Track B2 — VChart——SVG（统计定量与精细排版类）**：
  - 适用图种：柱状/折线/饼图、雷达图、散点图/散点矩阵、柏拉图（含累计百分比折线）、直方图/正态拟合曲线、SPC 控制图、箱线图、热力图、瀑布图、桑基图、旭日图、矩形树图、玫瑰图、词云图，以及 Mermaid 难以精细排版的 5M1E 鱼骨图与评分矩阵等。
  - 输出形式：遵循 VChart 视觉规范（主色 `#3b82f6`、警示/超限红 `#ef4444`、达标绿 `#10b981`、中性灰 `#6b7280`；学术灰度打印场景使用 `#000000`/`#4b5563`/`#9ca3af` 配合线型/填充纹理区分），以**独立可预览的 `.svg` 矢量图文件**落盘至工作区图表目录，并在正文中以 `![图表标题](相对路径/xxx.svg)` 嵌入。若运行端自带 VChart-to-SVG 渲染工具，则生成标准 VisActor VChart JSON Spec 经其导出 `.svg`；若完全离线无渲染器，则由 Agent 直接生成结构严谨、坐标/刻度/数据标签/图例完备的自包含标准 `<svg>` 文件落盘。

### 6.3 合法交付口径与必要附注
- 上游生产节点与下游组装/审计节点须统一认可 **三种合法图表交付物**：① MCP 返回的图片引用（`![标题](返回地址)`）；② 降级生成的 `.svg` 矢量图引用（`![标题](*.svg)`）；③ 降级生成的标准 `mermaid` 代码块。
- 无论采用哪种形态，每幅图表均须配有清晰编号/标题，并在图后紧跟 **≥150 字**的数据或技术解读（公文按需配图亦须给出数据出处与要点说明）。
