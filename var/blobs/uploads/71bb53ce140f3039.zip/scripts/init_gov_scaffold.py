#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gov-Unified-Writer 脚手架初始化与素材保真搬运引擎 (init_gov_scaffold.py)
遵循跨集群统一的五层物理工作区架构 (00_Meta_Config + 业务阶段目录)，同时兼容 {task_id}/00_Meta_Config/ 软链接/同步别名。
"""

import argparse
import datetime
import os
import shutil


VALID_REPORT_TYPES = [
    "述职述廉报告",
    "年度工作总结",
    "党建工作报告",
    "整改报告",
    "专项工作报告",
]


def init_gov_scaffold(
    work_dir: str,
    year: int,
    report_type: str,
    dept_name: str,
    person_name: str,
    org_type: str = None,
    source_dir: str = None,
    industry_profile: str = "tobacco_gov_default",
):
    if not org_type:
        if "县" in dept_name:
            org_type = "县级烟草专卖局（分公司）"
        elif "市" in dept_name:
            org_type = "市级烟草专卖局（公司）"
        else:
            org_type = "国有企业/事业机关单位"

    task_id = f"{year}-{report_type}"
    base_path = os.path.abspath(os.path.join(work_dir, task_id))
    print(f"🚀 Gov-Unified-Writer 脚手架初始化: {base_path}")

    dirs = [
        "00_Meta_Config",
        "01_Original_Materials",
        "03_PreAudit_Inquiries",
        "backgrounds/policy",
        "backgrounds/economy",
        "backgrounds/benchmark",
        "materials/summary",
        "materials/planning",
        "paradigms/history",
        "paradigms/current_template",
        "material_knowledge",
        "drafts/v1_initial",
        "drafts/final",
        "assets/images",
        "analysis_logs",
    ]
    for d in dirs:
        os.makedirs(os.path.join(base_path, d), exist_ok=True)

    now_iso = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00")
    config_content = (
        f"# 公文撰写全局元数据配置（含可配置企业规范插槽与撰写人署名）\n"
        f"task_id: \"{task_id}\"\n"
        f"auto_inference: true\n"
        f"industry_rule_slot: \"{industry_profile}\"\n"
        f"identity:\n"
        f"  name: \"{person_name}\"\n"
        f"  dept_name: \"{dept_name}\"\n"
        f"  org_type: \"{org_type}\"\n"
        f"report_meta:\n"
        f"  report_type: \"{report_type}\"\n"
        f"  year: {year}\n"
        f"priority_rules:\n"
        f"  p0_local_summary: true\n"
        f"  p3_policy_web: \"context_only\"\n"
    )

    progress_content = (
        f"# 公文撰写进度日志\n\n"
        f"> task_id: {task_id}\n"
        f"> report_type: {report_type}\n"
        f"> dept_name: {dept_name}\n"
        f"> person_name: {person_name}\n"
        f"> 创建时间: {now_iso}\n\n"
        f"| Phase | 状态 | 完成时间 | 备注 |\n"
        f"|:---|:---|:---|:---|\n"
        f"| Phase 0 意图嗅探 | ✅ 已完成 | {now_iso} | writing_intent.md 已初始化 |\n"
        f"| Phase 1 脚手架 | ✅ 已完成 | {now_iso} | 目录树 + config.yaml |\n"
        f"| Phase 2 八维拆解 | ⏳ 待执行 | — | — |\n"
        f"| Phase 3 背景检索 | ⏳ 待执行 | — | — |\n"
        f"| Phase 4 骨架构建 | ⏳ 待执行 | — | — |\n"
        f"| Phase 5 清单仲裁 | ⏳ 待执行 | — | — |\n"
        f"| Phase 6 组稿润色 | ⏳ 待执行 | — | 章节级分段挂起 |\n"
    )

    intent_content = (
        f"# 全局写作意图 (writing_intent.md)\n\n"
        f"- **报告类型**: {report_type}\n"
        f"- **目标年度**: {year}\n"
        f"- **所属单位**: {dept_name} ({org_type})\n"
        f"- **撰写署名**: {person_name}\n"
        f"- **结构偏好**: 标准骨架（优先参照历史同类报告，无历史参照时采用 {report_type} 标准骨架）\n"
        f"- **风格偏好**: 客观、务实、数据支撑\n"
    )

    # 统一写入单一权威的 L0 总控目录 00_Meta_Config/（避免双目录状态不一致）
    cfg_p = os.path.join(base_path, "00_Meta_Config", "config.yaml")
    if not os.path.exists(cfg_p):
        with open(cfg_p, "w", encoding="utf-8") as f:
            f.write(config_content)
    prog_p = os.path.join(base_path, "00_Meta_Config", "PROGRESS_LOG.md")
    if not os.path.exists(prog_p):
        with open(prog_p, "w", encoding="utf-8") as f:
            f.write(progress_content)
    intent_p = os.path.join(base_path, "00_Meta_Config", "writing_intent.md")
    if not os.path.exists(intent_p):
        with open(intent_p, "w", encoding="utf-8") as f:
            f.write(intent_content)

    # 搬运素材并生成 source_inventory.md
    inventory_rows = [
        "# 素材入仓清单 (source_inventory.md)",
        "",
        "| 原路径（相对 source_dir） | 文件类型 | 大小 | 推测用途 |",
        "|:---|:---|:---|:---|",
    ]
    if source_dir and os.path.exists(source_dir):
        count = 0
        for root, _, files in os.walk(source_dir):
            for file in sorted(files):
                if file.startswith(".") or file == "Thumbs.db":
                    continue
                src_file = os.path.join(root, file)
                rel_path = os.path.relpath(src_file, source_dir)
                dst_file = os.path.join(base_path, "01_Original_Materials", rel_path)
                os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                shutil.copy2(src_file, dst_file)
                ext = os.path.splitext(file)[1].lstrip(".").lower() or "unknown"
                size_kb = f"{round(os.path.getsize(src_file) / 1024, 1)}KB"
                purpose = "业务事实"
                if any(k in file for k in ("历年", str(year - 1), str(year - 2), "参照")):
                    purpose = "历史参照骨架"
                elif any(k in file for k in ("计划", "清单", "目标", "要点")):
                    purpose = "目标参照"
                inventory_rows.append(f"| {rel_path} | {ext} | {size_kb} | {purpose} |")
                count += 1
        print(f"✅ 已保真搬运 {count} 个素材文件至 01_Original_Materials/")

    inv_p = os.path.join(base_path, "00_Meta_Config", "source_inventory.md")
    if not os.path.exists(inv_p):
        with open(inv_p, "w", encoding="utf-8") as f:
            f.write("\n".join(inventory_rows) + "\n")

    print("✅ Gov-Unified-Writer 脚手架初始化完成。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="公文撰写脚手架初始化引擎")
    parser.add_argument("--work-dir", default=".", help="项目工作区根目录")
    parser.add_argument("--year", type=int, required=True, help="目标年度 (如 2026)")
    parser.add_argument("--report-type", required=True, choices=VALID_REPORT_TYPES, help="报告类型")
    parser.add_argument("--dept-name", required=True, help="部门/单位名称（可配置）")
    parser.add_argument("--person-name", required=True, help="撰写人姓名/署名（可配置）")
    parser.add_argument("--org-type", default=None, help="组织机构类型（可选，未传则自动推断）")
    parser.add_argument("--source-dir", default=None, help="原始素材目录路径")
    parser.add_argument("--industry-profile", default="tobacco_gov_default", help="企业规则插槽")
    args = parser.parse_args()

    init_gov_scaffold(
        args.work_dir,
        args.year,
        args.report_type,
        args.dept_name,
        args.person_name,
        args.org_type,
        args.source_dir,
        args.industry_profile,
    )
