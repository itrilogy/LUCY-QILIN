#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QC-Lifecycle-Manager 统一编排与增量池持久化引擎 (qc_orchestrator.py)
覆盖 Stage I (意向诊断) -> Stage II (成果撰写) -> Stage III (成果评审与批次轻量聚合) 全生命周期。
遵循零第三方库强依赖原则 (Stdlib-Only)。
"""

import argparse
import collections
import datetime
import os
import shutil
import sys


class QCOrchestrator:
    def __init__(self, base_dir: str, expert_name: str = "QC 资深诊断审计专家", org_name: str = "上饶市烟草专卖局（公司）"):
        if not base_dir:
            print("ERROR: --base [ProjectName] is REQUIRED to prevent path offset.")
            sys.exit(1)
        self.base_dir = os.path.abspath(base_dir)
        self.expert_name = expert_name
        self.org_name = org_name
        self.meta_dir = os.path.join(self.base_dir, "00_Meta_Config")
        self.scripts_dir = os.path.join(self.base_dir, "scripts")
        self.stage_intent_dir = os.path.join(self.base_dir, "01_意向诊断阶段")
        self.stage_writing_dir = os.path.join(self.base_dir, "02_成果撰写阶段")
        self.stage_review_dir = os.path.join(self.base_dir, "03_末端评审阶段")

    def init_common(self):
        os.makedirs(self.meta_dir, exist_ok=True)
        os.makedirs(self.scripts_dir, exist_ok=True)

        # 写入可配置元数据与署名插槽
        config_path = os.path.join(self.meta_dir, "config.yaml")
        if not os.path.exists(config_path):
            with open(config_path, "w", encoding="utf-8") as f:
                f.write("# QC 课题全生命周期全局配置（支持自定义企业规范与专家署名）\n")
                f.write(f"project_base: \"{os.path.basename(self.base_dir)}\"\n")
                f.write(f"org_name: \"{self.org_name}\"\n")
                f.write(f"expert_signature: \"{self.expert_name}\"\n")
                f.write("standard_code: \"T/CAQ 10201-2024\"\n")
                f.write("industry_rule_slot: \"tobacco_qc_default\"\n")

        # 部署统一标准库提取脚本副本到工作区 scripts/
        skill_script_dir = os.path.dirname(os.path.abspath(__file__))
        src_extractor = os.path.join(skill_script_dir, "extract_pdf.py")
        dst_extractor = os.path.join(self.scripts_dir, "pdf_extractor.py")
        if os.path.exists(src_extractor):
            shutil.copy2(src_extractor, dst_extractor)
            print(f"[VERIFIED] Unified stdlib document extractor deployed at: {dst_extractor}")

    def setup_intent(self):
        sub_dirs = ["01_原始申报书", "02_支撑背调", "03_单体诊断报告", "04_年度管理报告"]
        for d in sub_dirs:
            p = os.path.join(self.stage_intent_dir, d)
            os.makedirs(p, exist_ok=True)
            print(f"[VERIFIED] Directory created: {p}")

        pools = {
            "Enterprise_Problem_Pool.md": "# 企业全景真问题池\n\n",
            "Tech_Method_Pool.md": "# 技术与管理方法池 (TRIZ 映射)\n\n",
            "Term_Definition_Pool.md": "# 企业 QC 增量名词定义库\n\n",
            "Naming_Paradigm_Pool.md": "# 课题命名修订与范式库\n\n",
        }
        back_dir = os.path.join(self.stage_intent_dir, "02_支撑背调")
        for p, header in pools.items():
            file_path = os.path.join(back_dir, p)
            if not os.path.exists(file_path):
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(header)
        print(f"✅ Stage I (INTENT) initialized at {self.stage_intent_dir}")

    def setup_writing(self, project_type: str = "问题解决型·自定目标"):
        sub_dirs = ["05_素材碎片仓", "06_章节初稿仓", "07_总装草案仓", "Assets/Simulated", "Assets/Charts"]
        # 按课题类型条件创建章节目录（非自定目标跳过 02_现状调查）
        if "指令" in project_type or "创新" in project_type:
            standard_chapters = [
                "01_选择课题",
                "03_设定目标",
                "04_原因分析",
                "05_活动计划",
                "06_方案选定",
                "07_制定对策",
                "08_对策实施",
                "09_效果检查",
                "10_标准化",
                "11_总结",
            ]
        else:
            standard_chapters = [
                "01_选择课题",
                "02_现状调查",
                "03_设定目标",
                "04_原因分析",
                "05_活动计划",
                "06_方案选定",
                "07_制定对策",
                "08_对策实施",
                "09_效果检查",
                "10_标准化",
                "11_总结",
            ]
        for d in sub_dirs + standard_chapters:
            p = os.path.join(self.stage_writing_dir, d)
            os.makedirs(p, exist_ok=True)
            print(f"[VERIFIED] Directory created: {p}")

        # 初始化主成果报告书骨架（若不存在）
        report_path = os.path.join(self.stage_writing_dir, "成果报告书.md")
        if not os.path.exists(report_path):
            topic_title = os.path.basename(self.base_dir)
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(
                    f"# QC 课题成果报告书\n\n"
                    f"**课题名称**: {topic_title}\n"
                    f"**课题类型**: {project_type}\n"
                    f"**所属单位**: {self.org_name}\n"
                    f"**指导/评审署名**: {self.expert_name}\n\n"
                    f"---\n\n"
                    f"## 第 1 章 小组概况 <!-- [TAG: QC_01_TEAM] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 2 章 选择课题 <!-- [TAG: QC_02_SELECT] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 3 章 现状调查 <!-- [TAG: QC_02_STATUS] --> <!-- TYPE: 自定 -->\n\n"
                    f"## 第 4 章 设定目标与原因分析 <!-- [TAG: QC_03_GOALS] --> <!-- TYPE: ALL -->\n\n"
                    f"### 4.1 目标值设定\n\n"
                    f"### 4.2 可行性分析\n\n"
                    f"### 4.3 核心技术模拟实验验证 <!-- [TAG: QC_03_EXPERIMENTAL] --> <!-- TYPE: 创新 -->\n\n"
                    f"### 4.4 原因分析与主要原因确认 <!-- [TAG: QC_04_FACTORS] --> <!-- TYPE: 问题 -->\n\n"
                    f"## 第 5 章 制定活动计划 <!-- [TAG: QC_05_PLAN] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 6 章 提出方案并确定最佳方案 <!-- [TAG: QC_04_SOLUTIONS] --> <!-- TYPE: 创新,可选 -->\n\n"
                    f"## 第 7 章 制定对策 <!-- [TAG: QC_06_COUNTER] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 8 章 对策实施 <!-- [TAG: QC_06_IMPL] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 9 章 效果检查 <!-- [TAG: QC_07_EFFECT] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 10 章 {'标准化' if '创新' in project_type else '巩固措施'} <!-- [TAG: QC_08_STANDARD] --> <!-- TYPE: ALL -->\n\n"
                    f"## 第 11 章 总结和遗留问题 <!-- [TAG: QC_09_REVIEW] --> <!-- TYPE: ALL -->\n"
                )

        link_file = os.path.join(self.stage_writing_dir, "意向阶段资产索引.md")
        if not os.path.exists(link_file):
            with open(link_file, "w", encoding="utf-8") as f:
                f.write(
                    "# 意向阶段资产索引\n\n"
                    "- **意向知识池**: [02_支撑背调](../01_意向诊断阶段/02_支撑背调/)\n"
                    "- **诊断报告**: [03_单体诊断报告](../01_意向诊断阶段/03_单体诊断报告/)\n"
                )

        session_ctx = os.path.join(self.stage_writing_dir, "session_context.md")
        if not os.path.exists(session_ctx):
            with open(session_ctx, "w", encoding="utf-8") as f:
                f.write(
                    f"# QC 课题会话上下文 (session_context)\n\n"
                    f"- **课题名称**: {os.path.basename(self.base_dir)}\n"
                    f"- **[PROJECT_TYPE]**: {project_type}\n"
                    f"- **责任单位**: {self.org_name}\n"
                    f"- **指导/评审署名**: {self.expert_name}\n"
                )

        index_path = os.path.join(self.stage_writing_dir, "PROJECT_INDEX.md")
        if not os.path.exists(index_path):
            with open(index_path, "w", encoding="utf-8") as f:
                f.write(
                    "# QC 课题成果档案总账 (PROJECT_INDEX)\n\n"
                    "## 1. 课题基本信息\n"
                    f"- **课题名称**: {os.path.basename(self.base_dir)}\n"
                    f"- **课题类型**: {project_type}\n\n"
                    "## 2. 碎片文件索引\n"
                    "| 步骤 | 文件名 | 状态 | 备注 |\n"
                    "| :--- | :--- | :--- | :--- |\n"
                )
        print(f"✅ Stage II (WRITING) initialized at {self.stage_writing_dir}")

    def setup_review(self):
        sub_dirs = [
            "08_单体评审报告",
            "09_问题增量池",
            "10_收益增量池",
            "11_企业整体改善诊断报告",
            "12_QC活动质量诊断报告",
            "13_可推广成果推荐清单",
        ]
        for d in sub_dirs:
            p = os.path.join(self.stage_review_dir, d)
            os.makedirs(p, exist_ok=True)
            print(f"[VERIFIED] Directory created: {p}")

        pool_headers = {
            "09_问题增量池/规则维度_问题池.md": (
                "# 评审问题池 — 规则维度\n\n"
                "> 单体审计完成时逐条追加。\n\n"
                "| 规则ID(标签) | 课题名称 | 级别 | 描述 |\n"
                "| :--- | :--- | :--- | :--- |\n"
            ),
            "09_问题增量池/课题维度_问题池.md": (
                "# 评审问题池 — 课题维度\n\n"
                "| 课题名称 | CRITICAL数 | WARNING数 | 关键缺陷摘要 |\n"
                "| :--- | :---: | :---: | :--- |\n"
            ),
            "10_收益增量池/业务领域_收益池.md": (
                "# 收益池 — 业务领域维度\n\n"
                "| 课题名称 | 所属业务领域 | 解决的业务问题 | 改善幅度 | 经济效益 | 社会效益 |\n"
                "| :--- | :--- | :--- | :--- | :--- | :--- |\n"
            ),
            "10_收益增量池/课题维度_收益池.md": (
                "# 收益池 — 课题维度\n\n"
                "| 课题名称 | 目标达成率 | ROI | 巩固期趋势 |\n"
                "| :--- | :---: | :---: | :--- |\n"
            ),
        }
        for rel_path, header in pool_headers.items():
            full_path = os.path.join(self.stage_review_dir, rel_path)
            if not os.path.exists(full_path):
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(header)

        log_path = os.path.join(self.stage_review_dir, "AUDIT_LOG.md")
        if not os.path.exists(log_path):
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(
                    "# QC 成果审计流水账 (AUDIT_LOG)\n\n"
                    "| 时间 | 审计对象 | 结论 | 关键缺陷 |\n"
                    "| :--- | :--- | :--- | :--- |\n"
                )
        print(f"✅ Stage III (REVIEW) initialized at {self.stage_review_dir}")

    def ingest_bulk(self, source_dir: str):
        """批量摄取外部目录下的课题申报材料并保留相对路径层级"""
        if not os.path.exists(source_dir):
            print(f"ERROR: Ingest source directory NOT found: {source_dir}")
            sys.exit(1)

        self.setup_intent()
        target_base = os.path.join(self.stage_intent_dir, "01_原始申报书")
        count = 0
        for root, _, files in os.walk(source_dir):
            for file in sorted(files):
                if file.startswith(".") or file == "Thumbs.db":
                    continue
                src_file = os.path.join(root, file)
                rel_path = os.path.relpath(src_file, source_dir)
                dst_file = os.path.join(target_base, rel_path)
                os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                shutil.copy2(src_file, dst_file)
                count += 1
        print(f"✅ Bulk ingestion completed: {count} files copied into {target_base}")

    def update_pool(self, pool_type: str, title: str, content: str):
        back_dir = os.path.join(self.stage_intent_dir, "02_支撑背调")
        os.makedirs(back_dir, exist_ok=True)
        pool_map = {
            "term": "Term_Definition_Pool.md",
            "problem": "Enterprise_Problem_Pool.md",
            "method": "Tech_Method_Pool.md",
            "naming": "Naming_Paradigm_Pool.md",
            "name": "Naming_Paradigm_Pool.md",  # 兼容 name 与 naming 两种传参
        }
        if pool_type not in pool_map:
            print(f"ERROR: Unknown pool type '{pool_type}'. Valid: term, problem, method, name/naming")
            return
        path = os.path.join(back_dir, pool_map[pool_type])
        if not os.path.exists(path):
            self.setup_intent()
        with open(path, "a", encoding="utf-8") as f:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            if pool_type == "term":
                f.write(f"\n### {title}\n- **定义**: {content}\n- **记录时间**: {timestamp}\n---\n")
            else:
                f.write(f"## {title} ({timestamp})\n{content}\n\n")
        print(f"✅ Knowledge persistent to: {path}")

    def update_review_pool(self, args_list: list):
        """
        Stage III 专用增量池实时追加：
        - issue 模式: issue [规则ID(标签)] [课题名] [级别] [描述]
        - topic_issue 模式: topic_issue [课题名] [CRITICAL数] [WARNING数] [关键缺陷摘要]
        - benefit 模式: benefit [课题名] [业务领域] [解决的业务问题] [改善幅度] [经济效益] [社会效益] [目标达成率(可选)] [ROI(可选)] [巩固期趋势(可选)]
        """
        if not args_list:
            return
        mode = args_list[0]
        if not os.path.exists(self.stage_review_dir):
            self.setup_review()

        if mode == "issue" and len(args_list) >= 5:
            _, rule_id, topic, level, desc = args_list[:5]
            rule_pool = os.path.join(self.stage_review_dir, "09_问题增量池", "规则维度_问题池.md")
            with open(rule_pool, "a", encoding="utf-8") as f:
                f.write(f"| {rule_id} | {topic} | {level} | {desc} |\n")
            print(f"✅ Appended issue [{rule_id}] for '{topic}' to {rule_pool}")
        elif mode == "topic_issue" and len(args_list) >= 5:
            _, topic, crit_cnt, warn_cnt, summary = args_list[:5]
            topic_issue_pool = os.path.join(self.stage_review_dir, "09_问题增量池", "课题维度_问题池.md")
            with open(topic_issue_pool, "a", encoding="utf-8") as f:
                f.write(f"| {topic} | {crit_cnt} | {warn_cnt} | {summary} |\n")
            print(f"✅ Appended topic issue summary for '{topic}' to {topic_issue_pool}")
        elif mode == "benefit" and len(args_list) >= 7:
            topic, domain, problem, improvement, econ, social = args_list[1:7]
            domain_pool = os.path.join(self.stage_review_dir, "10_收益增量池", "业务领域_收益池.md")
            with open(domain_pool, "a", encoding="utf-8") as f:
                f.write(f"| {topic} | {domain} | {problem} | {improvement} | {econ} | {social} |\n")
            print(f"✅ Appended domain benefit for '{topic}' to {domain_pool}")

            if len(args_list) >= 8:
                rate = args_list[7]
                roi = args_list[8] if len(args_list) >= 9 else "-"
                trend = args_list[9] if len(args_list) >= 10 else "稳定"
                topic_pool = os.path.join(self.stage_review_dir, "10_收益增量池", "课题维度_收益池.md")
                with open(topic_pool, "a", encoding="utf-8") as f:
                    f.write(f"| {topic} | {rate} | {roi} | {trend} |\n")
                print(f"✅ Appended topic benefit for '{topic}' to {topic_pool}")
        else:
            print("ERROR: Invalid arguments for --update-review-pool. Use 'issue ...', 'topic_issue ...', or 'benefit ...'")

    def log_audit(self, target: str, conclusion: str, issues: str):
        if not os.path.exists(self.stage_review_dir):
            self.setup_review()
        path = os.path.join(self.stage_review_dir, "AUDIT_LOG.md")
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        entry = f"| {timestamp} | {target} | {conclusion} | {issues} |\n"
        with open(path, "a", encoding="utf-8") as f:
            f.write(entry)
        print(f"✅ Audit log updated at: {path}")

    def aggregate_review_pools(self):
        """从 09_问题增量池 与 10_收益增量池 轻量聚合统计摘要"""
        rule_pool = os.path.join(self.stage_review_dir, "09_问题增量池", "规则维度_问题池.md")
        domain_pool = os.path.join(self.stage_review_dir, "10_收益增量池", "业务领域_收益池.md")

        rule_counter = collections.Counter()
        if os.path.exists(rule_pool):
            with open(rule_pool, "r", encoding="utf-8") as f:
                for line in f:
                    if line.startswith("|") and "---" not in line and "规则ID" not in line:
                        cols = [c.strip() for c in line.split("|")[1:-1]]
                        if cols and cols[0]:
                            rule_counter[cols[0]] += 1

        domain_counter = collections.Counter()
        if os.path.exists(domain_pool):
            with open(domain_pool, "r", encoding="utf-8") as f:
                for line in f:
                    if line.startswith("|") and "---" not in line and "所属业务领域" not in line:
                        cols = [c.strip() for c in line.split("|")[1:-1]]
                        if len(cols) >= 2 and cols[1]:
                            domain_counter[cols[1]] += 1

        summary_path = os.path.join(self.stage_review_dir, "BATCH_AGGREGATION_SUMMARY.md")
        lines = [
            "# QC 成果评审增量池轻量聚合统计",
            f"- **生成日期**: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"- **审计署名**: {self.expert_name}",
            "",
            "## 1. TOP 10 高频规则缺陷分布",
        ]
        if rule_counter:
            lines.append("| 规则ID(标签) | 命中频次 |")
            lines.append("| :--- | :---: |")
            for rid, cnt in rule_counter.most_common(10):
                lines.append(f"| {rid} | {cnt} |")
        else:
            lines.append("*(当前问题增量池暂无记录)*")

        lines.extend(["", "## 2. 业务领域收益覆盖分布"])
        if domain_counter:
            lines.append("| 所属业务领域 | 课题数量 |")
            lines.append("| :--- | :---: |")
            for dom, cnt in domain_counter.most_common():
                lines.append(f"| {dom} | {cnt} |")
        else:
            lines.append("*(当前收益增量池暂无记录)*")

        with open(summary_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print(f"✅ Batch aggregation summary written to: {summary_path}")

    def run(self, stage=None, ingest=None, update=None, update_review=None, log=None, aggregate=False, project_type="问题解决型·自定目标"):
        self.init_common()
        if ingest:
            self.ingest_bulk(ingest)
            return
        if update:
            self.update_pool(update[0], update[1], update[2])
            return
        if update_review:
            self.update_review_pool(update_review)
            return
        if log:
            self.log_audit(log[0], log[1], log[2])
            return
        if aggregate:
            self.aggregate_review_pools()
            return
        if stage == "intent":
            self.setup_intent()
        elif stage == "writing":
            self.setup_writing(project_type=project_type)
        elif stage == "review":
            self.setup_review()
        elif stage == "all":
            self.setup_intent()
            self.setup_writing(project_type=project_type)
            self.setup_review()
        else:
            print("Usage: python3 qc_orchestrator.py --stage [intent|writing|review|all] --base [ProjectName]")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="QC 课题全生命周期编排引擎 ")
    parser.add_argument("--stage", choices=["intent", "writing", "review", "all"], help="初始化阶段")
    parser.add_argument("--base", required=True, help="项目工作区基准路径或名称")
    parser.add_argument("--project-type", default="问题解决型·自定目标", help="课题类型（问题解决型·自定目标 / 问题解决型·指令性目标 / 创新型）")
    parser.add_argument("--expert-name", default="QC 资深诊断审计专家", help="评审/诊断专家署名（可配置）")
    parser.add_argument("--org-name", default="上饶市烟草专卖局（公司）", help="所属企业/单位名称（可配置，默认企业预设）")
    parser.add_argument("--ingest", default=None, metavar="EXTERNAL_DIR", help="批量摄取外部申报书目录")
    parser.add_argument("--update-pool", nargs=3, metavar=("TYPE", "TITLE", "CONTENT"), help="更新 Stage I 四大知识池 (term|problem|method|name)")
    parser.add_argument("--update-review-pool", nargs="+", metavar="ARGS", help="更新 Stage III 评审问题池/收益池 (issue ... | topic_issue ... | benefit ...)")
    parser.add_argument("--log-audit", nargs=3, metavar=("TARGET", "CONCLUSION", "ISSUES"), help="记录审计流水账")
    parser.add_argument("--aggregate", action="store_true", help="对 Stage III 增量池执行轻量聚合统计")
    args = parser.parse_args()

    orch = QCOrchestrator(base_dir=args.base, expert_name=args.expert_name, org_name=args.org_name)
    orch.run(
        stage=args.stage,
        ingest=args.ingest,
        update=args.update_pool,
        update_review=args.update_review_pool,
        log=args.log_audit,
        aggregate=args.aggregate,
        project_type=args.project_type,
    )
