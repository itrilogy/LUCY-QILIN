---
name: qc-lifecycle-manager
version: 3.2.0
description: 通用 QC 课题全生命周期智能管理系统。覆盖 Stage I 意向诊断（TRIZ 矛盾分析+五维加权定级+实时知识池）、Stage II 成果撰写（三类型章节自动路由+14 Agent Map-Reduce 管线+规范叙事）与 Stage III 成果评审（150+规则三引擎审计+增量池轻量聚合+批次企业诊断）。遵循 T/CAQ 10201-2024 准则，支持可配置企业规则插槽与评审专家署名。
tags: [QC-Orchestration, PDCA-Lifecycle, Expert-Cluster, TRIZ]
category: qc-lifecycle-manager
---

[TAG: QC_MASTER_ORCHESTRATOR]

# QCC 智能体集群
QC 课题全生命周期智能管理系统。覆盖**意向诊断→成果撰写→成果评审**三阶段闭环，每阶段独立可运行：
- **Stage I**：接收申报书（PDF/Word）→ 统一格式降维提取 → TRIZ 矛盾分析 + 五维加权评分 → A/B/D 定级 + 九段式诊断建议书 + 四知识池实时沉淀
- **Stage II**：接收碎片素材 → 自动判定课题类型并路由章节（三种类型×三处分流）→ 14 Agent Map-Reduce 管线 → 符合 T/CAQ 10201-2024 标准的 10/11 章成果报告书
- **Stage III**：接收完稿报告 → 150+ 规则三引擎深度审计 → 增量池实时追加 → 全量完成后轻量聚合产出企业改善诊断 + QC 活动质量诊断 + 可推广成果推荐清单

## ⚙️ 全局可配置插槽 (`00_Meta_Config/config.yaml`)
- `org_name`: 所属企业/单位名称（默认预设：`上饶市烟草专卖局（公司）`，可按需配置为任意企业单位）
- `expert_signature`: 诊断与审计专家署名（默认：`QC 资深诊断审计专家`，可通过 `--expert-name` 或 `config.yaml` 自定义具体专家姓名）
- `industry_rule_slot`: 行业规则插槽（默认加载 `tobacco_qc_default` 及 `T/CAQ 10201-2024` 国标准则）

---

## §0 快速判断：三阶段场景速查

| 你手上的情况 | 走哪个阶段 | 核心产出 |
| :--- | :---: | :--- |
| 有一批申报书（PDF），要判断哪些值得立项 | **Stage I** | 单体诊断建议书 + 知识池 + 全景诊断 + 合并审计 + 评审汇总 |
| 有一个确定的课题，要写成果报告书 | **Stage II** | 11 章 QC 成果报告书 + 可视化图表（MCP 返图 / Mermaid / VChart-SVG）+ 碎片文件 |
| 已完成报告书，要审计评分 | **Stage III** | 三引擎深度审计报告 + 评分 + 等级 |

**快速入门 —— 三句话开始：**

- **Stage I**：把申报书 PDF 放入 `01_原始申报书/` → 发送 `意向诊断 [课题名]` → 收取 `03_单体诊断报告/` 中的九段式诊断建议书
- **Stage II**：发送 `为课题 [名称] 创建 [问题解决型|创新型] 脚手架` → 投喂素材 → 逐章扩写
- **Stage III**：发送 `成果审计 [课题名]` → 收取三引擎审计报告 + 评分定级；全量完成后发送 `汇总审计结果`

---

## §1 Stage I：意向评审 (Intent Review)

### 1.1 功能定位

批次评审 QC 课题申报书（PDF），逐份输出九段式诊断建议书，实时沉淀 4 个增量知识池，全量完成后自动聚合企业全景诊断与跨课题合并审计报告。

**核心专家角色**: 意向诊断专家（署名由 `00_Meta_Config/config.yaml` 中的 `expert_signature` 或运行时参数 `--expert-name` 注入，单体 Agent 角色内联模式）

### 1.2 运行方式

```bash
# 单课题初始化
python scripts/qc_orchestrator.py --stage intent --base "[项目名]"

# 批量自动化摄取
python scripts/qc_orchestrator.py --base "BatchSystem" --ingest "[外部父目录]"
```

单次诊断：将 PDF 放入 `01_原始申报书/`，发送 `意向诊断 [课题名称]`。Agent 在单个 prompt 内完成合规审计 → TRIZ 诊断 → 数据分析 → 战略建议 → 命名修订，输出九段式诊断建议书。

### 1.3 产出清单

| # | 产出物 | 落盘位置 | 说明 |
|:--|:---|:---|:---|
| 1 | 单体诊断建议书 | `01_意向诊断阶段/03_单体诊断报告/` | 九段式：客观概况 + 加权评分 + 法典拦截 + TRIZ 诊断 + 逻辑代偿挖掘 |
| 2 | 真问题池 | `01_意向诊断阶段/02_支撑背调/Enterprise_Problem_Pool.md` | 每份评审蒸馏一条真问题定义，实时追加 |
| 3 | TRIZ 方法池 | `01_意向诊断阶段/02_支撑背调/Tech_Method_Pool.md` | 每份评审映射 TRIZ 原理，实时追加 |
| 4 | 名词定义池 | `01_意向诊断阶段/02_支撑背调/Term_Definition_Pool.md` | 业务术语与算法名词解释，实时追加 |
| 5 | 命名范式库 | `01_意向诊断阶段/02_支撑背调/Naming_Paradigm_Pool.md` | 课题命名修订建议，评审完稿时聚合 |
| 6 | 企业全景管理诊断 | `01_意向诊断阶段/04_年度管理报告/` | 基于知识池的跨课题宏观诊断 |
| 7 | 跨课题合并审计 | `01_意向诊断阶段/04_年度管理报告/` | 语义聚类合并建议（Grade C 输出） |
| 8 | 评审结果汇总清单 | `01_意向诊断阶段/04_年度管理报告/` | A/B/D 分布 + 加权总分一览 |

### 1.4 按需加载的知识文件

| 优先级 | 文件 | 用途 |
|:---:|:---|:---|
| 🔴 必读 | `references/qc-intent-diagnostician.md` | 诊断专家角色定义 |
| 🔴 必读 | `references/qc_KB-IntentRules.md` | 评审法典：硬拦截 + 五维加权 + Grade 映射 |
| 🔴 必读 | `references/qc_KB-IntentTemplates.md` | 输出模板：单体报告 + 合并审计 + 全景诊断 |
| 🟡 按需 | `references/qc_KB-TRIZ.md` | 技术名词/创新课题评审时加载 |
| 🟡 按需 | `references/criteria-caq10201-2024.md` | 准则原文核查时加载 |
| 🟢 辅助 | `references/qc-coder.md` | 知识池落盘指令参考 |
| 🟢 辅助 | `references/qc-indexer.md` | 进度总账维护 |

---

## §2 Stage II：成果撰写 (Achievement Writing)

### 2.1 功能定位

接收碎片素材（PDF / Excel / 文字描述），自动识别课题类型，完成 PDCA 全流程扩写，输出符合评奖级叙事标准的 11 章 QC 成果报告书。

### 2.2 运行方式

```bash
python scripts/qc_orchestrator.py --stage writing --base "[项目名]"
```

### 2.3 工作流

#### Phase 0: 脚手架初始化
发送: `为课题 [名称] 创建 [问题解决型|创新型] 脚手架`
→ 创建 11 章标准目录 + `PROJECT_INDEX.md` + `成果报告书.md` + `session_context.md`

#### Phase 1: 素材提纯与闭环逼问
发送: `素材入库` 或 `解析新素材`
→ 六维自检（背景/痛点/小组/分工/方案/数据），缺失项自动追问，完稿写回 `session_context.md`

#### Phase 2: 章节扩写（Map-Reduce 管线）
发送: `请针对 [第X章 章节名] 进行深度扩写`
→ 子 Agent 并行产出 fragments + 图表（优先查调 MCP 绘图返图；无 MCP 时降级 Mermaid / VChart-SVG）→ qc-scribe 串行组装回填主报告

#### Phase 3: 同步与审稿
发送: `sync-report` 或 `同步成果报告书`
→ 三引擎审计（合规 150+ 规则 + 25 维度穿刺 + 自动化评分）

### 2.4 Agent 集群与阶段归属

| Agent | 角色 | Stage I | Stage II | Stage III |
|:---|:---|:---:|:---:|:---:|
| **qc-intent-diagnostician** | 意向诊断专家 | ✅ | — | — |
| **qc-pm** | 项目经理 / 中央调度 | — | ✅ | — |
| **qc-detective** | 现状调查 / 因果分析 | — | ✅ | — |
| **qc-inventor** | 方案设计 / TRIZ 映射 | — | ✅ | — |
| **qc-analyst** | 数据校验 / ROI 核算 | — | ✅ | — |
| **qc-scribe** | 报告组装 / 评奖级叙事 | — | ✅ | — |
| **qc-drafter** | 制图需求路由器 | — | ✅ | — |
| **qc-statistician** | 统计型图表 | — | ✅ | — |
| **qc-logician** | 逻辑型图表 | — | ✅ | — |
| **qc-planner** | 流程型图表 | — | ✅ | — |
| **qc-physics-modeler** | 数据仿真（按需唤醒） | — | 🔵 | — |
| **qc-coder** | 脚手架 / 知识池落盘 | ✅ | ✅ | ✅ |
| **qc-indexer** | 档案总账维护 | ✅ | ✅ | ✅ |
| **qc-reviewer** | 三引擎审计 / 评分 | — | ✅ | ✅ |

> 🔵 = 仅当满足激活条件时唤醒（详见 `references/qc-physics-modeler.md §0`）

### 2.5 课题类型与流程管线

#### 问题解决型 — 自定目标课题
选择课题 → 现状调查 → 设定目标 → 原因分析 → 确定主要原因 → 制定对策 → 对策实施 → 效果检查 → 制定巩固措施 → 总结和下一步打算

#### 问题解决型 — 指令性目标课题
选择课题 → 设定目标 → 目标可行性论证 → 原因分析 → 确定主要原因 → 制定对策 → 对策实施 → 效果检查 → 制定巩固措施 → 总结和下一步打算

#### 创新型
选择课题 → 设定目标及目标可行性论证 → 提出方案并确定最佳方案 → 制定对策 → 对策实施 → 效果检查 → 标准化 → 总结和下一步打算

### 2.6 知识文件索引

| 文件 | 用途 |
|:---|:---|
| `references/qc-pm.md` | 项目经理 Agent 定义 |
| `references/qc-detective.md` | 侦探 Agent 定义 |
| `references/qc-inventor.md` | 发明家 Agent 定义 |
| `references/qc-analyst.md` | 分析师 Agent 定义 |
| `references/qc-scribe.md` | 写手 Agent 定义 |
| `references/qc-drafter.md` | 制图路由器 Agent 定义 |
| `references/qc-statistician.md` | 统计制图 Agent 定义 |
| `references/qc-logician.md` | 逻辑制图 Agent 定义 |
| `references/qc-planner.md` | 计划制图 Agent 定义 |
| `references/qc-physics-modeler.md` | 数据仿真 Agent 定义 |
| `references/qc-coder.md` | 脚手架 Agent 定义 |
| `references/qc-indexer.md` | 索引员 Agent 定义 |
| `references/qc_KB-QCMethod.md` | QC 方法论知识库（单点真实源） |
| `references/qc_KB-ChartSpec.md` | 图表路由与降级渲染规范（MCP 优先 + Mermaid / VChart-SVG） |
| `references/qc_KB-ReportTemplate.md` | 成果报告书模板 |
| `references/qc_KB-ScriptTemplates.md` | 图表资产骨架与降级模板库 |
| `references/qc_KB-ParadigmCases.md` | 评奖级范式案例库 |
| `references/qc_KB-TRIZ.md` | TRIZ 创新方法论 |
| `references/core_KB-Guidelines.md` | 撰写与逻辑准则 |
| `references/core_KB-Relations.md` | Agent 级联依赖协议 |
| `references/core_KB-AgentInteraction.md` | 全集群交互与 BOND 触发协议 |
| `references/core_KB-ProjectIndex.md` | 档案总账模板 |
| `references/criteria-caq10201-2024.md` | T/CAQ 10201-2024 准则全文 |

---

## §3 Stage III：成果评审 (Achievement Review)

### 3.1 功能定位

两个层面：**(1) 单体审计** — 对已完成的成果报告书执行三引擎深度审计（150+ 规则 + 25 维度穿刺 + 自动化评分定级）；**(2) 批次聚合** — 全部单体审计完成后，从增量池轻量聚合产出企业改善诊断、QC 活动质量诊断、可推广成果推荐清单。

**核心专家角色**: 资深审计专家（署名由 `00_Meta_Config/config.yaml` 中的 `expert_signature` 配置注入）

### 3.2 运行方式

```bash
python scripts/qc_orchestrator.py --stage review --base "[项目名]"
```

**单体审计**: `成果审计 [课题名称]` 或 `深度审计 [课题名称]`
**批次聚合**: `汇总审计结果` 或 `生成批次审计报告`

### 3.3 三引擎审计（单体）

| 引擎 | 内容 | 依赖文件 |
|:---|:---|:---|
| **第一引擎** | 标准合规审计：逐条检查 150+ 常见错误（G/S/X/C/F/K/E/C-Series） | `references/problems-aqca002-2024.md` |
| **第二引擎** | 25 维度深度穿刺：物理审计 / 叙事审计 / 逻辑审计 / 美学审计 / 协作审计 | `references/qc_KB-ReviewRules.md` |
| **第三引擎** | 自动化评分：问题解决型 100 分 + 创新型 100 分 + 等级判定（一等/二等/三等/不合格） | `references/evaluation-appendices.md` |

单体审计输出：深度审计建议书（CRITICAL / WARNING / SUGGESTION + 评分 + 等级）

### 3.4 增量池与批次聚合

#### 增量追加（每次单体审计完立即执行）

每份审计落盘 `08_单体评审报告/` 后，同步向两个增量池实时追加：

| 增量池 | 追加内容 | 字段 |
|:---|:---|:---|
| `09_问题增量池/` | 规则维度：逐条 CRITICAL/WARNING + 课题维度：缺陷汇总 | 规则ID / 课题 / 级别 / 描述 |
| `10_收益增量池/` | 业务领域维度：解决的业务问题 + 改善幅度 + 效益 + 课题维度：达成率/ROI/趋势 | 课题 / 领域 / 问题 / 幅度 / 经济效益 / 社会效益 |

> **核心原则**: 增量池在每份审计时实时写入，聚合阶段只做轻量统计。详见 `references/qc-reviewer.md §4.1`。

#### 批次聚合（全量完成后触发）

发送 `汇总评审结果` → qc-reviewer 从增量池轻量聚合，产出三份终态报告：

| 产出 | 落盘位置 | 消费方 | 核心内容 |
|:---|:---|:---|:---|
| 企业整体改善诊断 | `11_企业整体改善诊断报告/` | 决策层 | 从收益反推短板 → 业务领域改善优先级 → 下一年度选题方向建议 |
| QC 活动质量诊断 | `12_QC活动质量诊断报告/` | 培训组 | 从问题池统计 → 高频缺陷 → 方法论成熟度评估 → 培训重点 |
| 可推广成果推荐 | `13_可推广成果推荐清单/` | 管理层/上级评审 | 一等+高ROI项 → 推广建议 + 标准化路径 + 推荐发表平台 |

### 3.5 知识文件索引

| 文件 | 用途 |
|:---|:---|
| `references/qc-reviewer.md` | 资深审计专家 Agent 定义（含 §4 增量池追加 + 批次聚合） |
| `references/qc_KB-ReviewRules.md` | 150+ 审计规则 + 25 维度准则 |
| `references/qc_KB-ReviewTemplates.md` | 单体审计报告模板 + 增量池 Schema + 三份终态报告模板 |
| `references/problems-aqca002-2024.md` | T/AQCA 002-2024 常见问题清单 |
| `references/evaluation-appendices.md` | 评分附录 A/B/C |
| `references/criteria-caq10201-2024.md` | T/CAQ 10201-2024 准则全文 |
| `references/qc-coder.md` | 脚手架 + 知识池/问题池/收益池落盘指令（§3 含 `--update-review-pool`） |

---

## §4 平台适配与统一文件处理协议

本技能集群的核心知识文件（`references/`）与标准库脚本（`scripts/`）均为跨平台（`platforms: ["any"]`）设计。
- **统一文件处理规范**：所有异构素材提取（`scripts/extract_pdf.py`）、长文本与知识池安全追加（`scripts/doc_append_helper.py`）、相对路径保真与最高版本优先原则，统一遵循 `references/unified_file_handling_protocol.md`。
- **全平台客户端适配**：调度语法和脚本路径适配说明见 `platform/` 目录：

| 平台 | 适配文件 |
|:---|:---|
| Reasonix | `platform/reasonix.md` |
| DeepSeek Harness | `platform/deepseek-harness.md` |
| Gemini CLI | `platform/gemini-cli.md` |
| OpenCode Hermes | `platform/opencode-hermes.md` |
| 通用 CLI / Agent 环境 | `platform/generic-cli.md` |

---

## 附录 A：标准合规审计核心规则（CRITICAL 拦截）

### 流程管线（G01-G09）
- **G01**: 自定目标课题不得使用指令性目标流程
- **G04**: 问题解决型不得使用创新型流程
- **G05**: 活动计划表不得放在选择课题之前

### 选择课题（S01-S06）
- **S02**: 课题名称必须包含量化或可度量特性值
- **S03**: 禁止「手段+目的」命名形式
- **S05**: 选题理由必须用事实与数据说明

### 现状调查（X01-X05）
- **X01**: 数据特性/计量单位必须一致
- **X04**: 必须找到问题症结

### 原因分析（C01-C06）
- **C01**: 必须针对症结开展原因分析
- **C04**: 末端原因必须分析到可直接采取对策为止

### 确定主要原因（F01-F04）
- **F01**: 必须排除超出小组能力范围的末端原因
- **F02**: 必须根据影响程度判定主要原因

### 制定对策（K01-K07）
- **K03**: 必须针对每一条主要原因逐条制定对策
- **K05**: 不得将课题目标作为对策目标

### 效果检查（E01-E06）
- **E02**: 效果检查时间段必须与现状调查时间段等长
- **E03**: 数据类型和统计口径必须一致

### 巩固措施（C1-C3）
- **C3**: 巩固措施跟踪数据不得少于 3 个统计周期

---

## 附录 B：自动化评分体系

### 问题解决型（100 分）
| 项目 | 分值 |
|:---|:---:|
| 选题 | 15 |
| 原因分析 | 30 |
| 对策与实施 | 20 |
| 效果 | 20 |
| 成果报告 | 5 |
| 特点 | 10 |

### 创新型（100 分）
| 项目 | 分值 |
|:---|:---:|
| 选题 | 20 |
| 提出方案并确定最佳方案 | 30 |
| 对策与实施 | 20 |
| 效果 | 15 |
| 成果报告 | 5 |
| 特点 | 10 |

### 等级分类
| 分数 | 等级 |
|:---|:---|
| ≥ 80 | 一等成果 |
| 70–79 | 二等成果 |
| 60–69 | 三等成果 |
| < 60 | 不合格 |

---

## 附录 C：TAG 锚点体系

| TAG 锚点 | 对应内容 | 负责 Agent |
|:---|:---|:---|
| `[TAG: QC_01_TEAM]` | 小组概况 | qc-scribe |
| `[TAG: QC_02_SELECT]` | 选择课题 | qc-scribe |
| `[TAG: QC_02_STATUS]` | 现状调查 | qc-detective |
| `[TAG: QC_03_GOALS]` | 设定目标 | qc-analyst |
| `[TAG: QC_04_FACTORS]` | 要因分析 | qc-detective |
| `[TAG: QC_04_SOLUTIONS]` | 方案选定 | qc-inventor |
| `[TAG: QC_05_PLAN]` | 活动计划 | qc-planner |
| `[TAG: QC_06_COUNTER]` | 制定对策 | qc-inventor |
| `[TAG: QC_06_IMPL]` | 对策实施 | qc-scribe |
| `[TAG: QC_07_EFFECT]` | 效果检查 | qc-analyst |
| `[TAG: QC_08_VALUE]` | 经济效益 | qc-analyst |
| `[TAG: QC_08_STANDARD]` | 标准化 | qc-scribe |
| `[TAG: QC_09_REVIEW]` | 总结 | qc-scribe |

---

## 附录 D：Agent 路由标识对照表

| Agent | 物理路由 TAG | 职责领域 |
|:---|:---|:---|
| **QC-PM** | `[TAG: QC_PM_ORCHESTRATION]` | 中央调度、状态机维护 |
| **QC-Intent-Diagnostician** | `[TAG: QC_01_INTENT]` | 意向评审、逻辑代偿 |
| **QC-Detective** | `[TAG: QC_02_DETECTION]` | 现状调查、因果分析 |
| **QC-Inventor** | `[TAG: QC_04_INVENTION]` | 方案发散、TRIZ 映射 |
| **QC-Analyst** | `[TAG: QC_07_ANALYSIS]` | 数据校验、ROI 计算 |
| **QC-Scribe** | `[TAG: QC_08_WRITING]` | 报告组装、八股文撰写 |
| **QC-Reviewer** | `[TAG: QC_09_REVIEW]` | 三引擎审计、自动化评分 |
| **QC-Drafter** | `[TAG: QC_DRAW_ROUTER]` | 制图需求路由分发 |
| **QC-Statistician** | `[TAG: QC_DRAW_STAT]` | 统计型图表 (Pareto/Hist...) |
| **QC-Logician** | `[TAG: QC_DRAW_LOGIC]` | 逻辑型图表 (Fishbone/Matrix...) |
| **QC-Planner** | `[TAG: QC_DRAW_PLAN]` | 流程型图表 (Gantt/Flow...) |
| **QC-Coder** | `[TAG: QC_SCAFFOLD_ENGINE]` | 物理脚手架、环境部署 |
| **QC-Indexer** | `[TAG: QC_PROJECT_INDEX]` | 档案总账、资产追踪 |
| **QC-Physics-Modeler** | `[TAG: QC_DATA_MODEL]` | 底层数据仿真与原始日志 |

---

## 附录 E：统计方法适用性

| 步骤 | 经常用 | 可用 |
|:---|:---|:---|
| 选择课题 | 调查表、排列图、简易图表 | 分层法、头脑风暴法 |
| 现状调查 | 调查表、排列图、分层法 | 直方图 |
| 设定目标 | 简易图表 | — |
| 原因分析 | 因果图、树图、关联图 | 头脑风暴法、亲和图 |
| 确定主因 | 调查表 | 散布图、矩阵图 |
| 制定对策 | 矩阵图、PDPC 法 | 简易图表 |
| 对策实施 | 简易图表 | 控制图、箭条图 |
| 效果检查 | 简易图表 | 控制图、直方图、散布图 |
| 巩固措施 | 简易图表、控制图 | — |
