# QC 图表资产骨架与降级模板库（Skeleton Library）

> 本文件供 `qc-coder` 与制图专项 Agent 在初始化或生成章节视觉资产时参考。
> 绘图时遵循 `references/qc_KB-ChartSpec.md` 的两轨原则：**优先调用运行期 MCP 服务绘图并返回图片地址；无对应 MCP 服务时，流程/计划类使用 Mermaid 代码块，统计/因果/精细排版类使用 VChart——SVG 生成自包含 `.svg` 文件存至 `02_成果撰写阶段/Assets/Charts/` 并引用**。

---

## 第 4 章：要因分析 · 鱼骨图（因果图）

**建议碎片文件名**: `04_原因分析/fishbone.md`（降级 SVG 落盘：`02_成果撰写阶段/Assets/Charts/ch04_fishbone.svg`）

````markdown
# 要因分析 · 鱼骨图

> **制图路由说明**：
> 1. 先执行 `[MCP_DISCOVER]` 查询环境是否存在鱼骨图绘图 MCP；若存在，按 MCP 实时 Schema 通过 `[MCP_CALL]` 绘图并将返回的图片地址填入下方 `![...]`；
> 2. 若无匹配 MCP 服务，则采用 Track B（VChart——SVG）生成符合 5M1E 四级下钻结构的自包含矢量图 `02_成果撰写阶段/Assets/Charts/ch04_fishbone.svg` 并引用（或使用 Mermaid `mindmap`/`flowchart`）。

![要因分析鱼骨图](../Assets/Charts/ch04_fishbone.svg)

> **场景化配图建议**: 建议在此处配一张 [现场实际问题场景] 的实拍照片或工况示意图。

## 深度解析

[待 @qc-detective / @qc-scribe 填写：150–300 字以上，分析 5M1E 各维要因的权重、排除依据及最终锁定主要原因]
````

---

## 第 5 章：活动计划 · 甘特图

**建议碎片文件名**: `05_活动计划/gantt.md`

````markdown
# 活动计划 · 甘特图

> **制图路由说明**：若运行端已挂载甘特图 MCP 则优先调用 MCP 返图；无匹配 MCP 时直接使用下列标准 Mermaid 甘特图（注意 `todayMarker off` 防止时间轴失真）。

```mermaid
gantt
    title QC 小组 PDCA 活动计划
    dateFormat  YYYY-MM-DD
    todayMarker off
    section P 计划阶段
    选择课题      :p1, 2026-01-01, 7d
    现状调查      :p2, after p1, 14d
    设定目标      :p3, after p2, 7d
    要因分析      :p4, after p3, 14d
    制定方案      :p5, after p4, 14d
    section D 执行阶段
    制定对策      :d1, after p5, 7d
    对策实施      :d2, after d1, 30d
    section C 检查阶段
    效果检查      :c1, after d2, 14d
    section A 改进阶段
    巩固标准化    :a1, after c1, 7d
    总结规划      :a2, after a1, 7d
```

> **图表解读说明**: 此处补充 ≥150 字对关键路径、跨阶段并行安排与节点管控节奏的说明。
````

---

## 第 6 章：方案比选 · 矩阵与多维雷达图

**建议碎片文件名**: `06_方案选定/matrix.md`、`06_方案选定/radar.md`（降级 SVG 落盘：`02_成果撰写阶段/Assets/Charts/ch06_radar.svg`）

````markdown
# 方案综合评价 · 评分矩阵与多维雷达图

> **制图路由说明**：优先查询运行期 MCP 是否支持 L 型矩阵图与雷达图渲染；无匹配 MCP 时，评分矩阵使用规范 Markdown 表格展示，多维竞争力雷达图使用 VChart——SVG 生成 `02_成果撰写阶段/Assets/Charts/ch06_radar.svg` 并引用。

![方案综合竞争力雷达图](../Assets/Charts/ch06_radar.svg)

<!-- 若宿支持 VChart 渲染工具，可参照以下 VChart JSON 数据契约传参生成 SVG：
{
  "type": "radar",
  "data": [{ "values": [
    {"dim": "响应速度", "val": 9.2, "plan": "优选方案"},
    {"dim": "精度", "val": 9.5, "plan": "优选方案"},
    {"dim": "成本控制", "val": 8.4, "plan": "优选方案"},
    {"dim": "可维护性", "val": 8.8, "plan": "优选方案"},
    {"dim": "推广性", "val": 9.0, "plan": "优选方案"}
  ]}],
  "categoryField": "dim", "valueField": "val", "seriesField": "plan"
}
-->

**综合评分（由 `@qc-analyst` 核算后填写）**：
| 方案 | 客观门槛校验 | 加权总分 | 结论 |
| :--- | :--- | :---: | :--- |
| 方案 A | 符合红线 | — | — |
| 方案 B | 触发物理门槛淘汰 | — | — |
| 方案 C | 符合红线 | — | — |
````

---

## 第 9 章：效果检查 · 实施前后对比与过程控制图

**建议碎片文件名**: `09_效果检查/before_after.md`、`09_效果检查/control_chart.md`（降级 SVG 落盘：`02_成果撰写阶段/Assets/Charts/ch09_bar.svg`、`ch09_spc.svg`）

````markdown
# 效果检查 · 实施前后对比与 SPC 稳定性验证

> **制图路由说明**：统计柱状对比图与 SPC 控制图须先确认样本量（控制图 ≥ 20 个观测值），随后优先调用绘图 MCP 获取图片地址；无匹配 MCP 时，按 `qc_KB-ChartSpec.md §4` 通过 VChart——SVG 生成 `.svg` 矢量图文件并附统计核对表。

![实施前后关键指标对比](../Assets/Charts/ch09_bar.svg)

![实施后过程监控 SPC 控制图](../Assets/Charts/ch09_spc.svg)

**改善效果汇总（由 `@qc-analyst` 核算后填写）**：
| 指标 | 实施前基准 | 实施后实测 | 改善幅度 | 达标情况 |
| :--- | :---: | :---: | :---: | :--- |
| 指标 1 | — | — | — | ⬜ |
| 指标 2 | — | — | — | ⬜ |

> **图表解读说明**: 此处补充 ≥150 字，说明统计周期一致性（E02/E03）、目标达成情况及连续稳态观测结论。
````
