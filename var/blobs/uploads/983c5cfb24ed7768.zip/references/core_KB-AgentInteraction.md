# QC 智能体集群交互与调度协议 (KB-AgentInteraction)

> **状态**: 全集群级联的核心规范，定义 Agent 间的 I/O TAG 与逻辑博弈链条。

---

## 1. Map-Reduce 核心交互全景 (Architecture Overview)

```mermaid
graph TD
    %% 全局控制总线
    CTX["📝 session_context.md (全局常量总线)"] -. "广播基准" .-> PM
    
    %% 调度层
    PM["💼 QC-PM (项目经理)"] -- "调度 [BOND: 分发碎片任务]" --> DET["🕵️ QC-Detective (侦探)"]
    PM -- "调度 [BOND: 分发方案任务]" --> INV["⚙️ QC-Inventor (发明家)"]
    
    %% 分析与切片层 (Map)
    DET -- "输出离散切片" --> FRAG["📄 碎片仓 (如 _f1.md, _f2.md)"]
    INV -- "输出离散切片" --> FRAG
    
    %% 图文强缝合层
    FRAG -- "请求图表挂载" --> STAT["📊 QC-Statistician (统计核爆)"]
    FRAG -- "请求图表挂载" --> LOGI["🔗 QC-Logician (逻辑连招)"]
    STAT -. "图表回填" .-> FRAG
    LOGI -. "图表回填" .-> FRAG
    
    %% 组装层 (Reduce)
    PM -- "指令 sync-reduce" --> SCRIB["✍️ QC-Scribe (组装工)"]
    SCRIB -- "串行降维读取" --> FRAG
    SCRIB -- "五段式八股写入" --> REPORT["📄 主成果报告书.md"]
    
    %% 审计防爆底盘
    REPORT -- "全文毛刺审计" --> REV["🔍 QC-Reviewer (审稿员)"]
    REV -- "反馈 Priority 1" --> PM
    
    %% IO 协调总账
    IDX["🗂️ QC-Indexer"] -. "维护总表" .-> REPORT
    IDX -. "维护总表" .-> FRAG
```

---

## 2. 标准化标记流转协议 (TAG Flow Protocol)

所有智能体在作业时，必须通过标记实现逻辑对接。

| 阶段 | 标准化 TAG | 生产 Source | 消费 Consumer | 交互语义 |
| :--- | :--- | :---: | :---: | :--- |
| **P** | `[TAG: QC_01_TEAM]` | `@qc-pm` | `@qc-scribe` | 小组成员与分工表 |
| **P** | `[TAG: QC_02_STATUS]` | `@qc-detective`| `@qc-scribe` | 现状调查数据与矛盾识别 |
| **P** | `[TAG: QC_04_FACTORS]` | `@qc-detective`| `@qc-inventor`| 穿透至组件级的 4 级要因树 |
| **D** | `[TAG: QC_04_SOLUTIONS]`| `@qc-inventor` | `@qc-scribe` | TRIZ 驱动的方案比选矩阵 |
| **D** | `[TAG: QC_06_IMPL]` | `@qc-scribe` | `@qc-reviewer`| 对策实施中的“异常攻坚”叙事 |
| **C** | `[TAG: QC_07_EFFECT]` | `@qc-analyst` | `@qc-scribe` | 工程毛刺美学化的改善数据 |
| **A** | `[TAG: QC_08_STANDARD]`| `@qc-pm` | `@qc-scribe` | 法典化标准化 (制度/标号) |

---

## 3. 核心 BOND 触发机制 (Logic Orchestration)

指挥官 (`@qc-pm`) 发起分发任务时，需显式携带以下 **BOND** 以开启专项深度分析逻辑：

### 3.1 物理穿刺模式 `[BOND: ATOMIC_MODE]`
- **触发对象**: `@qc-detective`
- **逻辑**: 要求根因锁定至原子物理颗粒（如 PTFE 密封圈、22.4V 回路波动）。

### 3.2 创新比选模式 `[BOND: TRIZ_MODE]`
- **触发对象**: `@qc-inventor`
- **逻辑**: 要求展示理想解 (IFR) 与矛盾解析，引用 40 发明原理，产出包含失效数据的对策表。

### 3.3 毛刺仿真模式 `[BOND: NOISE_MODE]`
- **触发对象**: `@qc-physics-modeler`
- **逻辑**: 强制生成 $99.993\%$ 这种具有非均匀分布特征的真实感数据 Asset。

### 3.4 博弈叙事模式 `[BOND: BATTLE_MODE]`
- **触发对象**: `@qc-scribe`
- **逻辑**: 强制启用“先描述失败/冲突 $\rightarrow$ 后叙述思维突破”的博弈级排版。

### 3.5 成果倒推模式 `[BOND: REVERSE_MODE]`
- **触发对象**: `@qc-detective`, `@qc-physics-modeler`, `@qc-analyst`
- **逻辑**: 应对“先有对策，后补过程”的倒推型课题。在用户授权下，允许基于经验与基本演绎法推演生成仿真实验数据与验证素材以完善逻辑链条（所有推演数据必须标注 `[AI推演建议：待补充现场实测数据]`）。

---

## 4. 协作审计准则 (Sync & Audit)

- **只增不删**: 调度过程严禁清理原始分析过程。
- **TAG 保护**: 成果报告书合稿后，任何 Agent 不得擅自删除 `<!-- [TAG: ...] -->` 锚点。
- **ASSET 真实性**: 级联过程中产生的所有数据资产，必须物理落地于 `[Project]/Assets/Simulated/`。
