# QC 图表路由与降级渲染规范 (Chart Spec & Rendering Protocol)

> **定位**: QC 课题图表选型路由、在线 MCP 调度与离线双引擎（Mermaid / VChart-SVG）降级渲染规范。
> **优先级声明**: 运行时**优先**通过 `[MCP_DISCOVER]` 获取宿主已连接绘图 MCP 服务实时提供的工具 Schema 与语法范式，通过 `[MCP_CALL]` 直接绘图并回填返回的图片地址；**仅当当前环境未提供对应图表类型的 MCP 服务时**，才采用本规范中的 Track B（Mermaid / VChart-SVG）完成绘制。

---

## 1. 两轨三级渲染决策总则

1. **前置方法合规检查**：制图前须满足 `references/evaluation-appendices.md`（T/CAQ 10201-2024 附录 A）的方法适用性与样本量门槛（排列图 ≥ 50、直方图 ≥ 50、散布图 ≥ 30 对、控制图 ≥ 20 个、折线图 ≥ 3 个统计周期）。
2. **Track A：运行期 MCP 四步协同绘制（第一优先级）**：
   - **先查路由与协议资源**：用 **`[MCP_DISCOVER]`** 检索当前运行环境已连接绘图 MCP 的意图路由/治理资源及工具列表；遵循 **CORE 专业工具优于 RELIEF 通用工具**（标准 QC 图及跨部门泳道 `flow` 优先选用 MCP 专用 CORE 工具，不用通用救济通道替代）。调用前**必须**先通过 MCP 自带协议查询工具或 Resource 读取该图种的完整语法细则与注释/符号红线，严禁仅凭工具列表简介盲拼 DSL。
   - **纯文本传参与重试**：严格按 MCP 实时提供的 Schema 调用 **`[MCP_CALL]`**（`dsl` 为纯文本字符串时**禁止包 Markdown 代码围栏与多余前后缀**、不传裸 JSON 对象）；若服务返回校验错误与骨架提示，修正重试 1 次。
   - **原样嵌入返图**：将 MCP 返回的 `![图标题](返回的图片路径或URL)` 原样挂载至报告/碎片文件。
3. **Track B：无匹配 MCP 时的降级双引擎（兜底路径）**：
   - **Track B1（结构/流程/计划类 → Mermaid）**：使用标准 ```` ```mermaid ```` 代码块。
   - **Track B2（统计定量/分布/控制限/精细排版类 → VChart——SVG）**：依据 VChart 统计视觉语义输出自包含标准 `.svg` 矢量图文件，落盘于 `02_成果撰写阶段/Assets/Charts/<章节或图表ID>.svg`，在正文/碎片中以 `![图标题](Assets/Charts/<name>.svg)` 引用。

---

## 2. QC 常用图表选型对照与降级引擎映射表

> 制图时先以“目标图表类型 / 关键词”查询运行期 MCP 是否支持；若无匹配 MCP，则按表中**降级推荐引擎**执行绘制。

### 2.1 统计型图表 (Statistical)

| 图表类型 | 典型关键字 / 用途 | 适用性 / 样本量硬门槛 | 降级推荐引擎 |
|:---|:---|:---|:---|
| **pareto (柏拉图)** | 二八定律、频次降序+累计占比曲线、找关键少数 (A类 < 80%) | 样本量 ≥ 50；**不可用于**直接确认末端主要原因 | **VChart——SVG**（双轴柱折组合） |
| **histogram (直方图/CPK)** | 分布分析、正态拟合、USL/LSL 规格限对比 | 样本量 ≥ 50 | **VChart——SVG**（柱状直方+拟合线+规格红线） |
| **control (控制图/SPC)** | 过程稳定性监控 (`I-MR`/`X-bar-R`/`P`/`NP`/`C`/`U`)、UCL/CL/LSL | 样本 ≥ 20 个；**不可用于**确认主要原因 | **VChart——SVG**（折线+控制上下限+异常点红标） |
| **scatter (散点/气泡图)** | 双变量相关性、线性回归、要因定量验证 | 数据对 ≥ 30 对 | **VChart——SVG**（散点+趋势拟合线） |
| **matrix_plot (散点矩阵/相关热力)** | 多变量全维度交互对比 | 关联指标多维对比 | **VChart——SVG**（热力矩阵或分面散点） |
| **radar (雷达图)** | 多维综合评价、实施前后均衡性/竞争力对比 | 各轴量纲与刻度需显式标注 | **VChart——SVG**（极坐标多边形雷达） |
| **basic (柱状/折线/饼图)** | 实施前后对比柱状图、多周期趋势折线、构成饼图 | 折线图需 ≥ 3 个统计周期 | **VChart——SVG**（或轻量统计 `Mermaid pie/xychart-beta`） |
| **waterfall / boxPlot / heatmap / sunburst / treemap** | ROI 经济效益归因、批次离散度箱线图、负荷热力、层级占比 | 数据源须与台账 1:1 对齐 | **VChart——SVG** |

### 2.2 逻辑与流程型图表 (Logic & Workflow)

| 图表类型 | 典型关键字 / 用途 | 规则与结构要点 | 降级推荐引擎 |
|:---|:---|:---|:---|
| **fishbone (鱼骨图)** | 因果分析、5M1E / 4P 分层拆解要因 | 至少展开 2 级，末端要因应穿透至 3–4 级可直接采取对策为止 | **VChart——SVG**（精细鱼骨矢量排版）或 `Mermaid mindmap/flowchart` |
| **affinity (亲和图/KJ法)** | 头脑风暴观点归纳、多维度聚类 | 每个分组下保持多条关联观点；**不可用于**替代原因分析 | **Mermaid** (`flowchart` subgraphs) 或 **VChart——SVG**（卡片聚类） |
| **relation (关联图)** | 复杂交叉因果、多因多果出/入度定位 | 高亮末端根因与核心症结节点 | **Mermaid** (`flowchart LR/TD` + 节点高亮样式) |
| **matrix (L/T/Y/X/C 型矩阵图)** | 方案比选评分、对策-要因映射 | 标明 `◎=9(强) ○=3(中) △=1(弱)` 与加权总分（或物理参数对比表） | **VChart——SVG** 或 **Markdown 评分矩阵表** |
| **pdpc (过程决策程序图)** | 风险预判、应急对策演化路径 | 须区分正常主线与风险应急分支 (`OK/NG`) | **Mermaid** (`flowchart` 含分组子图与条件虚线) |
| **arrow (矢线图/PERT/CPM)** | 关键路径工期核算、任务依赖 | 标明关键路径耗时、工序与虚任务依赖 | **Mermaid** (`flowchart` / `gantt`) 或 **VChart——SVG** |
| **flow (企业泳道/程序流程图)** | 跨部门对策流程、审批程序、制度流转 | 优先查 MCP 专用泳道 CORE 工具（区分部门/阶段/岗位与分支闭合）；离线用 Mermaid 泳道分栏 | **Mermaid** (`flowchart` subgraphs) |
| **Mermaid 工程流转图** | 活动计划甘特图、一般流程图、时序图、状态机、类图、ER 图、时间线 | 遵循 §3 防错规范 | **Mermaid** (`gantt`/`flowchart`/`sequenceDiagram`/`stateDiagram-v2`/`classDiagram`/`erDiagram`/`timeline`) |

---

## 3. Track B1：Mermaid 防错与通用配色规范

### 3.1 防错五原则（严格执行）
1. **节点 ID**：纯英文与数字组合（如 `A1`、`step_check`），禁止使用中文作节点 ID。
2. **标签封装**：所有节点描述文字统一用 `A["描述文本"]` 双引号包裹，防止括号、冒号、空格或逗号引发解析失败。
3. **标点防御**：节点内部描述优先使用中文全角标点（`，`、`；`、`：`），避免未加引号的半角逗号 `,` 或分号 `;`。
4. **甘特图缩放**：`gantt` 日期统一用 `YYYY-MM-DD`；若评估日期不在任务周期内，加 `todayMarker off` 防止时间轴拉伸。
5. **方向与缩进**：`flowchart` 必须显式声明方向（`TD` / `LR` / `RL`）；子层节点与 `section` 保持 4 空格缩进。

### 3.2 通用配色色板（Mermaid 与 VChart-SVG 共用）

| 语义用途 | 十六进制色值 | 说明 |
|:---|:---|:---|
| 主色（正常 / 中选 / 实施后） | `#3b82f6` | 工业蓝 |
| 预警 / 异常点 / 关键路径 / 淘汰项 | `#ef4444` | 预警红 |
| 成功 / 达标 / 改善目标达成 | `#10b981` | 成功绿 |
| 警示 / 80% 线 / 准入阈值 | `#f59e0b` | 琥珀黄 |
| 次要 / 对照组 / 中性参考 | `#6b7280` | 中性灰 |
| 图表背景 / 反白文字 | `#ffffff` | 纯白 |

---

## 4. Track B2：VChart——SVG 矢量图降级规范

当环境无可用绘图 MCP 且图种不适合纯 Mermaid 时，按以下规范产出矢量图表：

1. **VChart 结构驱动**：
   - 若当前宿主/工具链内置 **VisActor VChart → SVG** 渲染能力，按照标准 VChart JSON Spec（包含 `type`、`data: [{ values: [...] }]`、坐标轴 `axes: [bottom, left]`、`legends`、`label: { visible: true }`、`markLine` 等静态配置，禁止 JS 函数）传参导出 `.svg`。
   - 若处于完全离线无渲染器环境，则由 Agent **直接编写标准自包含 SVG** 文件落盘（保持与 VChart 相同的严谨坐标映射、比例刻度与配色规范）。
2. **SVG 自包含文件硬性规范**：
   - 根标签声明 `xmlns="http://www.w3.org/2000/svg"` 与明确 `viewBox`（建议横向 `0 0 960 540` 或纵向 `0 0 800 640`），背景使用 `#ffffff` 确保深浅主题阅读器均清晰可读。
   - 字体指定通用安全栈 `font-family="-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Microsoft YaHei', sans-serif"`；禁止外链字体、外链图片或 `<script>`。
   - **数据保真**：图中每个柱高、折线节点、饼扇比例、散点位置、control/spec 阈值线及数字标注必须按物理比例计算绘制，且与正文数据表及 `《原始数据采集日志.md》` 1:1 一致。
   - **落盘与引用**：默认写入 `02_成果撰写阶段/Assets/Charts/<章节前缀>_<图表名>.svg`，并在对应章节或碎片文件中使用相对路径挂载：`![图标题](../Assets/Charts/<文件名>.svg)`（主报告根目录则写 `Assets/Charts/<文件名>.svg`）。

---

## 5. QC 专项逻辑扩展模块 (Markdown 结构化模块)

以下模块属于 QC 评审与逻辑论证核心结构化组件，可直接作为 Markdown 结构块内嵌正文（其中方案树按 §3 Mermaid 规范绘制）：

### 5.1 ΔP 要因确认矩阵 (Causal Intensity Matrix)
用于量化末端要因暴露与问题发生的因果强度：

```yaml
Type: delta_p_matrix
Title: [末端因素项目] 要因确认矩阵
Legend: a:暴露且阳性, b:暴露且阴性, c:未暴露且阳性, d:未暴露且阴性
Rows:
  - Label: 因素暴露 (有)
    Positive: [a值]
    Negative: [b值]
  - Label: 因素未暴露 (无)
    Positive: [c值]
    Negative: [d值]
Calculate:
  Logic: ΔP = a/(a+b) - c/(c+d)
  Result: [计算出的ΔP值]
  Intensity: [因果强度判定：ΔP ≥ 0.5 判定为主要原因]
```

### 5.2 物理参数比选矩阵 (Physical Parameter Matrix)
用于创新型方案择优，强制列出客观物理与经济参数：

```markdown
| 比选维度 | 物理/技术指标门槛 | 方案 A | 方案 B | 方案 C | 结论判定 |
|:---|:---|:---:|:---:|:---:|:---|
| 尺寸精度 | 误差 ≤ [值] mm | [实测值] | [实测值] | [实测值] | 方案X优 |
| 响应速度 | 延迟 ≤ [值] ms | [实测值] | [实测值] | [实测值] | 方案X优 |
| 成本红线 | 预算 ≤ [值] 元 | [实算值] | [实算值] | [实算值] | 符合 / 超限淘汰 |
| 系统兼容性 | 工业接口/电压范围 | [实测值] | [实测值] | [实测值] | 兼容 |
| **综合结论** | **门槛筛选** | **推荐** | **备选** | **淘汰** | **中选方案X** |
```

### 5.3 4–5 层级联方案树 (Multi-level Cascade Tree)
使用标准 Mermaid `flowchart TD` 展现深度模块拆解：

```mermaid
flowchart TD
    Root["总体系统目标"] --> M1["功能模块 1"]
    Root --> M2["功能模块 2"]
    M1 --> D1["子模块决策 A"]
    M1 --> D2["子模块决策 B"]
    D1 --> Op1["备选方案 1（量化指标）"]
    D1 --> Op2["备选方案 2（量化指标）"]
    Op1 --> Exec1["步骤1：领用与标定组件"]
    Op1 --> Exec2["步骤2：电路/算法联调"]
    Op1 --> Exec3["步骤3：按图装配与验证"]
```

### 5.4 TRIZ 创新逻辑视觉表达 (TRIZ Visuals)
- **九屏幕分析表**：以 `[TRIZ: NINE_SCREENS]` 标记 3×3（超系统/系统/子系统 × 过去/现在/未来）Markdown 表格。
- **矛盾与原理映射**：以 `[TRIZ: CONTRADICTION]`（改善参数 / 恶化参数 / 推荐原理）及 `> [TRIZ PRINCIPLE: 原理名称] -> [具体工程落地动作]` 标注。

### 5.5 现场实景与图文排版配套建议 (Visual & Field Anchors)
每幅生成图（无论来自 MCP、Mermaid 还是 VChart-SVG）下均应配套：
1. **制表与审核落款**：`制表人：XXX  审核人：XXX  时间：YYYY.MM.DD`。
2. **现场实景图片建议位**：提示现场拍摄或设备原理配图位置（例如：`[现场图片建议：拍摄改进前故障位点 / 传感器安装角度与现场粉尘工况实照]`）。
3. **≥150 字解读段落**：阐明图中数据变化特征、关键异常拐点或结构闭环与本章结论的对应关系。

---

## 6. QC 章节-图表对照速查

| QC 章节 | 推荐图表类型 | 优先/降级路由提示 |
|:---|:---|:---|
| 第 1 章 小组概况 | 成员学历/职称分布饼图；活动计划预览 | MCP 优先；降级 VChart-SVG / Mermaid `pie` |
| 第 2 章 选择课题 | 头脑风暴归纳；背景现状趋势 | MCP 优先；降级 Mermaid / VChart-SVG `bar/line` |
| 第 3 章 现状调查 | 柏拉图问题排名；直方图分布；趋势对比 | MCP 优先；降级 VChart-SVG (`pareto`/`histogram`) |
| 第 4 章 设定目标与原因分析 | 5M1E 鱼骨图；复杂关联图；要因确认对比 | MCP 优先；降级 VChart-SVG 鱼骨或 Mermaid 关联图 + ΔP 矩阵 |
| 第 5 章 制定活动计划 | PDCA 活动计划甘特图；关键路径图 | MCP 优先；降级 Mermaid `gantt` |
| 第 6 章 提出并确定最佳方案 | 级联方案树；物理/L 型评分矩阵；多维雷达图 | MCP 优先；降级 Mermaid 方案树 + 矩阵表 + VChart-SVG `radar` |
| 第 7 章 制定对策 | 对策-要因映射矩阵；对策实施逻辑流程 | MCP 优先；降级 Mermaid `flowchart` + 5W1H 表 |
| 第 8 章 对策实施 | 系统架构/时序/状态机；风险预案 PDPC | MCP 优先；降级 Mermaid (`architecture`/`sequence`/`stateDiagram-v2`/`flowchart`) |
| 第 9 章 效果检查 | 实施前后对比柱状/折线图；SPC 控制图；雷达图 | MCP 优先；降级 VChart-SVG (`control`/`bar`/`radar`) |
| 第 10 章 巩固措施/标准化 | 标准化工作流程与闭环控制图 | MCP 优先；降级 Mermaid `flowchart` |
