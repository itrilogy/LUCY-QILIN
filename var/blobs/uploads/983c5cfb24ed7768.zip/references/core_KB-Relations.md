# QC 智能体集群级联依赖协议 (QC-Agent Relations Protocol)

## 1. 协议核心理念
各智能体不再是孤立的指令集，而是 QC 业务流程中的“职能部门”。上游输出必须满足下游的输入规范（参考 `references/qc_KB-QCMethod.md`），下游反馈必须通过 `PROJECT_INDEX.md` 同步。

## 2. 集群拓扑图 (Topology)

```mermaid
graph TD
    PM[qc-pm: 流程管控/总调度] --> DT[qc-detective: 现状数据/因果]
    PM --> IV[qc-inventor: 方案/对策]
    PM --> AN[qc-analyst: 指标/核算]
    PM --> SB[qc-scribe: 报告扩写]
    PM --> RV[qc-reviewer: 审稿修正]
    
    DT --> LG[qc-logician: 逻辑图表]
    DT --> ST[qc-statistician: 统计图表]
    
    IV --> LG
    IV --> PN[qc-planner: 流程图表]
    IV --> ST
    
    AN --> ST
    
    RV --> SB
    RV --> AN
    
    CD[qc-coder: 脚手架/代码] --> IX[qc-indexer: 档案索引]
    PM --> IX
    RV --> IX
```

## 3. 核心级联逻辑与交付物 (Handover)

### 3.1 PM -> 集群 (任务分解)
*   **输入**：包含 `[BOND: ...]` 锚点的素材碎片、课题类型。
*   **产出**：通过 `/qc-scaffold` 生成的物理目录与初始 `PROJECT_INDEX.md`。

### 3.2 Detective -> Inventor (痛点传递)
*   **交付物**：要因分析后的“真因清单”与“需求锚点”。
*   **规范**：每个真因必须对应一个 `[NEED: ...]` 标记，作为对策设计的输入。

### 3.3 Inventor/Analyst -> Charting Layers (制图指令)
*   **交付物**：符合 `references/qc_KB-ChartSpec.md` 的数据数组或逻辑结构。
*   **规范**：图表脚本（.md）必须放置在对应的章节目录下（如 `04_原因分析/`）。

### 3.4 Reviewer -> 集群 (质量回溯)
*   **交付物**：结构化审核报告。
*   **动作**：若某章节不合规，Reviewer 显式调用 `@qc-scribe` 或 `@qc-analyst` 重新生成，并由 `@qc-indexer` 更新版本。

## 4. 全局调度约束
1. **索引强制性**：所有产生物理文件变更的操作，末尾必须级联 `@qc-indexer update`。
2. **上下文隔离**：子任务执行时，优先读取该课题目录下的 `session_context.md`。
3. ** hallucin-free**：数据推演必须标注 `[DEDUCTION]`，禁止无据生成。
