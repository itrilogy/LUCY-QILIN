# QC 意向评审全量模板库

## 1. 单体评审报告模板 (Individual Review Template)

```markdown
# QC 课题意向申报深度审计报告 (Individual Audit)
**课题 ID**: {{project_id}} | **申报单位**: {{unit}}
**审计专家**: {{expert_signature}}

---

## Ⅰ. 课题客观概况描述 (Objective Summary)
> **专家视角**: {{objective_summary}}

---

## Ⅱ. 加权评分矩阵 (Weighted Scoring Matrix)
| 维度 | 得分 | 程度标记 | 简要评价 |
| :--- | :--- | :--- | :--- |
| **COMP** | {{score_comp}} | [{{degree_comp}}] | {{comment_comp}} |
| **TECH** | {{score_tech}} | [{{degree_tech}}] | {{comment_tech}} |
| **CAPA** | {{score_capa}} | [{{degree_capa}}] | {{comment_capa}} |
| **GOVN** | {{score_govn}} | [{{degree_govn}}] | {{comment_govn}} |
| **UTIL** | {{score_util}} | [{{degree_util}}] | {{comment_util}} |
| **加权总分** | **{{total_score}}** | **Grade {{grade}}** | —— |

---

## Ⅲ. 法典拦截：合规性判定 (Rule vs. Fact)
### 1. 程序与路由 (G-Series)
- **[G04] 路由准确性**: {{status_g04}} | **[IN01] 伪创新拦截**: {{status_in01}}

### 2. 命名与理由 (S-Series)
- **[S02] 课题名称量化**: {{status_s02}} | **专家修订建议**: {{name_revised}}
- **[S05] 理由数据化**: {{status_s05}} | **[S06] 阶段对齐**: {{status_s06}}

### 3. 目标与创新 (M/D/IN-Series)
- **[M02] 目标可测量性**: {{status_m02}} | **[IN04] 借鉴查新**: {{status_in04}}

---

## Ⅳ. TRIZ 专项诊断与创新指引 (TRIZ Consulting)
- **技术矛盾识别**: {{triz_contradiction}}
- **建议应用原理**: {{triz_principles}}
- **资源分析 (IFR)**: {{triz_ifr}}

---

## Ⅴ. 专家“逻辑代偿”与挖掘 (Expert Insight)
> {{potential_mining}}

---

## Ⅵ. 最终结论与行动清单 (Action Plan)
- **结论评价**: {{conclusion_comment}}
- **必办事项清单**:
  1. [ ] {{step_1}}
  2. [ ] {{step_2}}
```

---

## 2. 课题合并建议报告模板 (Consolidation Audit Template)

```markdown
# QC 课题合并与协同攻关审计报告
**审计负责人**: {{expert_signature}}

---

### 1. 总体合并策略概要 (Executive Summary)
> 本批次共识别出 {{total_clusters}} 组高价值合并集群。

---

### 2. 课题合并建议清单 (Detailed Proposals)

### 【合并集群编号】：{{cluster_id}} — {{cluster_name}}
#### 2.1 涉及课题明细
- {{project_list}}

#### 2.2 审计对消分析 (Homogeneity Audit)
- **业务场景重叠度**: {{overlap_perc}}%
- **技术栈一致性**: {{tech_consistency}}

#### 2.3 建议合并路径 (Synergy Path)
- {{synergy_path_options}}

#### 2.4 专家点评
> “{{expert_merger_advice}}”

---
**审计人**: {{expert_signature}}
```

---

## 3. 年度管理诊断报告模板 (Management Report Template)

```markdown
# {{org_name}} QC 意向申报年度管理诊断报告
**首席诊断人**: {{expert_signature}}

---

## Ⅰ. 申报大盘全景透视 (Enterprise Landscape Analysis)
- **申报总数**: {{total_count}} 份
- **分布画像**: [改进型: {{count_imp}} | 创新型: {{count_inn}}]
- **质量评级**: [A: {{count_a}} | B: {{count_b}} | D: {{count_d}}]

---

## Ⅱ. 年度企业共性问题全景清单 (Annual Problem Inventory)
### 2.1 流程管理类“肠梗阻”
- {{prob_flow_list}}

### 2.2 数字化转型中的“贫血”现象
- {{prob_digital_list}}

---

## Ⅲ. 企业 QC 管理成熟度诊断 (Maturity Diagnosis)
- **雷达图定级**: {{maturity_level}}
- **专家评述**: {{maturity_expert_comment}}

---

## Ⅳ. 决策支持：风险与价值象限 (Decision Support Matrix)
{{decision_matrix_table}}

---
**最终结论**: {{final_grand_conclusion}}
```
