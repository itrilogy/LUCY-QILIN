---
name: tech-project-manager
version: 3.2.0
description: 科技项目全生命周期智能管理系统。涵盖 Stage I 立项诊断评审、Stage II 异构材料拆解与 ATT01-ATT16 全套文档生产、Stage III 结题验收三引擎审计与跨课题增量池聚类聚合。支持四类项目路由、可配置企业管理规范插槽与专家署名。
category: tech-project-manager
---

[TAG: TECH_MASTER_ORCHESTRATOR]

# 科技项目全生命周期智能编排系统
本系统是科技项目管理与档案生成的集成化解决方案。通过多 Agent 协作管线，实现从"意向申报"到"结题验收"的全生命周期资产沉淀与文档自动化。

## ⚙️ 全局可配置插槽 (`00_Meta_Config/config.yaml`)
- `lead_unit`: 所属/牵头企业单位（默认预设：`上饶市烟草专卖局（公司）`，支持通过 `--lead-unit` 或 `config.yaml` 配置为其他单位）
- `expert_signature`: 诊断与审计专家署名（默认：`科技项目诊断与审计专家`，支持通过 `--expert-name` 或 `config.yaml` 自定义署名）
- `industry_rule_slot`: 企业科技项目管理办法插槽（默认加载 `shangrao_tobacco_1234`，即《江西省烟草公司上饶市公司科技计划项目管理办法》与“1234/五缺五低”战略基座，允许按需扩展或切换企业规则）

## 0. 项目类型路由 (Type Routing)

默认依据企业科技计划项目管理办法（默认插槽：《江西省烟草公司上饶市公司科技计划项目管理办法》第三条），项目分为四类。各 Agent 启动时必须读取 `[PROJECT_TYPE]` 分支执行：

| 类型 | 产出特征 | enricher 策略 | 特殊 ATT 要求 |
|:---|:---|:---|:---|
| **应用基础研究** | 论文、著作、原理性模型、发明专利 | 深度逆向解析 + 算法还原 + 图表渲染 | ATT12 偏理论推导 |
| **应用技术开发** | 可运行系统、技术方案、专利/软著 | 代码栈扫描 + 架构提取 + 工程指标统计 | ATT12 偏架构实现 |
| **成果推广** | 推广报告、效益证明、应用覆盖率 | 效益数据提取 + 推广前后对比 + ROI 核算 | ATT13 核心产出，ATT12 可选 |
| **软科学研究** | 企业标准、研究报告、政策建议 | 流程关键节点提取 + 逻辑闭环验证 | ATT12 以标准/报告替代 |

另设两种特殊通道：**揭榜挂帅项目**、**青年科技人才项目**。

各 Agent 的「必须提前阅读」列表中标注 `[TYPE: ALL]` / `[TYPE: 应用技术开发]` 标记，不匹配则跳过并在进度总账中注明「不适用」。`init_global_scaffold.py` 入参增加 `--project-type`，根据类型条件创建目录。

## 1. 核心参考文件 (Single Source of Truth)

| 文件路径 | 职责/属性 | 引用方式 |
|:---|:---|:---|
| `references/tech_audit_master_rules.md` | 【法典】评审权重、1234体系、五缺五低 | 必读 |
| `references/tech-auditor.md` | 【Agent】成果审计专家 — Stage III 三引擎审计执行者 | 必读 |
| `references/tech_KB-AuditRules.md` | 【法典】结题验收评奖评审 — 三引擎+7维度 | 必读 |
| `references/tech_KB-TRIZ.md` | 【方法】TRIZ 创新方法论 (含科技项目延伸) | 必读 |
| `references/tech-intent-diagnostician.md` | 【Agent】立项诊断专家 (含逻辑代偿与 TRIZ) | 必读 |
| `references/tech-material-extractor.md` | 【Agent】材料解构专家 (智能切片与标签) | 必读 |
| `references/tech-manifest-arbitrator.md` | 【Agent】材料仲裁专家 (P0/P1 冲突仲裁与大纲生成) | 必读 |
| `references/tech-enricher.md` | 【Agent】工程增强专家 (底层逻辑解析与 MCP/Mermaid/VChart-SVG 图表渲染) | 必读 |
| `references/tech-document-assembler.md` | 【Agent】文档组装专家 (Map-Reduce 组装) | 必读 |
| `references/tech-polish-expert.md` | 【Agent】文档精加工师 (公文化与字数达标) | 必读 |
| `references/tech-document-writer-bp.md` | 【机制】物理写入保障 (防止目录漂移) | 必读 |
| `references/tech_KB-ATT-Rules.md` | 【规则】ATT 编号复用与置信度矩阵 | 必读 |
| `references/tech_KB-WritingParadigms.md` | 【范式】ATT01-ATT16 写作结构与字数约束（唯一字数权威） | 必读 |
| `references/tech_KB-ResearchAssets.md` | 【法典】引用优先级(P0/P1/P2)与资产沉淀范式 | 必读 |
| `references/tech_KB-NumberingSystem.md` | 【规则】ATT 编号全量定义 (9 个附件) | 必读 |
| `references/tech_KB-ReuseMatrix.md` | 【规则】ATT 间内容置信度评价矩阵 | 必读 |
| `references/tech_KB-ChartSpec.md` | 【规范】科技项目图表选型与渲染规范（MCP 优先 + Mermaid / VChart-SVG） | 按需查阅 |
| `references/tech_KB-ScriptTemplates.md` | 【骨架】图表资产骨架与降级模板库 | 按需查阅 |
| `references/tech_document_paradigms.md` | 【标准】ATT01/ATT03 文档范式结构 | 必读 |
| `references/unified_file_handling_protocol.md` | 【协议】统一文件处理规范（异构降维提取、安全追加、版本保护、图表渲染兜底） | 必读 |
| `references/render-protocols/render_routing_index.md` | 【路由】图表渲染路由与双引擎降级索引 | 按需查阅 |
| `references/tech_prompt_ATT01.md` | 【Prompt】ATT01 创新课题研究意向书写作模板 | 按需查阅 |
| `references/tech_prompt_ATT03.md` | 【Prompt】ATT03 科技计划项目申报书写作模板 | 按需查阅 |
| `references/tech_prompt_ATT06.md` | 【Prompt】ATT06 科技计划项目任务书写作模板 | 按需查阅 |
| `references/tech_prompt_ATT09.md` | 【Prompt】ATT09 项目任务书执行情况年报写作模板 | 按需查阅 |
| `references/tech_prompt_ATT10.md` | 【Prompt】ATT10 科技计划项目结题申请书写作模板 | 按需查阅 |
| `references/tech_prompt_ATT11.md` | 【Prompt】ATT11 项目工作报告写作模板 | 按需查阅 |
| `references/tech_prompt_ATT12.md` | 【Prompt】ATT12 项目技术报告写作模板 | 按需查阅 |
| `references/tech_prompt_ATT13.md` | 【Prompt】ATT13 经济和社会效益分析报告写作模板 | 按需查阅 |
| `references/tech_prompt_ATT16.md` | 【Prompt】ATT16 查新报告写作模板 | 按需查阅 |
| `references/tech_template_manifest.md` | 【模板】素材总清单与 Labeled Outline | 按需查阅 |
| `references/tech_template_review.md` | 【模板】个体诊断报告 | 按需查阅 |
| `references/tech_template_inquiry.md` | 【模板】专家质询单 | 按需查阅 |
| `references/tech_template_consolidation.md` | 【模板】合并审计建议 | 按需查阅 |
| `references/tech_template_management_summary.md` | 【模板】全景总结报告 | 按需查阅 |
| `references/tech_template_enterprise_diagnosis.md` | 【模板】企业现状诊断 | 按需查阅 |
| `references/tech_template_reuse_tracking.md` | 【模板】复用追踪日志 | 按需查阅 |
| `references/tech_template_polish_log.md` | 【模板】润色扩写日志 | 按需查阅 |
| `references/tech_template_enterprise_improvement.md` | 【模板】企业整体改善诊断报告 (Stage III 终态报告一) | 按需查阅 |
| `references/tech_template_quality_diagnosis.md` | 【模板】科技项目质量诊断报告 (Stage III 终态报告二) | 按需查阅 |
| `references/tech_template_recommend_list.md` | 【模板】可推广成果推荐清单 (Stage III 终态报告三) | 按需查阅 |

## 2. 自动化物理脚本 (Automated Execution Engines)

| 脚本路径 | 核心效用 |
| :--- | :--- |
| `scripts/init_global_scaffold.py` | 环境一键部署 (支持 `--project-name` `--project-type`) |
| `scripts/shallow_profiler.py` | 资产初筛探针 |
| `scripts/semantic_chunker.py` | 高保真语义切分引擎 |
| `scripts/asset_manager.py` | 资产池增量同步工具 |
| `scripts/extract_pdf.py` | 统一异构文档格式降维提取引擎（支持 `.txt/.md/.csv/.docx/.xlsx/.pdf`，零第三方强依赖） |
| `scripts/consolidation_engine.py` | 跨课题聚类分析+增量池聚合 |
| `scripts/main_engine.py` | 任务主调度与进度总账 |
| `scripts/doc_append_helper.py` | 统一长文档与增量池安全追加器 |

---

## 3. 宏观运行时模式 (Macro State Machine)

> **Agent 文件名映射**: Extractor=`tech-material-extractor.md` | Arbitrator=`tech-manifest-arbitrator.md` | Enricher=`tech-enricher.md` | Assembler=`tech-document-assembler.md` | Polish=`tech-polish-expert.md` | Diagnostician=`tech-intent-diagnostician.md` | Auditor=`tech-auditor.md`

- **`--init`**: 执行 `scripts/init_global_scaffold.py --source-dir [路径] --project-name [名称] --project-type [类型]`
- **`--run-review`** (触发词: `立项诊断` / `申报评审`): 路由 `01_Intent_Review`，唤醒 `tech-intent-diagnostician`
- **`--run-build`** (触发词: `文档生产` / `档案组装`): 路由 `03_Documentation_Build`，串行唤醒 Extractor→Arbitrator→Enricher→Assembler→Polish
- **`--run-audit`** (触发词: `验收审计` / `结题评审`): 路由 `04_Audit_Review`，唤醒 `tech-auditor`，对 Stage II 产出的 ATT 文档执行三引擎审计
- **聚合触发** (触发词: `汇总诊断结果` / `汇总审计结果` / `生成战略报告`): 调用 `scripts/consolidation_engine.py` 对增量池做轻量聚合，产出终态报告

---

## 4. 全生命周期大一统物理脚手架 (Unified Scaffold)

> **架构对标**: 参照 qc-antigravity `03_末端评审阶段/` 的 08~13 六子模块设计。tech-antigravity 以 `04_Audit_Review/` 承载 Stage III。

```text
${Project_Workspace}/
├── 00_Meta_Config/                          # ⚙️ 全局总控
│
├── 01_Intent_Review/                        # 🔍 【Stage I】立项评审
│   ├── 01_Raw_Proposals/[项目名]/           #    📥 申报书入口
│   ├── 02_PreAudit_Inquiries/               #    📝 专家质询单
│   ├── 03_Diagnostic_Reviews/               #    📊 立项诊断建议书
│   └── 04_Strategic_Reports/                #    📈 跨课题聚类与对冲审计
│
├── 02_Research_Assets/                      # 🧠 全局资产沉淀池
│
├── 03_Documentation_Build/                  # 🏭 【Stage II】档案生产
│   ├── assets/                              #    📦 共享素材仓
│   └── [项目名]/ATT01~ATT16/               #    📁 按项目隔离的 ATT 产出
│
└── 04_Audit_Review/                         # 🔎 【Stage III】成果审计 (对标 qc 03_末端评审阶段)
    ├── 08_单体审计报告/                      #    对应 qc:08_
    ├── 09_问题增量池/                        #    对应 qc:09_ — 逐条追加
    │   ├── 规则维度_问题池.md
    │   └── 课题维度_问题池.md
    ├── 10_收益增量池/                        #    对应 qc:10_ — 逐条追加
    │   ├── 业务领域_收益池.md
    │   └── 课题维度_收益池.md
    ├── 11_企业整体改善诊断报告/              #    对应 qc:11_ — 收益池→短板→选题方向
    ├── 12_科技项目质量诊断报告/              #    对应 qc:12_ — TOP10缺陷+方法论成熟度+培训建议
    ├── 13_可推广成果推荐清单/                #    对应 qc:13_ — 一等+高ROI+跨领域适用
    ├── AUDIT_LOG.md                         #    📓 审计流水账
    └── AUDIT_PROGRESS.md                    #    📊 审计进度总账
```

### qc-lifecycle-manager ↔ tech-project-manager Stage III 对照

| qc (`03_末端评审阶段/`) | tech (`04_Audit_Review/`) | 适配说明 |
|:---|:---|:---|
| `08_深度审计报告/` | `08_单体审计报告/` | 审计对象: QC报告书→科技项目ATT文档 |
| `09_问题增量池/` (规则+课题) | `09_问题增量池/` | **直接复用**，规则ID: G/S/C系列→A/B/C系列 |
| `10_收益增量池/` (领域+课题) | `10_收益增量池/` | **直接复用** |
| `11_企业整体改善诊断报告/` | `11_企业整体改善诊断报告/` | **直接复用** |
| `12_QC活动质量诊断报告/` | `12_科技项目质量诊断报告/` | 规则系列+ATT合规维度 |
| `13_可推广成果推荐清单/` | `13_可推广成果推荐清单/` | **直接复用** |
| `AUDIT_LOG.md` | `AUDIT_LOG.md` | **直接复用** |

---

## 5. 强制物理纪律 (Security & Integrity)

1. **路径锁定**: 所有操作必须先确认工作目录。
2. **绝对寻址**: 调用脚本必须使用 `${SKILL_ROOT}/scripts/<脚本名>.py`（如 `init_global_scaffold.py`、`extract_pdf.py`）绝对路径。
3. **单点寻址**: Agent 内部引用必须直接指向 `references/实际文件名.md`。
4. **置信度红线**: 跨附件复用必须标注 `⭐引用自 ATTxx`。

---

## 6. 自然语言触发暗号

| 暗号 | 路由模式 |
|:---|:---|
| `立项诊断` / `申报评审` | Stage I 立项评审 |
| `文档生产` / `档案组装` | Stage II 档案生产 |
| `验收审计` / `结题评审` | Stage III 成果审计 |
| `汇总诊断结果` / `汇总审计结果` / `生成战略报告` | 跨课题聚合 |

---
## 7. 平台适配与统一文件处理协议

本技能集群支持全平台运行（`platforms: ["any"]`），异构文档提取、安全追加与版本控制统一遵循 `references/unified_file_handling_protocol.md`。各客户端环境的调度映射详见 `platform/` 目录（`reasonix.md`、`deepseek-harness.md`、`gemini-cli.md`、`opencode-hermes.md`、`generic-cli.md`）。

---
**系统标识**: 科技项目全生命周期智能编排系统
