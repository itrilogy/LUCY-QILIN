#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
浅层快照探针 (Shallow Profiler - Stdlib Only)
抽取 Raw_Data 下各类异构文件 (.md/.txt/.csv/.docx/.xlsx/.pdf) 的头部预览片段，
避免大文件直接进入模型上下文导致溢出。
"""

import argparse
import json
import os
from pathlib import Path

try:
    from extract_pdf import extract as unified_extract
except ImportError:
    unified_extract = None


def get_file_head(file_path: str, max_chars: int = 1200) -> str:
    """读取各类文件的头部可读文本片段"""
    ext = Path(file_path).suffix.lower()

    if ext in {".md", ".txt", ".json", ".yaml", ".yml", ".py", ".ts", ".tsx", ".csv"}:
        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                return f.read(max_chars)
        except Exception as e:
            return f"[读取失败: {e}]"

    # 对 .docx / .xlsx / .pdf 调用统一标准库提取引擎进行浅层降维
    if ext in {".docx", ".xlsx", ".pdf"} and unified_extract is not None:
        try:
            extracted = unified_extract(file_path)
            return extracted[:max_chars]
        except Exception as e:
            return f"[提取失败: {e}]"

    try:
        with open(file_path, "rb") as f:
            raw_bytes = f.read(2000)
        ascii_text = "".join(chr(b) for b in raw_bytes if 32 <= b <= 126 or b in (9, 10, 13))
        return ascii_text[:max_chars] if ascii_text else "[二进制文件，请调用 extract_pdf.py 转换]"
    except Exception as e:
        return f"[二进制读取失败: {e}]"


def profile_raw_data(base_dir: str) -> dict:
    """遍历 Raw_Data 目录，生成快照信息字典"""
    if not os.path.exists(base_dir):
        return {"error": f"Raw_Data 目录不存在: {base_dir}"}

    snapshots = {}
    for root, dirs, files in os.walk(base_dir):
        dirs[:] = [d for d in sorted(dirs) if not d.startswith(".") and d not in {"node_modules", "__pycache__", "venv"}]
        for file in sorted(files):
            if file.startswith(".") or file == "Thumbs.db":
                continue

            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, base_dir)
            size_kb = round(os.path.getsize(full_path) / 1024, 2)
            head_content = get_file_head(full_path)

            snapshots[rel_path] = {
                "file_name": file,
                "size_kb": size_kb,
                "extension": Path(file).suffix.lower(),
                "head_snippet": head_content.strip()[:1000],
            }

    return snapshots


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="浅层快照探针：安全抽取异构素材头部片段，避免上下文溢出。")
    parser.add_argument("--raw-dir", default="03_Documentation_Build/assets/Raw_Data", help="原始数据目录路径")
    parser.add_argument("--output", default="00_Meta_Config/shallow_snapshot.json", help="输出的 JSON 快照文件路径")
    args = parser.parse_args()

    result = profile_raw_data(args.raw_dir)
    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"✅ 浅层快照探针执行完毕，共扫描 {len(result) if isinstance(result, dict) and 'error' not in result else 0} 个文件，已保存至: {args.output}")
