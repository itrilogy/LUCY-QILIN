import os
import re
import argparse
from pathlib import Path

def semantic_chunk_markdown(content, max_chars=800):
    """
    语义切分核心算法：
    1. 按 H2/H3 小标题切分
    2. 按独立段落切分
    3. 识别并保护表格与列表
    """
    # 预处理：保护表格
    # 简单的表格识别：以 | 开头的行
    lines = content.split('\n')
    chunks = []
    current_chunk = []
    in_table = False
    
    for line in lines:
        stripped = line.strip()
        
        # H2/H3 标题判定 (原则 1)
        is_header = re.match(r'^#{2,3}\s+', stripped)
        
        # 表格判定 (原则 3)
        is_table_row = stripped.startswith('|')
        
        if is_header:
            if current_chunk:
                chunks.append('\n'.join(current_chunk))
                current_chunk = []
            current_chunk.append(line)
            continue
            
        if is_table_row:
            if not in_table and current_chunk:
                # 进入表格前，如果当前块字数已经不少，先切分
                if len('\n'.join(current_chunk)) > 200:
                    chunks.append('\n'.join(current_chunk))
                    current_chunk = []
            in_table = True
            current_chunk.append(line)
            continue
        else:
            if in_table:
                # 表格结束，强制成片 (原则 3)
                chunks.append('\n'.join(current_chunk))
                current_chunk = []
                in_table = False
            
        current_chunk.append(line)
        
        # 长度控制 (原则 2)
        if len('\n'.join(current_chunk)) > max_chars:
            chunks.append('\n'.join(current_chunk))
            current_chunk = []
            
    if current_chunk:
        chunks.append('\n'.join(current_chunk))
        
    return [c.strip() for c in chunks if c.strip()]

def process_file(file_path, output_base, att_type="ATT01"):
    """
    处理单个文件的切片与落盘
    """
    print(f"🔪 正在切片文件: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
        
    # [图片路径绝对化保护机制]
    # 将形如 ![alt](./image.png) 或 ![alt](images/pic.jpg) 的相对路径转换为绝对路径
    # 忽略已经带有 http://, https://, file://, 或绝对路径 (以 / 开头) 的链接
    source_dir = os.path.dirname(os.path.abspath(file_path))
    
    def path_replacer(match):
        alt_text = match.group(1)
        img_path = match.group(2)
        if img_path.startswith(('http://', 'https://', 'file://', '/', 'data:')):
            return match.group(0) # 保持原样
        
        abs_img_path = os.path.normpath(os.path.join(source_dir, img_path))
        return f"![{alt_text}]({abs_img_path})"
        
    # 正则匹配 Markdown 图片语法: ![alt](url)
    md_image_pattern = re.compile(r'!\[([^\]]*)\]\(([^)]+)\)')
    content = md_image_pattern.sub(path_replacer, content)
        
    chunks = semantic_chunk_markdown(content)
    
    dest_dir = os.path.join(output_base, att_type)
    os.makedirs(dest_dir, exist_ok=True)
    
    file_stem = Path(file_path).stem
    
    saved_paths = []
    for i, chunk in enumerate(chunks):
        chunk_filename = f"{file_stem}_chunk_{i+1:03d}.md"
        chunk_path = os.path.join(dest_dir, chunk_filename)
        
        with open(chunk_path, 'w', encoding='utf-8') as f:
            f.write(chunk)
        saved_paths.append(chunk_path)
        
    print(f"✅ 完成切片，地产出 {len(saved_paths)} 个物理切片文件。")
    return saved_paths

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="语义切分引擎：执行高保真 Markdown/文本切片落盘")
    parser.add_argument("--file", required=True, help="待切片的源文件路径")
    parser.add_argument("--output-base", default="03_Documentation_Build/assets/Extracted/text", help="切片存储基准目录")
    parser.add_argument("--att", default="ATT01", help="归属的 ATT 编号")
    
    args = parser.parse_args()
    process_file(args.file, args.output_base, args.att)