import os
import shutil
import argparse
from pathlib import Path

def classify_and_copy_source(source_dir, raw_data_base):
    """
    全量无损搬运并按后缀物理分拣
    """
    if not os.path.exists(source_dir):
        print(f"⚠️ 源目录不存在或未提供: {source_dir}")
        return

    print(f"📥 开始全量导入并分拣素材: {source_dir} -> {raw_data_base}")
    count = 0
    for root, _, files in os.walk(source_dir):
        for file in files:
            if file.startswith('.') or file == 'Thumbs.db':
                continue
            
            src_file = os.path.join(root, file)
            ext = Path(file).suffix.lower()
            
            # 分流路由
            if ext == '.pdf':
                dest_dir = os.path.join(raw_data_base, "01_PDF")
            elif ext in ['.doc', '.docx']:
                dest_dir = os.path.join(raw_data_base, "02_Word")
            elif ext in ['.ppt', '.pptx']:
                dest_dir = os.path.join(raw_data_base, "03_PPT")
            elif ext in ['.xls', '.xlsx', '.csv']:
                dest_dir = os.path.join(raw_data_base, "04_Excel_CSV")
            elif ext in ['.md', '.txt', '.json', '.yaml', '.ts', '.tsx', '.py']:
                dest_dir = os.path.join(raw_data_base, "05_MD_and_Code")
            else:
                dest_dir = os.path.join(raw_data_base, "06_Others")
                
            # 防覆写与结构保真机制：保留源文件的相对层级目录树
            rel_path = os.path.relpath(src_file, source_dir)
            target_full_path = os.path.join(dest_dir, rel_path)
            
            os.makedirs(os.path.dirname(target_full_path), exist_ok=True)
            shutil.copy2(src_file, target_full_path)
            count += 1
            
    print(f"✅ 全量导入完成，共搬运 {count} 个物理文件。")

def init_global_scaffold(work_dir, source_dir=None, project_name=None, project_type=None, lead_unit="上饶市烟草专卖局（公司）", expert_signature="科技项目诊断与审计专家"):
    """
    work_dir: 科技项目大一统架构工作区基准路径
    project_name: 项目名称。Stage II 模式下必填，用于创建项目 ATT 子目录
    project_type: 项目类型（应用基础研究/应用技术开发/成果推广/软科学研究）
    lead_unit: 牵头/所属单位（可配置，默认企业预设）
    expert_signature: 评审/审计专家署名（可配置）
    """
    print(f"🚀 Tech-Project-Manager - 全生命周期脚手架初始化")
    print(f"📁 工作基准路径: {os.path.abspath(work_dir)}")
    if project_name:
        print(f"📋 项目名称: {project_name}")
    if project_type:
        print(f"🏷️  项目类型: {project_type}")
    print()

    # 1. 00_Meta_Config - 全局总控与状态账本
    meta_dir = os.path.join(work_dir, "00_Meta_Config")
    os.makedirs(meta_dir, exist_ok=True)
    
    config_path = os.path.join(meta_dir, "config.yaml")
    if not os.path.exists(config_path):
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write("# 科技项目全局元数据配置（含可配置企业规范插槽与专家署名）\n")
            f.write("# 多项目并发时：project_name 为当前会话项目，切换项目时可更新此字段\n")
            f.write("project_number: \"待分配\"\n")
            f.write(f"project_name: \"{project_name if project_name else '待分配'}\"\n")
            f.write(f"project_type: \"{project_type if project_type else '待分配'}\"\n")
            f.write(f"lead_unit: \"{lead_unit}\"\n")
            f.write(f"expert_signature: \"{expert_signature}\"\n")
            f.write("industry_rule_slot: \"shangrao_tobacco_1234\"\n")
            f.write("year: \"2026\"\n")
    
    progress_path = os.path.join(meta_dir, "REVIEW_PROGRESS.md")
    if not os.path.exists(progress_path):
        with open(progress_path, 'w', encoding='utf-8') as f:
            f.write("# 科技项目立项评审进度总账\n\n")
            f.write("| 序号 | 申报单位 | 课题名称 | Phase 1-2 (质询与融合) | Phase 3 (评分) | Phase 4-5 (资产与汇编) | 状态 |\n")
            f.write("| :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n")
            
    manifest_path = os.path.join(meta_dir, "MANIFEST_ASSETS.md")
    if not os.path.exists(manifest_path):
        with open(manifest_path, 'w', encoding='utf-8') as f:
            f.write("# 文档组装期的切片与冲突仲裁总账\n\n")

    # 2. 01_Intent_Review - 立项评审工作区
    intent_dir = os.path.join(work_dir, "01_Intent_Review")
    intent_subdirs = [
        "01_Raw_Proposals",
        "02_PreAudit_Inquiries",
        "03_Diagnostic_Reviews",
        "04_Strategic_Reports"
    ]
    for sub in intent_subdirs:
        os.makedirs(os.path.join(intent_dir, sub), exist_ok=True)

    # 3. 02_Research_Assets - 全局资产沉淀池
    assets_dir = os.path.join(work_dir, "02_Research_Assets")
    os.makedirs(assets_dir, exist_ok=True)
    pool_files = ["01_企业真问题池.md", "02_核心技术方法池.md", "03_专业术语定义库.md", "04_命名修订范式库.md"]
    for pf in pool_files:
        p_path = os.path.join(assets_dir, pf)
        if not os.path.exists(p_path):
            with open(p_path, 'w', encoding='utf-8') as f:
                f.write(f"# {pf.replace('.md', '')}\n\n")

    # 4. 04_Audit_Review - Stage III 成果审计工作区
    audit_dir = os.path.join(work_dir, "04_Audit_Review")
    for sd in ["08_单体审计报告", "09_问题增量池", "10_收益增量池",
               "11_企业整体改善诊断报告", "12_科技项目质量诊断报告", "13_可推广成果推荐清单"]:
        os.makedirs(os.path.join(audit_dir, sd), exist_ok=True)
    log_path = os.path.join(audit_dir, "AUDIT_LOG.md")
    if not os.path.exists(log_path):
        with open(log_path, 'w', encoding='utf-8') as f:
            f.write("# 科技项目成果审计流水账 (AUDIT_LOG)\n\n| 时间 | 审计对象 | 结论 | 关键缺陷 |\n| :--- | :--- | :--- | :--- |\n")
    # 审计进度总账
    prog_path = os.path.join(audit_dir, "AUDIT_PROGRESS.md")
    if not os.path.exists(prog_path):
        with open(prog_path, 'w', encoding='utf-8') as f:
            f.write("# 科技项目成果审计进度总账\n\n| 序号 | 项目名称 | 审计状态 | 总分 | 等级 | 审计日期 |\n| :--- | :--- | :--- | :---: | :---: | :--- |\n")
    for pf, header in {
        "09_问题增量池/规则维度_问题池.md": "# 评审问题池 — 规则维度\n\n> 单体审计完成时逐条追加。禁止事后批量导入。\n\n| 规则ID(标签) | 课题名称 | 级别 | 描述 |\n| :--- | :--- | :--- | :--- |\n",
        "09_问题增量池/课题维度_问题池.md": "# 评审问题池 — 课题维度\n\n| 课题名称 | CRITICAL数 | WARNING数 | 关键缺陷摘要 |\n| :--- | :---: | :---: | :--- |\n",
        "10_收益增量池/业务领域_收益池.md": "# 收益池 — 业务领域维度\n\n| 课题名称 | 所属业务领域 | 解决的业务问题 | 改善幅度 | 经济效益 | 社会效益 |\n| :--- | :--- | :--- | :--- | :--- | :--- |\n",
        "10_收益增量池/课题维度_收益池.md": "# 收益池 — 课题维度\n\n| 课题名称 | 目标达成率 | ROI | 成果等级 | 推广建议 |\n| :--- | :---: | :---: | :--- | :--- |\n",
    }.items():
        pp = os.path.join(audit_dir, pf)
        if not os.path.exists(pp):
            with open(pp, 'w', encoding='utf-8') as f:
                f.write(header)
    print(f"✅ Stage III 审计工作区已创建: {audit_dir}/")

    # 5. 03_Documentation_Build - ATT 档案组装与生产区
    build_dir = os.path.join(work_dir, "03_Documentation_Build")

    # 细化 assets 子目录结构
    raw_data_base = os.path.join(build_dir, "assets/Raw_Data")
    build_assets = [
        "assets/Raw_Data/01_PDF",
        "assets/Raw_Data/02_Word",
        "assets/Raw_Data/03_PPT",
        "assets/Raw_Data/04_Excel_CSV",
        "assets/Raw_Data/05_MD_and_Code",
        "assets/Raw_Data/06_Others",
        "assets/Extracted/text", 
        "assets/Extracted/tables", 
        "assets/Images_Charts", 
        "assets/Charts",
        "assets/Code_Snippets",
        "assets/Tagged/high_priority",
        "assets/Tagged/medium_priority",
        "assets/Tagged/low_priority",
        "assets/Index"
    ]
    for ba in build_assets:
        os.makedirs(os.path.join(build_dir, ba), exist_ok=True)
        
    # 初始化空的 Index 索引账本 (Markdown 格式以增强大模型读写容错性)
    with open(os.path.join(build_dir, "assets/Index/search_index.md"), 'w', encoding='utf-8') as f:
        f.write("# 📑 科技项目素材切片检索索引 (Search Index)\n\n")
        f.write("| 切片 ID | 物理路径 | 标签库 | 内容摘要 |\n")
        f.write("| :--- | :--- | :--- | :--- |\n")
        
    # 执行物理搬运
    if source_dir:
        classify_and_copy_source(source_dir, raw_data_base)
        
    atts = ["ATT01_创新课题研究意向书", "ATT03_科技计划项目申报书", "ATT06_科技计划项目任务书", 
            "ATT09_项目任务书执行情况年报", "ATT10_科技计划项目结题申请书", "ATT11_项目工作报告", 
            "ATT12_项目技术报告", "ATT13_经济和社会效益分析报告", "ATT16_查新报告"]
    
    if project_name:
        # Stage II 模式：按项目隔离 ATT 目录
        project_build_dir = os.path.join(build_dir, project_name)
        for att in atts:
            att_dir = os.path.join(project_build_dir, att)
            os.makedirs(att_dir, exist_ok=True)
        print(f"✅ 项目 ATT 目录已创建: {project_build_dir}/")
    else:
        # 兼容模式：ATT 目录直接在 build_dir 下（向后兼容）
        for att in atts:
            att_dir = os.path.join(build_dir, att)
            os.makedirs(att_dir, exist_ok=True)

    print("✅ 大一统物理目录初始化完毕。系统随时可接受 --run-review / --run-build / --run-audit 指令介入。")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="初始化科技项目架构 ")
    parser.add_argument("--work-dir", default=".", help="目标工作区路径")
    parser.add_argument("--source-dir", default=None, help="原始素材的物理来源目录")
    parser.add_argument("--project-name", default=None, help="项目名称（Stage II 必填，创建项目 ATT 子目录）")
    parser.add_argument("--project-type", default=None, 
                        choices=["应用基础研究", "应用技术开发", "成果推广", "软科学研究"],
                        help="项目类型（用于条件创建目录）")
    parser.add_argument("--lead-unit", default="上饶市烟草专卖局（公司）", help="所属/牵头企业单位名称（可配置）")
    parser.add_argument("--expert-name", default="科技项目诊断与审计专家", help="评审/审计专家署名（可配置）")
    args = parser.parse_args()
    
    init_global_scaffold(args.work_dir, args.source_dir, args.project_name, args.project_type, args.lead_unit, args.expert_name)