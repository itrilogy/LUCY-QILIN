#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tech-Project-Manager 任务主调度与全生命周期状态检查引擎 (main_engine.py)
"""

import argparse
import os


class TechEngine:
    def __init__(self, workdir: str = "."):
        self.workdir = os.path.abspath(workdir)
        self.meta_dir = os.path.join(self.workdir, "00_Meta_Config")
        self.raw_dir = os.path.join(self.workdir, "01_Intent_Review", "01_Raw_Proposals")
        self.review_dir = os.path.join(self.workdir, "01_Intent_Review", "03_Diagnostic_Reviews")
        self.build_dir = os.path.join(self.workdir, "03_Documentation_Build")
        self.audit_dir = os.path.join(self.workdir, "04_Audit_Review", "08_单体审计报告")
        self.progress_log = os.path.join(self.meta_dir, "REVIEW_PROGRESS.md")

    def get_status(self) -> dict:
        # Stage I 状态
        all_folders = []
        if os.path.exists(self.raw_dir):
            all_folders = sorted(
                d for d in os.listdir(self.raw_dir) if os.path.isdir(os.path.join(self.raw_dir, d))
            )
        reviewed = set()
        if os.path.exists(self.review_dir):
            for f in os.listdir(self.review_dir):
                if f.endswith(".md"):
                    reviewed.add(f.replace("_评审报告.md", "").replace("_诊断建议书.md", ""))
        pending_intent = [f for f in all_folders if f not in reviewed]

        # Stage II 状态
        build_projects = []
        if os.path.exists(self.build_dir):
            build_projects = sorted(
                d for d in os.listdir(self.build_dir)
                if os.path.isdir(os.path.join(self.build_dir, d)) and d != "assets"
            )

        # Stage III 状态
        audited = []
        if os.path.exists(self.audit_dir):
            audited = sorted(f for f in os.listdir(self.audit_dir) if f.endswith(".md"))

        return {
            "stage1_total": len(all_folders),
            "stage1_processed": len(reviewed),
            "stage1_pending": pending_intent,
            "stage2_projects": build_projects,
            "stage3_audited_count": len(audited),
        }

    def update_progress(self, project_name: str, phase: str, status: str = "✅ 完成"):
        os.makedirs(self.meta_dir, exist_ok=True)
        if not os.path.exists(self.progress_log):
            with open(self.progress_log, "w", encoding="utf-8") as f:
                f.write("# 科技项目立项评审进度总账\n\n")
                f.write("| 序号 | 申报单位 | 课题名称 | Phase 1-2 (质询与融合) | Phase 3 (评分) | Phase 4-5 (资产与汇编) | 状态 |\n")
                f.write("| :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n")
        with open(self.progress_log, "a", encoding="utf-8") as f:
            p12 = status if "Phase 1" in phase or "Phase 2" in phase else "-"
            p3 = status if "Phase 3" in phase else "-"
            p45 = status if "Phase 4" in phase or "Phase 5" in phase else "-"
            f.write(f"| - | - | {project_name} | {p12} | {p3} | {p45} | {status} |\n")
        print(f"✅ 进度总账已更新: {project_name} - {phase} - {status}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="科技项目全生命周期状态检查与进度总账工具")
    parser.add_argument("--work-dir", default=".", help="项目工作区根目录")
    args = parser.parse_args()

    engine = TechEngine(args.work_dir)
    st = engine.get_status()
    print(f"Stage I 意向评审进度: {st['stage1_processed']}/{st['stage1_total']}")
    if st["stage1_pending"]:
        print(f"  待评审课题: {', '.join(st['stage1_pending'])}")
    print(f"Stage II 档案生产项目: {len(st['stage2_projects'])} 个 ({', '.join(st['stage2_projects']) if st['stage2_projects'] else '无'})")
    print(f"Stage III 已审计报告: {st['stage3_audited_count']} 份")
