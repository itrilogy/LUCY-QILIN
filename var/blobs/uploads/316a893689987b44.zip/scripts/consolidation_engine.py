#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tech-Project-Manager 跨课题聚类与增量池轻量聚合引擎 (consolidation_engine.py)
支持 Stage I (02_Research_Assets) 与 Stage III (04_Audit_Review/09~10) 聚合统计。
"""

import argparse
from collections import Counter
from datetime import datetime
import os


class TechConsolidationEngine:
    def __init__(self, workdir: str = "."):
        self.workdir = os.path.abspath(workdir)
        self.assets_dir = os.path.join(self.workdir, "02_Research_Assets")
        self.intent_report_dir = os.path.join(self.workdir, "01_Intent_Review", "04_Strategic_Reports")
        self.audit_dir = os.path.join(self.workdir, "04_Audit_Review")

    def read_pool_table_rows(self, pool_path: str) -> list:
        """读取 Markdown 表格格式的增量池文件，返回非表头数据行"""
        if not os.path.exists(pool_path):
            return []
        rows = []
        with open(pool_path, "r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if stripped.startswith("|") and "---" not in stripped and "规则ID" not in stripped and "课题名称" not in stripped:
                    cols = [c.strip() for c in stripped.split("|")[1:-1]]
                    if cols and any(cols):
                        rows.append(cols)
        return rows

    def count_bullet_entries(self, md_path: str) -> int:
        """统计 Stage I 资产池条目数量"""
        if not os.path.exists(md_path):
            return 0
        cnt = 0
        with open(md_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.lstrip().startswith("- **["):
                    cnt += 1
        return cnt

    def aggregate_intent_assets(self) -> str:
        """Stage I 资产池轻量汇总"""
        os.makedirs(self.intent_report_dir, exist_ok=True)
        pools = {
            "企业真问题池": "01_企业真问题池.md",
            "核心技术方法池": "02_核心技术方法池.md",
            "专业术语定义库": "03_专业术语定义库.md",
            "命名修订范式库": "04_命名修订范式库.md",
        }
        lines = [
            "# 立项评审资产池聚合摘要",
            f"- **生成日期**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "",
            "| 资产池 | 累计条目数 | 物理路径 |",
            "|:---|:---:|:---|",
        ]
        for label, fname in pools.items():
            fpath = os.path.join(self.assets_dir, fname)
            cnt = self.count_bullet_entries(fpath)
            lines.append(f"| {label} | {cnt} | `02_Research_Assets/{fname}` |")

        out_path = os.path.join(self.intent_report_dir, "intent_assets_summary.md")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print(f"✅ Stage I 资产池聚合摘要: {out_path}")
        return out_path

    def generate_consolidation_report(self) -> str:
        """Stage III 轻量聚合：读取规则/课题问题池与领域/课题收益池"""
        os.makedirs(self.audit_dir, exist_ok=True)

        rule_issues = self.read_pool_table_rows(os.path.join(self.audit_dir, "09_问题增量池", "规则维度_问题池.md"))
        topic_issues = self.read_pool_table_rows(os.path.join(self.audit_dir, "09_问题增量池", "课题维度_问题池.md"))
        domain_benefits = self.read_pool_table_rows(os.path.join(self.audit_dir, "10_收益增量池", "业务领域_收益池.md"))
        topic_benefits = self.read_pool_table_rows(os.path.join(self.audit_dir, "10_收益增量池", "课题维度_收益池.md"))

        issue_counter = Counter(row[0] for row in rule_issues if row and row[0])
        domain_counter = Counter(row[1] for row in domain_benefits if len(row) >= 2 and row[1])
        grade_counter = Counter(row[3] for row in topic_benefits if len(row) >= 4 and row[3])

        report = [
            "# 跨课题聚类与增量池聚合统计报告",
            f"- **审计日期**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"- **已记录缺陷条目**: {len(rule_issues)} 条（涉及课题记录 {len(topic_issues)} 份）",
            f"- **已记录收益课题**: {len(topic_benefits)} 项",
            "",
            "## Ⅰ. 高频缺陷 TOP 10 (来自 09_问题增量池)",
        ]
        if issue_counter:
            report.extend(["| 规则ID | 命中次数 |", "| :--- | :---: |"])
            for rule_id, count in issue_counter.most_common(10):
                report.append(f"| {rule_id} | {count} |")
        else:
            report.append("*(问题增量池暂无记录)*")

        report.extend(["", "## Ⅱ. 业务领域收益分布 (来自 10_收益增量池)"])
        if domain_counter:
            report.extend(["| 业务领域 | 涉及课题数 |", "| :--- | :---: |"])
            for domain, count in domain_counter.most_common():
                report.append(f"| {domain} | {count} |")
        else:
            report.append("*(收益增量池暂无记录)*")

        report.extend(["", "## Ⅲ. 成果等级分布"])
        if grade_counter:
            report.extend(["| 成果等级 | 课题数量 |", "| :--- | :---: |"])
            for grade, count in grade_counter.most_common():
                report.append(f"| {grade} | {count} |")
        else:
            report.append("*(暂无课题维度收益定级记录)*")

        out_path = os.path.join(self.audit_dir, "consolidation_report.md")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(report) + "\n")
        print(f"✅ Stage III 聚合统计报告: {out_path}")
        return out_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="科技项目跨课题增量池轻量聚合引擎")
    parser.add_argument("--work-dir", default=".", help="项目工作区根目录")
    parser.add_argument("--mode", default="all", choices=["intent", "audit", "all"], help="聚合模式: intent / audit / all")
    args = parser.parse_args()

    engine = TechConsolidationEngine(args.work_dir)
    if args.mode in ("intent", "all"):
        engine.aggregate_intent_assets()
    if args.mode in ("audit", "all"):
        engine.generate_consolidation_report()
