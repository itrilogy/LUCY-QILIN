
import os
import argparse
from datetime import datetime

class TechAssetManager:
    def __init__(self, workdir, assets_dirname="02_Research_Assets"):
        # 修正为支持传参的目录，默认适配 大一统架构
        self.research_dir = os.path.join(workdir, assets_dirname)
        os.makedirs(self.research_dir, exist_ok=True)
        
        # 修正为中文资产池命名
        self.pools = {
            "problem": "01_企业真问题池.md",
            "method": "02_核心技术方法池.md",
            "term": "03_专业术语定义库.md",
            "naming": "04_命名修订范式库.md"
        }

    def append_asset(self, pool_type, title, content_dict):
        """原子化追加资产内容"""
        if pool_type not in self.pools:
            print(f"❌ 未知的资产池类型: {pool_type}")
            return False
        
        file_path = os.path.join(self.research_dir, self.pools[pool_type])
        
        # 准备写入内容，由 ### 降级为 - 列表格式
        timestamp = datetime.now().strftime('%Y-%m-%d')
        entry = f"\n- **[{timestamp}] {title}**\n"
        for key, value in content_dict.items():
            # 修复换行符字面量陷阱，强制转换为真实的换行
            clean_value = str(value).replace("\\n", "\n")
            entry += f"    - **{key}**: {clean_value}\n"
        
        # 物理写入 (append 模式)
        try:
            with open(file_path, 'a', encoding='utf-8') as f:
                f.write(entry)
            print(f"✅ 成功追加记录至 {self.pools[pool_type]}")
            return True
        except Exception as e:
            print(f"❌ 写入资产池失败: {str(e)}")
            return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="科技项目资产池管理器")
    parser.add_argument("--workdir", default=".", help="项目工作区根目录")
    parser.add_argument("--assets-dir", default="02_Research_Assets", help="资产池相对目录名称")
    parser.add_argument("--pool", required=True, choices=["problem", "method", "term", "naming"], help="目标资产池")
    parser.add_argument("--title", required=True, help="记录标题")
    parser.add_argument("--key", required=True, help="内容键")
    parser.add_argument("--value", required=True, help="内容值")
    
    args = parser.parse_args()
    
    manager = TechAssetManager(args.workdir, args.assets_dir)
    manager.append_asset(args.pool, args.title, {args.key: args.value})
