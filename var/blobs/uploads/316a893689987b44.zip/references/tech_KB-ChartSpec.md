# 科技项目图表选型与渲染规范 (Chart Spec & Rendering Protocol)

> **定位**: 科技项目研发档案（ATT01 / ATT03 / ATT12 等）的可视化图表选型、运行期 MCP 调度与离线双引擎（Mermaid / VChart-SVG）降级规范。
> **优先级声明**: 运行时**优先**通过 `[MCP_DISCOVER]` 查询当前环境挂载的绘图 MCP 服务实时提供的工具 Schema 与语法范式，调用 `[MCP_CALL]` 绘图并取得返回的图片地址；**仅当当前环境未提供对应图表类型的 MCP 服务时**，才采用本规范及 `references/render-protocols/` 中的 Track B（Mermaid / VChart-SVG）完成绘制。

---

## 1. 两轨三级渲染决策总则

1. **Track A：运行期 MCP 四步协同绘制（第一优先级）**：
   - 使用 **`[MCP_DISCOVER]`** 探测当前宿主已挂载的绘图 MCP 服务路由目录与治理规则，遵循 **专业 CORE 工具优先于通用 RELIEF 工具**，并**必须调用该 MCP 自带的协议查询工具或读取对应 Resource 获取完整 DSL 语法与红线**。
   - 严格按 MCP Schema 与实时范式调用 **`[MCP_CALL]`**（`dsl` 为纯文本字符串时禁止包 Markdown 代码围栏与多余解释前后缀，也不直接传裸 JSON 对象；若返回校验报错与骨架提示可自修重试 1 次），并将返回的 `![图表标题](返回的图片路径或URL)` 原样挂载。
2. **Track B：无匹配 MCP 时的原生降级双引擎（兜底路径）**：
   - **Track B1（系统架构 / 流程 / 时序 / 计划类 → Mermaid）**：查阅 `references/render-protocols/render_routing_index.md` 与 `references/render-protocols/protocol_mermaid.md`，生成合规 ```` ```mermaid ```` 代码块。
   - **Track B2（工程指标对比 / 分布 / 散点 / 热力 / 瀑布 / 桑基 / 精细因果图 → VChart——SVG）**：查阅 `references/render-protocols/render_routing_index.md` 与 `references/render-protocols/protocol_vchart.md`，生成自包含 `.svg` 矢量图文件落盘至 `03_Documentation_Build/assets/Charts/<前缀>_<图表类型>.svg`，并通过 `![图表标题](相对或工作区路径)` 引用。

---

## 2. 科技项目常用图表选型对照表

| 场景阶段 | 常见可视化需求 | 图表类型 | 无 MCP 时推荐降级引擎 |
|:---|:---|:---|:---|
| **立项/总体方案 (ATT01/ATT03/ATT12)** | 系统总体架构、分层拓扑、模块依赖 | Architecture / Block / Flowchart | **Mermaid** (`architecture-beta` / `flowchart`) |
| **业务协同与程序制度 (ATT06/ATT11)** | 跨部门审批泳道、业务岗位流转闭环 | Swimlane / Enterprise Flow | **Mermaid** (`flowchart` subgraphs) |
| **核心技术攻坚 (ATT12)** | 业务流转、多智能体/服务交互时序、状态机、实体数据模型 | Sequence / State / Class / ER | **Mermaid** (`sequenceDiagram` / `stateDiagram-v2` / `classDiagram` / `erDiagram`) |
| **工程实施与管理 (ATT06/ATT11)** | 年度里程碑、阶段甘特图、关键路径、风险预案 | Gantt / PERT / PDPC | **Mermaid** (`gantt` / `flowchart`) 或 **VChart——SVG** |
| **性能验证与实验数据 (ATT12)** | 覆盖率/耗时对比、吞吐趋势、回归散点、箱线离散度、相关热力图 | Bar / Line / Scatter / BoxPlot / Heatmap | **VChart——SVG** |
| **效益分析与资源结构 (ATT13)** | 成本收益归因瀑布图、资金/工作量占比旭日图/矩形树图、综合雷达图 | Waterfall / Sunburst / Treemap / Radar | **VChart——SVG** |
| **因果分析与方案比选** | 5M1E 鱼骨图、多方案评分矩阵、四象限评估 | Fishbone / Matrix / Quadrant | **VChart——SVG**（鱼骨/矩阵）或 **Mermaid** (`quadrantChart`) |

---

## 3. Track B1：Mermaid 降级防错五原则

1. **节点 ID**：纯英文与数字组合（如 `gateway`、`step_1`），禁止使用中文作节点 ID。
2. **标签双引号封装**：所有含中文、空格、括号、冒号或标点的节点文本统一采用 `A["描述文本"]` 格式。
3. **标点防御**：节点内部描述优先使用中文全角标点（`，`、`；`、`：`），避免未包裹的半角逗号或分号破坏解析器。
4. **甘特图缩放防御**：跨年度或非当前日期任务必须加 `todayMarker off`，日期统一 `YYYY-MM-DD`。
5. **方向与实验图规范**：`flowchart` 明确声明 `TD`/`LR`/`RL`；`sankey-beta`、`quadrantChart`、`block-beta`、`xychart-beta` 中所有标签加双引号。

---

## 4. Track B2：VChart——SVG 降级绘图与色彩规范

### 4.1 通用工业配色色板（T4 审计对齐）

| 语义用途 | 十六进制色值 | 适用场景 |
|:---|:---|:---|
| **主色（工程主指标 / 正常状态）** | `#3b82f6` | 工业蓝：主对比柱/折线/核心模块 |
| **预警/异常/超限红线** | `#ef4444` | 预警红：基准对比、80% 线、异常突刺、淘汰项 |
| **成功/达标绿** | `#10b981` | 成功绿：优化后达标序列、通过阈值 |
| **辅助对比琥珀** | `#f59e0b` | 琥珀黄：累计占比折线、副轴指标 |
| **次要/中性** | `#6b7280` | 中性灰：参考基准、坐标轴与网格标签 |

### 4.2 VChart——SVG 输出约束
1. **有本地 VChart 渲染工具时**：依据 `references/render-protocols/protocol_vchart.md` 构造 100% 静态 VisActor VChart JSON Spec（`data: [{ values: [...] }]`，笛卡尔图必须显式包含 `bottom` 和 `left` 轴与 `"label": { "visible": true }`，严禁 JS 函数）导出 `.svg`。
2. **全离线无 VChart 渲染器时**：由 Agent 按 VChart 统计视觉语义直接生成自包含 `.svg` 矢量图：
   - 必须声明 `xmlns="http://www.w3.org/2000/svg"`、合理 `viewBox`（如 `0 0 960 540`）与白色背景底板 `#ffffff`；
   - 使用系统无衬线字体栈 `sans-serif`，禁止任何外部网络字体/图片/脚本依赖；
   - 所有柱高、折点、误差标注、轴刻度与图例必须按数值比例绘制，并与正文数据台账及工程指标文件（`Code_Snippets/*_metrics.md`）严格一致。
3. **资产挂账规范**：无论产出为 MCP 图片链接、`assets/Charts/*.svg` 还是含 Mermaid 的图表文件，均须在 `00_Meta_Config/MANIFEST_ASSETS.md` 通过 `doc_append_helper.py` 挂账（`- [INJECT: [项目名]/ATTxx_章节] -> 物理路径或图表资产路径`），由 `tech-document-assembler` 拼入正文。

---

## 5. 技术深度与解读强制门槛 (T4 审计)

- **每幅图 ≥150 字技术解读**：必须包含图表结构/横纵轴含义、关键数值拐点或对比幅度、数据来源标注（`⭐引用自 ...` 或实测台账路径），禁止只放图无下文。
- **数据非整数与真实性**：工程性能、延迟、准确率等实测可视化图表须保留实测随机尾数与测试环境约束说明，不得拼造全整数平滑曲线。
