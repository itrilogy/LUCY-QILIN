# VChart——SVG 统计图表规范 (Track B2 降级参考)

> **适用前提**：仅当 `[MCP_DISCOVER]` 未在运行环境中发现适配目标统计图的绘图 MCP（Track B 离线降级模式）时启用；若存在在线绘图 MCP，务必先读取该 MCP 自带的协议资源（例如是否要求 `Title:`/`Spec:` 纯文本外壳而禁用裸 JSON 对象）再调用。
> - 若宿主支持标准 VisActor VChart 转 SVG 渲染能力，构造下方标准纯静态 VChart JSON Spec 并导出 `.svg`；
> - 若完全离线无 VChart 渲染器，则严格参照下方各图种的数据字段、坐标轴、图例与色板语义，直接生成自包含标准 `<svg>` 文件落盘至 `03_Documentation_Build/assets/Charts/` 并以 `![标题](路径.svg)` 引用。

## 资源面积图 (area)
- **适用场景**: 工业级资源分布演进图。用于展示能源消耗、库存累积等结构的占比随时间变化。支持堆叠面积模式。
### 专家灵魂 (The Soul)
- **笛卡尔闭环 (Critical)**: 必须配置 `bottom` 与 `left` 轴。
- **层级堆叠**: 推荐开启 `"stack": true` 以展示总量及各分量的贡献配比。
- **显示标注**: 必须配置 `"label": { "visible": true }`。

### 核心语法结构
- **静态配置要求**: 输出纯静态 VisActor VChart JSON 对象（含 `type`、`title`、`data`），禁止在 JSON 中包含 JS 函数。
- **分类标记**: 使用 `seriesField` 区分不同的资源类别（如 电、气、水）。
- **填充样式**: 默认包含透明度梯度，以确多个序列层叠时的可读性。

### 官方示例
```json
{
  "title": { "visible": true, "text": "能源消耗结构分析" },
  "type": "area",
  "data": [{ "values": [
    {"x":"周一","y":50,"c":"电"}, {"x":"周一","y":30,"c":"气"}, {"x":"周一","y":10,"c":"水"},
    {"x":"周二","y":55,"c":"电"}, {"x":"周2","y":35,"c":"气"}, {"x":"周二","y":12,"c":"水"}
  ]}],
  "xField": "x", "yField": "y", "seriesField": "c", "stack": true,
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ],
  "legends": [{ "visible": true, "orient": "bottom" }]
}
```

---
## 基础柱状图 (bar)
- **适用场景**: 工业级柱状对比工具。支持垂直、堆叠、分组展示。通过 Canvas 渲染优化，支撑万级数据点实时交互。
### 专家灵魂 (The Soul)
- **笛卡尔闭环 (Critical)**: 作为笛卡尔坐标系图表，**必须**显式包含 `bottom` 和 `left` 两个轴配置，否则会导致渲染异常。
- **显示标注**: 为了保证工业读数精度，必须在 series 中配置 `"label": { "visible": true }`。
- **静态约束**: 严禁在 Spec 块内出现 JavaScript 函数或 formatMethod 逻辑。

### 核心语法结构
- **静态配置要求**: 输出纯静态 VisActor VChart JSON 对象（含 `type`、`title`、`data`），禁止在 JSON 中包含 JS 函数。
- **数据容器**: 所有的 `Spec.data` 必须是数组格式 `data: [{ values: [...] }]`。
- **字段绑定**: `xField` 绑定类别，`yField` 绑定数值。

### 官方示例
```json
{
  "title": { "visible": true, "text": "生产单元故障堆叠分析" },
  "type": "bar",
  "data": [{ "values": [
    {"unit":"单元A","type":"机械","v":10}, {"unit":"单元A","type":"电气","v":20}, {"unit":"单元A","type":"人为","v":5},
    {"unit":"单元B","type":"机械","v":15}, {"unit":"单元B","type":"电气","v":5}, {"unit":"单元B","type":"人为","v":8}
  ]}],
  "xField": "unit", "yField": "v", "seriesField": "type", "stack": true,
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ],
  "legends": [{ "visible": true, "orient": "bottom" }]
}
```

---
## 质量离散箱线图 (boxPlot)
- **适用场景**: 工业级批次离散度审计工具。展示数据的中位数、分位数及异常点分布。通过五数概括法快速识别过程稳定性。
### 专家灵魂 (The Soul)
- **预计算统计量 (Critical)**: VChart BoxPlot **不负责**原始行数据的统计，必须传递已计算好的 `min`, `q1`, `median`, `q3`, `max` 值。
- **笛卡尔闭环**: 作为笛卡尔系图表，必须包含 `bottom` 和 `left` 坐标轴。
- **静态约束**: 所有计算值必须为字面量数字。

### 核心语法结构
- **字段绑定**: 显式映射 `minField`, `q1Field`, `medianField`, `q3Field`, `maxField`。
- **样式**: `boxPlot` 关键字采用驼峰命名。

### 官方示例
```json
{
  "title": { "visible": true, "text": "加工尺寸分布审计 (箱线图)" },
  "type": "boxPlot",
  "data": [ {
      "values": [
        { "batch": "批次A", "min": 10.1, "q1": 10.2, "median": 10.3, "q3": 10.4, "max": 10.5 },
        { "batch": "批次B", "min": 10.6, "q1": 10.7, "median": 10.75, "q3": 10.85, "max": 11.0 }
      ]
    } ],
  "xField": "batch", "minField": "min", "q1Field": "q1", "medianField": "median", "q3Field": "q3", "maxField": "max",
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ]
}
```

---
## 进度追踪环 (circularProgress)
- **适用场景**: 多指标达成率对比工具。通过环形轨道的填充比例展示当前进度，适用于多个 KPI 指标的横向对齐对比。
### 专家灵魂 (The Soul)
- **多条追踪**: 支持在一个圆环内展示多条进度轨道（seriesField 分组）。
- **严禁跨系挂载**: 极坐标系下的专用进度组件，禁制挂载笛卡尔轴。

### 核心语法结构
- **字段绑定**: `valueField` (0-1 的进度值)，`categoryField` 进度名，`seriesField` 锚定轨道分组。

### 官方示例
```json
{
  "title": { "visible": true, "text": "核心指标达成进度" },
  "type": "circularProgress",
  "data": [{ "values": [
    { "name": "产量达成", "value": 0.88 },
    { "name": "直通率", "value": 0.95 }
  ]}],
  "valueField": "value", "categoryField": "name", "seriesField": "name",
  "radius": 0.8, "innerRadius": 0.2,
  "label": { "visible": true, "position": "bottom" }
}
```

---
## 多轴组合分析图 (common)
- **适用场景**: 工业级多轴组合分析工具。支持在同一坐标系内混合展示柱、线、面积等序列，实现多维度指标的同步监测。
### 专家灵魂 (The Soul)
- **多轴绑定 (Critical)**: 在组合图中，必须通过 `seriesIndex` 或 `seriesId` 显式绑定轴向（如 `orient: left` 绑定 series 0）。
- **笛卡尔闭环**: 整体必须包含 `bottom` 轴，且每个垂直轴向均需显式配置。
- **数据解耦**: 每类序列建议使用独立的 `data` 块或通过 `series` 内置数据定义。

### 核心语法结构
- **系列定义**: 使用 `series` 数组，每个对象需声明 `type` (bar/line/area)。
- **轴线映射**: `axes` 数组中通过 `seriesIndex: [idx]` 指定该轴服务的序列。

### 官方示例
```json
{
  "title": { "visible": true, "text": "生产效能双轴组合图" },
  "type": "common",
  "series": [
    { "id": "cost", "type": "bar", "data": {"values": [{"x":"Q1","y":120},{"x":"Q2","y":150}]}, "xField": "x", "yField": "y", "label": { "visible": true } },
    { "id": "yield", "type": "line", "data": {"values": [{"x":"Q1","y":98},{"x":"Q2","y":96}]}, "xField": "x", "yField": "y", "label": { "visible": true } }
  ],
  "axes": [
    { "orient": "left", "seriesIndex": [0], "title": {"visible": true, "text": "成本 (K)"} },
    { "orient": "right", "seriesIndex": [1], "title": {"visible": true, "text": "良率 (%)"} },
    { "orient": "bottom", "label": { "visible": true } }
  ],
  "legends": [{ "visible": true, "orient": "bottom" }]
}
```

---
## 相关性热力矩阵图 (heatmap)
- **适用场景**: 工业级多维指标相关性分析工具。通过 2D 矩阵热力颜色展示变量之间的正负相关强度，是韦恩图 (Venn) 的标准等效替代方案。
### 专家灵魂 (The Soul)
- **Venn 替代策略**: 由于 VChart 暂不支持 `venn` 类型，**必须**引导用户或 AI 使用 `heatmap` 构建相关性矩阵进行等效表达。
- **笛卡尔闭环**: 必须包含 `bottom` 和 `left` 两个类别轴。
- **显示标注**: 必须在 series 中配置 `"label": { "visible": true }` 以展示相关系数数值。

### 核心语法结构
- **数据构建**: 建立对称的 X-Y 坐标数据对，`valueField` 存储相关系数值（通常为 -1 到 1）。

### 官方示例
```json
{
  "title": { "visible": true, "text": "品质指标相关性矩阵" },
  "type": "heatmap",
  "data": [{ "values": [
    {"x":"温度","y":"压力","v":0.92}, {"x":"温度","y":"转速","v":0.45},
    {"x":"压力","y":"温度","v":0.92}, {"x":"压力","y":"转速","v":0.31}
  ]}],
  "xField": "x", "yField": "y", "valueField": "v",
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ]
}
```

---
## 过程转化漏斗图 (funnel)
- **适用场景**: 业务流转转化率分析工具。展示从入口到终口各阶段的数据衰减情况，定位转化瓶颈。
### 专家灵魂 (The Soul)
- **数组结构**: VChart Funnel 必须接受数组格式的数据容器。
- **排序准则**: 默认按数值降序排列以符合“漏斗”语义，建议通过 `categoryField` 对齐逻辑阶段。

### 核心语法结构
- **静态配置要求**: 输出纯静态 VisActor VChart JSON 对象（含 `type`、`title`、`data`），禁止在 JSON 中包含 JS 函数。
- **字段绑定**: `categoryField` 定义阶段名称，`valueField` 定义各阶段余留量。

### 官方示例
```json
{
  "title": { "visible": true, "text": "业务转化漏斗" },
  "type": "funnel",
  "data": [{ "values": [
    {"step":"访问","v":1000}, {"step":"注册","v":600}, {"step":"试用","v":300}
  ]}],
  "categoryField": "step", "valueField": "v",
  "label": { "visible": true }
}
```

---
## 实时性能仪表盘 (gauge)
- **适用场景**: 核心 KPI 达成效率呈现工具。模拟物理仪表盘，展示数值在量程范围内的当前水位，适用于良率、效率的阈值监控。
### 专家灵魂 (The Soul)
- **角度控制**: 应显式定义 `startAngle` (如 -225) 和 `endAngle` (如 45) 以形成工业标准的扫掠范围。
- **严禁跨系挂载**: 禁止配置 Cartesian 坐标轴。
- **量程定义**: 通过半径 `outerRadius` 与 `innerRadius` 控制环厚。

### 核心语法结构
- **数据限制**: 建议单系列数据展示。使用 `valueField` 绑定当前测得数值。

### 官方示例
```json
{
  "title": { "visible": true, "text": "产线实时直通率仪表盘" },
  "type": "gauge",
  "data": [{ "values": [{"v": 0.88}] }],
  "valueField": "v",
  "categoryField": "v",
  "outerRadius": 0.8, "innerRadius": 0.5,
  "startAngle": -225, "endAngle": 45,
  "label": { "visible": true }
}
```

---
## 空间负荷热力图 (heatmap)
- **适用场景**: 工业级关联强度与负荷热力可视化工具。通过颜色深浅表达数值密度，适用于相关性矩阵或产线负荷分析。
### 专家灵魂 (The Soul)
- **Venn 替代**: VChart 不支持 Venn 图，处理逻辑关联集合时，推荐使用 Heatmap 或 Scatter 作为替代方案。
- **笛卡尔闭环**: 必须包含 `bottom` 和 `left` 轴。
- **颜色策略**: 必须配置 `visualMap` 或色带，以保证数值与色彩的直观映射感。

### 核心语法结构
- **字段绑定**: `xField` 对应时间维或 X 维度，`yField` 对应分类维度，`valueField` 对应热力强度。

### 官方示例
```json
{
  "title": { "visible": true, "text": "产线负荷热力分布" },
  "type": "heatmap",
  "data": [{ "values": [
    {"hour":"08:00","line":"Line1","v":90}, {"hour":"09:00","line":"Line1","v":95},
    {"hour":"08:00","line":"Line2","v":40}, {"hour":"09:00","line":"Line2","v":50}
  ]}],
  "xField": "hour", "yField": "line", "valueField": "v",
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ]
}
```

---
## 趋势折线图 (line)
- **适用场景**: 工业级过程趋势追踪工具。专注于随时间维度的良率波动、参数演变分析。支持高频采样脉冲显示。
### 专家灵魂 (The Soul)
- **笛卡尔闭环 (Critical)**: 必须显式定义 `bottom` (时间/类别轴) 与 `left` (数值轴) 对齐。
- **显示标注**: series 中必须配置 `"label": { "visible": true }` 以确保关键拐点数值可见。
- **数据平滑**: 可选配置 `"smooth": true` 以美化非精度敏感的趋势描述。

### 核心语法结构
- **静态配置要求**: 输出纯静态 VisActor VChart JSON 对象（含 `type`、`title`、`data`），禁止在 JSON 中包含 JS 函数。
- **字段绑定**: `xField` 对应时间维，`yField` 对应监控指标。
- **数据点**: 设置 `"point": { "visible": true }` 增强交互触达。

### 官方示例
```json
{
  "title": { "visible": true, "text": "月度良率趋势分析" },
  "type": "line",
  "data": [{ "values": [
    {"month":"1月","v":95}, {"month":"2月","v":96}, {"month":"3月","v":94},
    {"month":"4月","v":97}, {"month":"5月","v":98}, {"month":"6月","v":95}
  ]}],
  "xField": "month", "yField": "v",
  "label": { "visible": true },
  "point": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ]
}
```

---
## VChart——SVG 降级渲染总纲 (Master Protocol)
- **适用场景**: 无匹配绘图 MCP 时的 Track B2 统计图表总治理准则。定义纯静态 VisActor VChart JSON 结构及自包含 SVG 矢量落盘规范。
### 核心约束
- **纯静态 JSON Spec**：严禁出现 JavaScript 函数、注释或自定义私有文本外壳关键字，所有字段均为标准 JSON。
- **SVG 矢量落盘规范**：导出或手写生成 `.svg` 时必须含 `xmlns="http://www.w3.org/2000/svg"`、明确 `viewBox`、`#ffffff` 背景与无衬线字体回退栈，禁用外部资源引用。
- **工业配色基线**：主色 `#3b82f6`、警示红 `#ef4444`、成功绿 `#10b981`、琥珀黄 `#f59e0b`、中性灰 `#6b7280`。
- **数据容器规范**: `data` 必须为 `[{"values": [...]}]` 数组格式。

### 标准结构示例 (VChart JSON Spec)
```json
{
  "type": "bar",
  "title": { "visible": true, "text": "月度设备综合效率 (OEE)" },
  "color": ["#3b82f6"],
  "data": [{ "values": [
    { "month": "1月", "v": 0.85 },
    { "month": "2月", "v": 0.88 }
  ]}],
  "xField": "month",
  "yField": "v",
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ]
}
```

---
## 占比饼图/环形图 (pie)
- **适用场景**: 高精度构成比例分析工具。支持饼图、环形图。适用于质量成本、市场份额等核心占比展示。
### 专家灵魂 (The Soul)
- **严禁坐标轴**: 饼图工作在极坐标系，**绝对禁止**出现 `axes` 或 `orient: left/bottom` 配置。
- **数据容器**: `Spec.data` 顶层必须为数组格式 `[{ values: [...] }]`。
- **形态策略**: 默认为实心饼图 (`innerRadius: 0`)。当用户提到“环形”或“Donut”时，才设置 `innerRadius: 0.5`。

### 核心语法结构
- **静态配置要求**: 输出纯静态 VisActor VChart JSON 对象（含 `type`、`title`、`data`）。
- **字段绑定**: `categoryField` 对应分类名称，`valueField` 对应数值。
- **显示控制**: `"label": { "visible": true }`。

### 官方示例
```json
{
  "title": { "visible": true, "text": "质量成本构成明细" },
  "type": "pie",
  "data": [{ "values": [
    {"name":"预防成本","v":400},
    {"name":"鉴定成本","v":200}
  ]}],
  "categoryField": "name", "valueField": "v",
  "outerRadius": 0.8, "innerRadius": 0,
  "label": { "visible": true }
}
```

---
## 多维指标雷达图 (radar)
- **适用场景**: 多轴展现对象在不同维度上的均衡性与优劣势对比（支持标准化与面积对比）。
### 分析要点
- 通过多边形各顶点分布直观暴露系统“短板维度”；对比多个方案或优化前后时使用 `seriesField` 区分序列。

### 标准 VChart JSON 示例
```json
{
  "type": "radar",
  "title": { "visible": true, "text": "方案多维竞争力对比" },
  "color": ["#3b82f6", "#ef4444"],
  "data": [{ "values": [
    { "dim": "响应速度", "val": 92, "plan": "优选方案" },
    { "dim": "精度", "val": 95, "plan": "优选方案" },
    { "dim": "成本控制", "val": 84, "plan": "优选方案" },
    { "dim": "响应速度", "val": 71, "plan": "原基准方案" },
    { "dim": "精度", "val": 76, "plan": "原基准方案" },
    { "dim": "成本控制", "val": 88, "plan": "原基准方案" }
  ]}],
  "categoryField": "dim",
  "valueField": "val",
  "seriesField": "plan",
  "area": { "visible": true, "style": { "fillOpacity": 0.35 } },
  "legends": [{ "visible": true, "orient": "bottom" }]
}
```

---
## 南丁格尔玫瑰图 (rose)
- **适用场景**: 极坐标下的面积占比工具。通过半径长度表达数值大小，兼具分类占比与数值对比的双重表现力。
### 专家灵魂 (The Soul)
- **严禁跨系挂载 (Warning)**: 严禁配置 `orient` 笛卡尔轴。玫瑰图工作在极坐标系下。
- **数据容器**: 严格遵循 Top-level 数组结构。

### 核心语法结构
- **类型声明**: `"type": "rose"`。
- **字段绑定**: `categoryField` 与 `valueField`。
- **视觉标注**: 必须开启 `"label": { "visible": true }`。

### 官方示例
```json
{
  "title": { "visible": true, "text": "供应商异常反馈分布 (玫瑰图)" },
  "type": "rose",
  "data": [{ "values": [
    {"type":"物流","v":400}, {"type":"包装","v":200}, {"type":"性能","v":300}, {"type":"外观","v":150}
  ]}],
  "categoryField": "type", "valueField": "v",
  "outerRadius": 0.8, "innerRadius": 0.2,
  "label": { "visible": true }
}
```

---
## 能量传递桑基图 (sankey)
- **适用场景**: 工业级复杂流转分析工具。展示节点间多对多的流量权重传递。用于分析能源流、报文路径或生产流转。
### 专家灵魂 (The Soul)
- **分线图架构 (Node/Children)**: 推荐使用带有 `children` 的层级结构来定义流量，这比扁平的 from/to 在大规模工业拓扑中更具表达力。
- **严禁跨系挂载**: 作为关系型图表，**严禁**挂载任何 `orient` 轴，否则渲染崩溃。
- **显示标注**: series 中必须配置 `"label": { "visible": true }`。

### 核心语法结构
- **字段绑定**: `categoryField` 对应节点 ID，`valueField` 对应节点权重/流量大小。

### 官方示例
```json
{
  "title": { "visible": true, "text": "生产资源流转路径分析" },
  "type": "sankey",
  "data": [
    {
      "values": [
        {
          "nodes": [
            { 
              "name": "总投入", 
              "children": [
                { "name": "原料A", "value": 160, "children": [{ "name": "工序1", "value": 160 }] },
                { "name": "原料B", "value": 120, "children": [{ "name": "工序1", "value": 120 }] },
                { "name": "原料C", "value": 140, "children": [{ "name": "工序2", "value": 140 }] }
              ]
            },
            {
              "name": "工序1",
              "children": [
                { "name": "工序2", "value": 210 },
                { "name": "废料", "value": 70 }
              ]
            },
            {
              "name": "工序2",
              "children": [
                { "name": "工序3", "value": 290 },
                { "name": "废料", "value": 60 }
              ]
            },
            {
              "name": "工序3",
              "children": [
                { "name": "产品X", "value": 190 },
                { "name": "产品Y", "value": 100 }
              ]
            }
          ]
        }
      ]
    }
  ],
  "nodeKey": "name",
  "categoryField": "name",
  "valueField": "value",
  "label": { "visible": true }
}
```

---
## 相关性散点图 (scatter)
- **适用场景**: 双变量或三变量（气泡）定量相关性验证与回归趋势识别（注意相关性不等同于因果关系）。
### 分析要点
- 涉及 QC 要因定量验证时须满足样本 ≥ 30 对；可叠加回归趋势线说明离散度与拟合趋势。

### 标准 VChart JSON 示例
```json
{
  "type": "scatter",
  "title": { "visible": true, "text": "工艺温度与压实强度相关性分析" },
  "color": ["#3b82f6"],
  "data": [{ "values": [
    { "temp": 195.5, "pressure": 85.2, "shrink": 2.4 },
    { "temp": 192.0, "pressure": 82.5, "shrink": 2.5 },
    { "temp": 198.5, "pressure": 88.0, "shrink": 2.2 }
  ]}],
  "xField": "temp",
  "yField": "pressure",
  "sizeField": "shrink",
  "axes": [
    { "orient": "bottom", "type": "linear", "title": { "visible": true, "text": "温度 (℃)" } },
    { "orient": "left", "type": "linear", "title": { "visible": true, "text": "压力 (MPa)" } }
  ]
}
```

---
## 层级穿透旭日图 (sunburst)
- **适用场景**: 多层级占比透视工具。向上追溯父类结构，向下穿透子类细节。适用于成本构成或组织架构的递归展示。
### 专家灵魂 (The Soul)
- **层级数据结构**: 数据必须采用 `children` 嵌套的树形 JSON 格式，包裹在顶层数组内。
- **严禁跨系挂载**: 禁制挂载笛卡尔坐标轴。
- **中心对齐**: 自动计算圆心，支持从内向外的占比逻辑解析。

### 核心语法结构
- **字段绑定**: `categoryField` 锚定名称，`valueField` 锚定叶子节点数值及枝干聚合权值。

### 官方示例
```json
{
  "title": { "visible": true, "text": "产品成本层级拆解 (旭日图)" },
  "type": "sunburst",
  "data": [ {
      "values": [ {
          "name": "总成本",
          "children": [
            { "name": "材料", "value": 500, "children": [{ "name": "铝材", "value": 300 }] },
            { "name": "人工", "value": 400 }
          ]
        } ]
    } ],
  "categoryField": "name", "valueField": "value",
  "label": { "visible": true }
}
```

---
## 资产矩形树图 (treemap)
- **适用场景**: 通过空间平铺面积展示层级占比的视觉化工具。适用于固定资产分布、文件空间占用等树形比例分析。
### 专家灵魂 (The Soul)
- **递归深度**: 支持深层嵌套结构解析。父节点的面积等于所有子节点面积之和。
- **无轴约束**: 禁止配置坐标轴。利用几何空间的矩形分割展示比例关系。

### 核心语法结构
- **字段绑定**: `categoryField` 用于节点标注，`valueField` 用于计算矩形权重。

### 官方示例
```json
{
  "title": { "visible": true, "text": "固定资产分布比例图" },
  "type": "treemap",
  "data": [ {
      "values": [ {
          "name": "总资产",
          "children": [
            { "name": "生产设备", "value": 500 }, { "name": "IT设备", "value": 150 }
          ]
        } ]
    } ],
  "categoryField": "name", "valueField": "value",
  "label": { "visible": true }
}
```

---
## 变动归因瀑布图 (waterfall)
- **适用场景**: 工业级价值流变动分析工具。展示从起始点到终点过程中各因素的增减贡献，适用于成本分析或质量损失归因。
### 专家灵魂 (The Soul)
- **终值标记**: 必须在最后一个数据点中使用标记字段（如 `isTotal: true`），并在 Spec 中通过 `total` 字段绑定，以确立总计柱的悬空基准。
- **笛卡尔闭环**: 必须显式包含 `bottom` 和 `left` 轴。

### 核心语法结构
- **关键字定义**: `"total": { "tagField": "isTotal" }` 用于识别总计项。
- **配色语义**: 自动识别数值正负并分配上升/下降色系。

### 官方示例
```json
{
  "title": { "visible": true, "text": "质量成本变动归因分析" },
  "type": "waterfall",
  "data": [ {
      "values": [
        { "x": "起始成本", "y": 1000 },
        { "x": "材料波动", "y": 200 },
        { "x": "工艺改进", "y": -150 },
        { "x": "最终成本", "y": 1050, "isTotal": true }
      ]
    } ],
  "xField": "x", "yField": "y",
  "total": { "tagField": "isTotal" },
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ]
}
```

---
## 异常关键词词云图 (wordCloud)
- **适用场景**: 工业舆向与文本热度分析工具。挖掘检测报告、巡检记录中的高频关键词，实现非结构化数据的快速语义画像。
### 专家灵魂 (The Soul)
- **驼峰命名**: 必须使用 `wordCloud` (非小写) 作为 type 声明。
- **无轴约束**: 禁止配置坐标轴。所有信息通过节点的空间排布与文字大小表示。
- **显示标注**: 应配合 `valueField` 通过字号大小直观表达权重。

### 核心语法结构
- **字段绑定**: `nameField` 定义文本内容，`valueField` 定义权重频率。

### 官方示例
```json
{
  "title": { "visible": true, "text": "巡检异常关键词画像" },
  "type": "wordCloud",
  "data": [{ "values": [
    {"name":"故障","value":100}, {"name":"波动","value":80}, {"name":"纠偏","value":40}
  ]}],
  "nameField": "name", "valueField": "value"
}
```

---
