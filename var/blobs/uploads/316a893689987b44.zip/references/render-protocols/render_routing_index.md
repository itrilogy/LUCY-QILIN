# 科技项目图表渲染路由与双引擎降级索引 (Render Routing Index)

> **运行时决策铁律**：当 `tech-enricher` 需要将素材或指标可视化时，**禁止预设固定 MCP 地址或盲猜工具细节**。
> 必须严格遵循 `references/unified_file_handling_protocol.md §6`：
> 1. **Track A（MCP 优先四步走）**：先用 `[MCP_DISCOVER]` 查看已连接绘图 MCP 的意图路由/治理资源，优先匹配专业 CORE 工具（如统计/因果/跨部门泳道流程等），再**调用该 MCP 的协议查询工具或读取对应 Resource 获取完整 DSL 语法与红线**；严格按纯文本无围栏规则调用 `[MCP_CALL]`（报错自修重试 1 次）并将返回的 `![图标题](地址)` 原样落盘；
> 2. **Track B（无匹配 MCP 时自动降级）**：仅在环境未提供匹配图表 MCP 或调用不可达时，按下方索引查阅 **Mermaid**（`references/render-protocols/protocol_mermaid.md`）或 **VChart——SVG**（`references/render-protocols/protocol_vchart.md`）进行本地绘制。注意 Track B 的 Markdown 代码围栏不可直接传入要求纯文本 `dsl` 的 MCP 接口。

---

## 1. 通用图表选型与降级引擎路由总表

| 图表意图关键字 | 适用业务/工程场景 | Track A（MCP 优先查询路由） | Track B（无匹配 MCP 时降级字典与引擎） |
|:---|:---|:---|:---|
| 跨部门泳道 / 审批程序流程 | 业务协同流转、制度审批与管理闭环 | 优先以 `flow` / `swimlane` 匹配 MCP CORE 工具 | **Mermaid** (`protocol_mermaid.md § 流程图` 分栏子图) |
| 系统架构 / 微服务拓扑 | 分层系统架构、网元/容器拓扑 | 以 `architecture` 查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md § 架构拓扑图`) |
| 业务流程 / 决策树 | 算法管线、异常处理、技术路线框图 | 以 `flowchart` 查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md § 流程图`) |
| 时序协作 / 接口调用 | 多智能体交互、API/MCP 调用链 | 以 `sequence` 查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md § 时序图`) |
| 状态迁移 / 生命周期 | 工单/模型任务状态切换 | 以 `state` 查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md § 状态图`) |
| 类结构 / 实体关系 ER | 模块接口、数据库建模 | 以 `class` / `er` 查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md § 类图 / ER图`) |
| 进度规划 / 里程碑 | 年度任务甘特图、版本演进时间线 | 以 `gantt` / `timeline` 查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md § 甘特图 / 时间线`) |
| 分块 / 需求 / 看板 / 四象限 | 组件网格、需求追踪、优先级四象限 | 以对应图种名查询 `[MCP_DISCOVER]` | **Mermaid** (`protocol_mermaid.md` 对应章节) |
| 树状思维导图 / 亲和归类 | 知识体系拆解、问题分类归纳 | 以 `mindmap` / `affinity` 查询 `[MCP_DISCOVER]` | **Mermaid** (`mindmap` / `flowchart` 子图) 或 **VChart——SVG** |
| 柱状 / 面积 / 折线 / 饼图 / 玫瑰图 | 吞吐趋势、延迟对比、资源占比、构成分析 | 以 `bar` / `line` / `area` / `pie` / `rose` 查询 `[MCP_DISCOVER]` | **VChart——SVG** (`protocol_vchart.md` 对应章节 + `.svg` 输出) |
| 组合双轴对比 / 进度环 / 仪表盘 | 产量 vs 准确率双轴、KPI 达成率监控 | 以 `common` / `gauge` / `progress` 查询 `[MCP_DISCOVER]` | **VChart——SVG** (`protocol_vchart.md`) |
| 散点 / 相关矩阵 / 热力图 | 双变量回归相关性、指标矩阵负荷 | 以 `scatter` / `heatmap` 查询 `[MCP_DISCOVER]` | **VChart——SVG** (`protocol_vchart.md`) |
| 箱线图 / 直方图 / SPC 控制图 | 批次离散度稳定性、分布直方、过程控制限 | 以 `boxplot` / `histogram` / `control` 查询 `[MCP_DISCOVER]` | **VChart——SVG** (`protocol_vchart.md` / 标准 SVG 控制限线) |
| 瀑布图 / 漏斗图 / 桑基图 / 旭日图 / 矩形树图 / 词云 | ROI 增减归因、转化漏斗、流量去向、资产占比、异常词云 | 以 `waterfall` / `funnel` / `sankey` / `sunburst` / `treemap` / `wordcloud` 查询 `[MCP_DISCOVER]` | **VChart——SVG** (`protocol_vchart.md`) |
| 5M1E 鱼骨图 / 方案矩阵 / PERT 矢线图 | 复杂根因排查、多维度打分、关键路径网络 | 以 `fishbone` / `matrix` / `arrow` 查询 `[MCP_DISCOVER]` | **VChart——SVG**（精细矢量图）或 **Mermaid**（`flowchart` / 评分表） |

---

## 2. 标准执行五步法 (SOP)

1. **选型判定**：根据素材的数据特征（关系拓扑 vs 定量分布）确定目标图表类型关键字。
2. **Track A 探测与查询**：调用 `[MCP_DISCOVER]` 探测运行期绘图 MCP 的路由目录与协议治理规范（优先选用专用 CORE 工具而非通用救济通道），再通过该 MCP 自带的协议查询工具/Resource 读完目标图种完整语法；严格按纯文本无围栏约定调用 `[MCP_CALL]`（遇到校验报错提示可自修重试 1 次），并将返回的 `![图标题](地址)` 原样保留。
3. **Track B 降级查阅（仅当无对应 MCP 时触发）**：
   - 属于 Mermaid 系 → 用 `[FILE_READ]` 检索 `references/render-protocols/protocol_mermaid.md` 对应章节，生成合法 ```` ```mermaid ```` 代码块；
   - 属于 VChart——SVG 系 → 用 `[FILE_READ]` 检索 `references/render-protocols/protocol_vchart.md` 对应章节，遵循 VChart 静态配置语义生成自包含 `.svg` 矢量图文件。
4. **物理资产落盘**：
   - 将图表产出及 **≥150 字技术解读**存至 `03_Documentation_Build/assets/Charts/`（Mermaid 片段或 MCP 图片包装片段存 `.md`；降级矢量图同时存 `<prefix>_<type>.svg` 并在引用处写 `![图标题](03_Documentation_Build/assets/Charts/<prefix>_<type>.svg)`）。
5. **总账注册**：通过 `scripts/doc_append_helper.py --mode a` 将 `- [INJECT: [项目名]/ATTxx_章节] -> <资产物理路径>` 写入 `00_Meta_Config/MANIFEST_ASSETS.md`，供 `tech-document-assembler` 提取注入。
