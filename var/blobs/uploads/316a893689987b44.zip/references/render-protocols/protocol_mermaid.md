# Mermaid 架构与流程图表规范 (Track B1 降级参考)

> **适用前提**：仅当 `[MCP_DISCOVER]` 未在运行环境中发现适配目标图种的绘图 MCP（Track B 离线降级模式）时参考本规范输出 ```` ```mermaid ```` 代码块；若存在在线绘图 MCP，**禁止**将本文件代码块语法直接塞入要求纯文本 `dsl` 的 MCP 接口，务必先查询该 MCP 自身协议资源后再调用。

## 架构拓扑图 (architecture-beta)
- **适用场景**: 基于 Mermaid 的系统架构可视化工具。支持逻辑分层（Group）、服务定义及带方向的拓扑连线。
### 专家灵魂 (The Soul)
- **核心分类**: 结构建模类图表。用于刻画现代云原生或微服务架构的逻辑层级与物理拓扑。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **拓扑语法 (Critical)**: 连线方向必须遵循 `源节点:方向 --> 方向:目标节点`（例如 `gateway:R --> L:auth`）。
- **命名建议**: Label 建议优先使用英文以确保持续兼容性。

### 全量图表关键字定义
- `architecture-beta`: 定义架构图起始。
- `group [ID](图标)[Label]`: 定义逻辑层级组。
- `service [ID](图标)[Label]`: 定义具体服务节点。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "base"}}%%` 样式渲染。

### 官方示例
```
architecture-beta
    group api(cloud)[API Layer]
    group services(server)[Service Layer]
    group db(database)[Database Layer]

    service gateway(internet)[API Gateway] in api
    service auth(server)[Auth Service] in services
    service user(server)[User Service] in services
    service mysql(database)[MySQL] in db

    gateway:R --> L:auth
    gateway:B --> T:user
    auth:R --> L:mysql
    user:R --> L:mysql
```

---
## 分层块图 (block-beta)
- **适用场景**: 基于 Mermaid 的分块结构图。用于展示层级化的服务、组件或逻辑块，支持网格化布局。
### 专家灵魂 (The Soul)
- **核心分类**: 结构建模类图表。用于将复杂的系统拆解为可视化的逻辑矩形块（Block）与容器。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **引号强制**: 在 `block-beta` 中，**所有中文标签必须用双引号 "" 包裹**。

### 全量图表关键字定义
- `block-beta`: 定义块图起始。
- `columns [N]`: 设置每行显示的网格列数。
- `block:[ID]`: 定义容器块。
- `"Label"`: 定义具体内容块。

### 官方示例
```
block-beta
    columns 3
    "服务1" "服务2" "服务3"
    block:group1
        columns 1
        "子项A" "子项B"
    end
```

---
## 类图 (classDiagram)
- **适用场景**: 基于 Mermaid 的类图建模工具。刻画系统组件间的继承、组合、关联关系。支持成员变量与方法标注。
### 专家灵魂 (The Soul)
- **核心分类**: 结构建模类图表。专注于软件工程中的静态结构，表现类、接口及其依赖路径。

### 全量图表关键字定义
- `classDiagram`: 定义类图起始。
- `<|--` (继承) / `*--` (组合) / `o--` (聚合)。
- `+` (public) / `-` (private) / `#` (protected): 访问性标识。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "neutral"}}%%` 进行标准化结构渲染。

### 官方示例
```
%%{init: {"theme": "neutral"}}%%
classDiagram
    class Vehicle {
        +move()
    }
    class Car {
        -engine: String
        +drive()
    }
    Vehicle <|-- Car
```

---
## ER图 (erDiagram)
- **适用场景**: 基于 Mermaid 的实体关系建模工具。用于描述系统架构、数据模型及组织关系。强调一对多、多对一的关系严谨性。
### 专家灵魂 (The Soul)
- **核心分类**: 结构建模类图表。用于定义数据实体（Entities）及其相互关联（Relationships）。
- **逻辑准则**: 刻画父子、依赖及引用关系。强调基数（Cardinality）的准确性，如 `||--o{` 代表一对多。

### 全量图表关键字定义
- `erDiagram`: 定义 ER 图起始。
- `||--o{` / `||--|{` / `}|--|{`: 定义基数关系。
- `ENTITY { int id }`: 定义属性列表。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "forest"}}%%` 适配森林工业风渲染。

### 官方示例
```
%%{init: {"theme": "forest"}}%%
erDiagram
    USER ||--o{ ORDER : "下单"
    ORDER ||--|{ PRODUCT : "包含"
    USER {
        int id
        string name
    }
```

---
## 流程图 (flowchart)
- **适用场景**: 基于 Mermaid 的结构化建模工具。用于刻画业务流转、决策树及闭环逻辑。支持多种布局方向与样式自定义。
### 专家灵魂 (The Soul)
- **核心分类**: 逻辑流转类图表。专注于描述业务流转、决策分支及逻辑闭环。

### 公共事项及说明 (Common Instructions)
1. **纯净 DSL 范式**: AI 必须生成纯文本 DSL 指令。严禁将代码块包裹在 JSON 结构中或附加冗余解释。
2. **符号冲突防御**: 在中文描述文字中，必须优先使用中文全角标点（如 ，、；、：）。严禁使用半角逗号或分号，防止解析误认。
3. **复杂内容包裹**: 包含特殊符号或多行的节点，必须使用 ["内容"]（矩形）、("内容")（圆角）等显式包裹。

### 全量图表关键字定义
- `graph` / `flowchart`: 定义流程图起始。
- `TD` (Top Down) / `LR` (Left Right): 定义布局方向。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "neutral", "look": "handDrawn"}}%%` 进行手绘效果渲染。

### 典型语法结构
`A[节点] --> B{判断}`

### 官方示例
```
%%{init: {"theme": "neutral", "look": "handDrawn"}}%%
graph TD
    A[提交申请] --> B{经理审批}
    B -- "通过" --> C[财务放款]
    B -- "驳回" --> D[退回修改]
    D --> A
    C --> E[流程结束]
```

---
## 甘特图 (gantt)
- **适用场景**: 基于 Mermaid 的项目进度管理工具。专注于时间维度、阶段划分及任务分配。
### 专家灵魂 (The Soul)
- **核心分类**: 计划与追踪类图表。关注任务在时间轴上的分布、依赖及完成状态。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **缩放防御 (Critical)**: 若当前日期不在项目周期内，必须强制设置 `todayMarker off`，否则时间轴会被无限拉伸导致图例不可见。
- **日期格式**: 必须通过 `dateFormat YYYY-MM-DD` 显式声明日期解析方式，以确保跨平台渲染一致性。

### 全量图表关键字定义
- `gantt`: 定义甘特图起始。
- `section`: 定义阶段。
- `任务 :a1, 2024-03-01, 5d`: 任务定义语法。
- `after a1`: 任务依赖语法。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "base", "gantt": {"barHeight": 35, "fontSize": 16}}}%%` 进行基础风格渲染。

### 官方示例
```
%%{init: {"theme": "base", "gantt": {"barHeight": 35, "fontSize": 16}}}%%
gantt
    title 项目开发进度
    dateFormat YYYY-MM-DD
    todayMarker off
    section 核心开发
    架构设计 :a1, 2024-03-01, 5d
    功能开发 :after a1, 10d
    section 质量验证
    集成测试 :2024-03-15, 7d
```

---
## Git 分支图 (gitGraph)
- **适用场景**: 基于 Mermaid 的 Git 工作流模拟工具。展示提交记录、分支创建、切换及合并过程。
### 专家灵魂 (The Soul)
- **核心分类**: 逻辑流转类图表。专注于展示代码版本控制中的分支演进及合并逻辑。

### 全量图表关键字定义
- `gitGraph`: 定义 Git 图起始。
- `commit id: "ID"`: 提交记录。
- `branch [Name]`: 创建分支。
- `checkout [Name]`: 切换分支。
- `merge [Name]`: 合并分支。

### 官方示例
```
gitGraph
    commit id: "Initial"
    branch develop
    checkout develop
    commit id: "Feature-A"
    checkout main
    merge develop
    commit id: "Release-1.0"
```

---
## 用户旅程图 (journey)
- **适用场景**: 基于 Mermaid 的用户旅程映射工具。标注不同阶段用户的情绪、动作与角色参与。适用于体验感知分析。
### 专家灵魂 (The Soul)
- **核心分类**: 多维认知类图表。通过时间序列展示用户在交互过程中的情感曲线与参与点。

### 全量图表关键字定义
- `journey`: 定义旅程图起始。
- `title`: 设置旅程名称。
- `section`: 设置阶段（如 搜索、决策）。
- `动作: 5: 角色`: 分别代表 动作名, 评分 (0-5), 角色名。

### 官方示例
```
%%{init: {"theme": "base"}}%%
journey
    title 线上购物旅程
    section 搜索
      点击商品: 5: 用户
      查看详情: 4: 用户
    section 决策
      加购物车: 5: 用户
      下单支付: 3: 用户
```

---
## 任务看板 (kanban)
- **适用场景**: 基于 Mermaid 的敏捷开发看板工具。支持列划分、任务卡片定义及责任人分配状态。
### 专家灵魂 (The Soul)
- **核心分类**: 计划与追踪类图表。用于模拟敏捷看板，展示任务在不同状态列（Todo, InProgress, Done）间的分布。

### 全量图表关键字定义
- `kanban`: 定义看板起始。
- `[列名]`: 顶格书写定义列。
- `[事项]`: 缩进定义任务项。
- `@{ assigned: "人" }`: 分配责任人语法。

### 官方示例
```
%%{init: {"theme": "neutral"}}%%
kanban
  Todo
    需求评审
    架构设计
  InProgress
    API开发
  Done
    环境搭建
```

---
## Mermaid 渲染总纲 (Master Protocol)
- **适用场景**: Mermaid 渲染引擎的全局治理逻辑。定义了甘特图、流程图等图表的渲染纠偏规则。
### 专家灵魂 (The Soul)

#### 基于文本的万能建模工具 (Mermaid Engine)
Mermaid 是一种基于文本的绘图工具，旨在通过简单的标记语言，快速构建、迭代和分享复杂的逻辑结构图。它是从“感性思维”向“结构化逻辑”转化的桥梁。

#### 核心分类视角：
- **逻辑流转类**: 获取业务流转、决策树及闭环逻辑 (flowchart, stateDiagram-v2)。
- **时序交互类**: 刻画系统组件间的协作、调用链与消息传递 (sequenceDiagram)。
- **结构建模类**: 描述系统架构、数据模型、组织关系 (erDiagram, classDiagram, architecture)。
- **计划与追踪类**: 专注于时间维度、进度管理及任务分配 (gantt, kanban, timeline)。
- **多维认知类**: 用于发散性思维梳理、体验感知分析及比例展示 (mindmap, journey, pie)。

### 公共事项及说明 (Common Instructions)
1. **纯净 DSL 范式**: AI 必须生成纯文本 DSL 指令。严禁将代码块包裹在 JSON 结构中或附加冗余解释。
2. **符号冲突防御**: 在中文描述文字中，必须优先使用中文全角标点（如 ，、；、：）。严禁在未经过 "" 或 [] 包裹的文本中出现半角逗号 , 或分号 ;，以防止被解析器误认为语法分隔符。
3. **复杂内容包裹**: 凡是包含空格、特殊符号或多行文本的节点，必须使用 ["内容"]（矩形）、("内容")（圆角）或 {{ "内容" }}（六角）进行显式包裹。

### 分类图表注意事项 (Diagram-Specific Precautions)
| 图表类型 | 核心约束与避坑指南 |
| :--- | :--- |
| **甘特图 (Gantt)** | **缩放防御**: 若当前日期不在项目周期内，必须强制设置 todayMarker off，否则时间轴会被无限拉伸导致图例不可见。 |
| **状态图 (State)** | **语义固化**: 必须采用 state "描述文本" as 别名 语法。严禁直接在转移连线上书写过于复杂的逻辑描述。 |
| **架构图 (Architecture)** | **拓扑语法**: 连线方向必须遵循 源节点:方向 --> 方向:目标节点（如 gateway:R --> L:auth）。Label 建议优先使用英文。 |
| **需求图 (Requirement)** | **关系严谨**: 关系连接必须带箭头（如 - satisfies ->）。验证方法必须使用关键字 verifyMethod。 |
| **实验性图表 (Beta)** | **引号强制**: 在 sankey-beta, quadrantChart, block-beta, xychart-beta 中，所有中文标签必须用双引号 "" 包裹。 |
| **桑基图 (Sankey)** | **语言退避**: 当前版本 sankey-beta 解析器对非 ASCII 字符极其敏感，建议强制使用英文标注以确保渲染成功。 |

### 全量图表关键字定义
| 分类 | 关键字 | 典型语法结构 |
| :--- | :--- | :--- |
| **流程图** | `graph` / `flowchart` | `A[节点] --> B{判断}` |
| **时序图** | `sequenceDiagram` | `Alice ->> Bob: 消息` |
| **甘特图** | `gantt` | `section [阶段]\n 任务 :a1, 2024-01-01, 5d` |
| **状态图** | `stateDiagram-v2` | `[*] --> State1\n State1 --> [*]` |
| **类图** | `classDiagram` | `class A { +attr }` |
| **饼图** | `pie` | `title [标题]\n "项" : 50` |
| **ER图** | `erDiagram` | `ENTITY ||--o{ OTHER : rel` |
| **旅程图** | `journey` | `section [阶段]\n 步骤: 5: [角色]` |
| **思维导图** | `mindmap` | `root(("中心"))\n  分支` |
| **时间线** | `timeline` | `2024 : [事件]` |
| **看板图** | `kanban` | `[列名]\n  [事项] @{ assigned: "人" }` |
| **架构图** | `architecture` | `group 组名\n service 服务名` |

### 视觉初始化指令 (Directives)
使用 `%%{init: {...}}%%` 定义全局风格：
- `theme`: `default`, `forest`, `dark`, `neutral`, `base`。
- `look`: `handDrawn` (手绘效果)。
- `layout`: `elk` (针对复杂大图的算法优化)。

### 官方示例
```
N/A
```

---
## 思维导图 (mindmap)
- **适用场景**: 基于 Mermaid 的发散性思维梳理工具。通过中心节点放射出的层级结构，快速理清逻辑架构。
### 专家灵魂 (The Soul)
- **核心分类**: 多维认知类图表。用于非线性的思维发散与归纳。

### 全量图表关键字定义
- `mindmap`: 定义脑图起始。
- `root(("中心"))`: 双括号代表圆角容器。
- `(分支)` / `{{ 六角 }}` / `[矩形]`: 节点边界语法。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "neutral"}}%%` 样式渲染。

### 官方示例
```
%%{init: {"theme": "neutral"}}%%
mindmap
  root(("质量管理"))
    控制方法
      (SPC 统计)
      (异常拦截)
    标准体系
      (ISO 9001)
      (行业标准)
```

---
## 报文解析图 (packet-beta)
- **适用场景**: 基于 Mermaid 的报文协议可视化工具。用于精确刻画比特位偏移、字段宽度及报文协议头结构。
### 专家灵魂 (The Soul)
- **核心分类**: 报文协议解析类。专注于底层通信数据结构的精确位图展示。

### 全量图表关键字定义
- `packet-beta`: 定义报文图起始。
- `[Start]-[End]: "Label"`: 定义位偏移量及字段名称（例：`0-7: "Type"`）。

### 官方示例
```
packet-beta
    0-7: "版本号"
    8-15: "类型"
    16-31: "校验和"
    32-63: "偏移量"
```

---
## 极简饼图 (pie)
- **适用场景**: 基于 Mermaid 的极简数据比例展示工具。适用于文档内快速插入，对非工业级高精场景的补充。
### 专家灵魂 (The Soul)
- **核心分类**: 辅助类图表。仅当用户明确要求使用 Mermaid 或“极简”风格时使用。**常规占比分析首选 VChart——SVG 饼图**。

### 公共事项及说明 (Common Instructions)
1. **标题策略**: 必须在 `pie` 关键字后显式跟随 `title [标题]`。
2. **数值约束**: 建议项数不超过 8 个。

### 全量图表关键字定义
- `pie`: 定义饼图起始。
- `title [标题内容]`: 设置标题。
- `"项名" : 数值`: 数据项定义语法 (项名必须用双引号包裹)。

### 官方示例
```
%%{init: {"theme": "neutral"}}%%
pie title 缺陷原因分布
    "物流损坏" : 45
    "品质瑕疵" : 30
    "包装问题" : 15
    "其他" : 10
```

---
## 四象限分析图 (quadrantChart)
- **适用场景**: 基于 Mermaid 的多维评估工具。通过 X/Y 轴构建四个维度象限，快速定位任务或对象的优先级。
### 专家灵魂 (The Soul)
- **核心分类**: 多维认知类图表。用于将事物按照两种维度的强弱划分为四个象限，辅助决策。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **引号强制**: 在 `quadrantChart` 中，**所有中文标签必须用双引号 "" 包裹**，否则会导致解析引擎挂起。

### 全量图表关键字定义
- `quadrantChart`: 定义象限图起始。
- `x-axis "Min" --> "Max"`: X 轴标签定义。
- `quadrant-1 "Label"`: 象限区域标注。
- `"Item": [x, y]`: 数据点定位语法。

### 官方示例
```
quadrantChart
    title "研发任务优先级"
    x-axis "低价值" --> "高价值"
    y-axis "难实现" --> "易实现"
    quadrant-1 "重点投入"
    quadrant-2 "长期规划"
    "任务A": [0.8, 0.9]
    "任务B": [0.2, 0.3]
```

---
## 需求建模图 (requirementDiagram)
- **适用场景**: 基于 Mermaid 的系统需求工程工具。定义需求条目、风险等级及验证方法，建立需求与实现的关联。
### 专家灵魂 (The Soul)
- **核心分类**: 系统需求建模类图表。专注于需求条目的结构化定义及其在物理系统中的闭环验证。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **关系严谨**: 关系连接必须带箭头（如 `- satisfies ->`）。
- **验证闭环**: 验证方法建议必须使用官方关键字 `verifyMethod`。

### 全量图表关键字定义
- `requirementDiagram`: 定义需求图起始。
- `requirement [Name] { id: text, risk: level }`: 需求定义块。
- `element [Name] { type: "Type" }`: 系统元素定义块。
- `element - satisfies -> requirement`: 关联关系定义。

### 官方示例
```
requirementDiagram
    requirement req_lock {
        id: 1.1
        text: "当速度超过20km/h时自动锁定车门"
        risk: medium
        verifyMethod: test
    }
    element actuator {
        type: "Actuator"
    }
    actuator - satisfies -> req_lock
```

---
## 桑基图 (sankey-beta)
- **适用场景**: 基于 Mermaid 的能量或价值流向可视化工具。展现系统内部的分配与转移逻辑。
### 专家灵魂 (The Soul)
- **核心分类**: 能量/价值流向类图表。用于展示流动量在不同节点间的分配关系。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **语言退避 (Critical)**: 当前版本 `sankey-beta` 解析器对非 ASCII 字符极其敏感。**强烈建议强制使用英文标注**以确保渲染成功，否则可能导致节点崩解。

### 全量图表关键字定义
- `sankey-beta`: 定义桑基图起始。
- `Source,Sink,Value`: 数据行定义语法。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "neutral"}}%%` 渲染样式。

### 官方示例
```
sankey-beta
    Agricultural,Fertilizer,150
    Agricultural,Irrigation,100
    Fertilizer,Crop,120
    Irrigation,Crop,80
```

---
## 时序图 (sequenceDiagram)
- **适用场景**: 基于 Mermaid 的时序交互建模工具。用于刻画系统组件间的协作、调用链与消息传递。
### 专家灵魂 (The Soul)
- **核心分类**: 时序交互类图表。专注于刻画参与者（Participants）之间的消息传递顺序与调用逻辑。

### 公共事项及说明 (Common Instructions)
1. **纯净 DSL 范式**: AI 必须生成纯文本 DSL 指令。严禁将代码块包裹在 JSON 结构中或附加冗余解释。
2. **符号冲突防御**: 中文描述必须优先使用全角标点，或用引号包裹。例：`Alice ->> Bob: "处理中，请稍候"`。
3. **角色定义**: 使用 `actor` 定义人工角色，`participant` 定义系统组件。

### 全量图表关键字定义
- `sequenceDiagram`: 定义时序图起始。
- `->>` (实线箭头) / `-->>` (虚线返回箭头)。
- `activate` / `deactivate`: 开启/关闭生命线。
- `loop` / `alt` / `opt`: 控制流结构。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "forest"}}%%` 进行森林风格渲染。

### 官方示例
```
%%{init: {"theme": "forest"}}%%
sequenceDiagram
    actor 用户
    participant Web as Web端
    participant Srv as 服务端
    
    用户 ->> Web: 点击登录
    Web ->> Srv: 发送鉴权请求
    Srv -->> Web: 返回 Token
    Web -->> 用户: 显示主界面
```

---
## 状态图 (stateDiagram-v2)
- **适用场景**: 基于 Mermaid 的系统状态建模工具。用于刻画对象的生命周期、状态演变及触发条件。
### 专家灵魂 (The Soul)
- **核心分类**: 逻辑流转类图表。专注于描述对象在不同触发条件下如何从一个状态转移到另一个状态。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **语义固化**: 必须采用 `state "描述文本" as 别名` 语法。严禁直接在转移连线上书写过于复杂的逻辑描述，以防渲染混乱。
- **闭环思维**: 必须包含起始状态 `[*]`。建议显式标注每一个终结状态 `[*]`。

### 全量图表关键字定义
- `stateDiagram-v2`: 定义状态图起始。
- `-->`: 定义状态转移。
- `[*]`: 定义起始/结束点。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "neutral"}}%%` 进行中性风格渲染。

### 官方示例
```
%%{init: {"theme": "neutral"}}%%
stateDiagram-v2
    state "待支付" as s1
    state "已支付" as s2
    state "待发货" as s3
    [*] --> s1
    s1 --> s2: 支付成功
    s2 --> s3
    s3 --> [*]
```

---
## 时间线 (timeline)
- **适用场景**: 基于 Mermaid 的时间轴呈现工具。用于展示产品迭代、历史事件及关键里程碑的线性演进。
### 专家灵魂 (The Soul)
- **核心分类**: 计划与追踪类图表。专注于以非刻度化的方式展示重要事件的先后顺序环境。

### 全量图表关键字定义
- `timeline`: 定义时间线起始。
- `title`: 设置标题。
- `2024 : [事件1] : [事件2]`: 时间段与事件定义语法。

### 初始化指令 (Directives)
使用 `%%{init: {"theme": "forest"}}%%` 进行森林工业风格渲染。

### 官方示例
```
%%{init: {"theme": "forest"}}%%
timeline
    title 平台产品迭代历程
    2023 : 1.0 版本
    2024 : 2.0 版本
    2025 : 3.0 版本
```

---
## 通用双轴图 (xychart-beta)
- **适用场景**: 基于 Mermaid 的通用组合图表。支持柱状与线状混合展示，适用于简单的趋势与对比分析。
### 专家灵魂 (The Soul)
- **核心分类**: 通过 XY 坐标系展示混合趋势。相比 VChart 混合图，XYChart 更强调在文档流中的快速直观输出。

### 分类图表注意事项 (Diagram-Specific Precautions)
- **引号强制**: 在 `xychart-beta` 中，**所有中文标签必须用双引号 "" 包裹**。

### 全量图表关键字定义
- `xychart-beta`: 定义图表起始。
- `x-axis ["L1", "L2"]`: X 轴离散标签。
- `bar [v1, v2]` / `line [v1, v2]`: 系列定义语法。

### 官方示例
```
xychart-beta
    title "季度产量趋势"
    x-axis ["Q1", "Q2", "Q3", "Q4"]
    y-axis "产量(Ton)" 0 --> 500
    bar [320, 410, 390, 450]
    line [300, 380, 420, 440]
```

---
