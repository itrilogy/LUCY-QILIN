# 科技项目图表资产骨架与降级模板库（Skeleton Library）

> 本文件供 `tech-enricher` 在制作科技项目图表资产时参考。
> 绘图时严格遵循 `references/tech_KB-ChartSpec.md` 的两轨机制：**优先通过 `[MCP_DISCOVER]`/`[MCP_CALL]` 调用环境绘图 MCP 获取图片地址；无匹配 MCP 时，架构/流程类使用 Mermaid（存为 `.md` 片段），定量统计/因果矩阵类使用 VChart——SVG（落盘 `.svg` 至 `03_Documentation_Build/assets/Charts/`）**，并在 `00_Meta_Config/MANIFEST_ASSETS.md` 挂账。

---

## 模板 1：系统架构与流程拓扑（Mermaid 降级示范）

**建议资产路径**: `03_Documentation_Build/assets/Charts/<prefix>_arch.md`

````markdown
<!-- CHART: arch-01 — 系统总体分层架构 -->
```mermaid
flowchart TB
    subgraph L1["接入与交互层"]
        A["统一门户"] --> B["权限与网关"]
    end
    subgraph L2["核心调度与服务层"]
        B --> C["规则路由引擎"]
        C --> D["多引擎分析服务"]
    end
    subgraph L3["数据与资产存储层"]
        D --> E[("结构化台账库")]
        D --> F["向量与文件资产仓"]
    end
```

> **技术解读（≥150字）**：图 X 展示了系统从接入层、核心调度层到资产存储层的三层解耦架构……（结合项目实测接口数、并发响应耗时等指标展开技术阐述，标注数据来源）。
````

---

## 模板 2：项目实施计划甘特图（Mermaid 降级示范）

**建议资产路径**: `03_Documentation_Build/assets/Charts/<prefix>_gantt.md`

````markdown
<!-- CHART: plan-01 — 项目研发实施计划 -->
```mermaid
gantt
    title 项目研发与验证里程碑计划
    dateFormat  YYYY-MM-DD
    todayMarker off
    section 阶段一：立项与架构设计
    需求调研与基线确认 :p1, 2026-01-10, 14d
    总体架构与接口评审 :p2, after p1, 14d
    section 阶段二：核心研发与联调
    核心引擎开发与单元测试 :d1, after p2, 30d
    全链路集成测试与调优 :d2, after d1, 21d
    section 阶段三：试点应用与结题
    试点运行与效果统计 :c1, after d2, 21d
    成果总结与档案归档 :a1, after c1, 14d
```

> **技术解读（≥150字）**：图 X 给出了项目三阶段研制周期安排与关键依赖链路……（补充实际考核节点与交付物对应说明）。
````

---

## 模板 3：性能对比与趋势分析（MCP 返图 / VChart——SVG 降级示范）

**建议资产路径**: `03_Documentation_Build/assets/Charts/<prefix>_kpi_bar.md`（若走降级轨，矢量图同步存为 `03_Documentation_Build/assets/Charts/<prefix>_kpi_bar.svg`）

````markdown
<!-- 若环境存在匹配绘图 MCP，调用 [MCP_CALL] 后替换为真实返回地址；无匹配 MCP 时生成自包含 SVG 并按下方相对路径挂载 -->
![核心指标实施前后对比](03_Documentation_Build/assets/Charts/<prefix>_kpi_bar.svg)

<!-- 若宿主自带 VChart 渲染器，可参照以下静态 VisActor VChart Spec 构造输入：
{
  "type": "bar",
  "data": [{ "values": [
    {"metric": "平均处理耗时(s)", "stage": "优化前", "val": 18.4},
    {"metric": "平均处理耗时(s)", "stage": "优化后", "val": 3.7},
    {"metric": "字段准确率(%)", "stage": "优化前", "val": 81.2},
    {"metric": "字段准确率(%)", "stage": "优化后", "val": 96.8}
  ]}],
  "xField": ["metric", "stage"], "yField": "val", "seriesField": "stage",
  "color": ["#ef4444", "#3b82f6"],
  "label": { "visible": true },
  "axes": [
    { "orient": "bottom", "label": { "visible": true } },
    { "orient": "left", "label": { "visible": true } }
  ],
  "legends": [{ "visible": true, "orient": "bottom" }]
}
-->

**实测数据核对表（按项目实测台账填写，严禁复制示例数字）**：
| 考核指标 | 优化前基准 | 优化后实测 | 改善幅度 | 测试样本数与条件 |
| :--- | :---: | :---: | :---: | :--- |
| `<指标 1>` | — | — | — | — |
| `<指标 2>` | — | — | — | — |

> **技术解读（≥150字）**：结合实验记录与实测数据说明指标变化机理、瓶颈消除过程及边界限制。
````

---

## 模板 4：根因分析鱼骨图与方案比选（MCP 返图 / VChart——SVG 降级示范）

**建议资产路径**: `03_Documentation_Build/assets/Charts/<prefix>_fishbone.md`（SVG 路径：`03_Documentation_Build/assets/Charts/<prefix>_fishbone.svg`）

````markdown
![项目关键技术瓶颈 5M1E 因果分析](03_Documentation_Build/assets/Charts/<prefix>_fishbone.svg)

> **技术解读（≥150字）**：围绕核心技术瓶颈，按人、机、料、法、环、测多维度逐层定位根因，说明与后续技术方案设计的直接映射关系。
````
