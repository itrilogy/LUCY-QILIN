# 基于报告质量的科技项目活动诊断报告 (tech_template_quality_diagnosis.md)

> **对应**: qc-lifecycle-manager `12_QC活动质量诊断报告/` — TOP10高频缺陷+规则系列分布+方法论成熟度+培训建议  
> **数据源**: `04_Audit_Review/09_问题增量池/` (规则维度 + 课题维度)  
> **消费方**: 培训组 / 创新中心

---

```markdown
# 基于报告质量的科技项目活动诊断报告
**批次周期**: {{batch_period}} | **诊断人**: {{expert_signature}}

---

## 一、评审结果整体画像

| 指标 | 数值 |
|:---|:---|
| 评审课题总数 | {{total_count}} |
| 特等奖（≥95分） | {{grade_s_count}}（{{grade_s_pct}}%） |
| 一等奖（85-94分） | {{grade_a_count}}（{{grade_a_pct}}%） |
| 二等奖（75-84分） | {{grade_b_count}}（{{grade_b_pct}}%） |
| 三等奖（60-74分） | {{grade_c_count}}（{{grade_c_pct}}%） |
| 不合格（<60分） | {{grade_d_count}}（{{grade_d_pct}}%） |
| 平均分 | {{avg_score}} |
| 平均每课题 CRITICAL 数 | {{avg_crit}} |
| 平均每课题 WARNING 数 | {{avg_warn}} |

## 二、高频缺陷 TOP 10

| 排名 | 规则ID(标签) | 缺陷类别 | 命中数 | 涉及课题数 | 方法论薄弱环节 |
|:---:|:---|:---|:---:|:---:|:---|
| 1 | {{top1_id}}({{top1_label}}) | {{top1_cat}} | {{top1_hit}} | {{top1_proj}} | {{top1_weakness}} |
| 2 | {{top2_id}}({{top2_label}}) | {{top2_cat}} | {{top2_hit}} | {{top2_proj}} | {{top2_weakness}} |
| ... | ... | ... | ... | ... | ... |
| 10 | {{top10_id}}({{top10_label}}) | {{top10_cat}} | {{top10_hit}} | {{top10_proj}} | {{top10_weakness}} |

## 三、按规则系列的缺陷分布

| 规则系列 | 范围 | 命中总数 | 占比 | 薄弱程度 |
|:---|:---|:---:|:---:|:---:|
| A 系列 | ATT编号与复用合规 (A01-A05) | {{a_hits}} | {{a_pct}}% | {{a_level}} |
| B 系列 | 内容完整性 (B01-B04) | {{b_hits}} | {{b_pct}}% | {{b_level}} |
| C 系列 | 段落标注与来源 (C01-C02) | {{c_hits}} | {{c_pct}}% | {{c_level}} |
| T 系列 | 技术审计 (T1-T5) | {{t_hits}} | {{t_pct}}% | {{t_level}} |
| E 系列 | 效益审计 (E1-E5) | {{e_hits}} | {{e_pct}}% | {{e_level}} |
| N 系列 | 叙事审计 (N1-N3) | {{n_hits}} | {{n_pct}}% | {{n_level}} |
| I 系列 | 创新审计 (I1-I2) | {{i_hits}} | {{i_pct}}% | {{i_level}} |

## 四、方法论成熟度评估

| 能力维度 | 当前水平 | 标杆水平 | 差距 | 培训优先级 |
|:---|:---:|:---:|:---|:---:|
| ATT 编号复用规范 | {{m_att}}/100 | 90 | {{gap_att}} | {{pri_att}} |
| 技术报告撰写深度 | {{m_tech}}/100 | 85 | {{gap_tech}} | {{pri_tech}} |
| 效益分析量化能力 | {{m_roi}}/100 | 80 | {{gap_roi}} | {{pri_roi}} |
| TRIZ 工具应用 | {{m_triz}}/100 | 75 | {{gap_triz}} | {{pri_triz}} |
| 图表规范与数据真实性 | {{m_chart}}/100 | 85 | {{gap_chart}} | {{pri_chart}} |

## 五、下一年度培训建议

1. **{{train_1_title}}**：{{train_1_detail}}（依据：{{train_1_basis}}）
2. **{{train_2_title}}**：{{train_2_detail}}（依据：{{train_2_basis}}）
3. **{{train_3_title}}**：{{train_3_detail}}（依据：{{train_3_basis}}）

---
**诊断人签章**: {{expert_signature}}
```
