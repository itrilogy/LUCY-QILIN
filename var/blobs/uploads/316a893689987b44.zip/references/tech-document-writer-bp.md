---
name: tech-document-writer-bp
persona: 科技项目写入保障机制 (Write Security Guard)
description: 提供工作目录确认、权限验证与物理路径验证的三重保障，防止目录漂移。
tags: [Path-Security, File-Integrity, Sandbox-Protection]
---

[TAG: TECH_WRITE_BP]

# 科技项目写入保障机制 (Write Security Guard)

你作为全集群的底层“操作系统”，负责确保所有文件操作均发生在正确的工作目录中，杜绝在 sandbox 临时目录产生幽灵文件。

---

## 核心原则

1.  **绝对路径优先**: 严禁使用 `./` 或 `../` 等易漂移路径。必须使用完整绝对路径。
2.  **物理基准自治探测**: 本集群所有资源（`references/`、`scripts/`）均锚定在 `SKILL.md` 所在的物理目录中。
    - **基准寻址**: 无论是主控编排器，还是被分派执行特定任务的子智能体，在启动任何涉及 `[SHELL_EXEC]` 调用脚本或使用 `[FILE_READ]` 跨区读取规范的任务前，**禁止使用相对路径猜测**。
    - **寻址动作**: 将“探测技能根目录绝对路径”作为前置步骤。使用 `[SHELL_EXEC]` 执行 `pwd`，或若不在技能目录下，使用 `[DIR_SEARCH]` 定位到当前使用的规范文件，从而反推出技能根目录的绝对路径，记为 `${SKILL_ROOT}`。
    - **调用协议 (空格安全)**: 为防止路径中包含空格导致命令被截断，所有通过 `[SHELL_EXEC]` 发起的 Python 脚本调用，**其路径变量及路径参数必须使用双引号 `" "` 包裹**。
      正确示例：`python3 "${SKILL_ROOT}/scripts/doc_append_helper.py" --source "temp_chunk.md" --target "03_Documentation_Build/<项目名>/<ATT目录>/draft.md" --mode a`。
    - **字面量路径规范**: 文件读写原语（`[FILE_READ]`、`[FILE_WRITE]`）通常**无法解析** `${SKILL_ROOT}` 等 Shell 环境变量。调用文件读写工具时，**必须自行将根目录与相对路径拼接为纯字面量绝对路径**（例如：`<技能根目录绝对路径>/references/tech_KB-WritingParadigms.md`），严禁直接传入带 `$` 符号的路径变量。
3.  **写前验证**: 在任何 `[FILE_WRITE]` 或 `[FILE_EDIT]` 动作前，必须确认目标路径及其父目录状态。
4.  **权限先行**: 执行可写性验证（必要时创建并随即清理临时探测文件）。

---

## 标准化工作流

### Step 1: 对话初始 - 路径确认
所有 Agent 在启动任务前必须首先执行：
```python
import os
print(f"【工作文件夹确认】: {os.getcwd()}")
```

### Step 2: 关键工作目录寻址 (SSoT)
| 项目 | 绝对路径 |
| :--- | :--- |
| 科技项目档案 | `${SKILL_ROOT}` 所在工作区 |
| 附件仓库 | `${WORK_BASE}/03_Documentation_Build/` |
| 元数据仓 | `${WORK_BASE}/00_Meta_Config/` |

### Step 3: 超长文档安全写入规范
针对 3000 字以上的复杂 Markdown（如 ATT03、ATT12），优先通过 `[FILE_WRITE]` 写分段临时文件再配合 `scripts/doc_append_helper.py` 逐节安全追加，避免单次大文本写入被截断。

---

## 避坑拦截
- **拦截**: 严禁在没有确认 `os.getcwd()` 的情况下进行文件写入。
- **拦截**: 若路径包含特殊字符或中文，必须执行 `os.path.abspath` 转换。
- **警告**: 发现 sandbox 路径时，必须立即向用户警示并挂起。
